================================================================================
NAGALAND ME EXPERTS PLUGIN — v0.1.0
The Foundation Build
================================================================================

This is the v0.1 plugin for Nagaland Me Experts marketplace.

WHAT IT DOES (v0.1):
- Creates 4 database tables (experts, categories, services, audit_log)
- Adds 3 custom user roles (nme_buyer, nme_expert, nme_moderator)
- Seeds 8 launch categories
- Provides expert registration form via shortcode
- Manages expert applications via admin dashboard
- Renders public expert profile pages at /expert/{name-slug}/
- Sends transactional emails on application/approval/rejection
- Logs all sensitive admin actions

WHAT IT DOES NOT DO YET (coming in v1.0):
- Payment processing (Razorpay Route)
- Service/gig creation by experts
- Order placement and lifecycle
- Escrow and auto-release
- Reviews and disputes
- In-platform messaging
- Refunds

================================================================================
INSTALLATION
================================================================================

METHOD A — WordPress admin (easiest)
1. Log in to experts.nagaland.me/wp-admin
2. Plugins → Add New → Upload Plugin
3. Choose nagaland-me-experts.zip → Install Now
4. Click "Activate"

METHOD B — Hostinger File Manager
1. Log in to Hostinger File Manager
2. Navigate to: experts.nagaland.me/wp-content/plugins/
3. Upload nagaland-me-experts.zip
4. Right-click → Extract
5. Delete the ZIP file
6. WP admin → Plugins → activate "Nagaland Me Experts"

================================================================================
WHAT HAPPENS ON ACTIVATION
================================================================================

1. 4 database tables are created (wp_nme_experts, wp_nme_categories, wp_nme_services, wp_nme_audit_log)
2. 8 categories are seeded
3. 3 user roles are added
4. 2 pages are auto-created if they don't exist:
   - "Become an Expert — Apply" (slug: expert-register)
   - "Browse Experts" (slug: experts)
5. URL rewrite rules are flushed for /expert/{slug}/ profile pages

================================================================================
SHORTCODES
================================================================================

[nme_expert_registration_form]
  - The full expert application form
  - Already added to the auto-created "expert-register" page
  - Can be added to any page

[nme_experts_directory]
  - Browse all approved experts in a grid
  - Already added to the auto-created "experts" page
  - Optional attributes: category="slug", limit="24"

[nme_featured_experts limit="6"]
  - Featured experts strip (alias for directory)

================================================================================
ADMIN PAGES
================================================================================

After activation, a new menu "NME Experts" appears in WordPress admin with:
  - Dashboard (stats overview)
  - Experts (pending/approved/rejected lists, detail pages, approve/reject buttons)
  - Categories (view the 8 launch categories)
  - Audit Log (last 100 sensitive actions)

================================================================================
ADDING THE REGISTRATION PAGE TO YOUR MENU
================================================================================

After activation:
1. WP Admin → Appearance → Menus
2. Add "Become an Expert — Apply" page to your Primary Menu
   OR update your existing /become-an-expert/ page from Batch 2 to add a button:
   <a href="/expert-register/" class="nme-btn nme-btn-gold">Apply Now</a>

================================================================================
IMPORTANT NOTES
================================================================================

1. The first thing you should do after activation is visit:
   experts.nagaland.me/wp-admin/admin.php?page=nagaland-me-experts
   to confirm the dashboard loads.

2. Test the registration flow by visiting:
   experts.nagaland.me/expert-register/
   Submit a test application and check that you can review it in the admin.

3. The Experts directory at /experts/ will be empty until you approve
   your first expert. Once approved, they appear in the directory and have
   a public profile at /expert/{their-name-slug}/

4. PAN, bank, and ID details are stored in the database for KYC purposes.
   These are NOT publicly visible — only admin users with the
   "nme_approve_experts" capability can see them.

5. The plugin coexists peacefully with other plugins. It uses its own
   table prefix (wp_nme_) and does not modify WordPress core tables.

================================================================================
TROUBLESHOOTING
================================================================================

Q: Activation fails or shows a fatal error
A: Check PHP version (requires 7.4+). Check error logs in Hostinger.

Q: Categories don't appear
A: Deactivate and reactivate the plugin to re-trigger the seeder.

Q: /expert/{name}/ URLs return 404
A: Go to Settings → Permalinks → click "Save Changes" to flush rewrite rules.

Q: Registration form doesn't submit
A: Check that the form is on a published page (not draft) and that
   the page contains [nme_expert_registration_form].

Q: Emails not arriving
A: Hostinger may need an SMTP plugin. Install "WP Mail SMTP" and
   configure it with your Hostinger email account.

================================================================================
WHAT'S NEXT — PLUGIN v1.0
================================================================================

Once Razorpay Route is approved and the plugin v0.1 is stable, we move to v1.0:
  - Service/gig creation wizard for experts
  - Razorpay Route checkout integration
  - Order pages with state machine
  - Delivery and approval flow
  - Auto-release cron job
  - Dispute system
  - Reviews
  - Buyer dashboard
  - Expert dashboard with earnings

================================================================================
END OF README
================================================================================
