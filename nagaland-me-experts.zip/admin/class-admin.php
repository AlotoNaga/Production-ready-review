<?php
/**
 * NME_Admin
 * WordPress admin interface for managing experts and the marketplace.
 *
 * v0.4.0 — adds:
 *   - "Expert Requests" submenu (change-request review queue)
 *   - Direct admin editors on the expert detail page for profile photo
 *     and bank account (bypass the OTP + review flow; every write is
 *     audit-logged).
 *   - Two new admin_post handlers: nme_admin_update_expert_photo and
 *     nme_admin_update_expert_bank.
 *   The submenu registration and inline editors are all safely guarded
 *   by class_exists( 'NME_Change_Requests' ) so the file remains usable
 *   if the companion class is missing.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class NME_Admin {

    public static function init() {
        add_action( 'admin_menu', array( __CLASS__, 'register_menu' ) );
        add_action( 'admin_post_nme_approve_expert', array( __CLASS__, 'handle_approve' ) );
        add_action( 'admin_post_nme_reject_expert', array( __CLASS__, 'handle_reject' ) );
        add_action( 'admin_post_nme_delete_application', array( __CLASS__, 'handle_delete_application' ) );
        add_action( 'admin_post_nme_mark_founding', array( __CLASS__, 'handle_mark_founding' ) );
        add_action( 'admin_post_nme_approve_kyc', array( __CLASS__, 'handle_approve_kyc' ) );
        add_action( 'admin_post_nme_reject_kyc', array( __CLASS__, 'handle_reject_kyc' ) );
        add_action( 'admin_post_nme_purge_kyc_docs', array( __CLASS__, 'handle_purge_kyc_docs' ) );

        // v0.4.0 — admin-direct editors (bypass expert-side OTP/approval; audit-logged)
        add_action( 'admin_post_nme_admin_update_expert_photo', array( __CLASS__, 'handle_admin_update_expert_photo' ) );
        add_action( 'admin_post_nme_admin_update_expert_bank',  array( __CLASS__, 'handle_admin_update_expert_bank' ) );

        // v0.5.0 — admin-direct postal address editor (Razorpay Route requires this)
        add_action( 'admin_post_nme_admin_update_expert_address', array( __CLASS__, 'handle_admin_update_expert_address' ) );

        // v0.6.0 — admin-direct PAN + ID-proof editor. Required because the
        // expert-side KYC form locks PAN once kyc_status is 'submitted' or
        // 'verified', but Razorpay Route may reject the PAN (duplicate PAN,
        // name mismatch, wrong entity type) and leave no way to correct it.
        add_action( 'admin_post_nme_admin_update_expert_kyc', array( __CLASS__, 'handle_admin_update_expert_kyc' ) );

        // v0.6.0 — admin-side KYC doc uploads. Mirrors NME_KYC's expert upload
        // endpoint but gated on the nme_approve_experts capability so support
        // staff can re-upload a corrected PAN card / ID proof on behalf of an
        // expert without going through the Media Library.
        add_action( 'wp_ajax_nme_admin_upload_kyc_doc', array( __CLASS__, 'handle_admin_upload_kyc_doc' ) );
    }

    /**
     * Register admin menu pages
     */
    public static function register_menu() {
        // Top-level menu
        add_menu_page(
            'Nagaland Me Experts',
            'NME Experts',
            'nme_approve_experts',
            'nagaland-me-experts',
            array( __CLASS__, 'render_dashboard' ),
            'dashicons-groups',
            30
        );

        // Submenu: Dashboard
        add_submenu_page(
            'nagaland-me-experts',
            'Dashboard',
            'Dashboard',
            'nme_approve_experts',
            'nagaland-me-experts',
            array( __CLASS__, 'render_dashboard' )
        );

        // Submenu: Experts
        add_submenu_page(
            'nagaland-me-experts',
            'Experts',
            'Experts',
            'nme_approve_experts',
            'nme-experts',
            array( __CLASS__, 'render_experts_list' )
        );

        // v0.4.0 — Submenu: Expert Requests (profile-photo / bank-account change review queue)
        if ( class_exists( 'NME_Change_Requests' ) ) {
            $pending_count = (int) NME_Change_Requests::count_pending_admin_queue();
            $label         = $pending_count > 0
                ? 'Expert Requests <span class="awaiting-mod" style="background:#d63638;color:#fff;border-radius:10px;padding:1px 8px;font-size:11px;margin-left:5px;">' . $pending_count . '</span>'
                : 'Expert Requests';
            add_submenu_page(
                'nagaland-me-experts',
                'Expert Requests',
                $label,
                apply_filters( 'nme_change_request_admin_cap', 'nme_approve_experts' ),
                'nme-change-requests',
                array( 'NME_Change_Requests', 'render_admin_queue' )
            );
        }

        // Submenu: Categories
        add_submenu_page(
            'nagaland-me-experts',
            'Categories',
            'Categories',
            'nme_approve_experts',
            'nme-categories',
            array( __CLASS__, 'render_categories' )
        );

        // Submenu: Audit Log
        add_submenu_page(
            'nagaland-me-experts',
            'Audit Log',
            'Audit Log',
            'nme_approve_experts',
            'nme-audit-log',
            array( __CLASS__, 'render_audit_log' )
        );
    }

    /**
     * Dashboard page
     */
    public static function render_dashboard() {
        $pending = NME_Experts::count_by_status( 'pending' );
        $approved = NME_Experts::count_by_status( 'approved' );
        $rejected = NME_Experts::count_by_status( 'rejected' );
        ?>
        <div class="wrap nme-admin">
            <h1>Nagaland Me Experts — Dashboard</h1>
            <p>Welcome to the marketplace command center. Manage experts, categories, and platform health from here.</p>

            <div class="nme-admin-stats">
                <div class="nme-stat-card nme-stat-pending">
                    <div class="nme-stat-num"><?php echo (int) $pending; ?></div>
                    <div class="nme-stat-label">Pending Applications</div>
                    <a href="<?php echo esc_url( admin_url( 'admin.php?page=nme-experts&status=pending' ) ); ?>" class="button button-primary">Review Now</a>
                </div>
                <div class="nme-stat-card nme-stat-approved">
                    <div class="nme-stat-num"><?php echo (int) $approved; ?></div>
                    <div class="nme-stat-label">Approved Experts</div>
                    <a href="<?php echo esc_url( admin_url( 'admin.php?page=nme-experts&status=approved' ) ); ?>" class="button">View All</a>
                </div>
                <div class="nme-stat-card nme-stat-rejected">
                    <div class="nme-stat-num"><?php echo (int) $rejected; ?></div>
                    <div class="nme-stat-label">Rejected</div>
                    <a href="<?php echo esc_url( admin_url( 'admin.php?page=nme-experts&status=rejected' ) ); ?>" class="button">View All</a>
                </div>
            </div>

            <div class="nme-admin-section">
                <h2>Quick Actions</h2>
                <p>
                    <a href="<?php echo esc_url( admin_url( 'admin.php?page=nme-experts&status=pending' ) ); ?>" class="button button-primary">Review Pending Applications</a>
                    &nbsp;
                    <a href="<?php echo esc_url( admin_url( 'admin.php?page=nme-categories' ) ); ?>" class="button">Manage Categories</a>
                    &nbsp;
                    <a href="<?php echo esc_url( admin_url( 'admin.php?page=nme-audit-log' ) ); ?>" class="button">View Audit Log</a>
                </p>
            </div>

            <div class="nme-admin-section">
                <h2>Plugin Status</h2>
                <p><strong>Version:</strong> <?php echo esc_html( NME_VERSION ); ?> (Foundation Build)</p>
                <p><strong>Phase:</strong> 0.1 — Pre-Razorpay (Registration & Profiles only)</p>
                <p>This version handles expert applications, profiles, and admin approval. Payment processing, orders, and disputes will be added in v1.0 once Razorpay Route is approved.</p>
            </div>
        </div>
        <?php
    }

    /**
     * Experts list page
     */
    public static function render_experts_list() {
        $status = isset( $_GET['status'] ) ? sanitize_text_field( $_GET['status'] ) : 'pending';
        $action = isset( $_GET['action'] ) ? sanitize_text_field( $_GET['action'] ) : '';
        $id     = isset( $_GET['id'] ) ? (int) $_GET['id'] : 0;

        if ( $action === 'view' && $id ) {
            self::render_expert_detail( $id );
            return;
        }

        $experts = NME_Experts::get_by_status( $status );
        ?>
        <div class="wrap nme-admin">
            <h1>Experts</h1>

            <?php if ( ! empty( $_GET['nme_reject_failed'] ) ) : ?>
                <div class="notice notice-error is-dismissible"><p>Could not reject the application. Please refresh and try again.</p></div>
            <?php endif; ?>
            <?php if ( ! empty( $_GET['nme_deleted'] ) ) :
                $with_user = ! empty( $_GET['nme_user_deleted'] );
            ?>
                <div class="notice notice-success is-dismissible"><p>
                    Application deleted.<?php echo $with_user ? ' The linked WordPress user account was also removed.' : ''; ?>
                </p></div>
            <?php endif; ?>
            <?php if ( ! empty( $_GET['nme_delete_failed'] ) ) : ?>
                <div class="notice notice-error is-dismissible"><p>Could not delete the application. Please try again.</p></div>
            <?php endif; ?>

            <ul class="subsubsub">
                <li><a href="?page=nme-experts&status=pending" <?php echo $status === 'pending' ? 'class="current"' : ''; ?>>Pending (<?php echo NME_Experts::count_by_status( 'pending' ); ?>)</a> |</li>
                <li><a href="?page=nme-experts&status=approved" <?php echo $status === 'approved' ? 'class="current"' : ''; ?>>Approved (<?php echo NME_Experts::count_by_status( 'approved' ); ?>)</a> |</li>
                <li><a href="?page=nme-experts&status=rejected" <?php echo $status === 'rejected' ? 'class="current"' : ''; ?>>Rejected (<?php echo NME_Experts::count_by_status( 'rejected' ); ?>)</a></li>
            </ul>

            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Category</th>
                        <th>District</th>
                        <th>Tier</th>
                        <th>Applied</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ( empty( $experts ) ) : ?>
                        <tr><td colspan="7" style="text-align: center; padding: 40px;">No experts found.</td></tr>
                    <?php else : ?>
                        <?php foreach ( $experts as $expert ) :
                            $category = NME_Categories::get_by_id( $expert->primary_category_id );
                        ?>
                            <?php
                                $resubmitted_at = isset( $expert->resubmitted_at ) ? $expert->resubmitted_at : null;
                                $is_resubmit    = ! empty( $resubmitted_at ) && $resubmitted_at !== '0000-00-00 00:00:00';
                            ?>
                            <tr>
                                <td><strong><?php echo esc_html( $expert->full_name ); ?></strong>
                                    <?php if ( $expert->is_founding_expert ) : ?>
                                        <span class="nme-founding">★ Founding</span>
                                    <?php endif; ?>
                                    <?php if ( $is_resubmit ) : ?>
                                        <span style="display:inline-block;margin-left:6px;padding:2px 8px;background:#DBEAFE;color:#1E40AF;border-radius:10px;font-size:11px;font-weight:600;" title="Resubmitted after rejection on <?php echo esc_attr( $resubmitted_at ); ?>">🔄 Resubmitted</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo esc_html( $expert->email ); ?></td>
                                <td><?php echo $category ? esc_html( $category->name ) : '—'; ?></td>
                                <td><?php echo esc_html( $expert->district ); ?></td>
                                <td><?php echo NME_Experts::get_tier_badge( $expert->tier ); ?></td>
                                <td><?php echo esc_html( date( 'd M Y', strtotime( $expert->applied_at ) ) ); ?></td>
                                <td>
                                    <a href="?page=nme-experts&action=view&id=<?php echo (int) $expert->id; ?>" class="button button-small">View</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php
    }

    /**
     * Expert detail page
     */
    public static function render_expert_detail( $id ) {
        $expert = NME_Experts::get( $id );
        if ( ! $expert ) {
            echo '<div class="wrap"><h1>Expert not found</h1></div>';
            return;
        }
        $category = NME_Categories::get_by_id( $expert->primary_category_id );
        ?>
        <div class="wrap nme-admin">
            <h1>
                <?php echo esc_html( $expert->full_name ); ?>
                <a href="?page=nme-experts" class="page-title-action">← Back to List</a>
            </h1>

            <div class="nme-detail-grid">
                <div class="nme-detail-main">
                    <div class="nme-detail-card">
                        <h2>Personal Information</h2>
                        <table class="form-table">
                            <tr><th>Full Name</th><td><?php echo esc_html( $expert->full_name ); ?></td></tr>
                            <tr><th>Email</th><td><?php echo esc_html( $expert->email ); ?></td></tr>
                            <tr><th>Phone</th><td><?php echo esc_html( $expert->phone ); ?></td></tr>
                            <tr><th>WhatsApp</th><td><?php echo esc_html( $expert->whatsapp ?: '—' ); ?></td></tr>
                            <tr><th>District</th><td><?php echo esc_html( $expert->district ); ?>, <?php echo esc_html( $expert->state ); ?></td></tr>
                            <tr><th>Languages</th><td><?php echo esc_html( $expert->languages ); ?></td></tr>
                            <tr><th>Years Experience</th><td><?php echo (int) $expert->years_experience; ?></td></tr>
                        </table>
                    </div>

                    <?php
                    // ============================================================
                    // Registered Address (Razorpay Route KYC)
                    // ------------------------------------------------------------
                    // Razorpay v2 /accounts rejects linked-account creation unless
                    // street1, street2, postal_code are non-empty. We surface the
                    // values inline and let an admin fill / correct them without
                    // needing the expert to resubmit anything.
                    // ============================================================
                    $addr_street  = isset( $expert->street_address ) ? $expert->street_address : '';
                    $addr_village = isset( $expert->village_locality ) ? $expert->village_locality : '';
                    $addr_pin     = isset( $expert->postal_code ) ? $expert->postal_code : '';
                    $addr_complete = ( $addr_street !== '' && $addr_village !== '' && preg_match( '/^\d{6}$/', (string) $addr_pin ) );
                    ?>
                    <div class="nme-detail-card">
                        <h2>Registered Address
                            <?php if ( $addr_complete ) : ?>
                                <span style="background:#F0FDF4;color:#065F46;padding:2px 10px;border-radius:999px;font-size:0.7em;font-weight:700;margin-left:8px;vertical-align:middle;">Complete</span>
                            <?php else : ?>
                                <span style="background:#FEF2F2;color:#991B1B;padding:2px 10px;border-radius:999px;font-size:0.7em;font-weight:700;margin-left:8px;vertical-align:middle;">Incomplete — blocks payouts</span>
                            <?php endif; ?>
                        </h2>
                        <p style="color:#6B7280;margin-top:-6px;">Used for Razorpay Route KYC. All three fields are required before a Linked Account can be created.</p>

                        <?php if ( isset( $_GET['address_updated'] ) ) : ?>
                            <div class="notice notice-success inline" style="margin:12px 0;"><p>Address updated.</p></div>
                        <?php endif; ?>
                        <?php if ( isset( $_GET['address_error'] ) ) : ?>
                            <div class="notice notice-error inline" style="margin:12px 0;"><p><?php echo esc_html( urldecode( $_GET['address_error'] ) ); ?></p></div>
                        <?php endif; ?>

                        <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                            <input type="hidden" name="action" value="nme_admin_update_expert_address">
                            <input type="hidden" name="expert_id" value="<?php echo (int) $expert->id; ?>">
                            <?php wp_nonce_field( 'nme_admin_update_expert_address_' . $expert->id ); ?>
                            <table class="form-table">
                                <tr>
                                    <th><label for="nme_street_address">Street Address *</label></th>
                                    <td><input type="text" id="nme_street_address" name="street_address" maxlength="160" required
                                        value="<?php echo esc_attr( $addr_street ); ?>"
                                        placeholder="House / building / lane"
                                        style="width:100%;max-width:480px;"></td>
                                </tr>
                                <tr>
                                    <th><label for="nme_village_locality">Village / Locality *</label></th>
                                    <td><input type="text" id="nme_village_locality" name="village_locality" maxlength="120" required
                                        value="<?php echo esc_attr( $addr_village ); ?>"
                                        placeholder="Village name or colony / ward"
                                        style="width:100%;max-width:480px;"></td>
                                </tr>
                                <tr>
                                    <th><label for="nme_postal_code">PIN Code *</label></th>
                                    <td><input type="text" id="nme_postal_code" name="postal_code"
                                        inputmode="numeric" pattern="\d{6}" maxlength="6" required
                                        value="<?php echo esc_attr( $addr_pin ); ?>"
                                        placeholder="797112"
                                        style="width:140px;letter-spacing:2px;">
                                        <p class="description">6 digits. Indian PIN code.</p></td>
                                </tr>
                            </table>
                            <p><button type="submit" class="button button-primary">Save Address</button></p>
                        </form>
                    </div>

                    <?php
                    // ============================================================
                    // Address change history — last 10 events from audit_log.
                    // Lets admins spot suspicious rapid-fire changes (potential
                    // account-takeover signal) at a glance without digging
                    // through the full audit log.
                    // ============================================================
                    global $wpdb;
                    $audit_table = NME_Database::table( 'audit_log' );
                    $address_events = $wpdb->get_results( $wpdb->prepare(
                        "SELECT action, details, created_at FROM {$audit_table}
                         WHERE object_type = %s AND object_id = %d
                         AND action IN (
                            'address_updated',
                            'address_cooldown_blocked',
                            'address_change_otp_sent',
                            'address_change_otp_delivery_failed',
                            'address_razorpay_sync_ok',
                            'address_razorpay_sync_failed',
                            'address_razorpay_sync_skipped'
                         )
                         ORDER BY created_at DESC LIMIT 10",
                        'expert',
                        (int) $expert->id
                    ) );
                    ?>
                    <div class="nme-detail-card">
                        <h2>Address change history
                            <span style="background:#F3F4F6;color:#374151;padding:2px 10px;border-radius:999px;font-size:0.7em;font-weight:700;margin-left:8px;vertical-align:middle;">Last 10 events</span>
                        </h2>
                        <p style="color:#6B7280;margin-top:-6px;">Self-service address updates, OTP sends, cooldown blocks, and Razorpay sync outcomes for this expert.</p>
                        <?php if ( empty( $address_events ) ) : ?>
                            <p style="color:#6B7280;font-style:italic;margin:12px 0 0;">No address-related events recorded yet.</p>
                        <?php else : ?>
                            <table class="widefat striped" style="margin-top:10px;">
                                <thead>
                                    <tr>
                                        <th style="width:170px;">When</th>
                                        <th>Event</th>
                                        <th>Details</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php
                                $event_labels = array(
                                    'address_updated'                    => array( 'label' => '✅ Address updated',           'color' => '#065F46', 'bg' => '#D1FAE5' ),
                                    'address_cooldown_blocked'           => array( 'label' => '⏳ Change blocked (cooldown)', 'color' => '#92400E', 'bg' => '#FEF3C7' ),
                                    'address_change_otp_sent'            => array( 'label' => '🔐 OTP sent',                   'color' => '#1E40AF', 'bg' => '#DBEAFE' ),
                                    'address_change_otp_delivery_failed' => array( 'label' => '⚠️ OTP delivery failed',        'color' => '#991B1B', 'bg' => '#FEE2E2' ),
                                    'address_razorpay_sync_ok'           => array( 'label' => '🔄 Razorpay synced',            'color' => '#065F46', 'bg' => '#D1FAE5' ),
                                    'address_razorpay_sync_failed'       => array( 'label' => '⚠️ Razorpay sync failed',       'color' => '#991B1B', 'bg' => '#FEE2E2' ),
                                    'address_razorpay_sync_skipped'      => array( 'label' => 'ℹ️ Razorpay sync skipped',      'color' => '#4B5563', 'bg' => '#E5E7EB' ),
                                );
                                foreach ( $address_events as $evt ) :
                                    $meta_decoded = $evt->details ? json_decode( (string) $evt->details, true ) : array();
                                    $el = $event_labels[ $evt->action ] ?? array( 'label' => esc_html( $evt->action ), 'color' => '#374151', 'bg' => '#F3F4F6' );

                                    // Compact details by event type.
                                    $details = '';
                                    if ( $evt->action === 'address_updated' && is_array( $meta_decoded ) ) {
                                        $new = $meta_decoded['new'] ?? array();
                                        if ( is_array( $new ) ) {
                                            $details = sprintf(
                                                '%s, %s · %s',
                                                esc_html( (string) ( $new['street_address']   ?? '' ) ),
                                                esc_html( (string) ( $new['village_locality'] ?? '' ) ),
                                                esc_html( (string) ( $new['postal_code']      ?? '' ) )
                                            );
                                        }
                                    } elseif ( $evt->action === 'address_razorpay_sync_failed' && is_array( $meta_decoded ) ) {
                                        $details = esc_html( (string) ( $meta_decoded['error'] ?? '' ) );
                                    } elseif ( $evt->action === 'address_cooldown_blocked' && is_array( $meta_decoded ) ) {
                                        $dr = (int) ( $meta_decoded['days_remaining'] ?? 0 );
                                        $details = esc_html( $dr . ' day' . ( $dr === 1 ? '' : 's' ) . ' remaining' );
                                    } elseif ( $evt->action === 'address_change_otp_sent' && is_array( $meta_decoded ) ) {
                                        $channels = array();
                                        if ( ! empty( $meta_decoded['email'] ) ) $channels[] = 'email';
                                        if ( ! empty( $meta_decoded['sms'] ) )   $channels[] = 'SMS';
                                        $details = esc_html( $channels ? implode( ' + ', $channels ) : 'no channel delivered' );
                                    }
                                ?>
                                    <tr>
                                        <td><?php echo esc_html( mysql2date( 'd M Y H:i', $evt->created_at ) ); ?></td>
                                        <td><span style="background:<?php echo esc_attr( $el['bg'] ); ?>;color:<?php echo esc_attr( $el['color'] ); ?>;padding:2px 10px;border-radius:999px;font-size:0.8em;font-weight:600;white-space:nowrap;"><?php echo $el['label']; // label is a small allow-listed string literal from $event_labels ?></span></td>
                                        <td style="color:#4B5563;font-size:0.9em;"><?php echo $details ?: '&mdash;'; ?></td>
                                    </tr>
                                <?php endforeach; ?>
                                </tbody>
                            </table>
                        <?php endif; ?>
                    </div>

                    <div class="nme-detail-card">
                        <h2>Expertise</h2>
                        <table class="form-table">
                            <tr><th>Category</th><td><?php echo $category ? esc_html( $category->name ) : '—'; ?></td></tr>
                            <tr><th>Tagline</th><td><?php echo esc_html( $expert->tagline ?: '—' ); ?></td></tr>
                            <tr><th>Bio</th><td><?php echo nl2br( esc_html( $expert->bio ) ); ?></td></tr>
                        </table>
                    </div>

                    <div class="nme-detail-card">
                        <h2>Portfolio & Channels</h2>
                        <table class="form-table">
                            <tr><th>Portfolio</th><td><?php echo $expert->portfolio_url ? '<a href="' . esc_url( $expert->portfolio_url ) . '" target="_blank">' . esc_html( $expert->portfolio_url ) . '</a>' : '—'; ?></td></tr>
                            <tr><th>YouTube</th><td><?php echo $expert->youtube_channel ? '<a href="' . esc_url( $expert->youtube_channel ) . '" target="_blank">' . esc_html( $expert->youtube_channel ) . '</a>' : '—'; ?></td></tr>
                            <tr><th>Facebook</th><td><?php echo $expert->facebook_page ? '<a href="' . esc_url( $expert->facebook_page ) . '" target="_blank">' . esc_html( $expert->facebook_page ) . '</a>' : '—'; ?></td></tr>
                        </table>
                    </div>

                    <div class="nme-detail-card">
                        <h2>🛡️ KYC Verification</h2>
                        <?php
                        $kyc_status = $expert->kyc_status ?? 'not_started';
                        $kyc_colors = array(
                            'not_started' => array( 'bg' => '#FFFBEB', 'color' => '#92400E', 'label' => 'Not Started' ),
                            'submitted'   => array( 'bg' => '#EFF6FF', 'color' => '#1E40AF', 'label' => 'Submitted — Needs Review' ),
                            'verified'    => array( 'bg' => '#F0FDF4', 'color' => '#065F46', 'label' => 'Verified ✅' ),
                            'rejected'    => array( 'bg' => '#FEF2F2', 'color' => '#991B1B', 'label' => 'Rejected ❌' ),
                        );
                        $kc = $kyc_colors[ $kyc_status ] ?? $kyc_colors['not_started'];
                        ?>
                        <div style="background:<?php echo $kc['bg']; ?>;color:<?php echo $kc['color']; ?>;padding:12px 16px;border-radius:8px;font-weight:700;margin-bottom:16px;">
                            KYC Status: <?php echo esc_html( $kc['label'] ); ?>
                        </div>

                        <?php if ( isset( $_GET['kyc_updated'] ) ) : ?>
                            <div class="notice notice-success inline" style="margin:0 0 12px;"><p>KYC record updated. The expert has been emailed a before/after summary.</p></div>
                        <?php endif; ?>
                        <?php if ( isset( $_GET['kyc_error'] ) ) : ?>
                            <div class="notice notice-error inline" style="margin:0 0 12px;"><p><?php echo esc_html( urldecode( $_GET['kyc_error'] ) ); ?></p></div>
                        <?php endif; ?>

                        <?php if ( $kyc_status === 'not_started' ) : ?>
                            <p style="color:#6B7280;">Expert has not submitted KYC documents yet.</p>

                        <?php else : ?>
                            <table class="form-table">
                                <tr><th>PAN Number</th><td><code style="font-size:1.1em;letter-spacing:1px;"><?php echo esc_html( $expert->pan_number ?? '—' ); ?></code></td></tr>
                                <tr><th>ID Type</th><td><?php echo esc_html( ucwords( str_replace( '_', ' ', $expert->id_proof_type ?? '—' ) ) ); ?></td></tr>
                                <?php if ( ! empty( $expert->kyc_submitted_at ) ) : ?>
                                    <tr><th>Submitted</th><td><?php echo esc_html( date( 'd M Y H:i', strtotime( $expert->kyc_submitted_at ) ) ); ?></td></tr>
                                <?php endif; ?>
                                <?php if ( $kyc_status === 'verified' && ! empty( $expert->kyc_verified_at ) ) : ?>
                                    <tr><th>Verified On</th><td><?php echo esc_html( date( 'd M Y H:i', strtotime( $expert->kyc_verified_at ) ) ); ?></td></tr>
                                <?php endif; ?>
                            </table>

                            <!-- Document previews -->
                            <?php $front = $expert->id_proof_url ?? ''; $back = $expert->id_proof_back_url ?? ''; ?>
                            <?php if ( $front || $back ) : ?>
                                <h3 style="margin-top:20px;">ID Documents</h3>
                                <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:16px;">
                                    <?php if ( $front ) : ?>
                                        <div>
                                            <label style="font-weight:600;color:#374151;display:block;margin-bottom:6px;">Front Side</label>
                                            <a href="<?php echo esc_url( $front ); ?>" target="_blank">
                                                <img src="<?php echo esc_url( $front ); ?>" style="width:100%;border-radius:8px;border:2px solid #E5E7EB;" alt="ID Front">
                                            </a>
                                        </div>
                                    <?php endif; ?>
                                    <?php if ( $back ) : ?>
                                        <div>
                                            <label style="font-weight:600;color:#374151;display:block;margin-bottom:6px;">Back Side</label>
                                            <a href="<?php echo esc_url( $back ); ?>" target="_blank">
                                                <img src="<?php echo esc_url( $back ); ?>" style="width:100%;border-radius:8px;border:2px solid #E5E7EB;" alt="ID Back">
                                            </a>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            <?php elseif ( $kyc_status === 'verified' ) : ?>
                                <p style="color:#065F46;background:#F0FDF4;padding:12px;border-radius:8px;">🗑️ Documents were purged after verification (privacy policy).</p>
                            <?php endif; ?>

                            <!-- KYC Action Buttons -->
                            <?php if ( $kyc_status === 'submitted' ) : ?>
                                <div style="display:flex;gap:12px;margin-top:16px;flex-wrap:wrap;">
                                    <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="flex:1;">
                                        <input type="hidden" name="action" value="nme_approve_kyc">
                                        <input type="hidden" name="expert_id" value="<?php echo (int) $expert->id; ?>">
                                        <?php wp_nonce_field( 'nme_approve_kyc_' . $expert->id ); ?>
                                        <button type="submit" class="button button-primary" style="width:100%;padding:10px;" onclick="return confirm('Approve KYC for <?php echo esc_js( $expert->full_name ); ?>? This confirms their identity is verified.');">
                                            ✅ Approve KYC
                                        </button>
                                    </form>
                                    <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="flex:1;">
                                        <input type="hidden" name="action" value="nme_reject_kyc">
                                        <input type="hidden" name="expert_id" value="<?php echo (int) $expert->id; ?>">
                                        <?php wp_nonce_field( 'nme_reject_kyc_' . $expert->id ); ?>
                                        <textarea name="kyc_reason" placeholder="Reason for rejection (shown to expert)" style="width:100%;margin-bottom:8px;" rows="2"></textarea>
                                        <button type="submit" class="button" style="width:100%;color:#991B1B;">
                                            ❌ Reject KYC
                                        </button>
                                    </form>
                                </div>
                            <?php endif; ?>

                            <?php if ( $kyc_status === 'verified' && ( $front || $back ) ) : ?>
                                <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin-top:16px;">
                                    <input type="hidden" name="action" value="nme_purge_kyc_docs">
                                    <input type="hidden" name="expert_id" value="<?php echo (int) $expert->id; ?>">
                                    <?php wp_nonce_field( 'nme_purge_kyc_' . $expert->id ); ?>
                                    <button type="submit" class="button" style="color:#991B1B;" onclick="return confirm('Delete KYC document images permanently? The verification record will be kept but the actual document images will be removed for privacy.');">
                                        🗑️ Purge Documents (Privacy)
                                    </button>
                                    <p style="font-size:0.85rem;color:#6B7280;margin-top:6px;">Removes document images after verification. KYC verified status is preserved.</p>
                                </form>
                            <?php endif; ?>

                            <?php
                            // v0.6.0 — Admin-direct PAN + ID-proof edit.
                            $current_pan      = (string) ( $expert->pan_number ?? '' );
                            $current_id_type  = (string) ( $expert->id_proof_type ?? '' );
                            $current_pan_card = (string) ( $expert->pan_card_url ?? '' );
                            $id_types = array(
                                'aadhaar'         => 'Aadhaar Card',
                                'voter_id'        => 'Voter ID',
                                'passport'        => 'Passport',
                                'driving_license' => 'Driving License',
                            );
                            $admin_kyc_upload_nonce = wp_create_nonce( 'nme_admin_upload_kyc_doc' );
                            // Inline tile renderer — identical UX to expert-side upload widget
                            // but with expert-id-scoped DOM ids so multiple expert forms on
                            // a single admin page don't collide.
                            $render_admin_upload_tile = function( $field, $url, $label ) use ( $expert ) {
                                $fid = 'nme-admin-' . str_replace( '_', '-', $field ) . '-' . (int) $expert->id;
                                ob_start(); ?>
                                <div class="nme-admin-kyc-uploader" id="<?php echo esc_attr( $fid ); ?>-tile"
                                     data-field="<?php echo esc_attr( $field ); ?>"
                                     data-expert="<?php echo (int) $expert->id; ?>"
                                     style="border:2px dashed #D1D5DB;border-radius:10px;padding:14px;text-align:center;background:#F9FAFB;cursor:pointer;margin:4px 0;">
                                    <div class="tile-preview" style="<?php echo $url ? '' : 'display:none;'; ?>margin-bottom:8px;">
                                        <?php if ( $url ) : ?>
                                            <img src="<?php echo esc_url( $url ); ?>" style="max-width:100%;max-height:160px;border-radius:6px;border:1px solid #E5E7EB;" alt="">
                                        <?php endif; ?>
                                    </div>
                                    <div class="tile-prompt" style="<?php echo $url ? 'display:none;' : ''; ?>">
                                        <div style="font-size:1.6rem;">📄</div>
                                        <div style="font-weight:600;color:#374151;font-size:0.9rem;"><?php echo esc_html( $label ); ?></div>
                                        <div style="color:#9CA3AF;font-size:0.75rem;margin-top:2px;">Drag &amp; drop, or click to choose · JPG / PNG / PDF · max 5MB</div>
                                    </div>
                                    <div class="tile-actions" style="<?php echo $url ? '' : 'display:none;'; ?>margin-top:6px;">
                                        <button type="button" class="button tile-replace" style="font-size:0.8rem;">🔄 Replace</button>
                                        <button type="button" class="button tile-remove" style="font-size:0.8rem;color:#991B1B;">🗑️ Remove</button>
                                    </div>
                                    <div class="tile-progress" style="display:none;margin-top:8px;">
                                        <div style="background:#E5E7EB;border-radius:4px;height:4px;overflow:hidden;">
                                            <div class="tile-bar" style="background:#10B981;height:100%;width:0%;transition:width 0.3s;"></div>
                                        </div>
                                        <small style="color:#6B7280;">Uploading…</small>
                                    </div>
                                    <div class="tile-error" style="display:none;margin-top:8px;color:#991B1B;background:#FEE2E2;padding:6px;border-radius:4px;font-size:0.8rem;"></div>
                                </div>
                                <input type="file" class="nme-admin-kyc-file-input" data-field-for="<?php echo esc_attr( $fid ); ?>"
                                       accept="image/jpeg,image/png,application/pdf" style="display:none;">
                                <?php
                                return ob_get_clean();
                            };
                            ?>
                            <details style="margin-top:16px;">
                                <summary style="cursor:pointer;color:#2271b1;font-weight:600;">✏️ Edit PAN &amp; ID proof (admin override)</summary>
                                <div style="margin-top:12px;background:#FEF3C7;border-left:4px solid #F59E0B;padding:14px;border-radius:6px;">
                                    <p style="margin:0 0 10px;color:#92400E;font-size:0.9em;"><strong>Use with care.</strong> PAN changes are sent to Razorpay Route. If a Linked Account already exists for this expert, changing the PAN here will mark it as needing re-creation (Razorpay doesn't allow PAN updates on live linked accounts). Every write is audit-logged and the expert is emailed.</p>
                                    <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" id="nme-admin-kyc-form-<?php echo (int) $expert->id; ?>">
                                        <input type="hidden" name="action" value="nme_admin_update_expert_kyc">
                                        <input type="hidden" name="expert_id" value="<?php echo (int) $expert->id; ?>">
                                        <?php wp_nonce_field( 'nme_admin_update_expert_kyc_' . $expert->id ); ?>
                                        <table class="form-table">
                                            <tr><th>Current PAN on file</th>
                                                <td><code style="font-size:1.05em;letter-spacing:1px;"><?php echo esc_html( $current_pan ?: '—' ); ?></code></td></tr>
                                            <tr><th><label for="nme-admin-pan1-<?php echo (int) $expert->id; ?>">New PAN</label></th>
                                                <td>
                                                    <input type="text" id="nme-admin-pan1-<?php echo (int) $expert->id; ?>" name="pan_number" value="" class="regular-text" style="text-transform:uppercase;letter-spacing:2px;font-family:monospace;" maxlength="10" pattern="[A-Za-z]{5}[0-9]{4}[A-Za-z]{1}" placeholder="ABCDE1234F" autocomplete="off" required>
                                                    <p class="description">10 characters: 5 letters, 4 digits, 1 letter. 4th character must be <code>P</code> for an individual.</p>
                                                </td></tr>
                                            <tr><th><label for="nme-admin-pan2-<?php echo (int) $expert->id; ?>">Confirm PAN</label></th>
                                                <td>
                                                    <input type="text" id="nme-admin-pan2-<?php echo (int) $expert->id; ?>" name="pan_number_confirm" value="" class="regular-text" style="text-transform:uppercase;letter-spacing:2px;font-family:monospace;" maxlength="10" pattern="[A-Za-z]{5}[0-9]{4}[A-Za-z]{1}" placeholder="Re-type exactly" autocomplete="off" required>
                                                    <p class="description" id="nme-admin-pan-match-<?php echo (int) $expert->id; ?>" style="color:#6B7280;">Both PAN fields must match before saving.</p>
                                                </td></tr>
                                            <tr><th>PAN card photo</th>
                                                <td>
                                                    <?php echo $render_admin_upload_tile( 'pan_card', $current_pan_card, 'Upload PAN card' ); ?>
                                                    <input type="hidden" name="pan_card_url" id="nme-admin-pan-card-url-<?php echo (int) $expert->id; ?>" value="<?php echo esc_attr( $current_pan_card ); ?>">
                                                    <p class="description">Photo is deleted after verification — only the PAN number is retained.</p>
                                                </td></tr>
                                            <tr><th><label for="nme-admin-idtype-<?php echo (int) $expert->id; ?>">ID proof type</label></th>
                                                <td>
                                                    <select id="nme-admin-idtype-<?php echo (int) $expert->id; ?>" name="id_proof_type">
                                                        <option value="">— Keep current (<?php echo esc_html( $id_types[ $current_id_type ] ?? '—' ); ?>) —</option>
                                                        <?php foreach ( $id_types as $val => $label ) : ?>
                                                            <option value="<?php echo esc_attr( $val ); ?>"><?php echo esc_html( $label ); ?></option>
                                                        <?php endforeach; ?>
                                                    </select>
                                                </td></tr>
                                            <tr><th>ID proof — front</th>
                                                <td>
                                                    <?php echo $render_admin_upload_tile( 'id_proof_front', $front, 'Upload ID front side' ); ?>
                                                    <input type="hidden" name="id_proof_url" id="nme-admin-id-proof-front-url-<?php echo (int) $expert->id; ?>" value="<?php echo esc_attr( $front ); ?>">
                                                </td></tr>
                                            <tr><th>ID proof — back</th>
                                                <td>
                                                    <?php echo $render_admin_upload_tile( 'id_proof_back', $back, 'Upload ID back side' ); ?>
                                                    <input type="hidden" name="id_proof_back_url" id="nme-admin-id-proof-back-url-<?php echo (int) $expert->id; ?>" value="<?php echo esc_attr( $back ); ?>">
                                                </td></tr>
                                            <tr><th><label for="nme-admin-kyc-reason-<?php echo (int) $expert->id; ?>">Reason (required)</label></th>
                                                <td><textarea id="nme-admin-kyc-reason-<?php echo (int) $expert->id; ?>" name="reason" required rows="2" class="large-text" placeholder="Why this direct edit? (stored in audit log, shown to the expert in the notification email)"></textarea></td></tr>
                                        </table>
                                        <button type="submit" class="button button-primary">💾 Save KYC (admin override)</button>
                                    </form>
                                </div>
                            </details>
                            <script>
                            (function(){
                                var eid = <?php echo (int) $expert->id; ?>;
                                var form = document.getElementById('nme-admin-kyc-form-' + eid);
                                if ( ! form ) return;
                                var p1 = document.getElementById('nme-admin-pan1-' + eid);
                                var p2 = document.getElementById('nme-admin-pan2-' + eid);
                                var hint = document.getElementById('nme-admin-pan-match-' + eid);
                                var panRe = /^[A-Z]{5}[0-9]{4}[A-Z]$/;

                                function refresh() {
                                    var v1 = (p1.value || '').toUpperCase();
                                    var v2 = (p2.value || '').toUpperCase();
                                    p1.value = v1;
                                    p2.value = v2;
                                    if ( ! v1 || ! v2 ) {
                                        hint.style.color = '#6B7280';
                                        hint.textContent = 'Both PAN fields must match before saving.';
                                        return;
                                    }
                                    if ( v1 !== v2 ) {
                                        hint.style.color = '#991B1B';
                                        hint.textContent = '❌ PANs do not match.';
                                        return;
                                    }
                                    if ( ! panRe.test( v1 ) ) {
                                        hint.style.color = '#991B1B';
                                        hint.textContent = '❌ Format must be 5 letters, 4 digits, 1 letter (e.g. ABCDE1234F).';
                                        return;
                                    }
                                    if ( v1.charAt(3) !== 'P' ) {
                                        hint.style.color = '#B45309';
                                        hint.textContent = '⚠️ 4th character is "' + v1.charAt(3) + '" — not an individual PAN. Razorpay will reject unless business_type matches.';
                                        return;
                                    }
                                    hint.style.color = '#065F46';
                                    hint.textContent = '✓ Match — individual PAN format OK.';
                                }
                                p1.addEventListener('input', refresh);
                                p2.addEventListener('input', refresh);
                                form.addEventListener('submit', function(ev) {
                                    var v1 = (p1.value || '').toUpperCase();
                                    var v2 = (p2.value || '').toUpperCase();
                                    if ( v1 !== v2 || ! panRe.test( v1 ) ) {
                                        ev.preventDefault();
                                        alert('PAN fields do not match or format is invalid. Please fix before saving.');
                                        return false;
                                    }
                                    var msg = 'Confirm: set PAN for this expert to\n\n    ' + v1 + '\n\nThis will be sent to Razorpay on the next Linked Account creation.';
                                    if ( ! confirm(msg) ) { ev.preventDefault(); return false; }
                                });

                                // === Upload tiles (drag-drop + AJAX) ===
                                var ajaxUrl = '<?php echo esc_url_raw( admin_url( 'admin-ajax.php' ) ); ?>';
                                var uploadNonce = '<?php echo esc_js( $admin_kyc_upload_nonce ); ?>';
                                var expertId = eid;

                                document.querySelectorAll('#nme-admin-kyc-form-' + eid + ' + script, #nme-admin-kyc-form-' + eid).forEach(function(){});

                                // Scope to this expert's tiles only (other experts may share the page).
                                var formRoot = form.parentElement; // the .details > .div wrapper
                                formRoot.querySelectorAll('.nme-admin-kyc-uploader').forEach(function(tile) {
                                    var field   = tile.getAttribute('data-field');
                                    var fid     = tile.id.replace('-tile', '');
                                    var fileInp = formRoot.querySelector('.nme-admin-kyc-file-input[data-field-for="' + fid + '"]');
                                    var hidden  = document.getElementById(fid + '-url');
                                    var prev    = tile.querySelector('.tile-preview');
                                    var prompt  = tile.querySelector('.tile-prompt');
                                    var acts    = tile.querySelector('.tile-actions');
                                    var prog    = tile.querySelector('.tile-progress');
                                    var bar     = tile.querySelector('.tile-bar');
                                    var errBox  = tile.querySelector('.tile-error');
                                    var btnRep  = tile.querySelector('.tile-replace');
                                    var btnRm   = tile.querySelector('.tile-remove');

                                    function showUploaded(url) {
                                        prev.innerHTML = '<img src="' + url + '" style="max-width:100%;max-height:160px;border-radius:6px;border:1px solid #E5E7EB;">';
                                        prev.style.display = '';
                                        prompt.style.display = 'none';
                                        acts.style.display = '';
                                        prog.style.display = 'none';
                                        errBox.style.display = 'none';
                                        if ( hidden ) hidden.value = url;
                                    }
                                    function showErr(msg) {
                                        errBox.textContent = msg;
                                        errBox.style.display = '';
                                        prog.style.display = 'none';
                                    }
                                    function doUpload(file) {
                                        if ( ! file ) return;
                                        errBox.style.display = 'none';
                                        prog.style.display = '';
                                        bar.style.width = '0%';

                                        var fd = new FormData();
                                        fd.append('action', 'nme_admin_upload_kyc_doc');
                                        fd.append('nonce', uploadNonce);
                                        fd.append('field', field);
                                        fd.append('expert_id', expertId);
                                        fd.append('kyc_doc_file', file);

                                        var xhr = new XMLHttpRequest();
                                        xhr.upload.addEventListener('progress', function(e) {
                                            if ( e.lengthComputable ) bar.style.width = ( (e.loaded / e.total) * 100 ) + '%';
                                        });
                                        xhr.addEventListener('load', function() {
                                            try {
                                                var res = JSON.parse(xhr.responseText);
                                                if ( res.success && res.data && res.data.url ) showUploaded(res.data.url);
                                                else showErr( (res.data && res.data.message) || 'Upload failed.' );
                                            } catch (e) { showErr('Unexpected server response.'); }
                                        });
                                        xhr.addEventListener('error', function() { showErr('Network error. Try again.'); });
                                        xhr.open('POST', ajaxUrl);
                                        xhr.send(fd);
                                    }

                                    tile.addEventListener('click', function(e) {
                                        if ( e.target.closest('.tile-actions') ) return;
                                        fileInp.click();
                                    });
                                    if ( btnRep ) btnRep.addEventListener('click', function(e) { e.stopPropagation(); fileInp.click(); });
                                    if ( btnRm )  btnRm.addEventListener('click',  function(e) {
                                        e.stopPropagation();
                                        if ( ! confirm('Remove this document? The hidden URL will be cleared on next save.') ) return;
                                        prev.innerHTML = '';
                                        prev.style.display = 'none';
                                        prompt.style.display = '';
                                        acts.style.display = 'none';
                                        if ( hidden ) hidden.value = '';
                                    });
                                    fileInp.addEventListener('change', function() { doUpload(fileInp.files[0]); });

                                    ['dragover','dragleave','drop'].forEach(function(ev) {
                                        tile.addEventListener(ev, function(e) { e.preventDefault(); e.stopPropagation(); });
                                    });
                                    tile.addEventListener('dragover', function() { tile.style.borderColor = '#10B981'; tile.style.background = '#F0FDF4'; });
                                    tile.addEventListener('dragleave', function() { tile.style.borderColor = '#D1D5DB'; tile.style.background = '#F9FAFB'; });
                                    tile.addEventListener('drop', function(e) {
                                        tile.style.borderColor = '#D1D5DB'; tile.style.background = '#F9FAFB';
                                        if ( e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files.length ) doUpload(e.dataTransfer.files[0]);
                                    });
                                });
                            })();
                            </script>
                        <?php endif; ?>
                    </div>

                    <div class="nme-detail-card">
                        <h2>Payout Details</h2>
                        <table class="form-table">
                            <tr><th>Account Holder</th><td><?php echo esc_html( $expert->bank_account_holder ?: '—' ); ?></td></tr>
                            <tr><th>Account Number</th><td><code><?php echo esc_html( $expert->bank_account_number ?: '—' ); ?></code></td></tr>
                            <tr><th>IFSC</th><td><code><?php echo esc_html( $expert->bank_ifsc ?: '—' ); ?></code></td></tr>
                            <tr><th>UPI ID</th><td><code><?php echo esc_html( $expert->upi_id ?: '—' ); ?></code></td></tr>
                        </table>

                        <!-- v0.4.0 — Admin-direct bank edit (bypasses OTP/approval, audit-logged) -->
                        <details style="margin-top:16px;">
                            <summary style="cursor:pointer;color:#2271b1;font-weight:600;">✏️ Edit bank account (admin override)</summary>
                            <div style="margin-top:12px;background:#FEF3C7;border-left:4px solid #F59E0B;padding:14px;border-radius:6px;">
                                <p style="margin:0 0 10px;color:#92400E;font-size:0.9em;"><strong>Direct admin edit:</strong> bypasses the expert-side OTP + approval workflow. Use only when the expert cannot complete the self-service flow (e.g. lost phone). Every write is audit-logged.</p>
                                <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                                    <input type="hidden" name="action" value="nme_admin_update_expert_bank">
                                    <input type="hidden" name="expert_id" value="<?php echo (int) $expert->id; ?>">
                                    <?php wp_nonce_field( 'nme_admin_update_expert_bank_' . $expert->id ); ?>
                                    <table class="form-table">
                                        <tr><th><label for="nme-admin-bah-<?php echo (int) $expert->id; ?>">Account Holder</label></th>
                                            <td><input type="text" id="nme-admin-bah-<?php echo (int) $expert->id; ?>" name="bank_account_holder" value="<?php echo esc_attr( $expert->bank_account_holder ?: '' ); ?>" class="regular-text"></td></tr>
                                        <tr><th><label for="nme-admin-ban-<?php echo (int) $expert->id; ?>">Account Number</label></th>
                                            <td><input type="text" id="nme-admin-ban-<?php echo (int) $expert->id; ?>" name="bank_account_number" value="<?php echo esc_attr( $expert->bank_account_number ?: '' ); ?>" class="regular-text"></td></tr>
                                        <tr><th><label for="nme-admin-ifsc-<?php echo (int) $expert->id; ?>">IFSC</label></th>
                                            <td><input type="text" id="nme-admin-ifsc-<?php echo (int) $expert->id; ?>" name="bank_ifsc" value="<?php echo esc_attr( $expert->bank_ifsc ?: '' ); ?>" class="regular-text" style="text-transform:uppercase;" maxlength="11"></td></tr>
                                        <tr><th><label for="nme-admin-upi-<?php echo (int) $expert->id; ?>">UPI ID</label></th>
                                            <td><input type="text" id="nme-admin-upi-<?php echo (int) $expert->id; ?>" name="upi_id" value="<?php echo esc_attr( $expert->upi_id ?: '' ); ?>" class="regular-text"></td></tr>
                                        <tr><th><label for="nme-admin-bank-reason-<?php echo (int) $expert->id; ?>">Reason (required)</label></th>
                                            <td><textarea id="nme-admin-bank-reason-<?php echo (int) $expert->id; ?>" name="reason" required rows="2" class="large-text" placeholder="Why this direct edit? (stored in audit log)"></textarea></td></tr>
                                    </table>
                                    <button type="submit" class="button button-primary" onclick="return confirm('Save admin-direct bank-account edit for <?php echo esc_js( $expert->full_name ); ?>? This bypasses OTP/approval.');">💾 Save bank (admin override)</button>
                                </form>
                            </div>
                        </details>
                    </div>
                </div>

                <div class="nme-detail-sidebar">
                    <div class="nme-detail-card">
                        <h2>Status</h2>
                        <p><strong>Current:</strong> <span class="nme-status nme-status-<?php echo esc_attr( $expert->status ); ?>"><?php echo esc_html( ucfirst( $expert->status ) ); ?></span></p>
                        <p><strong>Tier:</strong> <?php echo NME_Experts::get_tier_badge( $expert->tier ); ?></p>
                        <p><strong>Applied:</strong> <?php echo esc_html( date( 'd M Y H:i', strtotime( $expert->applied_at ) ) ); ?></p>
                        <?php if ( $expert->approved_at ) : ?>
                            <p><strong>Approved:</strong> <?php echo esc_html( date( 'd M Y H:i', strtotime( $expert->approved_at ) ) ); ?></p>
                        <?php endif; ?>
                        <?php if ( $expert->is_founding_expert ) : ?>
                            <p><span class="nme-founding">★ Founding Expert</span></p>
                        <?php endif; ?>
                    </div>

                    <div class="nme-detail-card">
                        <h2>Profile Photo</h2>
                        <?php if ( $expert->profile_photo ) : ?>
                            <img src="<?php echo esc_url( $expert->profile_photo ); ?>" style="max-width: 100%; border-radius: 8px;">
                        <?php else : ?>
                            <p style="color:#6B7280;">No profile photo set.</p>
                        <?php endif; ?>

                        <!-- v0.4.0 — Admin-direct photo edit (resets 30-day cooldown, audit-logged) -->
                        <details style="margin-top:12px;">
                            <summary style="cursor:pointer;color:#2271b1;font-weight:600;font-size:0.9em;">✏️ Replace photo (admin override)</summary>
                            <div style="margin-top:10px;background:#FEF3C7;border-left:4px solid #F59E0B;padding:12px;border-radius:6px;">
                                <p style="margin:0 0 10px;color:#92400E;font-size:0.85em;">Bypasses the expert 30-day cooldown. Audit-logged.</p>
                                <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" enctype="multipart/form-data">
                                    <input type="hidden" name="action" value="nme_admin_update_expert_photo">
                                    <input type="hidden" name="expert_id" value="<?php echo (int) $expert->id; ?>">
                                    <?php wp_nonce_field( 'nme_admin_update_expert_photo_' . $expert->id ); ?>
                                    <p><input type="file" name="profile_photo" accept="image/jpeg,image/png,image/webp" required></p>
                                    <p><textarea name="reason" required rows="2" class="large-text" placeholder="Reason (stored in audit log)"></textarea></p>
                                    <button type="submit" class="button button-primary" onclick="return confirm('Upload new profile photo for <?php echo esc_js( $expert->full_name ); ?>? This bypasses the 30-day cooldown.');">⬆️ Upload new photo</button>
                                </form>
                            </div>
                        </details>
                    </div>

                    <div class="nme-detail-card">
                        <h2>Actions</h2>
                        <?php if ( $expert->status === 'pending' ) : ?>
                            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin-bottom: 12px;">
                                <input type="hidden" name="action" value="nme_approve_expert">
                                <input type="hidden" name="expert_id" value="<?php echo (int) $expert->id; ?>">
                                <?php wp_nonce_field( 'nme_approve_' . $expert->id ); ?>
                                <button type="submit" class="button button-primary" style="width: 100%;">✓ Approve Expert</button>
                            </form>

                            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin-bottom: 12px;">
                                <input type="hidden" name="action" value="nme_reject_expert">
                                <input type="hidden" name="expert_id" value="<?php echo (int) $expert->id; ?>">
                                <?php wp_nonce_field( 'nme_reject_' . $expert->id ); ?>
                                <textarea name="reason" placeholder="Reason for rejection (optional)" style="width: 100%; margin-bottom: 8px;"></textarea>
                                <button type="submit" class="button" style="width: 100%;">✗ Reject</button>
                            </form>
                        <?php endif; ?>

                        <?php if ( $expert->status === 'approved' && ! $expert->is_founding_expert ) : ?>
                            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                                <input type="hidden" name="action" value="nme_mark_founding">
                                <input type="hidden" name="expert_id" value="<?php echo (int) $expert->id; ?>">
                                <?php wp_nonce_field( 'nme_founding_' . $expert->id ); ?>
                                <button type="submit" class="button button-secondary" style="width: 100%;">★ Mark as Founding Expert</button>
                            </form>
                        <?php endif; ?>

                        <?php if ( $expert->status === 'approved' ) : ?>
                            <p style="margin-top: 12px;">
                                <a href="<?php echo esc_url( NME_Frontend::get_profile_url( $expert ) ); ?>" target="_blank" class="button" style="width: 100%; text-align: center;">View Public Profile</a>
                            </p>
                        <?php endif; ?>

                        <?php if ( $expert->status === 'rejected' ) :
                            // Hard-delete is only offered for rejected rows. A
                            // rejected applicant may still log in to resubmit,
                            // but if admin is certain the applicant will never
                            // come back (spam, obvious fraud, abandoned
                            // account), this button cleans up the row and
                            // optionally the WP user.
                        ?>
                            <details style="margin-top: 12px;">
                                <summary style="cursor: pointer; color: #B91C1C; font-weight: 600;">🗑️ Delete this rejected application</summary>
                                <form method="post"
                                      action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"
                                      style="margin-top: 10px; padding: 12px; background: #FEF2F2; border: 1px solid #FCA5A5; border-radius: 6px;"
                                      onsubmit="return confirm('Permanently delete this rejected application? This cannot be undone.');">
                                    <input type="hidden" name="action" value="nme_delete_application">
                                    <input type="hidden" name="expert_id" value="<?php echo (int) $expert->id; ?>">
                                    <?php wp_nonce_field( 'nme_delete_application_' . $expert->id ); ?>

                                    <p style="margin: 0 0 10px; font-size: 12px; color: #7F1D1D;">
                                        Removes the application row and its audit-visible history. The applicant will not be able to log in and edit/resubmit it.
                                    </p>

                                    <label style="display: block; margin-bottom: 10px; font-size: 12px; color: #7F1D1D;">
                                        <input type="checkbox" name="delete_wp_user" value="1" style="margin-right: 4px;">
                                        Also delete the WordPress user account (<code><?php echo esc_html( $expert->email ); ?></code>)
                                    </label>

                                    <button type="submit" class="button" style="width: 100%; background: #DC2626; color: #fff; border-color: #B91C1C;">
                                        Permanently delete
                                    </button>
                                </form>
                            </details>
                        <?php endif; ?>

                    </div>
                </div>
            </div>
        </div>
        <?php
    }

    /**
     * Categories management page
     */
    public static function render_categories() {
        $categories = NME_Categories::get_all();
        ?>
        <div class="wrap nme-admin">
            <h1>Categories</h1>
            <p>The 8 launch categories for Nagaland Me Experts. These are seeded automatically and used for expert specializations.</p>

            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th>Order</th>
                        <th>Icon</th>
                        <th>Name</th>
                        <th>Slug</th>
                        <th>Description</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ( $categories as $cat ) : ?>
                        <tr>
                            <td><?php echo (int) $cat->sort_order; ?></td>
                            <td style="font-size: 1.5rem;"><?php echo esc_html( $cat->icon ); ?></td>
                            <td><strong><?php echo esc_html( $cat->name ); ?></strong></td>
                            <td><code><?php echo esc_html( $cat->slug ); ?></code></td>
                            <td><?php echo esc_html( $cat->description ); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php
    }

    /**
     * Audit log page
     */
    public static function render_audit_log() {
        global $wpdb;
        $logs = $wpdb->get_results(
            "SELECT * FROM " . NME_Database::table( 'audit_log' ) . "
             ORDER BY created_at DESC LIMIT 100"
        );
        ?>
        <div class="wrap nme-admin">
            <h1>Audit Log</h1>
            <p>The last 100 sensitive actions on the platform.</p>

            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th>Time</th>
                        <th>User</th>
                        <th>Action</th>
                        <th>Object</th>
                        <th>Details</th>
                        <th>IP</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ( empty( $logs ) ) : ?>
                        <tr><td colspan="6" style="text-align: center;">No log entries yet.</td></tr>
                    <?php else : ?>
                        <?php foreach ( $logs as $log ) :
                            $user = $log->user_id ? get_user_by( 'id', $log->user_id ) : null;
                        ?>
                            <tr>
                                <td><?php echo esc_html( date( 'd M Y H:i', strtotime( $log->created_at ) ) ); ?></td>
                                <td><?php echo $user ? esc_html( $user->display_name ) : '—'; ?></td>
                                <td><code><?php echo esc_html( $log->action ); ?></code></td>
                                <td><?php echo esc_html( $log->object_type ); ?> #<?php echo (int) $log->object_id; ?></td>
                                <td><?php echo esc_html( $log->details ); ?></td>
                                <td><code><?php echo esc_html( $log->ip_address ); ?></code></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php
    }

    /**
     * Handle approve action
     */
    public static function handle_approve() {
        $expert_id = isset( $_POST['expert_id'] ) ? (int) $_POST['expert_id'] : 0;

        if ( ! current_user_can( 'nme_approve_experts' ) || ! wp_verify_nonce( $_POST['_wpnonce'], 'nme_approve_' . $expert_id ) ) {
            wp_die( 'Permission denied' );
        }

        NME_Experts::approve( $expert_id );
        wp_safe_redirect( admin_url( 'admin.php?page=nme-experts&action=view&id=' . $expert_id . '&approved=1' ) );
        exit;
    }

    /**
     * Handle reject action
     */
    public static function handle_reject() {
        $expert_id = isset( $_POST['expert_id'] ) ? (int) $_POST['expert_id'] : 0;
        $reason    = isset( $_POST['reason'] ) ? sanitize_textarea_field( $_POST['reason'] ) : '';

        if ( ! current_user_can( 'nme_approve_experts' ) || ! wp_verify_nonce( $_POST['_wpnonce'], 'nme_reject_' . $expert_id ) ) {
            wp_die( 'Permission denied' );
        }

        $ok = NME_Experts::reject( $expert_id, $reason );

        if ( $ok ) {
            $redirect = admin_url( 'admin.php?page=nme-experts&action=view&id=' . $expert_id . '&rejected=1' );
        } else {
            $redirect = add_query_arg(
                'nme_reject_failed',
                '1',
                admin_url( 'admin.php?page=nme-experts&status=pending' )
            );
        }

        wp_safe_redirect( $redirect );
        exit;
    }

    /**
     * Hard-delete a rejected application.
     * Gated on manage_options + per-id nonce. Status is re-checked server-side
     * to prevent accidentally wiping a pending or approved row if a stale form
     * is submitted. Optionally removes the linked WP user (NME_Experts::delete
     * itself refuses to delete site admin / current user / users who already
     * hold the nme_expert role).
     */
    public static function handle_delete_application() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( 'Permission denied', 403 );
        }

        $expert_id = isset( $_POST['expert_id'] ) ? (int) $_POST['expert_id'] : 0;
        check_admin_referer( 'nme_delete_application_' . $expert_id );

        $list_url = admin_url( 'admin.php?page=nme-experts&status=rejected' );

        $expert = NME_Experts::get( $expert_id );
        if ( ! $expert || $expert->status !== 'rejected' ) {
            wp_safe_redirect( add_query_arg( 'nme_delete_failed', '1', $list_url ) );
            exit;
        }

        $delete_wp_user = ! empty( $_POST['delete_wp_user'] );
        $ok = NME_Experts::delete( $expert_id, $delete_wp_user );

        if ( $ok ) {
            $list_url = add_query_arg( 'nme_deleted', '1', $list_url );
            if ( $delete_wp_user ) {
                $list_url = add_query_arg( 'nme_user_deleted', '1', $list_url );
            }
        } else {
            $list_url = add_query_arg( 'nme_delete_failed', '1', $list_url );
        }

        wp_safe_redirect( $list_url );
        exit;
    }

    /**
     * Mark as founding expert
     */
    public static function handle_mark_founding() {
        $expert_id = isset( $_POST['expert_id'] ) ? (int) $_POST['expert_id'] : 0;

        if ( ! current_user_can( 'nme_approve_experts' ) || ! wp_verify_nonce( $_POST['_wpnonce'], 'nme_founding_' . $expert_id ) ) {
            wp_die( 'Permission denied' );
        }

        NME_Experts::mark_as_founding( $expert_id );
        wp_safe_redirect( admin_url( 'admin.php?page=nme-experts&action=view&id=' . $expert_id . '&founding=1' ) );
        exit;
    }

    /* ================================================================
       KYC HANDLERS
       ================================================================ */

    /**
     * Approve KYC — marks expert as identity-verified
     */
    public static function handle_approve_kyc() {
        $expert_id = isset( $_POST['expert_id'] ) ? (int) $_POST['expert_id'] : 0;

        if ( ! current_user_can( 'nme_approve_experts' ) || ! wp_verify_nonce( $_POST['_wpnonce'], 'nme_approve_kyc_' . $expert_id ) ) {
            wp_die( 'Permission denied' );
        }

        global $wpdb;
        $wpdb->update(
            NME_Database::table( 'experts' ),
            array(
                'kyc_status'      => 'verified',
                'kyc_verified_at' => current_time( 'mysql' ),
                'kyc_verified_by' => get_current_user_id(),
            ),
            array( 'id' => $expert_id )
        );

        NME_Database::audit_log( 'kyc_approved', 'expert', $expert_id, array( 'by' => get_current_user_id() ) );

        wp_safe_redirect( admin_url( 'admin.php?page=nme-experts&action=view&id=' . $expert_id . '&kyc_approved=1' ) );
        exit;
    }

    /**
     * Reject KYC — expert must re-submit
     */
    public static function handle_reject_kyc() {
        $expert_id = isset( $_POST['expert_id'] ) ? (int) $_POST['expert_id'] : 0;
        $reason    = sanitize_textarea_field( $_POST['kyc_reason'] ?? '' );

        if ( ! current_user_can( 'nme_approve_experts' ) || ! wp_verify_nonce( $_POST['_wpnonce'], 'nme_reject_kyc_' . $expert_id ) ) {
            wp_die( 'Permission denied' );
        }

        global $wpdb;
        $update = array( 'kyc_status' => 'rejected' );

        // Store rejection reason if column exists
        $has_col = $wpdb->get_var( "SHOW COLUMNS FROM " . NME_Database::table( 'experts' ) . " LIKE 'kyc_rejection_reason'" );
        if ( $has_col ) {
            $update['kyc_rejection_reason'] = $reason;
        }

        $wpdb->update( NME_Database::table( 'experts' ), $update, array( 'id' => $expert_id ) );

        NME_Database::audit_log( 'kyc_rejected', 'expert', $expert_id, array( 'reason' => $reason ) );

        wp_safe_redirect( admin_url( 'admin.php?page=nme-experts&action=view&id=' . $expert_id . '&kyc_rejected=1' ) );
        exit;
    }

    /**
     * Purge KYC documents — delete images after verification for privacy
     * Keeps the verification record (status, dates) but removes actual document files.
     */
    public static function handle_purge_kyc_docs() {
        $expert_id = isset( $_POST['expert_id'] ) ? (int) $_POST['expert_id'] : 0;

        if ( ! current_user_can( 'nme_approve_experts' ) || ! wp_verify_nonce( $_POST['_wpnonce'], 'nme_purge_kyc_' . $expert_id ) ) {
            wp_die( 'Permission denied' );
        }

        $expert = NME_Experts::get( $expert_id );
        if ( ! $expert || ( $expert->kyc_status ?? '' ) !== 'verified' ) {
            wp_die( 'KYC must be verified before purging documents.' );
        }

        global $wpdb;
        $table = NME_Database::table( 'experts' );

        // Clear document URLs from database
        $update = array( 'id_proof_url' => '' );

        // Clear back URL if column exists
        $has_back = $wpdb->get_var( "SHOW COLUMNS FROM $table LIKE 'id_proof_back_url'" );
        if ( $has_back ) {
            $update['id_proof_back_url'] = '';
        }

        // v0.6.0 — also purge the PAN card photo. The PAN number column itself
        // is kept because Razorpay Route requires it for every payout.
        $has_pan_card = $wpdb->get_var( "SHOW COLUMNS FROM $table LIKE 'pan_card_url'" );
        if ( $has_pan_card ) {
            $update['pan_card_url'] = '';
        }

        $wpdb->update( $table, $update, array( 'id' => $expert_id ) );

        NME_Database::audit_log( 'kyc_docs_purged', 'expert', $expert_id, array( 'by' => get_current_user_id() ) );

        wp_safe_redirect( admin_url( 'admin.php?page=nme-experts&action=view&id=' . $expert_id . '&kyc_purged=1' ) );
        exit;
    }

    /* ================================================================
       v0.4.0 — ADMIN-DIRECT EDITORS
       Bypass the expert-side OTP + review flow. Every write is
       audit-logged with the admin user id and the stated reason.
       ================================================================ */

    /**
     * Admin-direct profile photo replace.
     * Bypasses the expert 30-day cooldown; resets profile_photo_updated_at.
     */
    public static function handle_admin_update_expert_photo() {
        $expert_id = isset( $_POST['expert_id'] ) ? (int) $_POST['expert_id'] : 0;
        $cap       = apply_filters( 'nme_change_request_admin_cap', 'nme_approve_experts' );

        if ( ! current_user_can( $cap ) || ! wp_verify_nonce( $_POST['_wpnonce'] ?? '', 'nme_admin_update_expert_photo_' . $expert_id ) ) {
            wp_die( 'Permission denied' );
        }

        $expert = NME_Experts::get( $expert_id );
        if ( ! $expert ) {
            wp_die( 'Expert not found' );
        }

        $reason = sanitize_textarea_field( $_POST['reason'] ?? '' );
        if ( $reason === '' ) {
            wp_safe_redirect( admin_url( 'admin.php?page=nme-experts&action=view&id=' . $expert_id . '&admin_photo_err=missing_reason' ) );
            exit;
        }

        if ( empty( $_FILES['profile_photo']['tmp_name'] ) || ! empty( $_FILES['profile_photo']['error'] ) ) {
            wp_safe_redirect( admin_url( 'admin.php?page=nme-experts&action=view&id=' . $expert_id . '&admin_photo_err=no_file' ) );
            exit;
        }

        $allowed = array( 'image/jpeg', 'image/png', 'image/webp' );
        $ftype   = wp_check_filetype_and_ext( $_FILES['profile_photo']['tmp_name'], $_FILES['profile_photo']['name'] );
        if ( ! in_array( (string) ( $ftype['type'] ?? '' ), $allowed, true ) ) {
            wp_safe_redirect( admin_url( 'admin.php?page=nme-experts&action=view&id=' . $expert_id . '&admin_photo_err=bad_type' ) );
            exit;
        }
        if ( (int) $_FILES['profile_photo']['size'] > 5 * 1024 * 1024 ) {
            wp_safe_redirect( admin_url( 'admin.php?page=nme-experts&action=view&id=' . $expert_id . '&admin_photo_err=too_large' ) );
            exit;
        }

        require_once ABSPATH . 'wp-admin/includes/file.php';
        $overrides = array( 'test_form' => false, 'mimes' => array( 'jpg|jpeg' => 'image/jpeg', 'png' => 'image/png', 'webp' => 'image/webp' ) );
        $uploaded  = wp_handle_upload( $_FILES['profile_photo'], $overrides );
        if ( isset( $uploaded['error'] ) ) {
            wp_safe_redirect( admin_url( 'admin.php?page=nme-experts&action=view&id=' . $expert_id . '&admin_photo_err=upload_failed' ) );
            exit;
        }

        global $wpdb;
        $table  = NME_Database::table( 'experts' );
        $update = array( 'profile_photo' => esc_url_raw( $uploaded['url'] ) );

        // Reset cooldown anchor if the column exists.
        $has_anchor = $wpdb->get_var( "SHOW COLUMNS FROM $table LIKE 'profile_photo_updated_at'" );
        if ( $has_anchor ) {
            $update['profile_photo_updated_at'] = current_time( 'mysql' );
        }

        $wpdb->update( $table, $update, array( 'id' => $expert_id ) );

        NME_Database::audit_log( 'admin_profile_photo_updated', 'expert', $expert_id, array(
            'by'     => get_current_user_id(),
            'reason' => $reason,
            'url'    => $uploaded['url'],
        ) );

        wp_safe_redirect( admin_url( 'admin.php?page=nme-experts&action=view&id=' . $expert_id . '&admin_photo_updated=1' ) );
        exit;
    }

    /**
     * Admin-direct bank-account edit.
     * Bypasses OTP + review; writes old snapshot to audit log.
     */
    public static function handle_admin_update_expert_bank() {
        $expert_id = isset( $_POST['expert_id'] ) ? (int) $_POST['expert_id'] : 0;
        $cap       = apply_filters( 'nme_change_request_admin_cap', 'nme_approve_experts' );

        if ( ! current_user_can( $cap ) || ! wp_verify_nonce( $_POST['_wpnonce'] ?? '', 'nme_admin_update_expert_bank_' . $expert_id ) ) {
            wp_die( 'Permission denied' );
        }

        $expert = NME_Experts::get( $expert_id );
        if ( ! $expert ) {
            wp_die( 'Expert not found' );
        }

        $reason = sanitize_textarea_field( $_POST['reason'] ?? '' );
        if ( $reason === '' ) {
            wp_safe_redirect( admin_url( 'admin.php?page=nme-experts&action=view&id=' . $expert_id . '&admin_bank_err=missing_reason' ) );
            exit;
        }

        $new = array(
            'bank_account_holder' => sanitize_text_field( $_POST['bank_account_holder'] ?? '' ),
            'bank_account_number' => preg_replace( '/\s+/', '', sanitize_text_field( $_POST['bank_account_number'] ?? '' ) ),
            'bank_ifsc'           => strtoupper( sanitize_text_field( $_POST['bank_ifsc'] ?? '' ) ),
            'upi_id'              => sanitize_text_field( $_POST['upi_id'] ?? '' ),
        );

        // Must have at least one payout method.
        if ( $new['bank_account_number'] === '' && $new['upi_id'] === '' ) {
            wp_safe_redirect( admin_url( 'admin.php?page=nme-experts&action=view&id=' . $expert_id . '&admin_bank_err=empty' ) );
            exit;
        }

        // Snapshot the OLD values for the audit log.
        $old = array(
            'bank_account_holder' => $expert->bank_account_holder ?? '',
            'bank_account_number' => $expert->bank_account_number ?? '',
            'bank_ifsc'           => $expert->bank_ifsc ?? '',
            'upi_id'              => $expert->upi_id ?? '',
        );

        global $wpdb;
        $wpdb->update( NME_Database::table( 'experts' ), $new, array( 'id' => $expert_id ) );

        // If the expert had a pending bank-change request in flight, this admin-side
        // override supersedes it. Mark the pending row as cancelled (not approved —
        // the admin applied their own values, not the expert's proposed ones).
        $superseded_request_ids = array();
        if ( class_exists( 'NME_Change_Requests' ) ) {
            $cr_table = NME_Database::table( 'change_requests' );
            // Guard: only attempt if the table exists (migration may not have run yet).
            if ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $cr_table ) ) === $cr_table ) {
                $pending_ids = $wpdb->get_col( $wpdb->prepare(
                    "SELECT id FROM {$cr_table}
                      WHERE expert_id = %d AND type = %s AND status = %s",
                    $expert_id,
                    'bank_account',
                    'pending'
                ) );
                foreach ( (array) $pending_ids as $pid ) {
                    $pid = (int) $pid;
                    if ( $pid <= 0 ) continue;
                    $wpdb->update( $cr_table, array(
                        'status'       => 'cancelled',
                        'reviewed_at'  => current_time( 'mysql' ),
                        'reviewed_by'  => get_current_user_id(),
                        'admin_reason' => 'Superseded by admin-direct override.',
                    ), array( 'id' => $pid ) );
                    $superseded_request_ids[] = $pid;
                }
            }
        }

        NME_Database::audit_log( 'admin_bank_account_updated', 'expert', $expert_id, array(
            'by'                     => get_current_user_id(),
            'reason'                 => $reason,
            'old'                    => $old,
            'new'                    => $new,
            'superseded_requests'    => $superseded_request_ids,
        ) );

        // Admin has applied new bank details directly — release any payouts that were
        // held waiting for change-request approval so the expert isn't frozen.
        if ( class_exists( 'NMEP_Payouts' ) && method_exists( 'NMEP_Payouts', 'release_held_for_expert' ) ) {
            NMEP_Payouts::release_held_for_expert( $expert_id );
        }

        wp_safe_redirect( admin_url( 'admin.php?page=nme-experts&action=view&id=' . $expert_id . '&admin_bank_updated=1' ) );
        exit;
    }

    /**
     * Admin-direct postal address update.
     *
     * Razorpay Route /v2/accounts requires non-empty street1, street2 and a real
     * 6-digit postal_code on the linked-account payload. Addresses change rarely
     * and the only operational case right now is admin fixing/filling on behalf
     * of an expert. We therefore bypass the OTP-gated change-requests flow and
     * just write directly, audit-logging the diff.
     */
    public static function handle_admin_update_expert_address() {
        $expert_id = isset( $_POST['expert_id'] ) ? (int) $_POST['expert_id'] : 0;

        if ( ! current_user_can( 'nme_approve_experts' )
            || ! wp_verify_nonce( $_POST['_wpnonce'] ?? '', 'nme_admin_update_expert_address_' . $expert_id ) ) {
            wp_die( 'Permission denied' );
        }

        $expert = NME_Experts::get( $expert_id );
        if ( ! $expert ) {
            wp_die( 'Expert not found' );
        }

        $street  = isset( $_POST['street_address'] ) ? trim( wp_unslash( $_POST['street_address'] ) ) : '';
        $village = isset( $_POST['village_locality'] ) ? trim( wp_unslash( $_POST['village_locality'] ) ) : '';
        $pin     = isset( $_POST['postal_code'] ) ? trim( wp_unslash( $_POST['postal_code'] ) ) : '';

        $street  = sanitize_text_field( $street );
        $village = sanitize_text_field( $village );
        $pin     = preg_replace( '/\D/', '', $pin );

        $redirect = admin_url( 'admin.php?page=nme-experts&action=view&id=' . $expert_id );

        if ( $street === '' || mb_strlen( $street ) > 160 ) {
            wp_safe_redirect( add_query_arg( 'address_error', urlencode( 'Street address is required (max 160 characters).' ), $redirect ) );
            exit;
        }
        if ( $village === '' || mb_strlen( $village ) > 120 ) {
            wp_safe_redirect( add_query_arg( 'address_error', urlencode( 'Village / locality is required (max 120 characters).' ), $redirect ) );
            exit;
        }
        if ( ! preg_match( '/^\d{6}$/', $pin ) ) {
            wp_safe_redirect( add_query_arg( 'address_error', urlencode( 'PIN code must be exactly 6 digits.' ), $redirect ) );
            exit;
        }

        global $wpdb;
        $old = array(
            'street_address'   => isset( $expert->street_address ) ? $expert->street_address : null,
            'village_locality' => isset( $expert->village_locality ) ? $expert->village_locality : null,
            'postal_code'      => isset( $expert->postal_code ) ? $expert->postal_code : null,
        );
        $new = array(
            'street_address'   => $street,
            'village_locality' => $village,
            'postal_code'      => $pin,
        );

        $updated = $wpdb->update(
            NME_Database::table( 'experts' ),
            $new,
            array( 'id' => $expert_id ),
            array( '%s', '%s', '%s' ),
            array( '%d' )
        );

        if ( $updated === false ) {
            wp_safe_redirect( add_query_arg( 'address_error', urlencode( 'Could not save address: ' . $wpdb->last_error ), $redirect ) );
            exit;
        }

        NME_Database::audit_log( 'admin_address_updated', 'expert', $expert_id, array(
            'by'  => get_current_user_id(),
            'old' => $old,
            'new' => $new,
        ) );

        wp_safe_redirect( add_query_arg( 'address_updated', '1', $redirect ) );
        exit;
    }

    /**
     * Admin-direct PAN + ID-proof override. (v0.6.0)
     *
     * The expert-side KYC form locks PAN / ID documents once kyc_status is
     * 'submitted' or 'verified', but Razorpay Route can reject a PAN for
     * reasons the expert has no way to self-correct (duplicate PAN already
     * bound to another merchant account, name-PAN mismatch, wrong entity
     * type, etc.). Admins need a safe way to patch the record and trigger
     * re-submission to Razorpay on the next transfer.
     *
     * Safeguards:
     *   1. Double-entry: pan_number must equal pan_number_confirm.
     *   2. Strict regex on server side (frontend regex can be bypassed).
     *   3. Required human-readable reason (stored in audit log + email).
     *   4. Every write is audit-logged with old+new+actor+IP.
     *   5. When PAN actually changes, any existing nmep_linked_accounts row
     *      for this expert (current mode) is marked needs_recreation so the
     *      next payout forces a fresh Linked Account create call.
     *   6. Expert is emailed a before/after diff (NME_Emails) — audit trail
     *      + notification catches unauthorised admin edits.
     */
    public static function handle_admin_update_expert_kyc() {
        $expert_id = isset( $_POST['expert_id'] ) ? (int) $_POST['expert_id'] : 0;

        if ( ! current_user_can( 'nme_approve_experts' )
            || ! wp_verify_nonce( $_POST['_wpnonce'] ?? '', 'nme_admin_update_expert_kyc_' . $expert_id ) ) {
            wp_die( 'Permission denied' );
        }

        $expert = NME_Experts::get( $expert_id );
        if ( ! $expert ) {
            wp_die( 'Expert not found' );
        }

        $redirect = admin_url( 'admin.php?page=nme-experts&action=view&id=' . $expert_id );

        $pan1         = strtoupper( trim( (string) ( $_POST['pan_number']         ?? '' ) ) );
        $pan2         = strtoupper( trim( (string) ( $_POST['pan_number_confirm'] ?? '' ) ) );
        $pan_card_url = esc_url_raw( trim( (string) ( $_POST['pan_card_url']      ?? '' ) ) );
        $id_type      = sanitize_key( (string) ( $_POST['id_proof_type']          ?? '' ) );
        $id_front     = esc_url_raw( trim( (string) ( $_POST['id_proof_url']      ?? '' ) ) );
        $id_back      = esc_url_raw( trim( (string) ( $_POST['id_proof_back_url'] ?? '' ) ) );
        $reason       = trim( wp_unslash( (string) ( $_POST['reason']             ?? '' ) ) );
        $reason       = sanitize_textarea_field( $reason );

        $fail = function( $msg ) use ( $redirect ) {
            wp_safe_redirect( add_query_arg( 'kyc_error', urlencode( $msg ), $redirect ) );
            exit;
        };

        if ( $reason === '' || mb_strlen( $reason ) < 5 ) {
            $fail( 'A reason is required (min 5 characters). It is stored in the audit log and emailed to the expert.' );
        }
        if ( $pan1 === '' || $pan2 === '' ) {
            $fail( 'Both PAN fields are required.' );
        }
        if ( $pan1 !== $pan2 ) {
            $fail( 'The two PAN entries do not match. Please retype.' );
        }
        if ( ! preg_match( '/^[A-Z]{5}[0-9]{4}[A-Z]$/', $pan1 ) ) {
            $fail( 'PAN format is invalid. Expected 5 letters, 4 digits, 1 letter (e.g. ABCDE1234F).' );
        }

        $allowed_id_types = array( 'aadhaar', 'voter_id', 'passport', 'driving_license' );
        if ( $id_type !== '' && ! in_array( $id_type, $allowed_id_types, true ) ) {
            $fail( 'ID proof type is not one of the allowed values.' );
        }

        global $wpdb;

        $old = array(
            'pan_number'        => (string) ( $expert->pan_number        ?? '' ),
            'pan_card_url'      => (string) ( $expert->pan_card_url      ?? '' ),
            'id_proof_type'     => (string) ( $expert->id_proof_type     ?? '' ),
            'id_proof_url'      => (string) ( $expert->id_proof_url      ?? '' ),
            'id_proof_back_url' => (string) ( $expert->id_proof_back_url ?? '' ),
        );

        // Only update fields that were actually provided. PAN is always required.
        $update = array( 'pan_number' => $pan1 );
        $formats = array( '%s' );

        if ( $pan_card_url !== '' ) { $update['pan_card_url']      = $pan_card_url; $formats[] = '%s'; }
        if ( $id_type      !== '' ) { $update['id_proof_type']     = $id_type;      $formats[] = '%s'; }
        if ( $id_front     !== '' ) { $update['id_proof_url']      = $id_front;     $formats[] = '%s'; }
        if ( $id_back      !== '' ) { $update['id_proof_back_url'] = $id_back;      $formats[] = '%s'; }

        $updated = $wpdb->update(
            NME_Database::table( 'experts' ),
            $update,
            array( 'id' => $expert_id ),
            $formats,
            array( '%d' )
        );

        if ( $updated === false ) {
            $fail( 'Could not save KYC: ' . $wpdb->last_error );
        }

        $new = array_merge( $old, $update );
        $pan_changed = ( $old['pan_number'] !== $pan1 );

        // If PAN actually changed and a Linked Account already exists for this
        // expert, stale it so the next payout / admin retry forces a fresh
        // create call with the corrected PAN. Razorpay does not allow PAN
        // edits on an existing linked account.
        $linked_stale = false;
        if ( $pan_changed && class_exists( 'NMEP_Database' ) && class_exists( 'NMEP_Settings' ) ) {
            $mode = NMEP_Settings::get_mode();
            $linked_table = NMEP_Database::table( 'linked_accounts' );
            $existing = $wpdb->get_row( $wpdb->prepare(
                "SELECT id, razorpay_account_id FROM {$linked_table} WHERE expert_id = %d AND mode = %s LIMIT 1",
                $expert_id, $mode
            ) );
            if ( $existing && ! empty( $existing->razorpay_account_id ) ) {
                $wpdb->update(
                    $linked_table,
                    array(
                        'razorpay_account_id' => null,
                        'status'              => 'needs_recreation',
                        'activation_status'   => 'needs_recreation',
                        'verification_status' => 'pending',
                    ),
                    array( 'id' => (int) $existing->id ),
                    array( '%s', '%s', '%s', '%s' ),
                    array( '%d' )
                );
                $linked_stale = true;
            }
        }

        NME_Database::audit_log( 'admin_kyc_updated', 'expert', $expert_id, array(
            'by'           => get_current_user_id(),
            'reason'       => $reason,
            'old'          => $old,
            'new'          => $new,
            'pan_changed'  => $pan_changed,
            'linked_stale' => $linked_stale,
        ) );

        if ( class_exists( 'NME_Emails' ) && method_exists( 'NME_Emails', 'send_admin_kyc_edited' ) ) {
            $fresh = NME_Experts::get( $expert_id );
            NME_Emails::send_admin_kyc_edited( $fresh ?: $expert, $old, $new, $reason );
        }

        wp_safe_redirect( add_query_arg( 'kyc_updated', '1', $redirect ) );
        exit;
    }

    /**
     * Admin-side AJAX upload for KYC documents (PAN card, ID front, ID back).
     * Returns JSON { url } on success. Files are stored as private attachments
     * owned by the admin who uploaded them, mirroring the expert-side flow.
     */
    public static function handle_admin_upload_kyc_doc() {
        if ( ! check_ajax_referer( 'nme_admin_upload_kyc_doc', 'nonce', false ) ) {
            wp_send_json_error( array( 'message' => 'Security check failed.' ) );
        }
        if ( ! current_user_can( 'nme_approve_experts' ) ) {
            wp_send_json_error( array( 'message' => 'Permission denied.' ) );
        }

        $expert_id = isset( $_POST['expert_id'] ) ? (int) $_POST['expert_id'] : 0;
        $field     = sanitize_key( $_POST['field'] ?? '' );

        if ( ! $expert_id || ! NME_Experts::get( $expert_id ) ) {
            wp_send_json_error( array( 'message' => 'Expert not found.' ) );
        }
        if ( ! in_array( $field, array( 'pan_card', 'id_proof_front', 'id_proof_back' ), true ) ) {
            wp_send_json_error( array( 'message' => 'Invalid document field.' ) );
        }

        if ( empty( $_FILES['kyc_doc_file'] ) || ! is_uploaded_file( $_FILES['kyc_doc_file']['tmp_name'] ) ) {
            wp_send_json_error( array( 'message' => 'No file uploaded.' ) );
        }

        $file = $_FILES['kyc_doc_file'];

        if ( $file['error'] !== UPLOAD_ERR_OK ) {
            wp_send_json_error( array( 'message' => 'Upload error. Please try again.' ) );
        }
        if ( $file['size'] > 5 * 1024 * 1024 ) {
            wp_send_json_error( array( 'message' => 'File must be under 5MB.' ) );
        }

        $allowed = array( 'image/jpeg', 'image/png', 'application/pdf' );
        $finfo = finfo_open( FILEINFO_MIME_TYPE );
        $mime  = finfo_file( $finfo, $file['tmp_name'] );
        finfo_close( $finfo );

        if ( ! in_array( $mime, $allowed, true ) ) {
            wp_send_json_error( array( 'message' => 'Only JPG, PNG, or PDF files allowed.' ) );
        }

        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';
        require_once ABSPATH . 'wp-admin/includes/media.php';

        $movefile = wp_handle_upload( $file, array(
            'test_form' => false,
            'mimes'     => array( 'jpg|jpeg' => 'image/jpeg', 'png' => 'image/png', 'pdf' => 'application/pdf' ),
        ) );

        if ( ! $movefile || isset( $movefile['error'] ) ) {
            wp_send_json_error( array( 'message' => $movefile['error'] ?? 'Could not save file.' ) );
        }

        $attachment = array(
            'post_mime_type' => $movefile['type'],
            'post_title'     => 'KYC Document (admin upload) — expert #' . $expert_id . ' — ' . $field,
            'post_content'   => '',
            'post_status'    => 'private',
            'post_author'    => get_current_user_id(),
        );
        $att_id = wp_insert_attachment( $attachment, $movefile['file'] );
        if ( ! is_wp_error( $att_id ) ) {
            $att_data = wp_generate_attachment_metadata( $att_id, $movefile['file'] );
            wp_update_attachment_metadata( $att_id, $att_data );
        }

        NME_Database::audit_log( 'admin_kyc_doc_uploaded', 'expert', $expert_id, array(
            'by'    => get_current_user_id(),
            'field' => $field,
        ) );

        wp_send_json_success( array( 'url' => $movefile['url'] ) );
    }
}