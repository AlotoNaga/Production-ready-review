/**
 * Nagaland Me Experts — Frontend JS
 */
(function($) {
    'use strict';

    $(document).ready(function() {

        // PAN auto-uppercase
        $('input[name="pan_number"]').on('input', function() {
            this.value = this.value.toUpperCase();
        });

        // IFSC auto-uppercase
        $('input[name="bank_ifsc"]').on('input', function() {
            this.value = this.value.toUpperCase();
        });

        // Form submission feedback
        $('form').on('submit', function() {
            var $btn = $(this).find('button[type="submit"]');
            if ($btn.length) {
                $btn.prop('disabled', true).text('Submitting...');
            }
        });

    });

})(jQuery);
