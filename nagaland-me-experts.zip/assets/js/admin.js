/**
 * Nagaland Me Experts — Admin JS
 */
(function($) {
    'use strict';

    $(document).ready(function() {
        // Confirmation on reject
        $('form input[name="action"][value="nme_reject_expert"]').closest('form').on('submit', function() {
            return confirm('Are you sure you want to reject this expert? They will receive an email notification.');
        });

        // Confirmation on mark as founding
        $('form input[name="action"][value="nme_mark_founding"]').closest('form').on('submit', function() {
            return confirm('Mark this expert as a Founding Expert? They will get permanent gold badge and 0% commission for 3 months.');
        });
    });

})(jQuery);
