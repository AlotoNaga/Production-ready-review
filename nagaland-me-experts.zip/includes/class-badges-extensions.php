<?php
/**
 * NME_Badges_Extensions
 *
 * Light-touch overlay on top of the nme-badges plugin — lives in the base
 * experts plugin so we can ship fixes without modifying the zipped badges
 * plugin itself. Everything here uses the badges plugin's public API:
 *   • NMEB_Engine::award_badge / revoke_badge / user_has_badge
 *   • NMEB_Badges::get_by_slug + direct wpdb inserts against
 *     NMEB_Database::table( 'badges' ) for defining new badges
 *
 * Three concerns, one file:
 *
 * 1. Premium Buyer badge
 *    nme-payments activates a buyer premium record in
 *    NMEP_Buyer_Premium::handle_payment_verification(). That handler now
 *    fires do_action( 'nmep_premium_activated', $user_id, $record ) (added
 *    in v0.4.2 of the payments patch). We subscribe to that event to award
 *    the badge instantly; we also retro-scan on the daily cron so existing
 *    premium members get backfilled.
 *
 * 2. Disable broken auto-award badges
 *    As reported in the badges audit (see conversation log):
 *      • rising_expert — gated on a fake 90% response-rate placeholder, so
 *        every expert with ≥1 order silently qualifies.
 *      • quick_responder — same placeholder drives the 90% threshold.
 *      • pan_india_reach — gated on unique_buyer_states which is hard-coded
 *        0, so it can only ever be awarded manually.
 *    We hook `nmeb_badge_awarded` and immediately revoke any of these three
 *    if they were awarded_by='auto'. Admin grants still stick.
 *
 * 3. Retire verified_buyer
 *    Its criterion (buyer_has_verified_email) is a no-op on plain WP users,
 *    so it auto-awards to everyone with ≥1 order — i.e., it duplicates the
 *    new_buyer badge. We flip is_visible=0 on the row (hidden from chips
 *    and the all-badges showcase) and revoke the auto-grants that already
 *    exist so the chip disappears from currently-awarded users.
 *
 * @package NagalandMeExperts
 * @version 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class NME_Badges_Extensions {

    /** Option flag that tracks which one-shot migrations have run. */
    const OPTION_MIGRATIONS = 'nme_badges_extensions_migrations';

    /** Slug we seed for the buyer-side Premium badge. */
    const PREMIUM_BUYER_SLUG = 'premium_buyer';

    /** Auto-award badges with placeholder metrics — revoke if awarded_by='auto'. */
    const BROKEN_AUTO_SLUGS = array( 'rising_expert', 'quick_responder', 'pan_india_reach' );

    /** Badge we retire because its criterion is effectively a no-op. */
    const RETIRED_SLUG = 'verified_buyer';

    public static function init() {
        // Wire everything on plugins_loaded at priority 40 — that's after
        // the badges plugin finishes its own init (priority 20) and its
        // own migration pass (priority 30). By 40 the `wp_nmeb_badges`
        // table exists, default badges are seeded, and we can layer our
        // own definitions + revocation rules on top.
        add_action( 'plugins_loaded', array( __CLASS__, 'bootstrap' ), 40 );
    }

    public static function bootstrap() {
        if ( ! self::badges_plugin_available() ) {
            return;
        }

        self::run_migrations_once();

        // Premium Buyer — event-driven for instant awards on purchase.
        add_action( 'nmep_premium_activated', array( __CLASS__, 'on_premium_activated' ), 10, 2 );

        // Premium Buyer — backfill + expiry cleanup piggybacking on the
        // badges plugin's daily cron. Runs after the main auto-award pass
        // so the DB is already warm.
        add_action( 'nmeb_daily_auto_award', array( __CLASS__, 'daily_premium_scan' ), 20 );

        // Broken auto-awards — revoke the moment the engine grants them.
        add_action( 'nmeb_badge_awarded', array( __CLASS__, 'maybe_undo_broken_auto_award' ), 10, 3 );
    }

    /* ================================================================
       ONE-SHOT MIGRATIONS
       ================================================================ */

    /**
     * Run any migration steps this class owns. Each step is keyed by a
     * short identifier so re-running is safe — we only touch the DB for
     * steps that haven't completed yet. The completed set is stored as an
     * array in a single option so the Settings → Options row stays tidy.
     */
    private static function run_migrations_once() {
        $ran = get_option( self::OPTION_MIGRATIONS, array() );
        if ( ! is_array( $ran ) ) {
            $ran = array();
        }

        if ( empty( $ran['seed_premium_buyer_v1'] ) ) {
            if ( self::seed_premium_buyer_definition() ) {
                $ran['seed_premium_buyer_v1'] = current_time( 'mysql' );
            }
        }

        if ( empty( $ran['retire_verified_buyer_v1'] ) ) {
            if ( self::retire_verified_buyer() ) {
                $ran['retire_verified_buyer_v1'] = current_time( 'mysql' );
            }
        }

        if ( empty( $ran['revoke_broken_auto_v1'] ) ) {
            if ( self::revoke_existing_broken_auto_awards() ) {
                $ran['revoke_broken_auto_v1'] = current_time( 'mysql' );
            }
        }

        update_option( self::OPTION_MIGRATIONS, $ran, false );
    }

    /**
     * Insert the Premium Buyer badge definition if it isn't present.
     * We intentionally do NOT set criteria_json — the badges plugin's
     * generic `expert_meets_criteria()` check doesn't understand
     * premium-membership, so there's nothing it could evaluate. Awards
     * happen exclusively through our own event + cron path below.
     */
    private static function seed_premium_buyer_definition() {
        global $wpdb;
        $table = NMEB_Database::table( 'badges' );

        $exists = $wpdb->get_var( $wpdb->prepare(
            "SELECT id FROM $table WHERE slug = %s LIMIT 1",
            self::PREMIUM_BUYER_SLUG
        ) );
        if ( $exists ) {
            return true;
        }

        $result = $wpdb->insert( $table, array(
            'slug'          => self::PREMIUM_BUYER_SLUG,
            'name'          => 'Premium Buyer',
            'icon'          => 'PB',
            'color'         => '#D4A843',
            'badge_type'    => 'buyer_achievement',
            'tier_rank'     => 0,
            'description'   => 'Active Nagaland Me Premium member — supports the marketplace and unlocks member benefits.',
            'criteria_json' => wp_json_encode( array(
                'auto'               => true,
                'requires_premium'   => true,
                'awarded_via'        => 'nmep_premium_activated',
            ) ),
            'is_admin_only' => 0,
            'is_visible'    => 1,
            'display_order' => 250,
        ) );

        return (bool) $result;
    }

    /**
     * Retire verified_buyer — hide from chips + showcases, then revoke
     * every auto-awarded copy so existing users lose the phantom badge.
     * Admin-granted copies (rare but possible) are preserved intentionally;
     * if an admin explicitly awarded it, we respect that.
     */
    private static function retire_verified_buyer() {
        global $wpdb;
        $badges_table = NMEB_Database::table( 'badges' );
        $ub_table     = NMEB_Database::table( 'user_badges' );

        $badge = NMEB_Badges::get_by_slug( self::RETIRED_SLUG );
        if ( ! $badge ) {
            // If the row doesn't exist there's nothing to retire — mark
            // the migration done so we stop checking.
            return true;
        }

        $wpdb->update(
            $badges_table,
            array( 'is_visible' => 0 ),
            array( 'id' => (int) $badge->id ),
            array( '%d' ),
            array( '%d' )
        );

        // Revoke all auto-awarded copies. We mark them revoked (rather
        // than deleting) so the audit trail is preserved.
        $wpdb->query( $wpdb->prepare(
            "UPDATE $ub_table
                SET is_revoked = 1,
                    revoked_at = %s,
                    revoked_reason = %s
              WHERE badge_id = %d
                AND awarded_by = 'auto'
                AND is_revoked = 0",
            current_time( 'mysql' ),
            'Retired by NME_Badges_Extensions: verified_buyer criterion was a no-op on standard WP accounts.',
            (int) $badge->id
        ) );

        return true;
    }

    /**
     * One-time cleanup: revoke any auto-awarded rising_expert /
     * quick_responder / pan_india_reach rows that the engine already
     * handed out before this class loaded. From this point on the
     * `nmeb_badge_awarded` hook below catches them at creation time.
     */
    private static function revoke_existing_broken_auto_awards() {
        global $wpdb;
        $ub_table     = NMEB_Database::table( 'user_badges' );
        $badges_table = NMEB_Database::table( 'badges' );

        $slugs_sql = "('" . implode( "','", array_map( 'esc_sql', self::BROKEN_AUTO_SLUGS ) ) . "')";
        $bad_ids   = $wpdb->get_col(
            "SELECT id FROM $badges_table WHERE slug IN $slugs_sql"
        );
        if ( empty( $bad_ids ) ) {
            return true;
        }

        $ids_sql = implode( ',', array_map( 'intval', $bad_ids ) );
        $wpdb->query( $wpdb->prepare(
            "UPDATE $ub_table
                SET is_revoked = 1,
                    revoked_at = %s,
                    revoked_reason = %s
              WHERE badge_id IN ($ids_sql)
                AND awarded_by = 'auto'
                AND is_revoked = 0",
            current_time( 'mysql' ),
            'Revoked by NME_Badges_Extensions: auto-award criteria rely on placeholder metrics.'
        ) );

        return true;
    }

    /* ================================================================
       EVENT + CRON HANDLERS
       ================================================================ */

    /**
     * nmep_premium_activated — fires when a buyer finishes Razorpay
     * verification and the premium record flips active. Award the
     * Premium Buyer badge to that user immediately.
     */
    public static function on_premium_activated( $user_id, $record ) {
        $user_id = (int) $user_id;
        if ( $user_id <= 0 ) {
            return;
        }
        NMEB_Engine::award_badge(
            $user_id,
            self::PREMIUM_BUYER_SLUG,
            'auto',
            0,
            'Awarded via nmep_premium_activated.'
        );
    }

    /**
     * Daily backfill pass. Runs alongside the badges plugin's own cron.
     *
     * Goals:
     *  • Backfill Premium Buyer for anyone who upgraded before this class
     *    existed (no event fired for them).
     *  • Revoke Premium Buyer from users whose premium membership has
     *    lapsed — the badge is conceptually "active subscription", not a
     *    lifetime award.
     */
    public static function daily_premium_scan() {
        if ( ! class_exists( 'NMEP_Buyer_Premium' ) ) {
            return;
        }

        global $wpdb;
        $premium_table = NMEP_Buyer_Premium::table( 'buyer_premium' );

        // Every user who has EVER had a premium record — active or lapsed.
        $user_ids = $wpdb->get_col(
            "SELECT DISTINCT user_id FROM $premium_table WHERE user_id > 0"
        );
        if ( empty( $user_ids ) ) {
            return;
        }

        foreach ( $user_ids as $user_id ) {
            $user_id = (int) $user_id;
            $is_premium = (bool) NMEP_Buyer_Premium::is_premium( $user_id );
            $has_badge  = (bool) NMEB_Engine::user_has_badge( $user_id, self::PREMIUM_BUYER_SLUG );

            if ( $is_premium && ! $has_badge ) {
                NMEB_Engine::award_badge(
                    $user_id,
                    self::PREMIUM_BUYER_SLUG,
                    'auto',
                    0,
                    'Awarded via daily_premium_scan backfill.'
                );
            } elseif ( ! $is_premium && $has_badge ) {
                NMEB_Engine::revoke_badge(
                    $user_id,
                    self::PREMIUM_BUYER_SLUG,
                    0,
                    'Premium membership lapsed.'
                );
            }
        }
    }

    /**
     * nmeb_badge_awarded — fires for every badge awarded (auto + admin).
     * If the badge is one of the known-broken auto awards AND the grant
     * came from the engine (awarded_by='auto'), revoke it immediately.
     * Admin grants pass through untouched — if a human explicitly chose
     * to award rising_expert we won't second-guess them.
     */
    public static function maybe_undo_broken_auto_award( $user_id, $badge, $awarded_by ) {
        if ( $awarded_by !== 'auto' ) {
            return;
        }
        if ( ! is_object( $badge ) || empty( $badge->slug ) ) {
            return;
        }
        if ( ! in_array( $badge->slug, self::BROKEN_AUTO_SLUGS, true ) ) {
            return;
        }

        NMEB_Engine::revoke_badge(
            (int) $user_id,
            $badge->slug,
            0,
            'Auto-revoked by NME_Badges_Extensions: criterion depends on placeholder metrics.'
        );
    }

    /* ================================================================
       INTERNALS
       ================================================================ */

    /**
     * Every class we depend on has to exist before this overlay can do
     * anything useful. Used as a guard so the experts plugin stays safe
     * when the badges plugin is deactivated.
     */
    private static function badges_plugin_available() {
        return class_exists( 'NMEB_Engine' )
            && class_exists( 'NMEB_Badges' )
            && class_exists( 'NMEB_Database' );
    }
}