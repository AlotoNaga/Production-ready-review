<?php
/**
 * NME_Experts
 * Core CRUD and queries for expert profiles.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class NME_Experts {

    const STATUS_PENDING  = 'pending';
    const STATUS_APPROVED = 'approved';
    const STATUS_REJECTED = 'rejected';
    const STATUS_SUSPENDED = 'suspended';

    const TIER_NEW     = 'new';
    const TIER_RISING  = 'rising';
    const TIER_PRO     = 'pro';
    const TIER_TOP_PRO = 'top_pro';

    /**
     * Create a new expert application
     */
    public static function create( $data ) {
        global $wpdb;

        $defaults = array(
            'user_id'                => 0,
            'full_name'              => '',
            'email'                  => '',
            'phone'                  => '',
            'whatsapp'               => '',
            'district'               => '',
            'state'                  => 'Nagaland',
            // Registered address (schema v0.5.0) — required by Razorpay Route.
            'street_address'         => '',
            'village_locality'       => '',
            'postal_code'            => '',
            'primary_category_id'    => 0,
            'secondary_category_id'  => null,
            'tagline'                => '',
            'bio'                    => '',
            'languages'              => '',
            'years_experience'       => 0,
            'portfolio_url'          => '',
            'youtube_channel'        => '',
            'facebook_page'          => '',
            'profile_photo'          => '',
            'pan_number'             => '',
            'id_proof_url'           => '',
            'id_proof_back_url'      => '',
            'id_proof_type'          => '',
            'kyc_status'             => 'not_started',
            'bank_account_holder'    => '',
            'bank_account_number'    => '',
            'bank_ifsc'              => '',
            'upi_id'                 => '',
            'tier'                   => self::TIER_NEW,
            'status'                 => self::STATUS_PENDING,
            'applied_at'             => current_time( 'mysql' ),
        );

        $data = wp_parse_args( $data, $defaults );

        $result = $wpdb->insert( NME_Database::table( 'experts' ), $data );

        if ( false === $result ) {
            return false;
        }

        $expert_id = $wpdb->insert_id;

        NME_Database::audit_log(
            'expert_application_submitted',
            'expert',
            $expert_id,
            array( 'email' => $data['email'] )
        );

        return $expert_id;
    }

    /**
     * Get expert by ID
     */
    public static function get( $id ) {
        global $wpdb;
        return $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM " . NME_Database::table( 'experts' ) . " WHERE id = %d",
            (int) $id
        ) );
    }

    /**
     * Get expert by user ID
     */
    public static function get_by_user( $user_id ) {
        global $wpdb;
        return $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM " . NME_Database::table( 'experts' ) . " WHERE user_id = %d",
            (int) $user_id
        ) );
    }

    /**
     * Get all experts by status
     */
    public static function get_by_status( $status, $limit = 50, $offset = 0 ) {
        global $wpdb;
        return $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM " . NME_Database::table( 'experts' ) . "
             WHERE status = %s
             ORDER BY applied_at DESC
             LIMIT %d OFFSET %d",
            $status, $limit, $offset
        ) );
    }

    /**
     * Get approved experts (for public display)
     */
    public static function get_approved( $args = array() ) {
        global $wpdb;

        $defaults = array(
            'category_id' => 0,
            'limit'       => 20,
            'offset'      => 0,
            'order_by'    => 'tier',
        );
        $args = wp_parse_args( $args, $defaults );

        $where = "WHERE status = 'approved'";
        if ( $args['category_id'] ) {
            $where .= $wpdb->prepare( " AND primary_category_id = %d", $args['category_id'] );
        }

        $order = "ORDER BY FIELD(tier, 'top_pro', 'pro', 'rising', 'new'), avg_rating DESC, total_orders DESC";

        return $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM " . NME_Database::table( 'experts' ) . "
             $where
             $order
             LIMIT %d OFFSET %d",
            $args['limit'], $args['offset']
        ) );
    }

    /**
     * Search approved experts with filters. Used by the directory page.
     *
     * Accepted keys:
     *   q           free-text search over full_name / tagline / bio
     *   category_id primary or secondary category
     *   district    exact district match (case-insensitive)
     *   tier        'new' | 'rising' | 'pro' | 'top_pro'
     *   language    substring match in languages column (legacy string)
     *   limit, offset
     *
     * Returns array: [ 'rows' => object[], 'total' => int ]
     */
    public static function search_approved( $args = array() ) {
        global $wpdb;

        $defaults = array(
            'q'           => '',
            'category_id' => 0,
            'district'    => '',
            'tier'        => '',
            'language'    => '',
            'limit'       => 24,
            'offset'      => 0,
        );
        $args  = wp_parse_args( $args, $defaults );
        $table = NME_Database::table( 'experts' );

        $where  = array( "status = 'approved'" );
        $params = array();

        if ( (int) $args['category_id'] > 0 ) {
            $where[]  = '( primary_category_id = %d OR secondary_category_id = %d )';
            $params[] = (int) $args['category_id'];
            $params[] = (int) $args['category_id'];
        }
        if ( $args['district'] !== '' ) {
            $where[]  = 'LOWER(district) = %s';
            $params[] = strtolower( $args['district'] );
        }
        if ( $args['tier'] !== '' && in_array( $args['tier'], array( 'new', 'rising', 'pro', 'top_pro' ), true ) ) {
            $where[]  = 'tier = %s';
            $params[] = $args['tier'];
        }
        if ( $args['language'] !== '' ) {
            $where[]  = 'languages LIKE %s';
            $params[] = '%' . $wpdb->esc_like( $args['language'] ) . '%';
        }
        if ( $args['q'] !== '' ) {
            $like     = '%' . $wpdb->esc_like( $args['q'] ) . '%';
            $where[]  = '( full_name LIKE %s OR tagline LIKE %s OR bio LIKE %s )';
            $params[] = $like;
            $params[] = $like;
            $params[] = $like;
        }

        $where_sql = 'WHERE ' . implode( ' AND ', $where );

        // Tier-weighted ranking: top_pro > pro > rising > new, then rating, then volume.
        $order_sql = "ORDER BY FIELD(tier, 'top_pro', 'pro', 'rising', 'new'), avg_rating DESC, total_orders DESC, id DESC";

        $limit  = max( 1, (int) $args['limit'] );
        $offset = max( 0, (int) $args['offset'] );

        $sql_rows  = "SELECT * FROM $table $where_sql $order_sql LIMIT %d OFFSET %d";
        $sql_count = "SELECT COUNT(*) FROM $table $where_sql";

        $row_params = array_merge( $params, array( $limit, $offset ) );

        $rows  = empty( $params )
            ? $wpdb->get_results( $wpdb->prepare( $sql_rows, $limit, $offset ) )
            : $wpdb->get_results( $wpdb->prepare( $sql_rows, $row_params ) );
        $total = empty( $params )
            ? (int) $wpdb->get_var( $sql_count )
            : (int) $wpdb->get_var( $wpdb->prepare( $sql_count, $params ) );

        return array( 'rows' => $rows ?: array(), 'total' => $total );
    }

    /**
     * Distinct districts from approved experts — used for the directory filter.
     */
    public static function distinct_districts() {
        global $wpdb;
        $rows = $wpdb->get_col(
            "SELECT DISTINCT district FROM " . NME_Database::table( 'experts' ) . "
             WHERE status = 'approved' AND district IS NOT NULL AND district != ''
             ORDER BY district ASC"
        );
        return $rows ?: array();
    }

    /**
     * Approve an expert
     */
    public static function approve( $expert_id ) {
        global $wpdb;

        $result = $wpdb->update(
            NME_Database::table( 'experts' ),
            array(
                'status'      => self::STATUS_APPROVED,
                'approved_at' => current_time( 'mysql' ),
                'approved_by' => get_current_user_id(),
            ),
            array( 'id' => $expert_id )
        );

        if ( false === $result ) {
            return false;
        }

        $expert = self::get( $expert_id );

        // Add expert role to the user
        if ( $expert && $expert->user_id ) {
            $user = get_user_by( 'id', $expert->user_id );
            if ( $user ) {
                $user->add_role( NME_Roles::ROLE_EXPERT );
            }
        }

        // Send approval email
        if ( class_exists( 'NME_Emails' ) ) {
            NME_Emails::send_approval_email( $expert );
        }

        NME_Database::audit_log(
            'expert_approved',
            'expert',
            $expert_id,
            array( 'approved_by' => get_current_user_id() )
        );

        return true;
    }

    /**
     * Reject an expert application.
     *
     * Sets status to 'rejected' and records the reason. The row is retained
     * so the applicant can edit their answers and resubmit from their
     * dashboard without losing anything (which would otherwise force them
     * to recreate the whole application from scratch).
     */
    public static function reject( $expert_id, $reason = '' ) {
        global $wpdb;

        $expert_id = (int) $expert_id;
        if ( $expert_id <= 0 ) {
            return false;
        }

        $result = $wpdb->update(
            NME_Database::table( 'experts' ),
            array(
                'status'           => self::STATUS_REJECTED,
                'rejection_reason' => $reason,
            ),
            array( 'id' => $expert_id ),
            array( '%s', '%s' ),
            array( '%d' )
        );

        if ( false === $result ) {
            return false;
        }

        $expert = self::get( $expert_id );
        if ( ! $expert ) {
            return false;
        }

        if ( class_exists( 'NME_Emails' ) ) {
            NME_Emails::send_rejection_email( $expert, $reason );
        }

        NME_Database::audit_log(
            'expert_rejected',
            'expert',
            $expert_id,
            array( 'reason' => $reason )
        );

        return true;
    }

    /**
     * Apply an applicant-driven edit to an existing application and flip
     * the status back to 'pending' so admin review can pick it up again.
     *
     * Intended for the "Edit & Resubmit" dashboard flow. The caller
     * (NME_Registration::handle_edit_application) is responsible for all
     * ownership, capability and field validation BEFORE invoking this.
     *
     * Never updates the `email` column here — email is the identity key that
     * ties the expert row to the underlying WP user, and changing it would
     * orphan the account. Callers must strip `email` from $data.
     *
     * @param int   $expert_id
     * @param array $data  Whitelisted field => value pairs.
     * @return bool
     */
    public static function update_application( $expert_id, array $data ) {
        global $wpdb;

        $expert_id = (int) $expert_id;
        if ( $expert_id <= 0 ) {
            return false;
        }

        // Guard: never allow a resubmit edit to mutate identity-critical fields.
        unset( $data['id'], $data['user_id'], $data['email'], $data['status'], $data['applied_at'] );

        $data['status']           = self::STATUS_PENDING;
        $data['rejection_reason'] = '';
        $data['updated_at']       = current_time( 'mysql' );

        // Only write resubmitted_at if the column exists (added in a later
        // schema version — this method must tolerate older installs so a
        // missed migration doesn't break the edit flow entirely).
        $has_resubmit_col = $wpdb->get_var(
            "SHOW COLUMNS FROM " . NME_Database::table( 'experts' ) . " LIKE 'resubmitted_at'"
        );
        if ( $has_resubmit_col ) {
            $data['resubmitted_at'] = current_time( 'mysql' );
        }

        $result = $wpdb->update(
            NME_Database::table( 'experts' ),
            $data,
            array( 'id' => $expert_id ),
            null,
            array( '%d' )
        );

        if ( false === $result ) {
            return false;
        }

        $expert = self::get( $expert_id );
        if ( $expert && class_exists( 'NME_Emails' ) ) {
            NME_Emails::send_application_resubmitted_admin_notice( $expert );
        }

        NME_Database::audit_log(
            'expert_application_resubmitted',
            'expert',
            $expert_id,
            array( 'fields_updated' => array_keys( $data ) )
        );

        return true;
    }

    /**
     * Self-service profile edit for an already-approved expert.
     *
     * Intentionally separate from update_application() because:
     *   - It must NEVER touch status, user_id, email, or identity/KYC fields
     *   - It must NEVER flip an approved expert back to pending
     *   - It only writes a fixed whitelist of "about me" / public-profile
     *     fields (tagline, bio, languages, portfolio_url, youtube_channel,
     *     facebook_page). Any other keys in $data are silently dropped.
     *
     * Caller is responsible for auth, nonce, ownership, and status=approved.
     *
     * @param int   $expert_id
     * @param array $data  Arbitrary input; only whitelisted keys are written.
     * @return bool
     */
    public static function update_profile_fields( $expert_id, array $data ) {
        global $wpdb;

        $expert_id = (int) $expert_id;
        if ( $expert_id <= 0 ) {
            return false;
        }

        $allowed = array(
            'tagline',
            'bio',
            'languages',
            'portfolio_url',
            'youtube_channel',
            'facebook_page',
        );

        $update = array();
        foreach ( $allowed as $key ) {
            if ( array_key_exists( $key, $data ) ) {
                $update[ $key ] = $data[ $key ];
            }
        }

        if ( empty( $update ) ) {
            return false;
        }

        $update['updated_at'] = current_time( 'mysql' );

        $result = $wpdb->update(
            NME_Database::table( 'experts' ),
            $update,
            array( 'id' => $expert_id ),
            null,
            array( '%d' )
        );

        if ( false === $result ) {
            return false;
        }

        NME_Database::audit_log(
            'expert_profile_self_edited',
            'expert',
            $expert_id,
            array( 'fields_updated' => array_keys( $update ) )
        );

        return true;
    }

    /**
     * Permanently delete a rejected application.
     *
     * Hard-deletes the nme_experts row and, if requested, the underlying WP
     * user. Callers MUST verify capability + status before calling this —
     * only 'rejected' rows should ever be destroyed through this path, so an
     * admin can never accidentally nuke a pending or approved expert.
     *
     * When $delete_wp_user is true, the WP user is only removed if it looks
     * safe to do so: we refuse to delete a user who also has the nme_expert
     * role, or whose ID is 1 (site admin), or who matches the current admin
     * performing the action (self-delete guard).
     *
     * @param int  $expert_id
     * @param bool $delete_wp_user  Whether to also call wp_delete_user().
     * @return bool
     */
    public static function delete( $expert_id, $delete_wp_user = false ) {
        global $wpdb;

        $expert_id = (int) $expert_id;
        if ( $expert_id <= 0 ) {
            return false;
        }

        $expert = self::get( $expert_id );
        if ( ! $expert ) {
            return false;
        }

        $user_id_before = (int) $expert->user_id;
        $email_before   = (string) $expert->email;

        $deleted = $wpdb->delete(
            NME_Database::table( 'experts' ),
            array( 'id' => $expert_id ),
            array( '%d' )
        );

        if ( false === $deleted || 0 === (int) $deleted ) {
            return false;
        }

        $wp_user_deleted = false;
        if ( $delete_wp_user && $user_id_before > 0 ) {
            $user = get_user_by( 'id', $user_id_before );
            $blockers = array();

            if ( ! $user ) {
                $blockers[] = 'user_not_found';
            } else {
                if ( $user_id_before === 1 )                             $blockers[] = 'is_site_admin';
                if ( $user_id_before === (int) get_current_user_id() )   $blockers[] = 'is_current_user';
                if ( in_array( NME_Roles::ROLE_EXPERT, (array) $user->roles, true ) ) {
                    $blockers[] = 'has_expert_role';
                }
            }

            if ( empty( $blockers ) ) {
                require_once ABSPATH . 'wp-admin/includes/user.php';
                $wp_user_deleted = (bool) wp_delete_user( $user_id_before );
            }
        }

        NME_Database::audit_log(
            'expert_application_deleted',
            'expert',
            $expert_id,
            array(
                'email'           => $email_before,
                'user_id'         => $user_id_before,
                'wp_user_deleted' => $wp_user_deleted,
            )
        );

        return true;
    }

    /**
     * Mark expert as a Founding Expert
     */
    public static function mark_as_founding( $expert_id ) {
        global $wpdb;
        return $wpdb->update(
            NME_Database::table( 'experts' ),
            array(
                'is_founding_expert' => 1,
                'commission_rate'    => 0.00,
            ),
            array( 'id' => $expert_id )
        );
    }

    /**
     * Count experts by status
     */
    public static function count_by_status( $status ) {
        global $wpdb;
        return (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM " . NME_Database::table( 'experts' ) . " WHERE status = %s",
            $status
        ) );
    }

    /**
     * Get the tier badge HTML.
     *
     * The legacy tier pill (NEW / Rising / Pro / Top Pro) duplicates the
     * equivalent level chips rendered by the nme-badges plugin (New Expert /
     * Rising Expert / Pro Expert / Top Pro), which landed public-side via
     * apply_filters('nmep_expert_profile_after_name', ...). Showing both at
     * once produced a confusing "NEW" + "New Expert" pair on the dashboard
     * and on directory cards.
     *
     * Resolution: when the badges plugin is active we suppress the legacy
     * pill on the front-end only. Admin screens (expert list, expert detail)
     * continue to render it so operators keep their existing tier column.
     * If the badges plugin is ever deactivated the legacy pill returns
     * automatically — fallback is preserved.
     */
    public static function get_tier_badge( $tier ) {
        if ( ! is_admin() && class_exists( 'NMEB_Engine' ) ) {
            return '';
        }

        $badges = array(
            'new'     => array( 'label' => 'New',     'color' => '#6B7280' ),
            'rising'  => array( 'label' => 'Rising',  'color' => '#10B981' ),
            'pro'     => array( 'label' => 'Pro',     'color' => '#0A7558' ),
            'top_pro' => array( 'label' => 'Top Pro', 'color' => '#D4A843' ),
        );

        $badge = isset( $badges[ $tier ] ) ? $badges[ $tier ] : $badges['new'];

        return sprintf(
            '<span class="nme-tier-badge" style="background:%s;color:#fff;padding:4px 10px;border-radius:50px;font-size:0.7rem;font-weight:700;text-transform:uppercase;letter-spacing:0.05em;">%s</span>',
            esc_attr( $badge['color'] ),
            esc_html( $badge['label'] )
        );
    }
}