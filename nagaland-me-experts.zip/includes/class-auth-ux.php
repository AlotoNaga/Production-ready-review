<?php
/**
 * NME_Auth_UX
 * Login / logout / account UX + role-based menu for the Nagaland Me Experts marketplace.
 *
 * v1.5.0 — Mobile: fix Expert Dashboard horizontal overflow.
 *   - The [nmep_expert_dashboard] header card uses `display:flex` without
 *     flex-wrap, so on narrow screens the profile photo + welcome text +
 *     "+ Create New Service" button all compete on a single row — the
 *     button gets truncated and the page scrolls sideways.
 *   - Fix (CSS-only, scoped to ≤ 768px): force flex-wrap on inline-flex
 *     cards, let flex:1 children shrink below intrinsic width, make tables
 *     scroll horizontally inside their card instead of pushing the page
 *     wider than the viewport, and collapse the 4-col stats grid earlier.
 *   - Purely additive. Desktop behaviour is untouched.
 *
 * v1.4.0 — Mobile: flatten the "Hi, {name}" account dropdown in the hamburger.
 *   - Desktop unchanged (hover dropdown preserved).
 *   - ≤ 920px the parent becomes a non-interactive "YOUR ACCOUNT" section
 *     label; sub-items render as 48px+ full-width rows; caret hidden;
 *     Log Out row gets a muted red tint.
 *   - Fixes: tapping "Hi, {name} ▾" on mobile just navigated to
 *     /expert-dashboard/, leaving Edit Profile / Change Picture / Edit
 *     Bank / KYC / Log Out unreachable from the hamburger.
 *
 * v1.3.1 — FIX: duplicate brand text on wp-login.php.
 *   - brand_login_header_text() now returns '' so the real <a> text is empty
 *     and only the ::after wordmark ("NAGALAND.ME · EXPERTS") is shown.
 *   - Zero other changes vs v1.3.0.
 *
 * v1.3.0 — Premium branded WordPress login page.
 *   - Skins wp-login.php with forest gradient bg, cream card, gold gradient button,
 *     Cormorant Garamond wordmark + inline-SVG brand mark.
 *   - Removes the default "W" WordPress logo and "Go to site" chrome.
 *   - Friendlier error messages (no user enumeration leak).
 *   - Purely additive — existing redirect / menu / logout flow unchanged.
 *
 * v1.2.0 FIXES:
 * - Login redirect: experts/buyers now go to dashboard (not homepage)
 * - block_wp_admin: excludes admin-post.php, REST API, CRON
 * - Expert/buyer menus: added Home link
 *
 * @package NagalandMeExperts
 * @version 1.5.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class NME_Auth_UX {

    public static function init() {
        add_filter( 'login_redirect', array( __CLASS__, 'after_login_redirect' ), 10, 3 );
        add_action( 'wp_logout', array( __CLASS__, 'after_logout_redirect' ) );
        add_action( 'admin_init', array( __CLASS__, 'block_wp_admin_for_non_admins' ) );
        add_filter( 'show_admin_bar', array( __CLASS__, 'hide_admin_bar_for_non_admins' ) );
        add_filter( 'wp_nav_menu_objects', array( __CLASS__, 'filter_menu_for_role' ), 10, 2 );
        add_filter( 'wp_nav_menu_items', array( __CLASS__, 'append_auth_menu_item' ), 10, 2 );
        add_action( 'wp_footer', array( __CLASS__, 'maybe_show_logout_toast' ) );

        // v1.3.0 — premium branded wp-login.php
        add_action( 'login_enqueue_scripts', array( __CLASS__, 'brand_login_page' ), 99 );
        add_filter( 'login_headerurl',  array( __CLASS__, 'brand_login_header_url' ) );
        add_filter( 'login_headertext', array( __CLASS__, 'brand_login_header_text' ) );
        add_filter( 'login_errors',     array( __CLASS__, 'friendly_login_errors' ) );
        add_filter( 'login_body_class', array( __CLASS__, 'add_login_body_class' ), 10, 2 );

        // v1.4.0 — flatten the "Hi, {name}" account dropdown on mobile so
        // users can actually reach Edit Profile / Change Picture / Edit Bank /
        // KYC / Log Out from the hamburger. On touch devices there's no hover
        // to open the desktop dropdown, and Astra's mobile menu doesn't inject
        // a toggle arrow for items added via wp_nav_menu_items — so taps on
        // the parent were just navigating to /expert-dashboard/ and hiding
        // the rest of the options. Priority 20 so our rules land AFTER Astra's
        // theme styles in the cascade.
        add_action( 'wp_head', array( __CLASS__, 'inject_mobile_menu_styles' ), 20 );

        // v1.5.0 — fix Expert Dashboard horizontal overflow on mobile. The
        // [nmep_expert_dashboard] shortcode lives in build/ (no patches
        // counterpart) and its header card is `display:flex` without
        // flex-wrap, so we can't edit the markup from here — instead inject
        // scoped CSS overrides that make inline-flex cards wrap, let flex
        // children shrink, scroll long tables, and collapse the 4-col stats
        // grid earlier. Priority 20 so our rules land after theme CSS.
        add_action( 'wp_head', array( __CLASS__, 'inject_dashboard_responsive_styles' ), 20 );
    }

    /* ================================================================
       LOGIN REDIRECT
       v1.2.0 FIX: Ignore homepage as redirect_to so role-based
       redirect always fires for homepage logins.
       Deep-link redirects (e.g., /services/xyz/) still honored.
       ================================================================ */
    public static function after_login_redirect( $redirect_to, $requested_redirect_to, $user ) {
        if ( is_wp_error( $user ) ) {
            return $redirect_to;
        }

        // Honor specific page redirects (NOT homepage, NOT wp-admin, NOT wp-login)
        if (
            ! empty( $requested_redirect_to ) &&
            strpos( $requested_redirect_to, 'wp-admin' ) === false &&
            strpos( $requested_redirect_to, 'wp-login' ) === false &&
            rtrim( $requested_redirect_to, '/' ) !== rtrim( home_url(), '/' ) &&
            $requested_redirect_to !== home_url( '/' )
        ) {
            return $requested_redirect_to;
        }

        // Role-based redirect
        if ( user_can( $user, 'manage_options' ) ) {
            return admin_url();
        }

        if ( in_array( 'nme_expert', (array) $user->roles, true ) ) {
            return home_url( '/expert-dashboard/' );
        }

        if (
            in_array( 'nme_buyer', (array) $user->roles, true ) ||
            in_array( 'subscriber', (array) $user->roles, true )
        ) {
            return home_url( '/my-orders/' );
        }

        return home_url( '/' );
    }

    /* ================================================================
       LOGOUT REDIRECT
       ================================================================ */
    public static function after_logout_redirect() {
        wp_safe_redirect( home_url( '/?logged_out=1' ) );
        exit;
    }

    /* ================================================================
       BLOCK WP-ADMIN FOR NON-ADMINS
       v1.2.0 FIX: Exclude admin-post.php (form submissions),
       REST API, and CRON so forms + API calls work properly.
       ================================================================ */
    public static function block_wp_admin_for_non_admins() {
        // Never block AJAX, CRON, or REST API
        if ( defined( 'DOING_AJAX' ) && DOING_AJAX ) return;
        if ( defined( 'DOING_CRON' ) && DOING_CRON ) return;
        if ( defined( 'REST_REQUEST' ) && REST_REQUEST ) return;

        // Never block admin-post.php (all frontend form submissions use this)
        if ( isset( $_SERVER['SCRIPT_NAME'] ) ) {
            $script = basename( $_SERVER['SCRIPT_NAME'] );
            if ( $script === 'admin-post.php' ) return;
        }

        if ( ! is_user_logged_in() ) return;

        $user = wp_get_current_user();
        if ( user_can( $user, 'manage_options' ) ) return;
        if ( user_can( $user, 'edit_posts' ) ) return;

        if ( in_array( 'nme_expert', (array) $user->roles, true ) ) {
            wp_safe_redirect( home_url( '/expert-dashboard/' ) );
            exit;
        }

        wp_safe_redirect( home_url( '/my-orders/' ) );
        exit;
    }

    /* ================================================================
       HIDE ADMIN BAR
       ================================================================ */
    public static function hide_admin_bar_for_non_admins( $show ) {
        if ( ! is_user_logged_in() ) return $show;
        $user = wp_get_current_user();
        if ( user_can( $user, 'edit_posts' ) ) return $show;
        return false;
    }

    /* ================================================================
       SMART MENU — Replace items based on role
       ================================================================ */
    public static function filter_menu_for_role( $items, $args ) {
        if ( is_admin() ) return $items;
        if ( ! is_user_logged_in() ) return $items;

        $user = wp_get_current_user();
        if ( user_can( $user, 'manage_options' ) ) return $items;

        $allowed_locations = array(
    'primary', 'menu_1', 'main', 'header', 'top',
    'mobile_menu', 'ast-hf-mobile-menu', 'ast-hf-menu-1',
    'ast-hf-menu-2', 'ast-desktop-header-menu', 'ast-mobile-header-menu',
);
        $location = isset( $args->theme_location ) ? $args->theme_location : '';
        if ( ! empty( $location ) && ! in_array( $location, $allowed_locations, true ) ) {
            return $items;
        }

        if ( in_array( 'nme_expert', (array) $user->roles, true ) ) {
            return self::build_expert_menu_items();
        }

        if (
            in_array( 'nme_buyer', (array) $user->roles, true ) ||
            in_array( 'subscriber', (array) $user->roles, true )
        ) {
            return self::build_buyer_menu_items();
        }

        return $items;
    }

    /**
     * v1.2.0: Added Home link for experts
     */
    private static function build_expert_menu_items() {
        return array(
            self::menu_item( 'Home', home_url( '/' ), 1, 0 ),
            self::menu_item( 'Dashboard', home_url( '/expert-dashboard/' ), 2, 0 ),
            self::menu_item( 'Browse Services', home_url( '/services/' ), 3, 0 ),
            self::menu_item( 'Categories', home_url( '/categories/' ), 4, 0 ),
        );
    }

    /**
     * v1.2.0: Added Home link for buyers
     */
    private static function build_buyer_menu_items() {
        return array(
            self::menu_item( 'Home', home_url( '/' ), 1, 0 ),
            self::menu_item( 'Browse Services', home_url( '/services/' ), 2, 0 ),
            self::menu_item( 'Categories', home_url( '/categories/' ), 3, 0 ),
            self::menu_item( 'My Orders', home_url( '/my-orders/' ), 4, 0 ),
        );
    }

    private static function menu_item( $title, $url, $id, $parent = 0 ) {
        $item = new stdClass();
        $item->ID            = (int) $id;
        $item->db_id         = (int) $id;
        $item->menu_item_parent = (string) $parent;
        $item->object_id     = (int) $id;
        $item->object        = 'custom';
        $item->type          = 'custom';
        $item->type_label    = 'Custom Link';
        $item->title         = $title;
        $item->url           = $url;
        $item->target        = '';
        $item->attr_title    = '';
        $item->description   = '';
        $item->classes       = array( 'menu-item', 'menu-item-type-custom', 'nme-dynamic-menu-item' );
        $item->xfn           = '';
        $item->current       = false;
        $item->current_item_ancestor = false;
        $item->current_item_parent   = false;
        return $item;
    }

    /* ================================================================
       APPEND AUTH ITEM (Log In OR Hi, Name ▾)
       ================================================================ */
    public static function append_auth_menu_item( $items, $args ) {
        $allowed_locations = array(
    'primary', 'menu_1', 'main', 'header', 'top',
    'mobile_menu', 'ast-hf-mobile-menu', 'ast-hf-menu-1',
    'ast-hf-menu-2', 'ast-desktop-header-menu', 'ast-mobile-header-menu',
);
        if (
            isset( $args->theme_location ) &&
            ! empty( $args->theme_location ) &&
            ! in_array( $args->theme_location, $allowed_locations, true )
        ) {
            return $items;
        }

        if ( ! is_user_logged_in() ) {
            $login_url = wp_login_url( home_url( $_SERVER['REQUEST_URI'] ?? '/' ) );
            $items .= '<li class="menu-item nme-auth-menu-item nme-login-item"><a href="' . esc_url( $login_url ) . '">Log In</a></li>';
            return $items;
        }

        $user = wp_get_current_user();
        $first_name = $user->first_name ?: $user->display_name ?: 'Account';

        $dashboard_url = home_url( '/' );
        $dashboard_label = 'My Account';
        $is_expert = false;
        $is_buyer = false;
        $is_applicant = false;
        $applicant_status = '';

        // Detect rejected / pending applicants (no nme_expert role yet).
        // They need a path back to /expert-dashboard/ (status panel) and,
        // when rejected, /edit-application/ to resubmit. Without this, the
        // header falls through to the buyer branch and hides those links.
        $applicant_row = null;
        if (
            class_exists( 'NME_Experts' ) &&
            ! in_array( 'nme_expert', (array) $user->roles, true ) &&
            ! user_can( $user, 'manage_options' )
        ) {
            $applicant_row = NME_Experts::get_by_user( $user->ID );
            if ( $applicant_row && in_array( $applicant_row->status, array( 'pending', 'rejected' ), true ) ) {
                $is_applicant     = true;
                $applicant_status = $applicant_row->status;
            }
        }

        if ( user_can( $user, 'manage_options' ) ) {
            $dashboard_url = admin_url();
            $dashboard_label = 'WP Admin';
        } elseif ( in_array( 'nme_expert', (array) $user->roles, true ) ) {
            $dashboard_url = home_url( '/expert-dashboard/' );
            $dashboard_label = 'Dashboard';
            $is_expert = true;
        } elseif ( $is_applicant ) {
            $dashboard_url   = home_url( '/expert-dashboard/' );
            $dashboard_label = 'Dashboard';
        } elseif (
            in_array( 'nme_buyer', (array) $user->roles, true ) ||
            in_array( 'subscriber', (array) $user->roles, true )
        ) {
            $dashboard_url = home_url( '/my-orders/' );
            $dashboard_label = 'My Orders';
            $is_buyer = true;
        }

        $logout_url = wp_logout_url( home_url( '/' ) );

        $sub_items = '';
        $sub_items .= '<li class="menu-item"><a href="' . esc_url( $dashboard_url ) . '">' . esc_html( $dashboard_label ) . '</a></li>';

        if ( $is_expert ) {
            $sub_items .= '<li class="menu-item"><a href="' . esc_url( home_url( '/expert-dashboard/?action=new' ) ) . '">+ Create Service</a></li>';
            $sub_items .= '<li class="menu-item"><a href="' . esc_url( home_url( '/edit-profile/' ) ) . '">✏️ Edit About &amp; Bio</a></li>';
            $sub_items .= '<li class="menu-item"><a href="' . esc_url( home_url( '/change-profile-photo/' ) ) . '">Change Profile Picture</a></li>';
            $sub_items .= '<li class="menu-item"><a href="' . esc_url( home_url( '/edit-bank-account/' ) ) . '">Edit Bank Account</a></li>';
            $sub_items .= '<li class="menu-item"><a href="' . esc_url( home_url( '/edit-address/' ) ) . '">Update Address</a></li>';

            // v0.6.0 — KYC entry with status-aware label so first-time experts
            // see a loud call-to-action and returning experts can re-check their
            // verification state without digging through the dashboard.
            $kyc_label  = 'KYC &amp; Documents';
            $kyc_status = 'not_started';
            if ( class_exists( 'NME_Experts' ) ) {
                $expert_row = NME_Experts::get_by_user( $user->ID );
                if ( $expert_row && ! empty( $expert_row->kyc_status ) ) {
                    $kyc_status = $expert_row->kyc_status;
                }
            }
            switch ( $kyc_status ) {
                case 'submitted':
                    $kyc_label = '⏳ KYC Under Review';
                    break;
                case 'verified':
                    $kyc_label = '🛡️ KYC &amp; Documents';
                    break;
                case 'rejected':
                    $kyc_label = '❌ KYC Rejected — Re-submit';
                    break;
                case 'not_started':
                default:
                    $kyc_label = '⚠️ Complete KYC';
                    break;
            }
            $sub_items .= '<li class="menu-item"><a href="' . esc_url( home_url( '/kyc/' ) ) . '">' . $kyc_label . '</a></li>';
        }

        if ( $is_applicant ) {
            if ( $applicant_status === 'rejected' ) {
                $sub_items .= '<li class="menu-item"><a href="' . esc_url( home_url( '/edit-application/' ) ) . '">🔄 Edit &amp; Resubmit Application</a></li>';
            } else {
                $sub_items .= '<li class="menu-item"><a href="' . esc_url( home_url( '/expert-dashboard/' ) ) . '">⏳ Application Status</a></li>';
            }
            $sub_items .= '<li class="menu-item"><a href="' . esc_url( home_url( '/services/' ) ) . '">Browse Services</a></li>';
        }

        if ( $is_buyer || $is_expert ) {
            $sub_items .= '<li class="menu-item"><a href="' . esc_url( home_url( '/services/' ) ) . '">Browse Services</a></li>';
        }

        // v0.7.2 — Premium Buyer entry (buyers only; experts are out of scope for Phase 1).
        // Label reflects membership state: new-user CTA, active status, or renew prompt.
        // Active/expired members land on /my-account/premium/ (status panel); prospects
        // land on /buyer-premium/ (sales landing) so each screen fits the audience.
        if ( $is_buyer && class_exists( 'NMEP_Buyer_Premium' ) && (bool) NMEP_Settings::get( 'premium_buyer_enabled', true ) ) {
            $premium_label = '⭐ Go Premium';
            $premium_url   = home_url( '/buyer-premium/' );

            $active_record = NMEP_Buyer_Premium::get_active_record( $user->ID );
            if ( $active_record ) {
                $premium_label = '⭐ Premium · Active';
                $premium_url   = home_url( '/my-account/premium/' );
            } else {
                // Any non-active record at all (expired/past) → show Renew instead of Go.
                global $wpdb;
                $has_past = (int) $wpdb->get_var( $wpdb->prepare(
                    "SELECT COUNT(*) FROM " . NMEP_Buyer_Premium::table( 'buyer_premium' ) . "
                     WHERE user_id = %d AND is_active = 1",
                    (int) $user->ID
                ) );
                if ( $has_past > 0 ) {
                    $premium_label = '⭐ Renew Premium';
                    $premium_url   = home_url( '/my-account/premium/' );
                }
            }

            $sub_items .= '<li class="menu-item nme-premium-item"><a href="' . esc_url( $premium_url ) . '">' . $premium_label . '</a></li>';
        }

        $sub_items .= '<li class="menu-item"><a href="' . esc_url( $logout_url ) . '">Log Out</a></li>';

        $items .= '
        <li class="menu-item menu-item-has-children nme-auth-menu-item nme-account-item">
            <a href="' . esc_url( $dashboard_url ) . '">Hi, ' . esc_html( $first_name ) . ' <span class="nme-caret" aria-hidden="true">▾</span></a>
            <ul class="sub-menu">' . $sub_items . '</ul>
        </li>';

        return $items;
    }

    /* ================================================================
       v1.4.0 — MOBILE ACCOUNT MENU FLATTEN
       Desktop: the "Hi, {name} ▾" item keeps its hover dropdown.
       Mobile (≤ 920px, Astra's hamburger breakpoint): the dropdown is
       force-expanded as a flat list inside the hamburger, the parent
       link becomes a non-interactive "YOUR ACCOUNT" section label,
       the caret is hidden, sub-items get 48px+ tap targets, and the
       Log Out row gets a subtle red tint so it's distinguishable.
       Selectors are scoped to .nme-account-item so no other menu or
       page chrome is affected.
       ================================================================ */
    public static function inject_mobile_menu_styles() {
        ?>
<style id="nme-mobile-account-menu">
@media (max-width: 920px) {
    /* Parent "Hi, {name}" row → static section label, not tappable. */
    .nme-account-item > a {
        pointer-events: none !important;
        cursor: default !important;
        color: rgba(15, 36, 25, 0.55) !important;
        font-family: 'Outfit', system-ui, -apple-system, Segoe UI, Roboto, sans-serif !important;
        font-size: 0.72rem !important;
        font-weight: 700 !important;
        letter-spacing: 0.09em !important;
        text-transform: uppercase !important;
        padding: 22px 20px 8px !important;
        margin-top: 6px !important;
        border-top: 1px solid rgba(15, 36, 25, 0.08) !important;
        background: transparent !important;
    }
    /* Hide the dropdown caret on mobile — nothing to drop down anymore. */
    .nme-account-item .nme-caret {
        display: none !important;
    }
    /* Always expand the sub-menu as a flat block, override any theme
       hide/position rules Astra applied. */
    .nme-account-item .sub-menu,
    .nme-account-item ul.sub-menu {
        display: block !important;
        position: static !important;
        visibility: visible !important;
        opacity: 1 !important;
        transform: none !important;
        box-shadow: none !important;
        background: transparent !important;
        width: 100% !important;
        min-width: 0 !important;
        padding: 0 !important;
        margin: 0 !important;
        border: 0 !important;
        left: auto !important;
        top: auto !important;
    }
    .nme-account-item .sub-menu > li {
        display: block !important;
        list-style: none !important;
        margin: 0 !important;
        padding: 0 !important;
        background: transparent !important;
    }
    /* Touch-friendly rows (48px+ tap target) matching top-level nav. */
    .nme-account-item .sub-menu > li > a {
        display: flex !important;
        align-items: center !important;
        padding: 15px 20px !important;
        min-height: 48px !important;
        font-family: inherit !important;
        font-size: 1rem !important;
        font-weight: 500 !important;
        color: #0F2419 !important;
        text-decoration: none !important;
        border-bottom: 1px solid rgba(15, 36, 25, 0.06) !important;
        background: transparent !important;
        line-height: 1.35 !important;
    }
    .nme-account-item .sub-menu > li > a:hover,
    .nme-account-item .sub-menu > li > a:focus {
        background: rgba(10, 117, 88, 0.06) !important;
        color: #0A7558 !important;
    }
    /* Premium row keeps its gold accent. */
    .nme-account-item .sub-menu > li.nme-premium-item > a {
        color: #8A6B1C !important;
        font-weight: 600 !important;
    }
    /* Log Out row — subtle red so it stands apart from regular actions,
       no hard top border (the row above already has a bottom border). */
    .nme-account-item .sub-menu > li:last-child > a {
        color: #9B2C2C !important;
        border-bottom: 0 !important;
    }
    .nme-account-item .sub-menu > li:last-child > a:hover,
    .nme-account-item .sub-menu > li:last-child > a:focus {
        background: rgba(155, 44, 44, 0.06) !important;
        color: #7F1D1D !important;
    }
}
</style>
        <?php
    }

    /* ================================================================
       v1.5.0 — EXPERT DASHBOARD MOBILE OVERFLOW FIX
       The dashboard shortcode ([nmep_expert_dashboard]) renders several
       cards whose inline styles use `display:flex` without flex-wrap,
       tables with 6+ columns, and a 4-col stats grid. On phones this
       pushes the page wider than the viewport (you can pinch-zoom out
       and see the right edge). Since that shortcode only lives in the
       payments plugin's build/ tree (no patches counterpart), we patch
       the symptom here with scoped mobile-only CSS.

       Selectors deliberately match inline-style substrings rather than
       dashboard-only classes so the rules also help other card layouts
       (service view, active orders, admin tools) without needing markup
       changes to those templates.
       ================================================================ */
    public static function inject_dashboard_responsive_styles() {
        ?>
<style id="nme-dashboard-responsive">
@media (max-width: 768px) {
    /* Any .nme-card rendered as an inline flex row (header strip, active
       order rows, profile photo + meta strips) wraps its children so a
       long button can't push the row past the viewport edge. */
    .nme-card[style*="display: flex"],
    .nme-card[style*="display:flex"] {
        flex-wrap: wrap !important;
    }
    /* Flex children declared `flex:1` default to min-width:auto which
       refuses to shrink below the intrinsic text width — on 360px phones
       with a long welcome text + link, that alone can blow the layout.
       Force them to the full row on mobile. */
    .nme-card > div[style*="flex:1"],
    .nme-card > div[style*="flex: 1"] {
        min-width: 0 !important;
        flex-basis: 100% !important;
    }
    /* Tables inside cards (services list, recent orders, active orders)
       scroll horizontally inside their card rather than forcing the card
       — and therefore the page — wider than the viewport. */
    .nme-card table {
        display: block !important;
        width: 100% !important;
        max-width: 100% !important;
        overflow-x: auto !important;
        -webkit-overflow-scrolling: touch;
    }
    /* The 4-col stats grid (Total Earnings / In Escrow / Completed /
       Rating) is unreadable at 4 columns on phone width. The existing
       frontend.css only collapses it at ≤ 640px which still leaves the
       641-768px zone cramped. Collapse earlier. */
    .nme-grid.nme-grid-4 {
        display: grid !important;
        grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
        gap: 12px !important;
    }
    /* Active-order rows use `min-width:240px` on their flex column; on
       narrow phones that forces expansion. Drop the min-width. */
    .nme-card [style*="min-width: 240px"],
    .nme-card [style*="min-width:240px"] {
        min-width: 0 !important;
    }
}

@media (max-width: 420px) {
    /* At iPhone-SE widths, 2-column stats are still cramped — stack. */
    .nme-grid.nme-grid-4 {
        grid-template-columns: 1fr !important;
    }
    /* Shrink header-card profile photos slightly so the welcome text
       has more room before wrapping. */
    .nme-card img[style*="border-radius: 50%"],
    .nme-card img[style*="border-radius:50%"] {
        width: 56px !important;
        height: 56px !important;
    }
}
</style>
        <?php
    }

    /* ================================================================
       FRIENDLY LOGOUT TOAST
       ================================================================ */
    public static function maybe_show_logout_toast() {
        if ( empty( $_GET['logged_out'] ) ) return;
        ?>
        <div id="nme-logout-toast" style="position: fixed; bottom: 30px; right: 30px; background: #0F2419; color: #fff; padding: 16px 24px; border-radius: 12px; box-shadow: 0 8px 24px rgba(0,0,0,0.2); z-index: 9999; font-family: Arial, sans-serif; max-width: 320px;">
            <div style="display: flex; align-items: center; gap: 12px;">
                <span style="font-size: 1.4rem;">👋</span>
                <div>
                    <strong style="display: block; margin-bottom: 4px;">You've been logged out</strong>
                    <span style="font-size: 0.85rem; opacity: 0.85;">Come back anytime!</span>
                </div>
            </div>
        </div>
        <script>
        setTimeout(function(){
            var t = document.getElementById('nme-logout-toast');
            if (t) {
                t.style.transition = 'opacity 0.5s';
                t.style.opacity = '0';
                setTimeout(function(){ t.remove(); }, 500);
            }
        }, 5000);
        </script>
        <?php
    }

    /* ================================================================
       v1.3.0 — PREMIUM BRANDED WP-LOGIN PAGE
       Skins wp-login.php to match experts.nagaland.me brand.
       ================================================================ */

    /** Make the login-page logo link to the site home (not wordpress.org). */
    public static function brand_login_header_url() {
        return home_url( '/' );
    }

    /**
     * v1.3.1 FIX: Return empty string so the real <a> text is blank and the
     * ::after pseudo-element ("NAGALAND.ME · EXPERTS") is the only wordmark
     * visible. Previously returned 'Nagaland Me Experts' which caused the
     * brand name to appear twice side-by-side.
     */
    public static function brand_login_header_text() {
        return '';
    }

    /** Add a custom body class so our CSS can target scope precisely. */
    public static function add_login_body_class( $classes, $action ) {
        $classes[] = 'nme-login';
        $classes[] = 'nme-login-' . sanitize_html_class( (string) $action );
        return $classes;
    }

    /**
     * Sanitise WP's leaky login errors (prevents username enumeration) and
     * rewrite the few common ones in plain, on-brand language.
     */
    public static function friendly_login_errors( $error ) {
        if ( empty( $error ) ) return $error;

        $lower = strtolower( wp_strip_all_tags( $error ) );

        if (
            strpos( $lower, 'incorrect password' )     !== false ||
            strpos( $lower, 'unknown username' )       !== false ||
            strpos( $lower, 'invalid username' )       !== false ||
            strpos( $lower, 'the username' )           !== false ||
            strpos( $lower, 'not registered' )         !== false
        ) {
            return '<strong>We couldn&rsquo;t sign you in.</strong> Please check your email and password and try again.';
        }

        if ( strpos( $lower, 'empty password' ) !== false ) {
            return '<strong>Please enter your password.</strong>';
        }

        if ( strpos( $lower, 'empty username' ) !== false ) {
            return '<strong>Please enter your email or username.</strong>';
        }

        return $error;
    }

    /**
     * Inject the premium brand skin onto wp-login.php.
     * Pure CSS — no markup rewrites, no JS dependency.
     */
    public static function brand_login_page() {
        ?>
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@500;600;700&family=Outfit:wght@400;500;600;700&display=swap">
        <style id="nme-login-skin">
            /* ===== Page background: forest radial with subtle gold + emerald bloom ===== */
            body.login {
                background: radial-gradient(ellipse at 50% 0%, #0A7558 0%, #0F2419 55%, #050D08 100%) !important;
                min-height: 100vh;
                font-family: 'Outfit', system-ui, -apple-system, Segoe UI, Roboto, sans-serif;
            }
            body.login::before {
                content: '';
                position: fixed;
                inset: 0;
                background-image:
                    radial-gradient(circle at 20% 30%, rgba(212,168,67,0.07), transparent 45%),
                    radial-gradient(circle at 80% 80%, rgba(16,185,129,0.06), transparent 45%);
                pointer-events: none;
                z-index: 0;
            }
            #login { position: relative; z-index: 1; padding-top: 7vh; width: 360px; }

            /* ===== Brand wordmark replacing the WP logo ===== */
            #login h1 { margin: 0 0 26px; text-align: center; }
            #login h1 a {
                background: none !important;
                text-indent: 0 !important;
                width: auto !important;
                height: auto !important;
                min-height: 0 !important;
                overflow: visible !important;
                display: inline-flex !important;
                align-items: center;
                justify-content: center;
                gap: 10px;
                color: #FAF7F0 !important;
                font-family: 'Cormorant Garamond', Georgia, serif !important;
                font-size: 1.95rem;
                font-weight: 600;
                letter-spacing: 0.035em;
                line-height: 1;
                text-decoration: none !important;
                outline: 0 !important;
                box-shadow: none !important;
            }
            #login h1 a::before {
                content: '';
                width: 40px;
                height: 40px;
                flex: 0 0 40px;
                border-radius: 11px;
                background: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 40 40'><defs><linearGradient id='g' x1='0' y1='0' x2='1' y2='1'><stop offset='0' stop-color='%230A7558'/><stop offset='1' stop-color='%2310B981'/></linearGradient></defs><rect width='40' height='40' rx='10' fill='url(%23g)'/><path d='M11 20 L17 26 L29 13' stroke='%23D4A843' stroke-width='3.2' stroke-linecap='round' stroke-linejoin='round' fill='none'/></svg>") center/contain no-repeat;
                box-shadow: 0 6px 18px rgba(16,185,129,0.35);
            }
            #login h1 a::after {
                content: 'NAGALAND.ME EXPERTS';
            }

            /* ===== Card ===== */
            #loginform, #registerform, #lostpasswordform, #resetpassform {
                background: #FAF7F0 !important;
                border: 0 !important;
                border-radius: 20px !important;
                box-shadow: 0 24px 60px rgba(0,0,0,0.38), 0 2px 6px rgba(0,0,0,0.25) !important;
                padding: 32px 28px 28px !important;
                position: relative;
                overflow: hidden;
            }
            #loginform::before, #registerform::before, #lostpasswordform::before, #resetpassform::before {
                content: '';
                position: absolute;
                top: 0; left: 0; right: 0;
                height: 4px;
                background: linear-gradient(90deg, #D4A843 0%, #10B981 50%, #D4A843 100%);
            }

            /* ===== Labels + inputs ===== */
            .login label {
                color: #0F2419 !important;
                font-family: 'Outfit', sans-serif !important;
                font-weight: 500 !important;
                font-size: 0.92rem !important;
            }
            .login input[type="text"],
            .login input[type="password"],
            .login input[type="email"] {
                background: #fff !important;
                border: 1.5px solid rgba(15,36,25,0.15) !important;
                border-radius: 10px !important;
                padding: 11px 14px !important;
                font-family: 'Outfit', sans-serif !important;
                font-size: 0.98rem !important;
                color: #0F2419 !important;
                box-shadow: none !important;
                transition: border-color 0.15s ease, box-shadow 0.15s ease;
            }
            .login input[type="text"]:focus,
            .login input[type="password"]:focus,
            .login input[type="email"]:focus {
                border-color: #0A7558 !important;
                box-shadow: 0 0 0 3px rgba(10,117,88,0.12) !important;
                outline: none !important;
            }
            .login .wp-pwd { position: relative; }
            .login .wp-pwd button.wp-hide-pw {
                color: rgba(15,36,25,0.55) !important;
                top: 2px !important;
            }
            .login .wp-pwd button.wp-hide-pw:hover { color: #0A7558 !important; }

            /* ===== Primary button ===== */
            .login .button-primary,
            .login input[type="submit"] {
                background: linear-gradient(135deg, #D4A843 0%, #B8902F 100%) !important;
                border: 0 !important;
                border-radius: 11px !important;
                color: #0F2419 !important;
                font-family: 'Outfit', sans-serif !important;
                font-weight: 600 !important;
                font-size: 1rem !important;
                letter-spacing: 0.02em !important;
                padding: 12px 20px !important;
                text-shadow: none !important;
                box-shadow: 0 5px 16px rgba(212,168,67,0.38) !important;
                transition: transform 0.15s ease, box-shadow 0.15s ease, filter 0.15s ease !important;
                width: 100% !important;
                height: auto !important;
                line-height: 1.2 !important;
                float: none !important;
            }
            .login .button-primary:hover,
            .login input[type="submit"]:hover {
                transform: translateY(-1px);
                box-shadow: 0 8px 22px rgba(212,168,67,0.5) !important;
                filter: brightness(1.03);
            }
            .login .button-primary:active,
            .login input[type="submit"]:active { transform: translateY(0); }

            /* ===== "Remember me" + submit row ===== */
            .login .forgetmenot { margin: 4px 0 14px; }
            .login .forgetmenot label {
                font-size: 0.88rem !important;
                color: rgba(15,36,25,0.75) !important;
                display: inline-flex;
                align-items: center;
                gap: 6px;
            }
            .login .submit { padding-top: 0 !important; }

            /* ===== Nav links below the card (Register / Lost password / Back) ===== */
            .login #nav, .login #backtoblog {
                text-align: center;
                padding: 0;
                margin: 14px 0 0;
            }
            .login #nav a, .login #backtoblog a {
                color: #FAF7F0 !important;
                text-decoration: none;
                font-family: 'Outfit', sans-serif !important;
                font-size: 0.9rem !important;
                opacity: 0.85;
                transition: opacity 0.15s, color 0.15s;
                text-shadow: 0 1px 6px rgba(0,0,0,0.25);
            }
            .login #nav a:hover, .login #backtoblog a:hover {
                opacity: 1;
                color: #D4A843 !important;
            }
            .login .privacy-policy-page-link {
                text-align: center;
                margin-top: 18px;
            }
            .login .privacy-policy-page-link a {
                color: rgba(250,247,240,0.7) !important;
                font-size: 0.85rem !important;
                text-decoration: none;
            }
            .login .privacy-policy-page-link a:hover { color: #D4A843 !important; }

            /* ===== Error / message banners ===== */
            .login .message, .login #login_error, .login .success, .login .notice {
                border-radius: 12px !important;
                border: 0 !important;
                border-left: 4px solid transparent !important;
                font-family: 'Outfit', sans-serif !important;
                font-size: 0.92rem !important;
                padding: 12px 16px !important;
                box-shadow: 0 6px 18px rgba(0,0,0,0.22) !important;
                margin-bottom: 18px !important;
            }
            .login #login_error {
                background: #FEF2F2 !important;
                border-left-color: #DC2626 !important;
                color: #7F1D1D !important;
            }
            .login .message, .login .success, .login .notice {
                background: #ECFDF5 !important;
                border-left-color: #10B981 !important;
                color: #065F46 !important;
            }

            /* ===== Hide WP language switcher to keep the page uncluttered ===== */
            .login .language-switcher { display: none !important; }

            /* ===== Mobile ===== */
            @media (max-width: 480px) {
                #login { width: 92%; max-width: 360px; padding-top: 5vh; }
                #login h1 a { font-size: 1.65rem; gap: 8px; }
                #login h1 a::before { width: 34px; height: 34px; flex-basis: 34px; }
                #loginform, #registerform, #lostpasswordform, #resetpassform {
                    padding: 26px 20px 22px !important;
                    border-radius: 16px !important;
                }
            }
        </style>
        <?php
    }
}