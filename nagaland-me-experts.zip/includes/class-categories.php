<?php
/**
 * NME_Categories
 * Manages the marketplace categories and seeds default data.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class NME_Categories {

    /**
     * Get the default 8 launch categories
     */
    public static function default_categories() {
        return array(
            array(
                'slug' => 'youtube-monetization',
                'name' => 'YouTube Monetization & AdSense',
                'icon' => '💰',
                'description' => 'AdSense PIN verification, monetization eligibility, ads not showing fixes, tax forms, strike recovery, and payment troubleshooting.',
                'sort_order' => 1,
            ),
            array(
                'slug' => 'facebook-monetization',
                'name' => 'Facebook Page Monetization',
                'icon' => '📘',
                'description' => 'In-stream ads, Reels Play bonus, page eligibility, Stars setup, subscriptions, and brand collab manager.',
                'sort_order' => 2,
            ),
            array(
                'slug' => 'channel-setup',
                'name' => 'Channel Setup & Optimization',
                'icon' => '🚀',
                'description' => 'New YouTube/Facebook channel creation, branding, SEO, playlist organization, and About page optimization.',
                'sort_order' => 3,
            ),
            array(
                'slug' => 'thumbnail-design',
                'name' => 'Thumbnail Design',
                'icon' => '🎨',
                'description' => 'Custom thumbnails, packs (5/10/20), templates, A/B test variants, and illustrated thumbnails.',
                'sort_order' => 4,
            ),
            array(
                'slug' => 'video-editing',
                'name' => 'Video Editing',
                'icon' => '🎬',
                'description' => 'Reels, Shorts, vlogs, tutorials, music videos, captions, color grading, and audio cleanup.',
                'sort_order' => 5,
            ),
            array(
                'slug' => 'animations',
                'name' => 'Subscribe / Bell / Animations',
                'icon' => '🔔',
                'description' => 'Custom subscribe, bell notification, end screen, intro, outro, and lower thirds animations.',
                'sort_order' => 6,
            ),
            array(
                'slug' => 'tax-pin-help',
                'name' => 'Tax & PIN Verification',
                'icon' => '📋',
                'description' => 'Indian creator tax filing, W-8BEN forms, AdSense PIN, GST guidance, and TDS understanding.',
                'sort_order' => 7,
            ),
            array(
                'slug' => 'channel-audit',
                'name' => 'Channel Audit & Strategy',
                'icon' => '📊',
                'description' => 'Full audits, content strategy, niche selection, competitor analysis, growth calls, and monetization roadmaps.',
                'sort_order' => 8,
            ),
        );
    }

    /**
     * Insert default categories into database (idempotent)
     */
    public static function seed_categories() {
        global $wpdb;
        $table = NME_Database::table( 'categories' );

        foreach ( self::default_categories() as $cat ) {
            $exists = $wpdb->get_var( $wpdb->prepare(
                "SELECT id FROM $table WHERE slug = %s",
                $cat['slug']
            ) );

            if ( ! $exists ) {
                $wpdb->insert( $table, array(
                    'slug'        => $cat['slug'],
                    'name'        => $cat['name'],
                    'icon'        => $cat['icon'],
                    'description' => $cat['description'],
                    'sort_order'  => $cat['sort_order'],
                    'is_active'   => 1,
                ) );
            }
        }
    }

    /**
     * Get all active categories ordered
     */
    public static function get_all() {
        global $wpdb;
        return $wpdb->get_results(
            "SELECT * FROM " . NME_Database::table( 'categories' ) . "
             WHERE is_active = 1 AND parent_id = 0
             ORDER BY sort_order ASC"
        );
    }

    /**
     * Get category by slug
     */
    public static function get_by_slug( $slug ) {
        global $wpdb;
        return $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM " . NME_Database::table( 'categories' ) . " WHERE slug = %s",
            $slug
        ) );
    }

    /**
     * Get category by ID
     */
    public static function get_by_id( $id ) {
        global $wpdb;
        return $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM " . NME_Database::table( 'categories' ) . " WHERE id = %d",
            (int) $id
        ) );
    }

    /**
     * Get categories formatted for select dropdown
     */
    public static function get_select_options() {
        $cats = self::get_all();
        $options = array();
        foreach ( $cats as $cat ) {
            $options[ $cat->id ] = $cat->name;
        }
        return $options;
    }
}
