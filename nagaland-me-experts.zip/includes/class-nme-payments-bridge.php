<?php
/**
 * NME_Payments_Bridge
 *
 * Thin, safe bridge between nagaland-me-experts (core) and nme-payments.
 *
 * The payments plugin owns the rich profile data (portfolio, languages,
 * certifications, metrics, tiers, reviews). Core must read it without
 * hard-coupling to payments — if payments is deactivated, every method
 * here must degrade to a safe empty value and never fatal.
 *
 * Also renders the tier / online / response-rate badges onto core's
 * public profile via the existing `nmep_expert_profile_after_name`
 * filter so we don't have to touch class-frontend.php to get them in.
 *
 * @package NagalandMeExperts
 * @since   0.3.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class NME_Payments_Bridge {

    public static function init() {
        add_filter( 'nmep_expert_profile_after_name', array( __CLASS__, 'render_badges' ), 10, 2 );
    }

    /* ============================================================
       AVAILABILITY CHECKS
       ============================================================ */

    public static function is_payments_active() {
        return class_exists( 'NMEP_Database' );
    }

    public static function has_profile_v2() {
        return class_exists( 'NMEP_Expert_Profile_V2' );
    }

    public static function has_metrics() {
        return class_exists( 'NMEP_Metrics' );
    }

    public static function has_reviews_v2() {
        return class_exists( 'NMEP_Reviews_V2' );
    }

    public static function has_reviews() {
        return class_exists( 'NMEP_Reviews' );
    }

    public static function has_services() {
        return class_exists( 'NMEP_Services' );
    }

    /* ============================================================
       PROFILE DATA ACCESSORS  (all safe when payments is inactive)
       ============================================================ */

    public static function get_portfolio( $expert_id ) {
        if ( ! self::has_profile_v2() ) return array();
        return NMEP_Expert_Profile_V2::list_portfolio( (int) $expert_id, true ) ?: array();
    }

    public static function get_languages( $expert_id ) {
        if ( ! self::has_profile_v2() ) return array();
        return NMEP_Expert_Profile_V2::list_languages( (int) $expert_id ) ?: array();
    }

    public static function get_certifications( $expert_id ) {
        if ( ! self::has_profile_v2() ) return array();
        return NMEP_Expert_Profile_V2::list_certifications( (int) $expert_id ) ?: array();
    }

    public static function get_subcategories( $category_id ) {
        if ( ! self::has_profile_v2() ) return array();
        return NMEP_Expert_Profile_V2::list_subcategories( (int) $category_id, true ) ?: array();
    }

    /**
     * Returns a metrics object — either the real one or a zeroed
     * fallback so callers can always read properties without guards.
     */
    public static function get_metrics( $expert_id ) {
        if ( self::has_metrics() ) {
            $m = NMEP_Metrics::get( (int) $expert_id );
            if ( $m ) return $m;
        }
        return (object) array(
            'expert_id'             => (int) $expert_id,
            'orders_total'          => 0,
            'orders_completed'      => 0,
            'orders_cancelled'      => 0,
            'response_rate_percent' => 0,
            'avg_response_seconds'  => 0,
            'availability_mode'     => 'offline',
            'last_seen_at'          => null,
            'away_message'          => null,
        );
    }

    public static function is_online( $expert_id ) {
        if ( ! self::has_metrics() ) return false;
        return (bool) NMEP_Metrics::is_online( (int) $expert_id );
    }

    public static function humanize_response_time( $seconds ) {
        if ( self::has_metrics() && method_exists( 'NMEP_Metrics', 'humanize_response_time' ) ) {
            return NMEP_Metrics::humanize_response_time( (int) $seconds );
        }
        $s = (int) $seconds;
        if ( $s <= 0 )      return '—';
        if ( $s < 3600 )    return max( 1, (int) round( $s / 60 ) ) . ' min';
        if ( $s < 86400 )   return max( 1, (int) round( $s / 3600 ) ) . ' hr';
        return max( 1, (int) round( $s / 86400 ) ) . ' days';
    }

    /* ============================================================
       TIER METADATA
       ============================================================ */

    /**
     * Payments owns the canonical tier labels; core already has the
     * slug stored on wp_nme_experts.tier. Centralise labels here so
     * both plugins render them the same way.
     */
    public static function tier_label( $tier ) {
        $map = array(
            'new'     => 'New',
            'rising'  => 'Rising Talent',
            'pro'     => 'Pro',
            'top_pro' => 'Top Pro',
        );
        $tier = $tier ?: 'new';
        return isset( $map[ $tier ] ) ? $map[ $tier ] : 'New';
    }

    public static function tier_color( $tier ) {
        $map = array(
            'new'     => '#6B7280',
            'rising'  => '#0A7558',
            'pro'     => '#10B981',
            'top_pro' => '#D4A843',
        );
        $tier = $tier ?: 'new';
        return isset( $map[ $tier ] ) ? $map[ $tier ] : '#6B7280';
    }

    /* ============================================================
       REVIEWS (two-way)
       ============================================================ */

    public static function get_reviews_for_expert( $expert_id, $limit = 10 ) {
        if ( self::has_reviews() && method_exists( 'NMEP_Reviews', 'get_for_expert' ) ) {
            return NMEP_Reviews::get_for_expert( (int) $expert_id, (int) $limit ) ?: array();
        }
        return array();
    }

    public static function render_stars( $rating, $size = 16 ) {
        if ( self::has_reviews() && method_exists( 'NMEP_Reviews', 'render_stars' ) ) {
            return NMEP_Reviews::render_stars( (float) $rating, (int) $size );
        }
        $rating = (float) $rating;
        $full   = (int) floor( $rating );
        $empty  = 5 - $full;
        $out    = '<span style="color:#D4A843;font-size:' . (int) $size . 'px;letter-spacing:1px;">';
        $out   .= str_repeat( '★', $full );
        $out   .= '<span style="color:#E5E7EB;">' . str_repeat( '★', max( 0, $empty ) ) . '</span>';
        $out   .= '</span>';
        return $out;
    }

    /* ============================================================
       ORDERS (for dashboard)
       ============================================================ */

    public static function has_orders() {
        return class_exists( 'NMEP_Orders' );
    }

    public static function get_orders_for_expert( $expert_id, $limit = 20 ) {
        if ( ! self::has_orders() ) return array();
        return NMEP_Orders::get_for_expert( (int) $expert_id, (int) $limit ) ?: array();
    }

    /**
     * Summary counts + totals from the payments orders table, grouped
     * by coarse lifecycle buckets. Returns zeroes when payments inactive.
     */
    public static function get_orders_summary( $expert_id ) {
        $summary = array(
            'active'     => 0,  // created / paid / in_progress / delivered (awaiting release)
            'completed'  => 0,
            'cancelled'  => 0,
            'in_dispute' => 0,
            'total'      => 0,
            'earned'     => 0.0,
            'pending_earnings' => 0.0,
        );
        if ( ! self::has_orders() ) return $summary;

        global $wpdb;
        if ( ! class_exists( 'NMEP_Database' ) ) return $summary;
        $table = NMEP_Database::table( 'orders' );
        $eid   = (int) $expert_id;

        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT status, COUNT(*) AS c, COALESCE(SUM(expert_amount), 0) AS amt
             FROM $table WHERE expert_id = %d GROUP BY status",
            $eid
        ) );

        foreach ( (array) $rows as $r ) {
            $s = (string) $r->status;
            $c = (int) $r->c;
            $a = (float) $r->amt;
            $summary['total'] += $c;
            if ( in_array( $s, array( 'completed', 'released' ), true ) ) {
                $summary['completed'] += $c;
                $summary['earned']    += $a;
            } elseif ( $s === 'cancelled' || $s === 'refunded' ) {
                $summary['cancelled'] += $c;
            } elseif ( $s === 'disputed' ) {
                $summary['in_dispute'] += $c;
                $summary['pending_earnings'] += $a;
            } else {
                // created / paid / in_progress / delivered etc.
                $summary['active'] += $c;
                $summary['pending_earnings'] += $a;
            }
        }
        return $summary;
    }

    /* ============================================================
       SERVICES (live gigs)
       ============================================================ */

    public static function get_active_services( $expert_id ) {
        if ( ! self::has_services() ) return array();
        if ( method_exists( 'NMEP_Services', 'get_for_expert' ) ) {
            return NMEP_Services::get_for_expert( (int) $expert_id, 'active' ) ?: array();
        }
        return array();
    }

    public static function service_url( $service ) {
        if ( empty( $service->slug ) ) return '#';
        return home_url( '/service/' . $service->slug . '/' );
    }

    public static function service_starting_price( $service ) {
        if ( self::has_services() && method_exists( 'NMEP_Services', 'get_package_price' ) ) {
            $tiers = method_exists( 'NMEP_Services', 'get_active_tiers' )
                ? NMEP_Services::get_active_tiers( $service )
                : array( 'basic', 'standard', 'premium' );
            $min = null;
            foreach ( $tiers as $t ) {
                $p = (float) NMEP_Services::get_package_price( $service, $t );
                if ( $p > 0 && ( $min === null || $p < $min ) ) $min = $p;
            }
            return $min;
        }
        return ! empty( $service->basic_price ) ? (float) $service->basic_price : null;
    }

    /* ============================================================
       RENDER: badges after expert name on public profile
       ============================================================ */

    public static function render_badges( $html, $expert ) {
        if ( ! $expert || empty( $expert->id ) ) return $html;

        $metrics   = self::get_metrics( (int) $expert->id );
        $is_online = self::is_online( (int) $expert->id );
        $tier      = isset( $expert->tier ) ? $expert->tier : 'new';

        ob_start();
        ?>
        <span class="nme-profile-badges" style="display:inline-flex;gap:8px;flex-wrap:wrap;align-items:center;margin-left:8px;vertical-align:middle;">
            <span class="nme-tier-pill" style="display:inline-block;padding:2px 10px;border-radius:999px;font-size:0.78rem;font-weight:600;color:#fff;background:<?php echo esc_attr( self::tier_color( $tier ) ); ?>;">
                <?php echo esc_html( self::tier_label( $tier ) ); ?>
            </span>
            <?php if ( $is_online ) : ?>
                <span class="nme-online-dot" title="Online now" style="display:inline-flex;align-items:center;gap:6px;font-size:0.78rem;color:#10B981;">
                    <span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:#10B981;box-shadow:0 0 0 3px rgba(16,185,129,0.2);"></span>
                    Online now
                </span>
            <?php endif; ?>
            <?php if ( ! empty( $metrics->response_rate_percent ) && (int) $metrics->response_rate_percent >= 50 ) : ?>
                <span class="nme-response-rate" title="Replies to <?php echo (int) $metrics->response_rate_percent; ?>% of buyer messages" style="display:inline-block;padding:2px 10px;border-radius:999px;font-size:0.78rem;background:#F3F4F6;color:#374151;">
                    <?php echo (int) $metrics->response_rate_percent; ?>% replies
                </span>
            <?php endif; ?>
            <?php if ( ! empty( $metrics->avg_response_seconds ) ) : ?>
                <span class="nme-response-time" title="Average response time" style="display:inline-block;padding:2px 10px;border-radius:999px;font-size:0.78rem;background:#F3F4F6;color:#374151;">
                    Replies in <?php echo esc_html( self::humanize_response_time( (int) $metrics->avg_response_seconds ) ); ?>
                </span>
            <?php endif; ?>
        </span>
        <?php
        return $html . ob_get_clean();
    }
}
