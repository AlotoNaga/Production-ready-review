<?php
/**
 * NME_Emails
 * Handles all transactional emails for the marketplace.
 *
 * v1.0.1 — fixes approval email so experts get a proper password setup link
 *          instead of a dead-end login link to an account they never received
 *          a password for.
 *
 * v1.1.0 — adds 4 change-request templates used by NME_Change_Requests:
 *            send_change_request_received    (expert — submission ack)
 *            send_change_request_admin_notice(admin — new pending request)
 *            send_change_request_approved    (expert — approval confirmation)
 *            send_change_request_rejected    (expert — rejection + reason)
 *
 * v1.1.1 — wp_mail delivery is now verified: every send logs on failure
 *          via NME_Database::audit_log so deliverability issues are
 *          visible instead of silently dropped. Change-request methods
 *          return the bool delivery result to callers.
 *
 * v1.2.0 — adds registered-address templates used by NME_Change_Requests:
 *            send_address_change_otp (expert — OTP for self-service edit)
 *            send_address_changed    (expert — confirmation + diff)
 *          change_type_label() now recognises the 'address' type.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class NME_Emails {

    /**
     * Get email "from" header
     */
    private static function from_header() {
        return array(
            'From: Nagaland Me Experts <noreply@nagaland.me>',
            'Content-Type: text/html; charset=UTF-8',
        );
    }

    /**
     * Wrap content in branded HTML template
     */
    private static function template( $title, $body ) {
        return '
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; background: #FAF7F0; padding: 20px;">
            <div style="background: #0F2419; padding: 24px; text-align: center; border-top: 4px solid #D4A843;">
                <h1 style="color: #fff; font-family: Georgia, serif; margin: 0; font-size: 24px;">
                    Nagaland Me <span style="color: #D4A843;">Experts</span>
                </h1>
            </div>
            <div style="background: #fff; padding: 32px; border: 1px solid #E5E7EB;">
                <h2 style="color: #0F2419; margin-top: 0;">' . esc_html( $title ) . '</h2>
                ' . $body . '
            </div>
            <div style="background: #081410; padding: 20px; text-align: center; color: rgba(255,255,255,0.6); font-size: 12px;">
                <p>© ' . date( 'Y' ) . ' Nagaland Me Experts<br>
                HN 09, Purna Bazar, Dimapur, Nagaland, India<br>
                GST: 13DIHPA5679B1ZK</p>
            </div>
        </div>';
    }

    /**
     * Build a first-login / password-reset link for the WP user behind the
     * given applicant email. Returns empty string if the user cannot be found
     * or a reset key cannot be issued.
     *
     * Used by send_application_received() and send_rejection_email() so the
     * applicant can log in to their dashboard at any time — to check status,
     * edit, or resubmit after a rejection.
     *
     * @param string $email
     * @param int    $user_id Optional, preferred lookup.
     * @return string URL to wp-login.php?action=rp&key=…&login=…, or '' on failure.
     */
    private static function build_login_link( $email, $user_id = 0 ) {
        $user = null;
        $user_id = (int) $user_id;
        if ( $user_id > 0 ) {
            $user = get_user_by( 'id', $user_id );
        }
        if ( ! $user && ! empty( $email ) ) {
            $user = get_user_by( 'email', $email );
        }
        if ( ! $user ) {
            return '';
        }

        $reset_key = get_password_reset_key( $user );
        if ( is_wp_error( $reset_key ) ) {
            return '';
        }

        return network_site_url(
            'wp-login.php?action=rp&key=' . $reset_key . '&login=' . rawurlencode( $user->user_login ),
            'login'
        );
    }

    /**
     * Send confirmation when an application is received.
     *
     * v0.7.0 — includes a first-login / password-reset link so applicants can
     * sign in to their dashboard before a decision is made (e.g. to review
     * what they submitted or respond to feedback after a rejection).
     */
    public static function send_application_received( $data ) {
        $email    = isset( $data['email'] ) ? $data['email'] : '';
        $user_id  = isset( $data['user_id'] ) ? (int) $data['user_id'] : 0;
        $dashboard_url = home_url( '/expert-dashboard/' );
        $login_url     = self::build_login_link( $email, $user_id );

        $identity_block = '';
        if ( $email !== '' ) {
            $identity_block = '
            <div style="background: #F0FDF4; padding: 12px 14px; border-left: 4px solid #0A7558; border-radius: 6px; margin: 16px 0;">
                <p style="margin: 0; font-size: 14px; color: #065F46;">
                    <strong>Your login email:</strong> ' . esc_html( $email ) . '
                </p>
            </div>';
        }

        $login_block = '';
        if ( $login_url !== '' ) {
            $login_block = '
            <div style="background: #FFF8E1; padding: 16px; border-left: 4px solid #D4A843; border-radius: 8px; margin: 20px 0;">
                <p style="margin: 0 0 8px;"><strong>Set your password &amp; access your dashboard</strong></p>
                <p style="margin: 0 0 14px; font-size: 14px; color: #5B4A20;">We have created an account for you so you can check your application status and, if needed, edit and resubmit it. Click below to set your password. This link is valid for 24 hours.</p>
                <p style="text-align: center; margin: 0;">
                    <a href="' . esc_url( $login_url ) . '" style="display: inline-block; background: #0A7558; color: #fff; padding: 14px 32px; text-decoration: none; border-radius: 50px; font-weight: 700;">Set Password &amp; Log In</a>
                </p>
                <p style="margin: 14px 0 0; font-size: 12px; color: #777; word-break: break-all;">Or copy this link into your browser:<br>' . esc_html( $login_url ) . '</p>
                <p style="margin: 10px 0 0; font-size: 12px; color: #777;">If this link expires, you can request a new one at <a href="' . esc_url( wp_lostpassword_url( $dashboard_url ) ) . '">' . esc_url( wp_lostpassword_url( $dashboard_url ) ) . '</a></p>
            </div>';
        }

        $subject = 'Application Received — Nagaland Me Experts';
        $body = '
            <p>Hi ' . esc_html( $data['full_name'] ) . ',</p>
            <p>Thank you for applying to become a Nagaland Me Expert!</p>
            <p>We have received your application and will review it within <strong>24 hours (sometimes up to 2 days)</strong>. You will receive an email once a decision has been made.</p>
            ' . $identity_block . '
            ' . $login_block . '
            <p><strong>What happens next:</strong></p>
            <ol>
                <li>Our team reviews your application and KYC details</li>
                <li>You receive an approval or rejection email</li>
                <li>If approved, you can log in and start creating service listings</li>
            </ol>
            <p>If you have questions, contact us via WhatsApp at <strong>+91 63833 59495</strong>.</p>
            <p>Best regards,<br>
            The Nagaland Me Team</p>
        ';

        wp_mail(
            $data['email'],
            $subject,
            self::template( 'Application Received', $body ),
            self::from_header()
        );
    }

    /**
     * Send admin notification of new application
     */
    public static function send_admin_notification( $data, $expert_id ) {
        $admin_email = get_option( 'admin_email' );
        $admin_url   = admin_url( 'admin.php?page=nme-experts' );

        $subject = '[Nagaland Me Experts] New Application — ' . $data['full_name'];
        $body = '
            <p>A new expert application has been received.</p>
            <p><strong>Applicant:</strong> ' . esc_html( $data['full_name'] ) . '<br>
            <strong>Email:</strong> ' . esc_html( $data['email'] ) . '<br>
            <strong>Phone:</strong> ' . esc_html( $data['phone'] ) . '<br>
            <strong>District:</strong> ' . esc_html( $data['district'] ) . '</p>
            <p><a href="' . esc_url( $admin_url ) . '" style="background: #0A7558; color: #fff; padding: 10px 20px; text-decoration: none; border-radius: 4px;">Review Application</a></p>
        ';

        wp_mail(
            $admin_email,
            $subject,
            self::template( 'New Expert Application', $body ),
            self::from_header()
        );
    }

    /**
     * Send approval email to expert.
     *
     * FIXED: Generates a real password reset link so the expert can set their
     * password and log in — instead of pointing them to a login page they
     * cannot use (because their auto-created account had a random password
     * they never received).
     */
    public static function send_approval_email( $expert ) {
        $dashboard_url = home_url( '/expert-dashboard/' );

        // Build the password setup link
        $set_password_url = '';
        $user = null;

        if ( ! empty( $expert->user_id ) ) {
            $user = get_user_by( 'id', (int) $expert->user_id );
        }
        if ( ! $user && ! empty( $expert->email ) ) {
            $user = get_user_by( 'email', $expert->email );
        }

        if ( $user ) {
            // Generate password reset key (same mechanism WordPress uses for "lost password")
            $reset_key = get_password_reset_key( $user );
            if ( ! is_wp_error( $reset_key ) ) {
                $set_password_url = network_site_url(
                    'wp-login.php?action=rp&key=' . $reset_key . '&login=' . rawurlencode( $user->user_login ),
                    'login'
                );
            }
        }

        // Fallback: if for any reason we couldn't generate the key, send a "lost password" link
        if ( empty( $set_password_url ) ) {
            $set_password_url = wp_lostpassword_url( $dashboard_url );
        }

        $subject = '🎉 You\'re Approved! Welcome to Nagaland Me Experts';
        $body = '
            <p>Hi ' . esc_html( $expert->full_name ) . ',</p>
            <p>Congratulations! Your application has been <strong>approved</strong>. You are now an official Nagaland Me Expert.</p>

            <div style="background: #FFF8E1; padding: 16px; border-left: 4px solid #D4A843; border-radius: 8px; margin: 20px 0;">
                <p style="margin: 0 0 8px;"><strong>Step 1: Set your password</strong></p>
                <p style="margin: 0 0 14px; font-size: 14px; color: #5B4A20;">Click the button below to create your password and log in for the first time. This link is valid for 24 hours.</p>
                <p style="text-align: center; margin: 0;">
                    <a href="' . esc_url( $set_password_url ) . '" style="display: inline-block; background: #0A7558; color: #fff; padding: 14px 32px; text-decoration: none; border-radius: 50px; font-weight: 700;">Set Your Password & Log In</a>
                </p>
                <p style="margin: 14px 0 0; font-size: 12px; color: #777; word-break: break-all;">Or copy this link into your browser:<br>' . esc_html( $set_password_url ) . '</p>
            </div>

            <p><strong>After setting your password:</strong></p>
            <ol>
                <li>You will be logged in automatically</li>
                <li>You can access your <a href="' . esc_url( $dashboard_url ) . '">Expert Dashboard</a> at <strong>' . esc_html( str_replace( array( 'https://', 'http://' ), '', $dashboard_url ) ) . '</strong></li>
                <li>Complete your profile if anything is missing</li>
                <li>Wait for the marketplace launch — services and orders go live soon</li>
            </ol>

            ' . ( ! empty( $expert->is_founding_expert ) ? '<div style="background: #FFF8E1; padding: 16px; border-left: 4px solid #D4A843; border-radius: 8px; margin: 20px 0;"><p style="margin: 0;"><strong>🏆 Founding Expert Status:</strong> You are one of our founding experts! You get a permanent gold badge and <strong>0% commission</strong> for the first 3 months after launch.</p></div>' : '' ) . '

            <p>If the password link expires before you use it, you can request a new one anytime at <a href="' . esc_url( wp_lostpassword_url( $dashboard_url ) ) . '">' . esc_url( wp_lostpassword_url( $dashboard_url ) ) . '</a></p>

            <p>Welcome to the team!<br>
            The Nagaland Me Team</p>
        ';

        wp_mail(
            $expert->email,
            $subject,
            self::template( 'Welcome to Nagaland Me Experts', $body ),
            self::from_header()
        );
    }

    /**
     * Send rejection email to expert.
     *
     * v0.7.0 — embeds a first-login link + a deep link to /edit-application/
     * so the applicant can sign in, address the feedback and resubmit their
     * application without having to start over or guess how to log in.
     */
    public static function send_rejection_email( $expert, $reason = '' ) {
        $email     = isset( $expert->email ) ? (string) $expert->email : '';
        $edit_url  = home_url( '/edit-application/' );

        // Rejected applicants already have a password from the initial signup,
        // so send them to the standard login page (not a password-reset link).
        // wp-login.php accepts email in the username field, so they don't need
        // to guess a user_login. We pre-fill the "log" field via GET so the
        // email box is populated once they arrive.
        $login_url = add_query_arg(
            array(
                'log'         => rawurlencode( $email ),
                'redirect_to' => rawurlencode( $edit_url ),
            ),
            wp_login_url( $edit_url )
        );

        $identity_block = '';
        if ( $email !== '' ) {
            $identity_block = '
            <div style="background: #F0FDF4; padding: 12px 14px; border-left: 4px solid #0A7558; border-radius: 6px; margin: 16px 0;">
                <p style="margin: 0; font-size: 14px; color: #065F46;">
                    <strong>Your login email:</strong> ' . esc_html( $email ) . '
                </p>
                <p style="margin: 6px 0 0; font-size: 12px; color: #065F46;">
                    Use this email and the password you chose when you first applied.
                </p>
            </div>';
        }

        $login_block = '
            <div style="background: #FFF8E1; padding: 16px; border-left: 4px solid #D4A843; border-radius: 8px; margin: 20px 0;">
                <p style="margin: 0 0 8px;"><strong>Ready to resubmit?</strong></p>
                <p style="margin: 0 0 14px; font-size: 14px; color: #5B4A20;">Log in and update your application. Your existing details will be pre-filled so you only need to change what needs fixing.</p>
                <p style="text-align: center; margin: 0;">
                    <a href="' . esc_url( $login_url ) . '" style="display: inline-block; background: #0A7558; color: #fff; padding: 14px 32px; text-decoration: none; border-radius: 50px; font-weight: 700;">Log In &amp; Edit Your Application</a>
                </p>
                <p style="margin: 10px 0 0; font-size: 12px; color: #777;">Forgot your password? <a href="' . esc_url( wp_lostpassword_url( $edit_url ) ) . '">Reset it here</a>.</p>
            </div>';

        $subject = 'About Your Nagaland Me Experts Application';
        $body = '
            <p>Hi ' . esc_html( $expert->full_name ) . ',</p>
            <p>Thank you for your interest in becoming a Nagaland Me Expert. After reviewing your application, we are unable to approve it at this time.</p>
            ' . ( $reason ? '<p><strong>Reason:</strong> ' . esc_html( $reason ) . '</p>' : '' ) . '
            <p>You are welcome to edit and resubmit your application once you have addressed the feedback above.</p>
            ' . $identity_block . '
            ' . $login_block . '
            <p>If you have questions, please contact us via WhatsApp at <strong>+91 63833 59495</strong>.</p>
            <p>Best regards,<br>
            The Nagaland Me Team</p>
        ';

        wp_mail(
            $expert->email,
            $subject,
            self::template( 'Application Update', $body ),
            self::from_header()
        );
    }

    /**
     * ADMIN: an applicant has resubmitted a previously-rejected application.
     * v0.7.0 — triggered by NME_Experts::update_application().
     *
     * @param object $expert Expert row (post-resubmit).
     * @return bool
     */
    public static function send_application_resubmitted_admin_notice( $expert ) {
        $admin_email = get_option( 'admin_email' );
        if ( ! $admin_email ) return false;

        $expert_id  = isset( $expert->id ) ? (int) $expert->id : 0;
        $admin_url  = admin_url( 'admin.php?page=nme-experts&action=view&id=' . $expert_id );
        $queue_url  = admin_url( 'admin.php?page=nme-experts&status=pending' );

        $subject = '[NME] Application resubmitted — ' . ( isset( $expert->full_name ) ? $expert->full_name : 'Expert' );
        $body = '
            <p>A previously-rejected expert application has been resubmitted and is back in the <strong>Pending</strong> queue.</p>
            <table style="border-collapse:collapse;margin:12px 0;">
                <tr><td style="padding:4px 12px 4px 0;color:#6B7280;">Applicant:</td><td style="padding:4px 0;"><strong>' . esc_html( isset( $expert->full_name ) ? $expert->full_name : '—' ) . '</strong></td></tr>
                <tr><td style="padding:4px 12px 4px 0;color:#6B7280;">Email:</td><td style="padding:4px 0;">' . esc_html( isset( $expert->email ) ? $expert->email : '—' ) . '</td></tr>
                <tr><td style="padding:4px 12px 4px 0;color:#6B7280;">Phone:</td><td style="padding:4px 0;">' . esc_html( isset( $expert->phone ) ? $expert->phone : '—' ) . '</td></tr>
                <tr><td style="padding:4px 12px 4px 0;color:#6B7280;">Expert ID:</td><td style="padding:4px 0;">#' . $expert_id . '</td></tr>
            </table>
            <p>
                <a href="' . esc_url( $admin_url ) . '" style="display:inline-block;background:#0A7558;color:#fff;padding:10px 20px;text-decoration:none;border-radius:6px;margin-right:8px;">Review application</a>
                <a href="' . esc_url( $queue_url ) . '" style="display:inline-block;background:#E5E7EB;color:#111827;padding:10px 20px;text-decoration:none;border-radius:6px;">Open pending queue</a>
            </p>
            <p style="color:#6B7280;font-size:0.9em;margin-top:18px;">The applicant has addressed the feedback from your previous rejection. Their rejection reason has been cleared and their status is now <em>Pending</em>.</p>
        ';

        return self::send_mail(
            $admin_email,
            $subject,
            self::template( 'Application resubmitted — review needed', $body ),
            array( 'template' => 'application_resubmitted_admin_notice', 'expert_id' => $expert_id )
        );
    }

    /* ================================================================
       CHANGE-REQUEST EMAILS  (v1.1.0)
       Called by NME_Change_Requests.
       ================================================================ */

    /**
     * wp_mail wrapper that logs failures so we can see deliverability issues
     * in the audit log instead of dropping them silently.
     *
     * @param string $to
     * @param string $subject
     * @param string $html_body  (already passed through self::template if desired)
     * @param array  $meta       extra audit context (e.g. expert_id, template)
     * @return bool true on successful handoff to MTA
     */
    private static function send_mail( $to, $subject, $html_body, $meta = array() ) {
        $sent = (bool) wp_mail( $to, $subject, $html_body, self::from_header() );
        if ( ! $sent && class_exists( 'NME_Database' ) ) {
            NME_Database::audit_log(
                'email_send_failed',
                'email',
                0,
                array_merge(
                    array(
                        'to'      => (string) $to,
                        'subject' => (string) $subject,
                    ),
                    (array) $meta
                )
            );
        }
        return $sent;
    }

    /**
     * Human-readable label for a change-request type.
     */
    private static function change_type_label( $type ) {
        if ( $type === 'bank_account' )   return 'bank account';
        if ( $type === 'profile_photo' )  return 'profile picture';
        if ( $type === 'address' )        return 'registered address';
        return str_replace( '_', ' ', (string) $type );
    }

    /**
     * EXPERT: we've received your request.
     *
     * @return bool true if wp_mail handed the message off to the MTA.
     */
    public static function send_change_request_received( $expert, $type ) {
        if ( empty( $expert->email ) ) return false;
        $label   = self::change_type_label( $type );
        $is_bank = ( $type === 'bank_account' );

        $subject = 'We received your ' . $label . ' change request';
        $body = '
            <p>Hi ' . esc_html( $expert->full_name ?? 'there' ) . ',</p>
            <p>We have received your request to update your <strong>' . esc_html( $label ) . '</strong>. For your security, this change needs to be reviewed by our team before it takes effect.</p>
            <p><strong>What happens next:</strong></p>
            <ol>
                <li>Our team reviews the request (usually within <strong>1–2 business days</strong>).</li>
                <li>You will receive an email once it is approved or if we need more information.</li>
                ' . ( $is_bank ? '<li>Payouts are <strong>paused</strong> for your account until this request is resolved, so funds never go to the wrong place.</li>' : '' ) . '
            </ol>
            <p style="background:#FEF3C7;border-left:4px solid #F59E0B;padding:12px 14px;margin-top:18px;color:#92400E;">
                <strong>Did not request this?</strong> Reply to this email or contact us on WhatsApp at <strong>+91 63833 59495</strong> immediately. We will pause your account and investigate.
            </p>
            <p>— The Nagaland Me Team</p>
        ';

        return self::send_mail(
            $expert->email,
            $subject,
            self::template( 'Request received', $body ),
            array( 'template' => 'change_request_received', 'expert_id' => (int) ( $expert->id ?? 0 ), 'type' => (string) $type )
        );
    }

    /**
     * ADMIN: a new change request needs review.
     *
     * @return bool true if wp_mail handed the message off to the MTA.
     */
    public static function send_change_request_admin_notice( $expert, $type, $request_id ) {
        $admin_email = get_option( 'admin_email' );
        if ( ! $admin_email ) return false;

        $label     = self::change_type_label( $type );
        $queue_url = admin_url( 'admin.php?page=nme-change-requests&status=pending' );
        $expert_url = admin_url( 'admin.php?page=nme-experts&action=view&id=' . (int) ( $expert->id ?? 0 ) );

        $subject = '[NME] New ' . $label . ' change request — ' . ( $expert->full_name ?? 'Expert' );
        $body = '
            <p>A new change request requires your review.</p>
            <table style="border-collapse:collapse;margin:12px 0;">
                <tr><td style="padding:4px 12px 4px 0;color:#6B7280;">Expert:</td><td style="padding:4px 0;"><strong>' . esc_html( $expert->full_name ?? '—' ) . '</strong></td></tr>
                <tr><td style="padding:4px 12px 4px 0;color:#6B7280;">Email:</td><td style="padding:4px 0;">' . esc_html( $expert->email ?? '—' ) . '</td></tr>
                <tr><td style="padding:4px 12px 4px 0;color:#6B7280;">Type:</td><td style="padding:4px 0;">' . esc_html( ucfirst( $label ) ) . '</td></tr>
                <tr><td style="padding:4px 12px 4px 0;color:#6B7280;">Request ID:</td><td style="padding:4px 0;">#' . (int) $request_id . '</td></tr>
            </table>
            <p>
                <a href="' . esc_url( $queue_url ) . '" style="display:inline-block;background:#0A7558;color:#fff;padding:10px 20px;text-decoration:none;border-radius:6px;margin-right:8px;">Open review queue</a>
                <a href="' . esc_url( $expert_url ) . '" style="display:inline-block;background:#E5E7EB;color:#111827;padding:10px 20px;text-decoration:none;border-radius:6px;">View expert</a>
            </p>
            <p style="color:#6B7280;font-size:0.9em;margin-top:18px;">Review as quickly as possible to minimise payout delays for the expert.</p>
        ';

        return self::send_mail(
            $admin_email,
            $subject,
            self::template( 'New change request — review needed', $body ),
            array( 'template' => 'change_request_admin_notice', 'request_id' => (int) $request_id, 'type' => (string) $type )
        );
    }

    /**
     * EXPERT: your request was approved.
     *
     * @return bool true if wp_mail handed the message off to the MTA.
     */
    public static function send_change_request_approved( $expert, $type ) {
        if ( empty( $expert->email ) ) return false;
        $label = self::change_type_label( $type );
        $is_bank = ( $type === 'bank_account' );

        $subject = 'Your ' . $label . ' change has been approved';
        $body = '
            <p>Hi ' . esc_html( $expert->full_name ?? 'there' ) . ',</p>
            <p>Good news — your <strong>' . esc_html( $label ) . '</strong> has been updated.</p>
            ' . ( $is_bank ? '<p>Any future payouts will now go to the new account. Payouts have been <strong>resumed</strong>.</p>' : '' ) . '
            <p>If you did not request this change, contact us immediately on WhatsApp at <strong>+91 63833 59495</strong>.</p>
            <p><a href="' . esc_url( home_url( '/expert-dashboard/' ) ) . '" style="display:inline-block;background:#0A7558;color:#fff;padding:10px 20px;text-decoration:none;border-radius:6px;">Open dashboard</a></p>
            <p>— The Nagaland Me Team</p>
        ';

        return self::send_mail(
            $expert->email,
            $subject,
            self::template( 'Change approved', $body ),
            array( 'template' => 'change_request_approved', 'expert_id' => (int) ( $expert->id ?? 0 ), 'type' => (string) $type )
        );
    }

    /**
     * EXPERT: your request was rejected.
     *
     * @return bool true if wp_mail handed the message off to the MTA.
     */
    public static function send_change_request_rejected( $expert, $type, $reason = '' ) {
        if ( empty( $expert->email ) ) return false;
        $label = self::change_type_label( $type );

        $subject = 'About your ' . $label . ' change request';
        $body = '
            <p>Hi ' . esc_html( $expert->full_name ?? 'there' ) . ',</p>
            <p>We reviewed your request to update your <strong>' . esc_html( $label ) . '</strong> and were unable to approve it this time.</p>
            ' . ( $reason !== '' ? '<p style="background:#FEE2E2;border-left:4px solid #EF4444;padding:12px 14px;color:#991B1B;"><strong>Reason:</strong> ' . esc_html( $reason ) . '</p>' : '' ) . '
            <p>You can submit a new request from your dashboard after addressing the feedback above. If you think this was a mistake, contact us on WhatsApp at <strong>+91 63833 59495</strong>.</p>
            <p><a href="' . esc_url( home_url( '/expert-dashboard/' ) ) . '" style="display:inline-block;background:#0A7558;color:#fff;padding:10px 20px;text-decoration:none;border-radius:6px;">Open dashboard</a></p>
            <p>— The Nagaland Me Team</p>
        ';

        return self::send_mail(
            $expert->email,
            $subject,
            self::template( 'Request could not be approved', $body ),
            array( 'template' => 'change_request_rejected', 'expert_id' => (int) ( $expert->id ?? 0 ), 'type' => (string) $type )
        );
    }

    /* ================================================================
       ADDRESS SELF-SERVICE EMAILS  (v1.2.0)
       Called by NME_Change_Requests::handle_*_address_*.
       Address updates have no admin-approval step — the OTP IS the
       proof-of-identity, and the confirmation email is the audit trail.
       ================================================================ */

    /**
     * EXPERT: 6-digit OTP to authorise a registered-address update.
     *
     * @param object $expert
     * @param string $otp 6-digit numeric code (already generated by caller)
     * @return bool true if wp_mail handed the message off to the MTA.
     */
    public static function send_address_change_otp( $expert, $otp ) {
        if ( empty( $expert->email ) ) return false;

        $subject = 'Your Nagaland Me Experts address-update code';
        $body = '
            <p>Hi ' . esc_html( $expert->full_name ?? 'there' ) . ',</p>
            <p>Your 6-digit code to confirm your registered-address change is:</p>
            <p style="font-size:26px;letter-spacing:8px;font-weight:700;font-family:monospace;margin:20px 0;color:#0A7558;text-align:center;background:#F0FDF4;padding:14px;border-radius:8px;">' . esc_html( $otp ) . '</p>
            <p>This code expires in <strong>10 minutes</strong> and can only be used once.</p>
            <p style="background:#FEF3C7;border-left:4px solid #F59E0B;padding:12px 14px;margin-top:18px;color:#92400E;">
                <strong>Did not request this?</strong> Ignore this email and contact us on WhatsApp at <strong>+91 63833 59495</strong> so we can secure your account.
            </p>
            <p>— The Nagaland Me Team</p>
        ';

        return self::send_mail(
            $expert->email,
            $subject,
            self::template( 'Confirm your address update', $body ),
            array( 'template' => 'address_change_otp', 'expert_id' => (int) ( $expert->id ?? 0 ) )
        );
    }

    /**
     * EXPERT: confirmation that their registered address was updated.
     * Includes a before/after diff so the expert can spot an unauthorised
     * change at a glance.
     *
     * @return bool true if wp_mail handed the message off to the MTA.
     */
    public static function send_address_changed( $expert, $old, $new ) {
        if ( empty( $expert->email ) ) return false;

        $row = function( $label, $from, $to ) {
            $from_html = esc_html( $from !== '' ? $from : '—' );
            $to_html   = esc_html( $to   !== '' ? $to   : '—' );
            $changed   = ( $from !== $to );
            $arrow_col = $changed ? '#0A7558' : '#9CA3AF';
            return '<tr>'
                 . '<td style="padding:4px 12px 4px 0;color:#6B7280;">' . esc_html( $label ) . '</td>'
                 . '<td style="padding:4px 0;"><s style="color:#9CA3AF;">' . $from_html . '</s> '
                 . '<span style="color:' . $arrow_col . ';font-weight:700;">→</span> '
                 . '<strong>' . $to_html . '</strong></td>'
                 . '</tr>';
        };

        $subject = 'Your registered address was updated';
        $body = '
            <p>Hi ' . esc_html( $expert->full_name ?? 'there' ) . ',</p>
            <p>Your registered address on Nagaland Me Experts has just been updated. Here is the change for your records:</p>
            <table style="border-collapse:collapse;margin:16px 0;font-size:14px;">
                ' . $row( 'Street',   (string) ( $old['street_address']   ?? '' ), (string) ( $new['street_address']   ?? '' ) ) . '
                ' . $row( 'Village',  (string) ( $old['village_locality'] ?? '' ), (string) ( $new['village_locality'] ?? '' ) ) . '
                ' . $row( 'PIN code', (string) ( $old['postal_code']      ?? '' ), (string) ( $new['postal_code']      ?? '' ) ) . '
            </table>
            <p>This address is used for KYC and tax records with Razorpay — it is not shown on your public profile.</p>
            <p style="background:#FEE2E2;border-left:4px solid #EF4444;padding:12px 14px;color:#991B1B;">
                <strong>Did not make this change?</strong> Contact us immediately on WhatsApp at <strong>+91 63833 59495</strong> — we will freeze your account and investigate.
            </p>
            <p><a href="' . esc_url( home_url( '/expert-dashboard/' ) ) . '" style="display:inline-block;background:#0A7558;color:#fff;padding:10px 20px;text-decoration:none;border-radius:6px;">Open dashboard</a></p>
            <p>— The Nagaland Me Team</p>
        ';

        return self::send_mail(
            $expert->email,
            $subject,
            self::template( 'Address updated', $body ),
            array( 'template' => 'address_changed', 'expert_id' => (int) ( $expert->id ?? 0 ) )
        );
    }

    /**
     * EXPERT: a Nagaland Me admin has edited your KYC record on your behalf.
     * Shows a before/after diff for every field that changed, the reason
     * logged by the admin, and a prominent "didn't expect this" banner so
     * unauthorised internal edits are visible to the expert too.
     *
     * PAN is masked to last 4 characters only in the email — the full value
     * never leaves the database via email.
     *
     * @param object $expert  Expert row (must have ->email / ->full_name / ->id).
     * @param array  $old     Before snapshot keyed by column name.
     * @param array  $new     After snapshot keyed by column name.
     * @param string $reason  Admin-supplied reason (human readable).
     * @return bool
     */
    public static function send_admin_kyc_edited( $expert, $old, $new, $reason = '' ) {
        if ( empty( $expert->email ) ) return false;

        $mask_pan = function( $pan ) {
            $pan = (string) $pan;
            if ( $pan === '' ) return '';
            if ( strlen( $pan ) <= 4 ) return str_repeat( '•', max( 0, strlen( $pan ) - 1 ) ) . substr( $pan, -1 );
            return str_repeat( '•', strlen( $pan ) - 4 ) . substr( $pan, -4 );
        };

        $labels = array(
            'pan_number'        => 'PAN number',
            'pan_card_url'      => 'PAN card image',
            'id_proof_type'     => 'ID proof type',
            'id_proof_url'      => 'ID proof — front',
            'id_proof_back_url' => 'ID proof — back',
        );

        $pretty = function( $key, $val ) use ( $mask_pan ) {
            $val = (string) $val;
            if ( $val === '' ) return '—';
            if ( $key === 'pan_number' )    return $mask_pan( $val );
            if ( $key === 'id_proof_type' ) return ucwords( str_replace( '_', ' ', $val ) );
            // URLs: show "uploaded" / "removed" / "changed" rather than the raw URL.
            if ( in_array( $key, array( 'pan_card_url', 'id_proof_url', 'id_proof_back_url' ), true ) ) {
                return 'uploaded';
            }
            return $val;
        };

        $rows_html = '';
        foreach ( $labels as $key => $label ) {
            $from = (string) ( $old[ $key ] ?? '' );
            $to   = (string) ( $new[ $key ] ?? '' );
            if ( $from === $to ) continue;

            $from_html = esc_html( $pretty( $key, $from ) );
            $to_html   = esc_html( $pretty( $key, $to ) );
            $rows_html .= '<tr>'
                . '<td style="padding:4px 12px 4px 0;color:#6B7280;">' . esc_html( $label ) . '</td>'
                . '<td style="padding:4px 0;"><s style="color:#9CA3AF;">' . $from_html . '</s> '
                . '<span style="color:#0A7558;font-weight:700;">→</span> '
                . '<strong>' . $to_html . '</strong></td>'
                . '</tr>';
        }

        if ( $rows_html === '' ) {
            // Nothing actually changed — don't spam the expert with an email.
            return false;
        }

        $reason_html = '';
        if ( $reason !== '' ) {
            $reason_html = '<p style="background:#F3F4F6;border-left:4px solid #9CA3AF;padding:10px 14px;color:#374151;"><strong>Reason provided by admin:</strong><br>' . nl2br( esc_html( $reason ) ) . '</p>';
        }

        $subject = 'Your KYC record was updated by Nagaland Me support';
        $body = '
            <p>Hi ' . esc_html( $expert->full_name ?? 'there' ) . ',</p>
            <p>A Nagaland Me administrator has just updated your KYC record on your behalf. This is usually done to fix a Razorpay verification error that you could not fix from the dashboard (e.g. a PAN mismatch).</p>
            <table style="border-collapse:collapse;margin:16px 0;font-size:14px;">
                ' . $rows_html . '
            </table>
            ' . $reason_html . '
            <p>Your PAN is shown masked above for safety. You can see the full updated values on your dashboard.</p>
            <p style="background:#FEE2E2;border-left:4px solid #EF4444;padding:12px 14px;color:#991B1B;">
                <strong>Didn\'t expect this change?</strong> Contact us immediately on WhatsApp at <strong>+91 63833 59495</strong> — we will freeze your payouts and investigate.
            </p>
            <p><a href="' . esc_url( home_url( '/expert-dashboard/' ) ) . '" style="display:inline-block;background:#0A7558;color:#fff;padding:10px 20px;text-decoration:none;border-radius:6px;">Open dashboard</a></p>
            <p>— The Nagaland Me Team</p>
        ';

        return self::send_mail(
            $expert->email,
            $subject,
            self::template( 'KYC updated by support', $body ),
            array( 'template' => 'admin_kyc_edited', 'expert_id' => (int) ( $expert->id ?? 0 ) )
        );
    }
}