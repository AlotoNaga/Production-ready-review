<?php
/**
 * NME_Presence
 *
 * Activity status + response-time indicator for experts and buyers.
 *
 * Three visible states (kept deliberately coarse so stale data never looks
 * creepily precise):
 *
 *   🟢 Online            — last seen in the past 5 minutes
 *   🟡 Active recently   — last seen in the past 72 hours (humanised as
 *                          "Active 4h ago", "Active yesterday", etc.)
 *   ⚪ Away               — more than 72 hours since last seen, or never
 *                          seen at all
 *
 * On the expert profile header we also surface the existing
 * wp_nme_experts.response_time_hours column as "Typically replies in Xh".
 * That column is maintained by the payments plugin (response-time rollups
 * computed from actual message turnaround), so it's the closest real-world
 * signal buyers care about. If it's zero we silently omit the line.
 *
 * Data collection:
 *   - Hooks `init` for logged-in users. One DB write per user per 5
 *     minutes, throttled via transient. Cron / WP-CLI / REST loopback
 *     requests are skipped so they don't count as presence.
 *   - Stores a Unix timestamp (int) in user_meta `nme_last_seen` so the
 *     comparison is timezone-safe — no strtotime() on MySQL datetimes.
 *
 * Privacy:
 *   - Any user with the user_meta `nme_presence_opt_out` set to a truthy
 *     value is treated as `away` from the outside. No UI for this yet;
 *     admins can toggle it from the user profile screen if someone asks.
 *
 * Display:
 *   - `nmep_expert_profile_after_name` (priority 20, after badges at 10)
 *     → full chip: coloured dot + human label + optional response line.
 *   - `nmep_service_card_after_expert`  (priority 20)
 *     → compact dot + short label, safe to sit inside a small card.
 *
 * @package NagalandMeExperts
 * @version 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class NME_Presence {

    /** user_meta key holding Unix-timestamp last-seen. */
    const LAST_SEEN_META = 'nme_last_seen';

    /** user_meta key: truthy value hides this user's presence from others. */
    const OPT_OUT_META = 'nme_presence_opt_out';

    /** Window during which a user is reported as "online". */
    const ONLINE_WINDOW = 5 * MINUTE_IN_SECONDS;

    /** Window during which a user is reported as "active recently". */
    const RECENT_WINDOW = 72 * HOUR_IN_SECONDS;

    /** DB-write throttle: at most one last_seen update per user per window. */
    const TRACK_THROTTLE = 5 * MINUTE_IN_SECONDS;

    public static function init() {
        // Tracking — runs on every normal page load for logged-in users.
        add_action( 'init', array( __CLASS__, 'maybe_track' ), 20 );

        // Display — priority 20 so the badges plugin (priority 10) renders
        // its chips first and ours appears immediately below.
        add_filter( 'nmep_expert_profile_after_name', array( __CLASS__, 'append_profile_presence' ), 20, 2 );
        add_filter( 'nmep_service_card_after_expert', array( __CLASS__, 'append_card_presence' ), 20, 2 );
    }

    /* ================================================================
       TRACKING
       ================================================================ */

    /**
     * Update the current user's last-seen timestamp, throttled.
     * Skipped for cron, WP-CLI, and xmlrpc so background processes
     * don't register as human presence.
     */
    public static function maybe_track() {
        if ( ! is_user_logged_in() ) {
            return;
        }
        if ( wp_doing_cron() ) {
            return;
        }
        if ( defined( 'WP_CLI' ) && WP_CLI ) {
            return;
        }
        if ( defined( 'XMLRPC_REQUEST' ) && XMLRPC_REQUEST ) {
            return;
        }

        $user_id      = get_current_user_id();
        $throttle_key = 'nme_presence_' . $user_id;

        if ( get_transient( $throttle_key ) ) {
            return;
        }

        update_user_meta( $user_id, self::LAST_SEEN_META, time() );
        set_transient( $throttle_key, 1, self::TRACK_THROTTLE );
    }

    /* ================================================================
       STATUS LOOKUPS
       ================================================================ */

    /**
     * Returns one of: 'online' | 'recent' | 'away' | 'hidden'.
     *
     * 'hidden' is what callers get when the user has opted out — treat it
     * the same as "don't render anything at all".
     */
    public static function get_status( $user_id ) {
        $user_id = (int) $user_id;
        if ( $user_id <= 0 ) {
            return 'away';
        }

        if ( get_user_meta( $user_id, self::OPT_OUT_META, true ) ) {
            return 'hidden';
        }

        $last_seen = (int) get_user_meta( $user_id, self::LAST_SEEN_META, true );
        if ( $last_seen <= 0 ) {
            return 'away';
        }

        $age = time() - $last_seen;
        if ( $age <= self::ONLINE_WINDOW ) {
            return 'online';
        }
        if ( $age <= self::RECENT_WINDOW ) {
            return 'recent';
        }
        return 'away';
    }

    /**
     * Human-friendly "Active X ago" string. Returns empty string if we
     * don't have a last_seen value at all.
     */
    public static function humanize_last_seen( $user_id ) {
        $last_seen = (int) get_user_meta( (int) $user_id, self::LAST_SEEN_META, true );
        if ( $last_seen <= 0 ) {
            return '';
        }
        return human_time_diff( $last_seen, time() ) . ' ago';
    }

    /* ================================================================
       RENDERERS
       ================================================================ */

    /**
     * Full chip for the profile / dashboard header.
     * Returns empty string when the user has opted out AND has no
     * response-time — i.e. when there is literally nothing useful to show.
     */
    public static function render_chip( $expert ) {
        if ( ! $expert || empty( $expert->user_id ) ) {
            return '';
        }

        $user_id = (int) $expert->user_id;
        $status  = self::get_status( $user_id );

        // Presence block (only when not opted-out).
        $presence_html = '';
        if ( $status !== 'hidden' ) {
            $dot_color = self::color_for_status( $status );
            $label     = self::label_for_status( $status, $user_id );

            // box-shadow halo gives the dot a soft ring that survives
            // the various card backgrounds we render inside.
            $presence_html = sprintf(
                '<span style="display:inline-flex;align-items:center;gap:6px;font-size:0.85rem;color:#374151;">
                    <span aria-hidden="true" style="display:inline-block;width:9px;height:9px;border-radius:50%%;background:%1$s;box-shadow:0 0 0 2px %1$s26;"></span>
                    %2$s
                </span>',
                esc_attr( $dot_color ),
                esc_html( $label )
            );
        }

        // Response-time line — read directly from the expert row so we
        // don't depend on the optional NME_Payments_Bridge class.
        $response_html = '';
        $hours         = isset( $expert->response_time_hours ) ? (int) $expert->response_time_hours : 0;
        if ( $hours > 0 ) {
            $response_html = sprintf(
                '<span style="display:inline-flex;align-items:center;gap:4px;font-size:0.8rem;color:#6B7280;">
                    <span aria-hidden="true">💬</span>
                    Typically replies in %s
                </span>',
                esc_html( self::humanize_hours( $hours ) )
            );
        }

        $parts = array_filter( array( $presence_html, $response_html ) );
        if ( empty( $parts ) ) {
            return '';
        }

        return '<div class="nme-presence-row" style="margin-top:8px;display:flex;flex-wrap:wrap;gap:14px;align-items:center;">'
            . implode( '', $parts )
            . '</div>';
    }

    /**
     * Compact dot + short label for directory / service cards.
     * Omits "away" and "hidden" so card rows don't fill up with
     * low-signal indicators.
     */
    public static function render_card_dot( $user_id ) {
        $status = self::get_status( (int) $user_id );
        if ( $status !== 'online' && $status !== 'recent' ) {
            return '';
        }

        $color      = self::color_for_status( $status );
        $short      = ( $status === 'online' ) ? 'Online' : 'Active';
        $tooltip    = self::label_for_status( $status, (int) $user_id );

        return sprintf(
            '<span title="%1$s" style="display:inline-flex;align-items:center;gap:4px;font-size:0.72rem;color:#6B7280;margin-top:4px;">
                <span aria-hidden="true" style="display:inline-block;width:7px;height:7px;border-radius:50%%;background:%2$s;box-shadow:0 0 0 2px %2$s26;"></span>
                %3$s
            </span>',
            esc_attr( $tooltip ),
            esc_attr( $color ),
            esc_html( $short )
        );
    }

    /* ================================================================
       FILTER HOOKS
       ================================================================ */

    public static function append_profile_presence( $html, $expert ) {
        return $html . self::render_chip( $expert );
    }

    public static function append_card_presence( $html, $user_id ) {
        return $html . self::render_card_dot( $user_id );
    }

    /* ================================================================
       INTERNALS
       ================================================================ */

    private static function color_for_status( $status ) {
        switch ( $status ) {
            case 'online':
                return '#10B981'; // emerald
            case 'recent':
                return '#D4A843'; // gold
            case 'away':
            default:
                return '#9CA3AF'; // slate-400
        }
    }

    private static function label_for_status( $status, $user_id ) {
        switch ( $status ) {
            case 'online':
                return 'Online now';
            case 'recent':
                $diff = self::humanize_last_seen( $user_id );
                return $diff ? 'Active ' . $diff : 'Active recently';
            case 'away':
            default:
                return 'Away';
        }
    }

    /**
     * "4 hours" / "1 day" / "under an hour" — used by the "Typically
     * replies in" string. Kept deliberately short so it fits on one line
     * next to the presence dot.
     */
    private static function humanize_hours( $hours ) {
        $hours = max( 0, (int) $hours );
        if ( $hours < 1 ) {
            return 'under an hour';
        }
        if ( $hours < 24 ) {
            return $hours . ' hour' . ( $hours === 1 ? '' : 's' );
        }
        $days = (int) floor( $hours / 24 );
        return $days . ' day' . ( $days === 1 ? '' : 's' );
    }
}