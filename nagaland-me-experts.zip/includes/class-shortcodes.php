<?php
/**
 * NME_Shortcodes
 * Registers all marketplace shortcodes.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class NME_Shortcodes {

    public static function init() {
        add_shortcode( 'nme_expert_registration_form', array( __CLASS__, 'registration_form' ) );
        add_shortcode( 'nme_expert_edit_application', array( __CLASS__, 'edit_application_form' ) );
        add_shortcode( 'nme_edit_profile', array( __CLASS__, 'edit_profile_form' ) );
        add_shortcode( 'nme_experts_directory', array( __CLASS__, 'experts_directory' ) );
        add_shortcode( 'nme_featured_experts', array( __CLASS__, 'featured_experts' ) );
    }

    /**
     * [nme_expert_registration_form] — Full application form
     */
    public static function registration_form( $atts ) {
        ob_start();

        // Show success message if just submitted
        if ( isset( $_GET['nme_status'] ) && $_GET['nme_status'] === 'application_received' ) {
            ?>
            <div class="nme-card nme-text-center" style="max-width: 720px; margin: 0 auto; border: 2px solid var(--nme-emerald);">
                <div style="font-size: 4rem;">✅</div>
                <h2>Application Received!</h2>
                <p>Thank you for applying to become a Nagaland Me Expert. Our team will review your application within 24 hours (sometimes up to 2 days).</p>
                <p>You'll receive an email and WhatsApp message with the result.</p>
                <p class="nme-mt-3">
                    <a href="<?php echo esc_url( home_url() ); ?>" class="nme-btn">Back to Home</a>
                </p>
            </div>
            <?php
            return ob_get_clean();
        }

        // Show error if any
        if ( isset( $_GET['nme_status'] ) && $_GET['nme_status'] === 'error' ) {
            $msg = isset( $_GET['nme_message'] ) ? sanitize_text_field( urldecode( $_GET['nme_message'] ) ) : 'Something went wrong.';
            echo '<div class="nme-card" style="max-width: 720px; margin: 0 auto 24px; border-left: 4px solid #DC2626; background: #FEF2F2;">';
            echo '<p style="color: #991B1B; margin: 0;"><strong>Error:</strong> ' . esc_html( $msg ) . '</p>';
            echo '</div>';
        }

        $categories = NME_Categories::get_all();
        ?>
        <section class="nme-section">
            <div class="nme-container" style="max-width: 820px;">
                <div class="nme-text-center nme-mb-4">
                    <h2>Apply to Become an Expert</h2>
                    <p>Join Northeast India's most trusted creator services marketplace. We review every application personally.</p>
                </div>

                <form method="post"
                      action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"
                      enctype="multipart/form-data"
                      class="nme-card">

                    <input type="hidden" name="action" value="nme_submit_application">
                    <?php wp_nonce_field( 'nme_expert_application', 'nme_nonce' ); ?>

                    <h3>1. Personal Information</h3>

                    <p>
                        <label>Full Name *</label>
                        <input type="text" name="full_name" required>
                    </p>

                    <div class="nme-grid nme-grid-2">
                        <p>
                            <label>Email *</label>
                            <input type="email" name="email" required>
                        </p>
                        <p>
                            <label>Phone *</label>
                            <input type="tel" name="phone" required placeholder="+91XXXXXXXXXX">
                        </p>
                    </div>

                    <div class="nme-grid nme-grid-2">
                        <p>
                            <label>WhatsApp Number</label>
                            <input type="tel" name="whatsapp" placeholder="Same as phone if applicable">
                        </p>
                        <p>
                            <label>Years of Experience</label>
                            <input type="number" name="years_experience" min="0" max="50" value="0">
                        </p>
                    </div>

                    <div class="nme-grid nme-grid-2">
                        <p>
                            <label>District / City *</label>
                            <input type="text" name="district" required placeholder="e.g., Dimapur">
                        </p>
                        <p>
                            <label>State *</label>
                            <input type="text" name="state" value="Nagaland" required>
                        </p>
                    </div>

                    <p>
                        <label>Street Address *</label>
                        <input type="text" name="street_address" required maxlength="160" placeholder="House / building / lane">
                        <small style="color:#6B7280;">Used for payment KYC. Kept private — never shown on your public profile.</small>
                    </p>

                    <div class="nme-grid nme-grid-2">
                        <p>
                            <label>Village / Locality *</label>
                            <input type="text" name="village_locality" required maxlength="120" placeholder="Village, colony or ward name">
                        </p>
                        <p>
                            <label>PIN Code *</label>
                            <input type="text" name="postal_code" required inputmode="numeric" pattern="\d{6}" maxlength="6" placeholder="797112">
                        </p>
                    </div>

                    <p>
                        <label>Languages You Speak *</label>
                        <input type="text" name="languages" required placeholder="e.g., English, Hindi, Nagamese, Ao">
                    </p>

                    <h3 class="nme-mt-4">2. Your Expertise</h3>

                    <div class="nme-grid nme-grid-2">
                        <p>
                            <label>Primary Category *</label>
                            <select name="primary_category_id" required>
                                <option value="">— Select your main specialty —</option>
                                <?php foreach ( $categories as $cat ) : ?>
                                    <option value="<?php echo (int) $cat->id; ?>">
                                        <?php echo esc_html( $cat->icon . ' ' . $cat->name ); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </p>
                        <p>
                            <label>Secondary Category</label>
                            <select name="secondary_category_id">
                                <option value="">— Optional: select another skill —</option>
                                <?php foreach ( $categories as $cat ) : ?>
                                    <option value="<?php echo (int) $cat->id; ?>">
                                        <?php echo esc_html( $cat->icon . ' ' . $cat->name ); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </p>
                    </div>

                    <p>
                        <label>Tagline (one line about you)</label>
                        <input type="text" name="tagline" maxlength="160" placeholder="e.g., I help YouTubers fix monetization issues fast">
                    </p>

                    <p>
                        <label>About You *</label>
                        <textarea name="bio" rows="5" required placeholder="Tell us about your skills, experience, past work, and why you want to join Nagaland Me Experts."></textarea>
                    </p>

                    <h3 class="nme-mt-4">3. Portfolio & Channels</h3>

                    <p>
                        <label>Portfolio URL</label>
                        <input type="url" name="portfolio_url" placeholder="https://...">
                    </p>

                    <div class="nme-grid nme-grid-2">
                        <p>
                            <label>Your YouTube Channel</label>
                            <input type="url" name="youtube_channel" placeholder="https://youtube.com/@...">
                        </p>
                        <p>
                            <label>Your Facebook Page</label>
                            <input type="url" name="facebook_page" placeholder="https://facebook.com/...">
                        </p>
                    </div>

                    <p>
                        <label>Profile Photo</label>
                        <input type="file" name="profile_photo" accept="image/*">
                        <small style="color: var(--nme-text-light);">A clear photo of you. Will be used on your public profile.</small>
                    </p>

                    <div class="nme-card" style="background: #F0FDF4; border: 1.5px solid #BBF7D0; margin-top: 24px;">
                        <p style="margin: 0; color: #065F46;">
                            <strong>💡 What happens next?</strong><br>
                            After registration, you can complete your KYC verification and add your payout details from your expert dashboard. This is required before you can start receiving payments.
                        </p>
                    </div>

                    <p class="nme-mt-4">
                        <label style="font-weight: 400; font-size: 0.9rem;">
                            <input type="checkbox" required style="width: auto; margin-right: 8px;">
                            I confirm all information provided is accurate. I agree to the
                            <a href="/terms-of-service/" target="_blank">Terms of Service</a>,
                            <a href="/privacy-policy/" target="_blank">Privacy Policy</a>, and
                            <a href="/refund-policy/" target="_blank">Refund Policy</a>.
                        </label>
                    </p>

                    <p class="nme-text-center nme-mt-4">
                        <button type="submit" class="nme-btn nme-btn-gold" style="font-size: 1.1rem; padding: 16px 48px;">
                            Submit Application
                        </button>
                    </p>

                </form>
            </div>
        </section>
        <?php
        return ob_get_clean();
    }

    /**
     * [nme_expert_edit_application] — Edit & resubmit a rejected (or still-
     * pending) application. Gated by: (a) must be logged in, (b) must own a
     * matching expert row, (c) row status must be rejected or pending. Once
     * approved, this flow is off-limits and changes go through the regulated
     * change-request flow instead.
     *
     * The form mirrors registration_form() but:
     *   - pre-fills every field from the expert row
     *   - omits the email field (identity-critical, locked)
     *   - posts to admin_post_nme_edit_application with a per-expert nonce
     *   - shows the previous rejection reason prominently at the top
     */
    public static function edit_application_form( $atts ) {
        ob_start();

        // Gate 1: must be logged in.
        if ( ! is_user_logged_in() ) {
            ?>
            <div class="nme-card nme-text-center" style="max-width: 720px; margin: 0 auto;">
                <h2>Sign in to edit your application</h2>
                <p>You need to be logged in to edit and resubmit your expert application. If you don't know your password yet, use the link in the email we sent you or reset it below.</p>
                <p class="nme-mt-3">
                    <a class="nme-btn nme-btn-gold" href="<?php echo esc_url( wp_login_url( home_url( '/edit-application/' ) ) ); ?>">Log In</a>
                    <a class="nme-btn" href="<?php echo esc_url( wp_lostpassword_url( home_url( '/edit-application/' ) ) ); ?>">Forgot password</a>
                </p>
            </div>
            <?php
            return ob_get_clean();
        }

        // Gate 2: must have an expert row.
        $user_id = get_current_user_id();
        $expert  = NME_Experts::get_by_user( $user_id );
        if ( ! $expert ) {
            ?>
            <div class="nme-card nme-text-center" style="max-width: 720px; margin: 0 auto;">
                <h2>No application found</h2>
                <p>We could not find an expert application linked to your account.</p>
                <p class="nme-mt-3">
                    <a class="nme-btn nme-btn-gold" href="<?php echo esc_url( home_url( '/expert-register/' ) ); ?>">Apply to Become an Expert</a>
                </p>
            </div>
            <?php
            return ob_get_clean();
        }

        // Gate 3: status must be rejected or pending.
        $editable_statuses = array( NME_Experts::STATUS_REJECTED, NME_Experts::STATUS_PENDING );
        if ( ! in_array( $expert->status, $editable_statuses, true ) ) {
            ?>
            <div class="nme-card nme-text-center" style="max-width: 720px; margin: 0 auto;">
                <h2>This form is not available</h2>
                <p>Your application is no longer in a state where it can be edited here. Please use your dashboard's account-change options instead.</p>
                <p class="nme-mt-3">
                    <a class="nme-btn nme-btn-gold" href="<?php echo esc_url( home_url( '/expert-dashboard/' ) ); ?>">Go to Dashboard</a>
                </p>
            </div>
            <?php
            return ob_get_clean();
        }

        // Flash: successful resubmit → redirect sends user to dashboard, but
        // if for some reason they land back here, show the state clearly.
        if ( isset( $_GET['nme_status'] ) && $_GET['nme_status'] === 'application_resubmitted' ) {
            ?>
            <div class="nme-card nme-text-center" style="max-width: 720px; margin: 0 auto; border: 2px solid var(--nme-emerald);">
                <div style="font-size: 4rem;">✅</div>
                <h2>Application Resubmitted</h2>
                <p>Thanks — your updated application is back with our review team. We will get back to you within <strong>24 hours (sometimes up to 2 days)</strong>.</p>
                <p class="nme-mt-3">
                    <a class="nme-btn nme-btn-gold" href="<?php echo esc_url( home_url( '/expert-dashboard/' ) ); ?>">Go to Dashboard</a>
                </p>
            </div>
            <?php
            return ob_get_clean();
        }

        // Inline error flash.
        if ( isset( $_GET['nme_status'] ) && $_GET['nme_status'] === 'error' ) {
            $msg = isset( $_GET['nme_message'] ) ? sanitize_text_field( urldecode( $_GET['nme_message'] ) ) : 'Something went wrong.';
            echo '<div class="nme-card" style="max-width: 820px; margin: 0 auto 24px; border-left: 4px solid #DC2626; background: #FEF2F2;">';
            echo '<p style="color: #991B1B; margin: 0;"><strong>Error:</strong> ' . esc_html( $msg ) . '</p>';
            echo '</div>';
        }

        $categories = NME_Categories::get_all();
        $is_rejected = ( $expert->status === NME_Experts::STATUS_REJECTED );
        ?>
        <section class="nme-section">
            <div class="nme-container" style="max-width: 820px;">
                <div class="nme-text-center nme-mb-4">
                    <h2><?php echo $is_rejected ? 'Edit &amp; Resubmit Your Application' : 'Edit Your Application'; ?></h2>
                    <p><?php echo $is_rejected
                        ? 'Address the feedback below and resubmit. Your existing details are pre-filled — change only what needs fixing.'
                        : 'Your application is still under review. You can make edits here while you wait for a decision.'; ?></p>
                </div>

                <?php if ( $is_rejected && ! empty( $expert->rejection_reason ) ) : ?>
                    <div class="nme-card" style="border-left: 4px solid #DC2626; background: #FEF2F2; margin-bottom: 24px;">
                        <p style="margin: 0 0 6px; font-weight: 700; color: #991B1B;">Reason we could not approve the last version:</p>
                        <p style="margin: 0; color: #7F1D1D; white-space: pre-wrap;"><?php echo esc_html( $expert->rejection_reason ); ?></p>
                    </div>
                <?php endif; ?>

                <form method="post"
                      action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"
                      enctype="multipart/form-data"
                      class="nme-card">

                    <input type="hidden" name="action" value="nme_edit_application">
                    <input type="hidden" name="expert_id" value="<?php echo (int) $expert->id; ?>">
                    <?php wp_nonce_field( 'nme_edit_application_' . (int) $expert->id, 'nme_nonce' ); ?>

                    <h3>1. Personal Information</h3>

                    <p>
                        <label>Full Name *</label>
                        <input type="text" name="full_name" required value="<?php echo esc_attr( $expert->full_name ); ?>">
                    </p>

                    <div class="nme-grid nme-grid-2">
                        <p>
                            <label>Email</label>
                            <input type="email" value="<?php echo esc_attr( $expert->email ); ?>" disabled>
                            <small style="color:#6B7280;">To change your email, contact support.</small>
                        </p>
                        <p>
                            <label>Phone *</label>
                            <input type="tel" name="phone" required placeholder="+91XXXXXXXXXX" value="<?php echo esc_attr( $expert->phone ); ?>">
                        </p>
                    </div>

                    <div class="nme-grid nme-grid-2">
                        <p>
                            <label>WhatsApp Number</label>
                            <input type="tel" name="whatsapp" value="<?php echo esc_attr( $expert->whatsapp ); ?>" placeholder="Same as phone if applicable">
                        </p>
                        <p>
                            <label>Years of Experience</label>
                            <input type="number" name="years_experience" min="0" max="50" value="<?php echo (int) $expert->years_experience; ?>">
                        </p>
                    </div>

                    <div class="nme-grid nme-grid-2">
                        <p>
                            <label>District / City *</label>
                            <input type="text" name="district" required placeholder="e.g., Dimapur" value="<?php echo esc_attr( $expert->district ); ?>">
                        </p>
                        <p>
                            <label>State *</label>
                            <input type="text" name="state" required value="<?php echo esc_attr( $expert->state ?: 'Nagaland' ); ?>">
                        </p>
                    </div>

                    <p>
                        <label>Street Address *</label>
                        <input type="text" name="street_address" required maxlength="160" placeholder="House / building / lane" value="<?php echo esc_attr( $expert->street_address ); ?>">
                        <small style="color:#6B7280;">Used for payment KYC. Kept private — never shown on your public profile.</small>
                    </p>

                    <div class="nme-grid nme-grid-2">
                        <p>
                            <label>Village / Locality *</label>
                            <input type="text" name="village_locality" required maxlength="120" placeholder="Village, colony or ward name" value="<?php echo esc_attr( $expert->village_locality ); ?>">
                        </p>
                        <p>
                            <label>PIN Code *</label>
                            <input type="text" name="postal_code" required inputmode="numeric" pattern="\d{6}" maxlength="6" placeholder="797112" value="<?php echo esc_attr( $expert->postal_code ); ?>">
                        </p>
                    </div>

                    <p>
                        <label>Languages You Speak *</label>
                        <input type="text" name="languages" required placeholder="e.g., English, Hindi, Nagamese, Ao" value="<?php echo esc_attr( $expert->languages ); ?>">
                    </p>

                    <h3 class="nme-mt-4">2. Your Expertise</h3>

                    <div class="nme-grid nme-grid-2">
                        <p>
                            <label>Primary Category *</label>
                            <select name="primary_category_id" required>
                                <option value="">— Select your main specialty —</option>
                                <?php foreach ( $categories as $cat ) : ?>
                                    <option value="<?php echo (int) $cat->id; ?>" <?php selected( (int) $expert->primary_category_id, (int) $cat->id ); ?>>
                                        <?php echo esc_html( $cat->icon . ' ' . $cat->name ); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </p>
                        <p>
                            <label>Secondary Category</label>
                            <select name="secondary_category_id">
                                <option value="">— Optional: select another skill —</option>
                                <?php foreach ( $categories as $cat ) : ?>
                                    <option value="<?php echo (int) $cat->id; ?>" <?php selected( (int) $expert->secondary_category_id, (int) $cat->id ); ?>>
                                        <?php echo esc_html( $cat->icon . ' ' . $cat->name ); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </p>
                    </div>

                    <p>
                        <label>Tagline (one line about you)</label>
                        <input type="text" name="tagline" maxlength="160" placeholder="e.g., I help YouTubers fix monetization issues fast" value="<?php echo esc_attr( $expert->tagline ); ?>">
                    </p>

                    <p>
                        <label>About You *</label>
                        <textarea name="bio" rows="5" required placeholder="Tell us about your skills, experience, past work, and why you want to join Nagaland Me Experts."><?php echo esc_textarea( $expert->bio ); ?></textarea>
                    </p>

                    <h3 class="nme-mt-4">3. Portfolio &amp; Channels</h3>

                    <p>
                        <label>Portfolio URL</label>
                        <input type="url" name="portfolio_url" placeholder="https://..." value="<?php echo esc_attr( $expert->portfolio_url ); ?>">
                    </p>

                    <div class="nme-grid nme-grid-2">
                        <p>
                            <label>Your YouTube Channel</label>
                            <input type="url" name="youtube_channel" placeholder="https://youtube.com/@..." value="<?php echo esc_attr( $expert->youtube_channel ); ?>">
                        </p>
                        <p>
                            <label>Your Facebook Page</label>
                            <input type="url" name="facebook_page" placeholder="https://facebook.com/..." value="<?php echo esc_attr( $expert->facebook_page ); ?>">
                        </p>
                    </div>

                    <p>
                        <label>Profile Photo</label>
                        <?php if ( ! empty( $expert->profile_photo ) ) : ?>
                            <span style="display:block;margin:4px 0 8px;">
                                <img src="<?php echo esc_url( $expert->profile_photo ); ?>" alt="" style="width:72px;height:72px;border-radius:50%;object-fit:cover;border:2px solid var(--nme-gold);vertical-align:middle;">
                                <span style="color:#6B7280;font-size:0.85rem;margin-left:8px;">Current photo — leave the file picker empty to keep it.</span>
                            </span>
                        <?php endif; ?>
                        <input type="file" name="profile_photo" accept="image/*">
                        <small style="color: var(--nme-text-light);">Upload a new photo only if you want to replace the current one.</small>
                    </p>

                    <div class="nme-card" style="background: #F0FDF4; border: 1.5px solid #BBF7D0; margin-top: 24px;">
                        <p style="margin: 0; color: #065F46;">
                            <strong>💡 After you resubmit:</strong><br>
                            Your application goes back into the pending queue. Our team reviews every resubmission within <strong>24 hours (sometimes up to 2 days)</strong>. You will get an email once a decision has been made.
                        </p>
                    </div>

                    <p class="nme-mt-4">
                        <label style="font-weight: 400; font-size: 0.9rem;">
                            <input type="checkbox" required style="width: auto; margin-right: 8px;">
                            I confirm the updated information is accurate. I agree to the
                            <a href="/terms-of-service/" target="_blank" rel="noopener">Terms of Service</a>,
                            <a href="/privacy-policy/" target="_blank" rel="noopener">Privacy Policy</a>, and
                            <a href="/refund-policy/" target="_blank" rel="noopener">Refund Policy</a>.
                        </label>
                    </p>

                    <p class="nme-text-center nme-mt-4">
                        <button type="submit" class="nme-btn nme-btn-gold" style="font-size: 1.1rem; padding: 16px 48px;">
                            <?php echo $is_rejected ? 'Resubmit Application' : 'Save Changes'; ?>
                        </button>
                    </p>

                </form>
            </div>
        </section>
        <?php
        return ob_get_clean();
    }

    /**
     * [nme_edit_profile] — v0.8.0
     *
     * Self-service "edit your public About & bio" form for APPROVED experts.
     *
     * Distinct from [nme_expert_edit_application] which is for pending/rejected
     * applicants going back through review. This form:
     *   - Only accepts approved experts
     *   - Only writes tagline, bio, languages, portfolio_url, youtube_channel,
     *     facebook_page — nothing that would require re-review or re-KYC
     *   - Does NOT flip the expert back to pending on save
     *   - Posts to admin-post.php with action=nme_edit_profile
     */
    public static function edit_profile_form( $atts ) {
        ob_start();

        // Gate 1: must be logged in.
        if ( ! is_user_logged_in() ) {
            ?>
            <div class="nme-card nme-text-center" style="max-width: 720px; margin: 0 auto;">
                <h2>Sign in to edit your profile</h2>
                <p>You need to be logged in to edit your public expert profile.</p>
                <p class="nme-mt-3">
                    <a class="nme-btn nme-btn-gold" href="<?php echo esc_url( wp_login_url( home_url( '/edit-profile/' ) ) ); ?>">Log In</a>
                </p>
            </div>
            <?php
            return ob_get_clean();
        }

        // Gate 2: must have an expert row.
        $user_id = get_current_user_id();
        $expert  = NME_Experts::get_by_user( $user_id );
        if ( ! $expert ) {
            ?>
            <div class="nme-card nme-text-center" style="max-width: 720px; margin: 0 auto;">
                <h2>No expert profile found</h2>
                <p>We could not find an expert profile linked to your account.</p>
                <p class="nme-mt-3">
                    <a class="nme-btn nme-btn-gold" href="<?php echo esc_url( home_url( '/expert-register/' ) ); ?>">Apply to Become an Expert</a>
                </p>
            </div>
            <?php
            return ob_get_clean();
        }

        // Gate 3: status must be approved — pending/rejected use /edit-application/.
        if ( $expert->status !== NME_Experts::STATUS_APPROVED ) {
            $target = home_url( '/edit-application/' );
            ?>
            <div class="nme-card nme-text-center" style="max-width: 720px; margin: 0 auto;">
                <h2>This form is for approved experts</h2>
                <p>Your application is currently <strong><?php echo esc_html( $expert->status ); ?></strong>. Use the application editor to update or resubmit your details.</p>
                <p class="nme-mt-3">
                    <a class="nme-btn nme-btn-gold" href="<?php echo esc_url( $target ); ?>">Edit Application</a>
                    <a class="nme-btn" href="<?php echo esc_url( home_url( '/expert-dashboard/' ) ); ?>">Dashboard</a>
                </p>
            </div>
            <?php
            return ob_get_clean();
        }

        // Success flash.
        if ( isset( $_GET['nme_status'] ) && $_GET['nme_status'] === 'profile_updated' ) {
            ?>
            <div class="nme-card" style="max-width: 820px; margin: 0 auto 24px; border-left: 4px solid #10B981; background: #ECFDF5;">
                <p style="color: #065F46; margin: 0;"><strong>✅ Saved.</strong> Your public profile has been updated.</p>
            </div>
            <?php
        }

        // Error flash.
        if ( isset( $_GET['nme_status'] ) && $_GET['nme_status'] === 'error' ) {
            $msg = isset( $_GET['nme_message'] ) ? sanitize_text_field( urldecode( $_GET['nme_message'] ) ) : 'Something went wrong.';
            echo '<div class="nme-card" style="max-width: 820px; margin: 0 auto 24px; border-left: 4px solid #DC2626; background: #FEF2F2;">';
            echo '<p style="color: #991B1B; margin: 0;"><strong>Error:</strong> ' . esc_html( $msg ) . '</p>';
            echo '</div>';
        }

        $public_slug = sanitize_title( (string) $expert->full_name );
        $public_url  = $public_slug ? home_url( '/expert/' . $public_slug . '/' ) : '';
        ?>
        <section class="nme-section">
            <div class="nme-container" style="max-width: 820px;">
                <div class="nme-text-center nme-mb-4">
                    <h2>Edit Your Public Profile</h2>
                    <p>Update how buyers see you on your public expert page. Changes are live immediately — no re-review needed.</p>
                    <?php if ( $public_url ) : ?>
                        <p style="margin-top: 6px;">
                            <a href="<?php echo esc_url( $public_url ); ?>" target="_blank" rel="noopener" style="font-size: 0.9rem;">View your public profile ↗</a>
                        </p>
                    <?php endif; ?>
                </div>

                <div class="nme-card" style="background: #F0FDF4; border: 1.5px solid #BBF7D0; margin-bottom: 24px;">
                    <p style="margin: 0; color: #065F46; font-size: 0.9rem;">
                        <strong>ℹ️ This form edits public text only.</strong>
                        To change your name, email, phone, address, category, photo, or bank details, use your
                        <a href="<?php echo esc_url( home_url( '/expert-dashboard/' ) ); ?>" style="color: #065F46; text-decoration: underline;">dashboard</a>.
                    </p>
                </div>

                <form method="post"
                      action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"
                      class="nme-card">

                    <input type="hidden" name="action" value="nme_edit_profile">
                    <input type="hidden" name="expert_id" value="<?php echo (int) $expert->id; ?>">
                    <?php wp_nonce_field( 'nme_edit_profile_' . (int) $expert->id, 'nme_nonce' ); ?>

                    <p>
                        <label>Tagline (one line under your name)</label>
                        <input type="text" name="tagline" maxlength="160" placeholder="e.g., I help YouTubers fix monetization issues fast" value="<?php echo esc_attr( $expert->tagline ); ?>">
                        <small style="color:#6B7280;">Up to 160 characters. Shown right below your name on your public profile.</small>
                    </p>

                    <p>
                        <label>About You *</label>
                        <textarea name="bio" rows="6" required placeholder="Tell buyers about your skills, experience, and the kind of work you do best."><?php echo esc_textarea( $expert->bio ); ?></textarea>
                        <small style="color:#6B7280;">Minimum 30 characters. This appears in the "About" section of your profile.</small>
                    </p>

                    <p>
                        <label>Languages You Speak *</label>
                        <input type="text" name="languages" required placeholder="e.g., English, Hindi, Nagamese, Ao" value="<?php echo esc_attr( $expert->languages ); ?>">
                    </p>

                    <p>
                        <label>Portfolio URL</label>
                        <input type="url" name="portfolio_url" placeholder="https://..." value="<?php echo esc_attr( $expert->portfolio_url ); ?>">
                    </p>

                    <div class="nme-grid nme-grid-2">
                        <p>
                            <label>YouTube Channel</label>
                            <input type="url" name="youtube_channel" placeholder="https://youtube.com/@..." value="<?php echo esc_attr( $expert->youtube_channel ); ?>">
                        </p>
                        <p>
                            <label>Facebook Page</label>
                            <input type="url" name="facebook_page" placeholder="https://facebook.com/..." value="<?php echo esc_attr( $expert->facebook_page ); ?>">
                        </p>
                    </div>

                    <p class="nme-text-center nme-mt-4">
                        <button type="submit" class="nme-btn nme-btn-gold" style="font-size: 1.1rem; padding: 14px 40px;">
                            Save Changes
                        </button>
                        <a href="<?php echo esc_url( home_url( '/expert-dashboard/' ) ); ?>" class="nme-btn" style="margin-left: 12px;">Cancel</a>
                    </p>

                </form>
            </div>
        </section>
        <?php
        return ob_get_clean();
    }

    /**
     * [nme_experts_directory] — Browse approved experts, with optional
     * filters: category, tier, district, language, q (free-text search).
     * Supports a `?page=N` query for pagination and `filters="0"` to
     * render without the filter bar (useful when embedding as a strip).
     */
    public static function experts_directory( $atts ) {
        $a = shortcode_atts( array(
            'category' => '',
            'limit'    => 24,
            'filters'  => '1',
        ), $atts );

        // Read filters from query args first, then fall back to shortcode attrs.
        $q          = isset( $_GET['q'] )        ? sanitize_text_field( wp_unslash( $_GET['q'] ) ) : '';
        $cat_slug   = isset( $_GET['category'] ) ? sanitize_title( wp_unslash( $_GET['category'] ) ) : sanitize_title( $a['category'] );
        $district   = isset( $_GET['district'] ) ? sanitize_text_field( wp_unslash( $_GET['district'] ) ) : '';
        $tier       = isset( $_GET['tier'] )     ? sanitize_key( wp_unslash( $_GET['tier'] ) )     : '';
        $language   = isset( $_GET['language'] ) ? sanitize_text_field( wp_unslash( $_GET['language'] ) ) : '';
        $online     = isset( $_GET['online'] ) && $_GET['online'] === '1';
        $page       = max( 1, isset( $_GET['paged'] ) ? (int) $_GET['paged'] : 1 );
        $limit      = max( 1, (int) $a['limit'] );

        $category_id = 0;
        if ( $cat_slug ) {
            $cat = NME_Categories::get_by_slug( $cat_slug );
            if ( $cat ) $category_id = (int) $cat->id;
        }

        // When filtering by "online now" we over-fetch to account for post-filter drop.
        $fetch_limit = $online ? ( $limit * 4 ) : $limit;

        $result = NME_Experts::search_approved( array(
            'q'           => $q,
            'category_id' => $category_id,
            'district'    => $district,
            'tier'        => $tier,
            'language'    => $language,
            'limit'       => $fetch_limit,
            'offset'      => ( $page - 1 ) * $limit,
        ) );

        $rows  = $result['rows'];
        $total = (int) $result['total'];

        if ( $online && class_exists( 'NME_Payments_Bridge' ) ) {
            $rows = array_values( array_filter( $rows, function ( $r ) {
                return NME_Payments_Bridge::is_online( (int) $r->id );
            } ) );
            if ( count( $rows ) > $limit ) $rows = array_slice( $rows, 0, $limit );
        }

        $categories = NME_Categories::get_all();
        $districts  = NME_Experts::distinct_districts();
        $show_bar   = $a['filters'] !== '0';
        $pages      = max( 1, (int) ceil( $total / $limit ) );

        ob_start();
        ?>
        <section class="nme-section">
            <div class="nme-container">
                <?php if ( $show_bar ) : ?>
                    <form method="get" role="search" aria-label="Filter experts" class="nme-card" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:10px;align-items:end;margin-bottom:24px;">
                        <div>
                            <label style="font-size:0.8rem;color:#6B7280;display:block;">Search</label>
                            <input type="search" name="q" value="<?php echo esc_attr( $q ); ?>" placeholder="Name or skill" style="width:100%;padding:8px;border:1px solid #E5E7EB;border-radius:6px;">
                        </div>
                        <div>
                            <label style="font-size:0.8rem;color:#6B7280;display:block;">Category</label>
                            <select name="category" style="width:100%;padding:8px;border:1px solid #E5E7EB;border-radius:6px;">
                                <option value="">All categories</option>
                                <?php foreach ( $categories as $c ) : ?>
                                    <option value="<?php echo esc_attr( $c->slug ); ?>" <?php selected( $cat_slug, $c->slug ); ?>>
                                        <?php echo esc_html( trim( ( $c->icon ? $c->icon . ' ' : '' ) . $c->name ) ); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div>
                            <label style="font-size:0.8rem;color:#6B7280;display:block;">District</label>
                            <select name="district" style="width:100%;padding:8px;border:1px solid #E5E7EB;border-radius:6px;">
                                <option value="">All districts</option>
                                <?php foreach ( $districts as $d ) : ?>
                                    <option value="<?php echo esc_attr( $d ); ?>" <?php selected( strtolower( $district ), strtolower( $d ) ); ?>>
                                        <?php echo esc_html( $d ); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div>
                            <label style="font-size:0.8rem;color:#6B7280;display:block;">Tier</label>
                            <select name="tier" style="width:100%;padding:8px;border:1px solid #E5E7EB;border-radius:6px;">
                                <option value="">Any tier</option>
                                <option value="top_pro" <?php selected( $tier, 'top_pro' ); ?>>Top Pro</option>
                                <option value="pro"     <?php selected( $tier, 'pro' ); ?>>Pro</option>
                                <option value="rising"  <?php selected( $tier, 'rising' ); ?>>Rising Talent</option>
                                <option value="new"     <?php selected( $tier, 'new' ); ?>>New</option>
                            </select>
                        </div>
                        <div>
                            <label style="font-size:0.8rem;color:#6B7280;display:block;">Language</label>
                            <input type="text" name="language" value="<?php echo esc_attr( $language ); ?>" placeholder="e.g. Nagamese" style="width:100%;padding:8px;border:1px solid #E5E7EB;border-radius:6px;">
                        </div>
                        <div>
                            <label style="font-size:0.8rem;color:#6B7280;display:block;">&nbsp;</label>
                            <label style="display:flex;align-items:center;gap:6px;padding:8px 0;font-size:0.9rem;">
                                <input type="checkbox" name="online" value="1" <?php checked( $online ); ?>>
                                Online now
                            </label>
                        </div>
                        <div>
                            <button type="submit" class="nme-btn nme-btn-gold" style="width:100%;">Search</button>
                        </div>
                    </form>

                    <p style="color:#6B7280;font-size:0.9rem;margin:0 0 16px;">
                        <?php echo (int) count( $rows ); ?> of <?php echo (int) $total; ?> experts
                    </p>
                <?php endif; ?>

                <?php if ( empty( $rows ) ) : ?>
                    <div class="nme-text-center">
                        <h2>No experts match those filters</h2>
                        <p style="font-size: 1.05rem; color: var(--nme-text-light);">
                            Try broadening your search, or join the waitlist — we're onboarding new experts every week.
                        </p>
                        <p class="nme-mt-3">
                            <a href="https://wa.me/916383359495?text=Add%20me%20to%20the%20Nagaland%20Me%20Experts%20waitlist" class="nme-btn nme-btn-gold" rel="noopener">
                                Join Waitlist
                            </a>
                        </p>
                    </div>
                <?php else : ?>
                    <div class="nme-grid nme-grid-3" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:16px;">
                        <?php foreach ( $rows as $expert ) : ?>
                            <a href="<?php echo esc_url( NME_Frontend::get_profile_url( $expert ) ); ?>" class="nme-card" style="text-decoration: none; display: block;">
                                <?php if ( $expert->profile_photo ) : ?>
                                    <img src="<?php echo esc_url( $expert->profile_photo ); ?>"
                                         alt="<?php echo esc_attr( $expert->full_name ); ?>"
                                         loading="lazy"
                                         style="width: 80px; height: 80px; border-radius: 50%; object-fit: cover; border: 3px solid var(--nme-gold); margin-bottom: 16px;">
                                <?php else : ?>
                                    <div style="width:80px;height:80px;border-radius:50%;background:var(--nme-cream);display:flex;align-items:center;justify-content:center;font-size:2rem;color:var(--nme-forest);border:3px solid var(--nme-gold);margin-bottom:16px;">
                                        <?php echo esc_html( strtoupper( substr( $expert->full_name, 0, 1 ) ) ); ?>
                                    </div>
                                <?php endif; ?>
                                <h3 style="font-size: 1.15rem; margin-bottom: 4px;">
                                    <?php echo esc_html( $expert->full_name ); ?>
                                </h3>
                                <div style="margin-bottom: 8px;display:flex;flex-wrap:wrap;gap:6px;align-items:center;">
                                    <?php echo NME_Experts::get_tier_badge( $expert->tier ); ?>
                                    <?php if ( ! empty( $expert->user_id ) ) { echo apply_filters( 'nmep_expert_profile_after_name', '', $expert ); } ?>
                                </div>
                                <?php if ( $expert->tagline ) : ?>
                                    <p style="color: var(--nme-text-light); font-size: 0.9rem;margin:0 0 8px;">
                                        <?php echo esc_html( wp_trim_words( $expert->tagline, 18, '…' ) ); ?>
                                    </p>
                                <?php endif; ?>
                                <div style="display:flex;justify-content:space-between;align-items:center;color:#6B7280;font-size:0.85rem;">
                                    <span><?php echo esc_html( $expert->district ?: '' ); ?></span>
                                    <?php if ( (float) $expert->avg_rating > 0 ) : ?>
                                        <span>★ <?php echo number_format( (float) $expert->avg_rating, 1 ); ?> · <?php echo (int) $expert->total_orders; ?> orders</span>
                                    <?php endif; ?>
                                </div>
                                <p style="color: var(--nme-emerald); font-weight: 600; margin-top: 10px;margin-bottom:0;">
                                    View Profile →
                                </p>
                            </a>
                        <?php endforeach; ?>
                    </div>

                    <?php if ( $show_bar && $pages > 1 && ! $online ) : ?>
                        <nav aria-label="Experts pagination" style="display:flex;justify-content:center;gap:8px;margin-top:24px;flex-wrap:wrap;">
                            <?php
                            $base = remove_query_arg( 'paged' );
                            for ( $p = 1; $p <= $pages; $p++ ) :
                                $url = esc_url( add_query_arg( 'paged', $p, $base ) );
                                $is  = $p === $page;
                            ?>
                                <a href="<?php echo $url; ?>" style="padding:6px 12px;border-radius:6px;border:1px solid <?php echo $is ? '#0A7558' : '#E5E7EB'; ?>;background:<?php echo $is ? '#0A7558' : '#fff'; ?>;color:<?php echo $is ? '#fff' : '#374151'; ?>;text-decoration:none;font-size:0.9rem;">
                                    <?php echo (int) $p; ?>
                                </a>
                            <?php endfor; ?>
                        </nav>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </section>
        <?php
        return ob_get_clean();
    }

    /**
     * [nme_featured_experts limit="6"] — Featured experts strip (no filter bar)
     */
    public static function featured_experts( $atts ) {
        $a = shortcode_atts( array( 'limit' => 6 ), $atts );
        return self::experts_directory( array( 'limit' => $a['limit'], 'filters' => '0' ) );
    }
}