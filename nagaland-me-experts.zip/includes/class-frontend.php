<?php
/**
 * NME_Frontend
 * Handles public-facing display of experts and routing.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class NME_Frontend {

    /** @var object|null Cached expert for the current request, set in handle_template_redirect */
    private static $current_expert = null;

    public static function init() {
        add_action( 'init', array( __CLASS__, 'add_rewrite_rules' ) );
        add_filter( 'query_vars', array( __CLASS__, 'add_query_vars' ) );
        add_action( 'template_redirect', array( __CLASS__, 'handle_template_redirect' ) );
        add_action( 'wp_head', array( __CLASS__, 'emit_head_meta' ), 5 );
        add_filter( 'document_title_parts', array( __CLASS__, 'filter_title_parts' ) );
    }

    /**
     * Add rewrite rules for /expert/{slug}/ URLs
     */
    public static function add_rewrite_rules() {
        add_rewrite_rule(
            '^expert/([^/]+)/?$',
            'index.php?nme_expert_slug=$matches[1]',
            'top'
        );
    }

    public static function add_query_vars( $vars ) {
        $vars[] = 'nme_expert_slug';
        return $vars;
    }

    /**
     * Resolve /expert/{slug}/ to an approved expert row (or 404).
     * Caches the row so emit_head_meta and render_expert_profile use the same data.
     *
     * We compare slugs in PHP (via sanitize_title) rather than in SQL so
     * names with apostrophes, dots, accented characters etc. resolve
     * the same way they're generated in get_profile_url().
     */
    public static function handle_template_redirect() {
        $slug = sanitize_title( (string) get_query_var( 'nme_expert_slug' ) );
        if ( ! $slug ) return;

        global $wpdb;
        $rows = $wpdb->get_results(
            "SELECT * FROM " . NME_Database::table( 'experts' ) . " WHERE status = 'approved'"
        );

        $expert = null;
        foreach ( (array) $rows as $r ) {
            if ( sanitize_title( (string) $r->full_name ) === $slug ) {
                $expert = $r;
                break;
            }
        }

        if ( ! $expert ) {
            global $wp_query;
            $wp_query->set_404();
            status_header( 404 );
            nocache_headers();
            return;
        }

        self::$current_expert = $expert;

        get_header();
        self::render_expert_profile( $expert );
        get_footer();
        exit;
    }

    /**
     * Filter wp_title (document_title_parts) on expert pages so browser
     * tabs and search results get a useful title without touching the theme.
     */
    public static function filter_title_parts( $parts ) {
        if ( ! self::$current_expert ) return $parts;
        $e = self::$current_expert;
        $tagline = $e->tagline ? ' — ' . $e->tagline : '';
        $parts['title'] = $e->full_name . $tagline;
        return $parts;
    }

    /**
     * Emit Open Graph + Twitter Card tags on expert profiles so shares
     * to Facebook / WhatsApp / Twitter / newspaper CMS render cleanly.
     * JSON-LD is handled in Phase C6.
     */
    public static function emit_head_meta() {
        if ( ! self::$current_expert ) return;
        $e   = self::$current_expert;
        $url = self::get_profile_url( $e );
        $desc = $e->tagline ?: ( $e->bio ? wp_trim_words( wp_strip_all_tags( $e->bio ), 30, '...' ) : 'Verified expert on Nagaland Me Experts.' );
        $img = $e->profile_photo ?: '';
        ?>
        <!-- Nagaland Me Experts: profile meta -->
        <meta property="og:type" content="profile">
        <meta property="og:title" content="<?php echo esc_attr( $e->full_name ); ?>">
        <meta property="og:description" content="<?php echo esc_attr( $desc ); ?>">
        <meta property="og:url" content="<?php echo esc_url( $url ); ?>">
        <meta property="og:site_name" content="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>">
        <?php if ( $img ) : ?>
            <meta property="og:image" content="<?php echo esc_url( $img ); ?>">
            <meta property="og:image:alt" content="<?php echo esc_attr( $e->full_name ); ?>">
        <?php endif; ?>
        <meta name="twitter:card" content="<?php echo $img ? 'summary_large_image' : 'summary'; ?>">
        <meta name="twitter:title" content="<?php echo esc_attr( $e->full_name ); ?>">
        <meta name="twitter:description" content="<?php echo esc_attr( $desc ); ?>">
        <?php if ( $img ) : ?>
            <meta name="twitter:image" content="<?php echo esc_url( $img ); ?>">
        <?php endif; ?>
        <meta name="description" content="<?php echo esc_attr( $desc ); ?>">
        <link rel="canonical" href="<?php echo esc_url( $url ); ?>">
        <?php
    }

    /**
     * Render the public expert profile.
     */
    public static function render_expert_profile( $expert ) {
        $category     = NME_Categories::get_by_id( $expert->primary_category_id );
        $sub_category = ! empty( $expert->secondary_category_id ) ? NME_Categories::get_by_id( $expert->secondary_category_id ) : null;
        $tier_badge   = NME_Experts::get_tier_badge( $expert->tier );

        $has_bridge    = class_exists( 'NME_Payments_Bridge' );
        $portfolio     = $has_bridge ? NME_Payments_Bridge::get_portfolio( (int) $expert->id ) : array();
        $languages     = $has_bridge ? NME_Payments_Bridge::get_languages( (int) $expert->id ) : array();
        $certs         = $has_bridge ? NME_Payments_Bridge::get_certifications( (int) $expert->id ) : array();
        $services      = $has_bridge ? NME_Payments_Bridge::get_active_services( (int) $expert->id ) : array();
        $reviews       = $has_bridge ? NME_Payments_Bridge::get_reviews_for_expert( (int) $expert->id, 6 ) : array();
        $metrics       = $has_bridge ? NME_Payments_Bridge::get_metrics( (int) $expert->id ) : null;

        $wa_number = '916383359495';
        $wa_msg    = urlencode( 'Hi, I want to hire ' . $expert->full_name . ' on Nagaland Me Experts.' );
        ?>
        <section class="nme-section">
            <div class="nme-container" style="max-width: 1040px;">

                <!-- Hero strip -->
                <div class="nme-card" style="display: flex; gap: 32px; align-items: flex-start; flex-wrap: wrap;">
                    <div style="flex-shrink: 0;">
                        <?php if ( $expert->profile_photo ) : ?>
                            <img src="<?php echo esc_url( $expert->profile_photo ); ?>"
                                 alt="<?php echo esc_attr( $expert->full_name ); ?>"
                                 style="width: 160px; height: 160px; border-radius: 50%; object-fit: cover; border: 4px solid var(--nme-gold);">
                        <?php else : ?>
                            <div style="width: 160px; height: 160px; border-radius: 50%; background: var(--nme-cream); display: flex; align-items: center; justify-content: center; font-size: 4rem; color: var(--nme-forest); border: 4px solid var(--nme-gold);">
                                <?php echo esc_html( strtoupper( substr( $expert->full_name, 0, 1 ) ) ); ?>
                            </div>
                        <?php endif; ?>
                    </div>

                    <div style="flex: 1; min-width: 280px;">
                        <div style="display: flex; align-items: center; gap: 12px; flex-wrap: wrap;">
                            <h1 style="margin: 0; font-size: 2rem;"><?php echo esc_html( $expert->full_name ); ?></h1>
                            <?php echo $tier_badge; ?>
                            <?php if ( $expert->is_founding_expert ) : ?>
                                <span class="nme-badge" style="background:#FEF3C7;color:#92400E;padding:2px 10px;border-radius:999px;font-size:0.8rem;font-weight:600;">Founding Expert</span>
                            <?php endif; ?>
                            <?php
                            // Tier pill / online dot / response badges from payments bridge
                            echo apply_filters( 'nmep_expert_profile_after_name', '', $expert );
                            ?>
                        </div>

                        <?php if ( $expert->tagline ) : ?>
                            <p style="font-size: 1.15rem; color: var(--nme-emerald); font-weight: 600; margin: 8px 0;">
                                <?php echo esc_html( $expert->tagline ); ?>
                            </p>
                        <?php endif; ?>

                        <div style="display: flex; gap: 24px; flex-wrap: wrap; color: var(--nme-text-light); font-size: 0.95rem; margin-top: 12px;">
                            <?php if ( $category ) : ?>
                                <div>📁 <?php echo esc_html( $category->name ); ?><?php if ( $sub_category ) echo ' · ' . esc_html( $sub_category->name ); ?></div>
                            <?php endif; ?>
                            <?php if ( $expert->district ) : ?>
                                <div>📍 <?php echo esc_html( $expert->district ); ?>, <?php echo esc_html( $expert->state ); ?></div>
                            <?php endif; ?>
                            <?php if ( ! empty( $languages ) ) : ?>
                                <div>🗣️ <?php
                                    $lang_names = array_map( function( $l ){ return $l->language; }, $languages );
                                    echo esc_html( implode( ', ', $lang_names ) );
                                ?></div>
                            <?php elseif ( $expert->languages ) : ?>
                                <div>🗣️ <?php echo esc_html( $expert->languages ); ?></div>
                            <?php endif; ?>
                            <?php if ( $expert->years_experience ) : ?>
                                <div>⏱️ <?php echo (int) $expert->years_experience; ?>+ years experience</div>
                            <?php endif; ?>
                        </div>

                        <div style="margin-top: 20px;display:flex;gap:10px;flex-wrap:wrap;">
                            <a href="https://wa.me/<?php echo esc_attr( $wa_number ); ?>?text=<?php echo $wa_msg; ?>" class="nme-btn nme-btn-gold" rel="noopener">
                                Contact Expert
                            </a>
                            <?php if ( ! empty( $services ) ) : ?>
                                <a href="#services" class="nme-btn">See services (<?php echo count( $services ); ?>)</a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <!-- About -->
                <?php if ( $expert->bio ) : ?>
                    <div class="nme-card nme-mt-3">
                        <h2>About</h2>
                        <p><?php echo nl2br( esc_html( $expert->bio ) ); ?></p>
                    </div>
                <?php endif; ?>

                <!-- Services (live gigs from payments) -->
                <?php if ( ! empty( $services ) ) : ?>
                    <div class="nme-card nme-mt-3" id="services">
                        <h2>Services</h2>
                        <div class="nme-grid nme-grid-3" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:16px;">
                            <?php foreach ( $services as $s ) :
                                $price = NME_Payments_Bridge::service_starting_price( $s );
                                $url   = NME_Payments_Bridge::service_url( $s );
                            ?>
                                <a href="<?php echo esc_url( $url ); ?>" style="text-decoration:none;color:inherit;display:block;border:1px solid #E5E7EB;border-radius:10px;overflow:hidden;background:#fff;transition:transform .15s;">
                                    <?php if ( ! empty( $s->cover_image ) ) : ?>
                                        <img src="<?php echo esc_url( $s->cover_image ); ?>" alt="<?php echo esc_attr( $s->title ); ?>" loading="lazy" style="width:100%;height:140px;object-fit:cover;display:block;">
                                    <?php else : ?>
                                        <div style="height:140px;background:linear-gradient(135deg,#0A7558,#10B981);"></div>
                                    <?php endif; ?>
                                    <div style="padding:12px;">
                                        <strong style="display:block;line-height:1.3;margin-bottom:6px;"><?php echo esc_html( $s->title ); ?></strong>
                                        <?php if ( ! empty( $s->avg_rating ) && (float) $s->avg_rating > 0 ) : ?>
                                            <div style="font-size:0.85rem;color:#6B7280;margin-bottom:6px;">
                                                <?php echo NME_Payments_Bridge::render_stars( (float) $s->avg_rating, 14 ); ?>
                                                <?php echo number_format( (float) $s->avg_rating, 1 ); ?>
                                            </div>
                                        <?php endif; ?>
                                        <?php if ( $price ) : ?>
                                            <div style="font-size:0.85rem;color:#6B7280;">Starting at</div>
                                            <div style="font-size:1.1rem;font-weight:700;color:#0A7558;">₹<?php echo number_format( (float) $price ); ?></div>
                                        <?php endif; ?>
                                    </div>
                                </a>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endif; ?>

                <!-- Portfolio grid -->
                <?php if ( ! empty( $portfolio ) ) : ?>
                    <div class="nme-card nme-mt-3" id="portfolio">
                        <h2>Portfolio</h2>
                        <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:14px;">
                            <?php foreach ( $portfolio as $p ) :
                                $has_url = ! empty( $p->external_url );
                                $wrap_open  = $has_url ? '<a href="' . esc_url( $p->external_url ) . '" target="_blank" rel="noopener" style="text-decoration:none;color:inherit;">' : '<div>';
                                $wrap_close = $has_url ? '</a>' : '</div>';
                            ?>
                                <?php echo $wrap_open; ?>
                                    <div style="border:1px solid #E5E7EB;border-radius:10px;overflow:hidden;background:#fff;">
                                        <?php if ( ! empty( $p->image_url ) ) : ?>
                                            <img src="<?php echo esc_url( $p->image_url ); ?>" alt="<?php echo esc_attr( $p->title ); ?>" loading="lazy" style="width:100%;height:140px;object-fit:cover;display:block;">
                                        <?php else : ?>
                                            <div style="height:140px;background:#F3F4F6;display:flex;align-items:center;justify-content:center;color:#9CA3AF;font-size:0.8rem;">No preview</div>
                                        <?php endif; ?>
                                        <div style="padding:10px 12px;">
                                            <strong style="display:block;line-height:1.3;"><?php echo esc_html( $p->title ); ?></strong>
                                            <?php if ( ! empty( $p->description ) ) : ?>
                                                <div style="font-size:0.85rem;color:#6B7280;margin-top:4px;"><?php echo esc_html( wp_trim_words( $p->description, 20, '…' ) ); ?></div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                <?php echo $wrap_close; ?>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endif; ?>

                <!-- Links -->
                <?php if ( $expert->portfolio_url || $expert->youtube_channel || $expert->facebook_page ) : ?>
                    <div class="nme-card nme-mt-3">
                        <h2>Channels</h2>
                        <?php if ( $expert->portfolio_url ) : ?>
                            <p>🌐 <a href="<?php echo esc_url( $expert->portfolio_url ); ?>" target="_blank" rel="noopener"><?php echo esc_html( $expert->portfolio_url ); ?></a></p>
                        <?php endif; ?>
                        <?php if ( $expert->youtube_channel ) : ?>
                            <p>▶️ <a href="<?php echo esc_url( $expert->youtube_channel ); ?>" target="_blank" rel="noopener"><?php echo esc_html( $expert->youtube_channel ); ?></a></p>
                        <?php endif; ?>
                        <?php if ( $expert->facebook_page ) : ?>
                            <p>📘 <a href="<?php echo esc_url( $expert->facebook_page ); ?>" target="_blank" rel="noopener"><?php echo esc_html( $expert->facebook_page ); ?></a></p>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>

                <!-- Certifications -->
                <?php if ( ! empty( $certs ) ) : ?>
                    <div class="nme-card nme-mt-3" id="certifications">
                        <h2>Certifications</h2>
                        <ul style="list-style:none;padding:0;margin:0;">
                            <?php foreach ( $certs as $c ) : ?>
                                <li style="padding:10px 0;border-bottom:1px solid #F3F4F6;">
                                    <strong><?php echo esc_html( $c->title ); ?></strong>
                                    <?php if ( ! empty( $c->issuer ) ) echo ' — ' . esc_html( $c->issuer ); ?>
                                    <?php if ( ! empty( $c->issued_year ) ) echo ' <span style="color:#6B7280;">(' . (int) $c->issued_year . ')</span>'; ?>
                                    <?php if ( ! empty( $c->credential_url ) ) : ?>
                                        — <a href="<?php echo esc_url( $c->credential_url ); ?>" target="_blank" rel="noopener" style="font-size:0.85rem;">View credential</a>
                                    <?php endif; ?>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <!-- Languages (detailed with proficiency) -->
                <?php if ( ! empty( $languages ) ) : ?>
                    <div class="nme-card nme-mt-3" id="languages">
                        <h2>Languages</h2>
                        <div style="display:flex;flex-wrap:wrap;gap:10px;">
                            <?php foreach ( $languages as $l ) : ?>
                                <span style="display:inline-block;padding:6px 14px;background:#F3F4F6;border-radius:999px;font-size:0.9rem;">
                                    <strong><?php echo esc_html( $l->language ); ?></strong>
                                    <span style="color:#6B7280;"> — <?php echo esc_html( ucfirst( $l->proficiency ) ); ?></span>
                                </span>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endif; ?>

                <!-- Reviews -->
                <?php if ( ! empty( $reviews ) ) : ?>
                    <div class="nme-card nme-mt-3" id="reviews">
                        <h2>What buyers are saying</h2>
                        <?php foreach ( $reviews as $r ) : ?>
                            <div style="padding:14px 0;border-bottom:1px solid #F3F4F6;">
                                <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;flex-wrap:wrap;">
                                    <strong><?php echo esc_html( ! empty( $r->buyer_name ) ? $r->buyer_name : 'Verified buyer' ); ?></strong>
                                    <?php echo NME_Payments_Bridge::render_stars( (float) ( $r->rating ?? 0 ), 14 ); ?>
                                </div>
                                <?php if ( ! empty( $r->comment ) ) : ?>
                                    <p style="margin:6px 0 0;color:#374151;"><?php echo esc_html( $r->comment ); ?></p>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

                <!-- Stats -->
                <div class="nme-card nme-mt-3">
                    <h2>Performance</h2>
                    <div class="nme-grid nme-grid-4 nme-text-center" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:14px;">
                        <div>
                            <div class="nme-trust-stat"><?php echo (int) $expert->total_orders; ?></div>
                            <div class="nme-trust-label">Orders</div>
                        </div>
                        <div>
                            <div class="nme-trust-stat"><?php echo number_format( (float) $expert->avg_rating, 1 ); ?></div>
                            <div class="nme-trust-label">Rating</div>
                        </div>
                        <div>
                            <div class="nme-trust-stat">
                                <?php
                                if ( $metrics && ! empty( $metrics->avg_response_seconds ) ) {
                                    echo esc_html( NME_Payments_Bridge::humanize_response_time( (int) $metrics->avg_response_seconds ) );
                                } else {
                                    echo $expert->response_time_hours ? (int) $expert->response_time_hours . 'h' : '—';
                                }
                                ?>
                            </div>
                            <div class="nme-trust-label">Response</div>
                        </div>
                        <div>
                            <div class="nme-trust-stat"><?php echo esc_html( NME_Payments_Bridge::tier_label( $expert->tier ) ); ?></div>
                            <div class="nme-trust-label">Tier</div>
                        </div>
                    </div>
                </div>

                <!-- CTA fallback -->
                <?php if ( empty( $services ) ) : ?>
                    <div class="nme-card nme-mt-3 nme-text-center">
                        <h2>Want to hire <?php echo esc_html( strtok( $expert->full_name, ' ' ) ); ?>?</h2>
                        <p style="color: var(--nme-text-light);">They'll be publishing service packages soon. For now, reach out directly on WhatsApp.</p>
                        <p>
                            <a href="https://wa.me/<?php echo esc_attr( $wa_number ); ?>?text=<?php echo $wa_msg; ?>" class="nme-btn nme-btn-gold" rel="noopener">
                                Message <?php echo esc_html( strtok( $expert->full_name, ' ' ) ); ?>
                            </a>
                        </p>
                    </div>
                <?php endif; ?>

            </div>
        </section>
        <?php
    }

    /**
     * Get the public profile URL for an expert.
     * sanitize_title handles punctuation, accented characters, multi-space runs, etc.
     */
    public static function get_profile_url( $expert ) {
        $slug = sanitize_title( (string) $expert->full_name );
        return home_url( '/expert/' . $slug . '/' );
    }

    /**
     * Expose the currently-resolved expert (used by SEO / JSON-LD in C6).
     */
    public static function current_expert() {
        return self::$current_expert;
    }
}
