<?php
/**
 * NME_Service_Review_Notify
 * Notify admins when an expert service is submitted for review.
 *
 * Context — why this exists:
 *   The nme-payments plugin's service submission handlers
 *   (NMEP_Services::handle_submit_for_review / ::handle_save) only update the
 *   DB row to `pending_review` and redirect. They never email the admin and
 *   they fire zero action hooks we can subscribe to. Admins had no idea new
 *   services were sitting in the review queue unless they happened to open
 *   the NME Payments → Service Review submenu and notice the badge.
 *
 * Fix, without editing nme-payments source (class-nmep-services.php lives in
 * the payments plugin's build tree, not patches/):
 *   1. Email on transition — hook `shutdown`. Any request whose $_POST action
 *      was one of the service save / submit admin-post actions, we re-read
 *      the service row and, if its status just became `pending_review`, fire
 *      an admin notification. A 10-minute transient prevents duplicate mails
 *      if the expert save-clicks twice.
 *   2. Visibility on every WP admin page — hook `admin_notices`. If there are
 *      pending services, show a dismissible banner linking to the review
 *      queue. That way admins see it the moment they log into wp-admin, not
 *      only when they drill into the payments submenu.
 *
 * @package NagalandMeExperts
 * @version 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class NME_Service_Review_Notify {

    /** Admin-post actions that can leave a service in `pending_review`. */
    const WATCH_ACTIONS = array( 'nmep_save_service', 'nmep_submit_service' );

    /** Transient TTL (seconds) used to debounce duplicate notifications. */
    const NOTIFY_DEBOUNCE = 10 * MINUTE_IN_SECONDS;

    public static function init() {
        // Email on transition. We hook `shutdown` rather than the admin-post
        // action itself because the payments plugin's handlers exit() after
        // redirecting — anything registered at priority 11+ never runs.
        // PHP shutdown fires after exit(), which gives us a deterministic
        // place to read the final DB state and decide whether to notify.
        add_action( 'shutdown', array( __CLASS__, 'maybe_notify_admin' ), 10 );

        // Global admin banner. Visible on every wp-admin page when one or
        // more services are sitting in `pending_review`. Dismissible per
        // page view by WordPress core; the count itself is live so if admin
        // clears the queue the banner disappears on next page load.
        add_action( 'admin_notices', array( __CLASS__, 'render_pending_services_banner' ) );
    }

    /* ================================================================
       SHUTDOWN NOTIFIER
       ================================================================ */

    /**
     * Fires on `shutdown`. If the current request was an expert service
     * save / submit, check the DB for the resulting status and email the
     * admin when a new `pending_review` is seen (debounced).
     */
    public static function maybe_notify_admin() {
        // Only care about admin-post.php requests that routed to our watched
        // actions. Silently skip everything else — shutdown runs on every
        // request so the guard has to be tight.
        $action = isset( $_POST['action'] ) ? sanitize_key( wp_unslash( $_POST['action'] ) ) : '';
        if ( ! in_array( $action, self::WATCH_ACTIONS, true ) ) {
            return;
        }

        $service_id = isset( $_POST['service_id'] ) ? absint( wp_unslash( $_POST['service_id'] ) ) : 0;
        if ( $service_id <= 0 ) {
            return;
        }

        // Depend only on the payments plugin classes we actually need. If
        // the payments plugin isn't loaded for any reason, bail quietly.
        if ( ! class_exists( 'NMEP_Services' ) ) {
            return;
        }

        $service = NMEP_Services::get( $service_id );
        if ( ! $service ) {
            return;
        }

        // Only notify when the current state is `pending_review`. Editing a
        // paused or draft service doesn't warrant an admin email.
        if ( $service->status !== 'pending_review' ) {
            return;
        }

        // Debounce. If we've emailed about this service in the last 10
        // minutes, skip — expert double-clicks shouldn't spam the admin.
        $debounce_key = 'nme_notified_pending_review_' . (int) $service_id;
        if ( get_transient( $debounce_key ) ) {
            return;
        }

        $ok = self::send_admin_email( $service );
        if ( $ok ) {
            set_transient( $debounce_key, 1, self::NOTIFY_DEBOUNCE );
        }
    }

    /**
     * Compose and send the admin notification email. Mirrors the visual
     * style of NME_Emails::send_change_request_admin_notice so the inbox
     * looks consistent.
     */
    private static function send_admin_email( $service ) {
        $admin_email = get_option( 'admin_email' );
        if ( ! $admin_email ) {
            return false;
        }

        // Best-effort expert lookup for the email body.
        $expert_name  = '—';
        $expert_email = '—';
        if ( class_exists( 'NMEP_Compat' ) && ! empty( $service->expert_id ) ) {
            $expert = NMEP_Compat::get_expert( (int) $service->expert_id );
            if ( $expert ) {
                $expert_name  = isset( $expert->full_name ) ? $expert->full_name : $expert_name;
                $expert_email = isset( $expert->email )     ? $expert->email     : $expert_email;
            }
        }

        $title        = isset( $service->title ) ? $service->title : 'Service #' . (int) $service->id;
        $basic_price  = isset( $service->basic_price ) ? (float) $service->basic_price : 0;
        $price_label  = function_exists( 'nmep_format_inr' ) ? nmep_format_inr( $basic_price ) : ( '₹' . number_format( $basic_price ) );

        $review_url = admin_url( 'admin.php?page=nmep-services-review' );
        $edit_url   = admin_url( 'admin.php?page=nmep-services-review#service-' . (int) $service->id );

        $subject = '[NME] Service awaiting review — ' . $title;
        $body = '
            <p>An expert has submitted a service for your review.</p>
            <table style="border-collapse:collapse;margin:12px 0;">
                <tr><td style="padding:4px 12px 4px 0;color:#6B7280;">Service:</td><td style="padding:4px 0;"><strong>' . esc_html( $title ) . '</strong></td></tr>
                <tr><td style="padding:4px 12px 4px 0;color:#6B7280;">Basic price:</td><td style="padding:4px 0;">' . esc_html( $price_label ) . '</td></tr>
                <tr><td style="padding:4px 12px 4px 0;color:#6B7280;">Expert:</td><td style="padding:4px 0;">' . esc_html( $expert_name ) . '</td></tr>
                <tr><td style="padding:4px 12px 4px 0;color:#6B7280;">Expert email:</td><td style="padding:4px 0;">' . esc_html( $expert_email ) . '</td></tr>
                <tr><td style="padding:4px 12px 4px 0;color:#6B7280;">Service ID:</td><td style="padding:4px 0;">#' . (int) $service->id . '</td></tr>
            </table>
            <p>
                <a href="' . esc_url( $review_url ) . '" style="display:inline-block;background:#0A7558;color:#fff;padding:10px 20px;text-decoration:none;border-radius:6px;margin-right:8px;">Open review queue</a>
                <a href="' . esc_url( $edit_url ) . '" style="display:inline-block;background:#E5E7EB;color:#111827;padding:10px 20px;text-decoration:none;border-radius:6px;">Jump to this service</a>
            </p>
            <p style="color:#6B7280;font-size:0.9em;margin-top:18px;">Experts see a 24–48 hour review-window message. Approving quickly keeps the funnel healthy.</p>
        ';

        // Prefer NME_Emails::send_mail + template wrappers so delivery
        // failures land in the same audit log as every other transactional
        // email. Fall back to wp_mail directly if the base plugin isn't
        // loaded (defensive — this class is inside the base plugin, but
        // keep the fallback so an unusual load order doesn't crash us).
        if ( class_exists( 'NME_Emails' ) && method_exists( 'NME_Emails', 'template' ) ) {
            $reflection = new ReflectionClass( 'NME_Emails' );
            if ( $reflection->hasMethod( 'send_mail' ) ) {
                $send = $reflection->getMethod( 'send_mail' );
                $send->setAccessible( true );
                return (bool) $send->invoke(
                    null,
                    $admin_email,
                    $subject,
                    NME_Emails::template( 'Service awaiting review', $body ),
                    array( 'template' => 'service_pending_review_admin', 'service_id' => (int) $service->id )
                );
            }
            return (bool) wp_mail( $admin_email, $subject, NME_Emails::template( 'Service awaiting review', $body ) );
        }

        return (bool) wp_mail( $admin_email, $subject, $body );
    }

    /* ================================================================
       GLOBAL ADMIN BANNER
       ================================================================ */

    /**
     * Render a "N services awaiting review" banner on every wp-admin page.
     * Dismissible by WordPress core, re-appears on next page load if the
     * queue still has items.
     */
    public static function render_pending_services_banner() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }
        if ( ! class_exists( 'NMEP_Services' ) ) {
            return;
        }

        // Don't duplicate the banner on the review queue page itself.
        $screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
        if ( $screen && isset( $screen->id ) && strpos( (string) $screen->id, 'nmep-services-review' ) !== false ) {
            return;
        }

        $count = (int) NMEP_Services::count_by_status( 'pending_review' );
        if ( $count <= 0 ) {
            return;
        }

        $review_url = admin_url( 'admin.php?page=nmep-services-review' );
        $noun       = $count === 1 ? 'service' : 'services';
        ?>
        <div class="notice notice-warning is-dismissible">
            <p>
                <strong>🔔 <?php echo (int) $count; ?> <?php echo esc_html( $noun ); ?> awaiting your review.</strong>
                Experts are waiting on approval before their listings go live.
                &nbsp;<a href="<?php echo esc_url( $review_url ); ?>" class="button button-primary" style="vertical-align:baseline;">Review now →</a>
            </p>
        </div>
        <?php
    }
}