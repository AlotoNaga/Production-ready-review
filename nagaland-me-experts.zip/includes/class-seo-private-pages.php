<?php
/**
 * NME_SEO_Private_Pages
 *
 * Keeps authenticated-only dashboard / account pages out of Google.
 *
 * WHY THIS EXISTS
 * Rank Math (and the WP core sitemap) happily lists every published
 * page on the site — including the plugin's private dashboard/account
 * screens (edit-profile, edit-bank-account, my-account, change-profile-
 * photo, edit-application, kyc, create-service…). These pages return
 * a login wall or empty content to crawlers, which:
 *
 *   - wastes crawl budget on URLs that can never rank,
 *   - dilutes ranking signal on the pages that DO matter
 *     (home, /experts/, /expert/{slug}/, /buyer-premium/),
 *   - and occasionally surfaces in SERPs as empty-looking results.
 *
 * A second, related problem: an earlier race condition in
 * nme_create_required_pages() produced auto-suffixed duplicate pages
 * (edit-profile-2, edit-profile-3, …edit-profile-12). The concurrency
 * bug is now fixed in the main plugin file, but any existing duplicate
 * pages still need to be de-indexed — they match a -<number> suffix
 * pattern and are handled here.
 *
 * WHAT IT DOES
 *   1. Emits <meta name="robots" content="noindex, nofollow"> on every
 *      plugin-owned private page, including auto-suffixed variants.
 *   2. Hooks rank_math/frontend/robots so Rank Math's own meta output
 *      stays consistent and — critically — Rank Math drops the page
 *      from its next sitemap rebuild.
 *   3. Filters wp_sitemaps_posts_query_args so the WP core sitemap
 *      excludes these pages too (belt-and-braces in case Rank Math
 *      is deactivated).
 *   4. One-shot migration writes rank_math_robots=['noindex','nofollow']
 *      into post_meta on every existing private page, so Rank Math
 *      removes them the first time it regenerates the sitemap after
 *      deploy without the user having to touch anything.
 *
 * Anything new that should not be public goes in PRIVATE_SLUGS.
 *
 * @package NagalandMeExperts
 * @version 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class NME_SEO_Private_Pages {

    /**
     * Slugs of plugin-owned pages that must never be indexed.
     * Each entry is matched exactly AND with a -<digits> suffix so
     * any auto-suffixed duplicate WordPress ever created is caught.
     */
    const PRIVATE_SLUGS = array(
        'my-account',
        'my-account-premium',   // stray from nested-page creation
        'expert-dashboard',
        'kyc',
        'create-service',
        'change-profile-photo',
        'edit-bank-account',
        'edit-address',
        'edit-application',
        'edit-profile',
        'inbox',                // buyer inbox — login-gated
        'expert-inbox',         // expert inbox — login-gated
    );

    const MIGRATION_OPTION     = 'nme_seo_private_meta_migrated';
    const ID_CACHE_TRANSIENT   = 'nme_seo_private_page_ids';
    const ID_CACHE_TTL         = 5 * MINUTE_IN_SECONDS;

    public static function init() {
        // wp_head priority 1 — our <meta robots> lands before any
        // SEO-plugin output, removing ambiguity about the signal.
        add_action( 'wp_head', array( __CLASS__, 'emit_noindex_meta' ), 1 );

        // Rank Math integration. When Rank Math's runtime robots
        // value includes "noindex", Rank Math also excludes the page
        // from its generated sitemap on the next rebuild.
        add_filter( 'rank_math/frontend/robots', array( __CLASS__, 'filter_rank_math_robots' ) );

        // WP core sitemap (/wp-sitemap-posts-page-1.xml) — drop these
        // IDs entirely.
        add_filter( 'wp_sitemaps_posts_query_args', array( __CLASS__, 'exclude_from_core_sitemap' ), 10, 2 );

        // One-shot migration: stamp rank_math_robots meta onto the
        // existing private pages so Rank Math drops them immediately
        // after deploy, rather than waiting for each page to be
        // re-rendered frontend-side.
        add_action( 'init', array( __CLASS__, 'maybe_migrate_rank_math_meta' ), 30 );

        // Invalidate caches whenever a private page's post_name
        // changes (e.g., admin slug edit) so we don't keep treating a
        // stale ID as private.
        add_action( 'save_post_page', array( __CLASS__, 'flush_caches' ) );
    }

    /* ================================================================
       PUBLIC HELPERS
       ================================================================ */

    /**
     * Returns true when $slug is either exactly one of PRIVATE_SLUGS
     * or a -<digits> variant (edit-profile-2, my-account-11, etc.).
     */
    public static function slug_is_private( $slug ) {
        $slug = (string) $slug;
        if ( $slug === '' ) {
            return false;
        }
        foreach ( self::PRIVATE_SLUGS as $private ) {
            if ( $slug === $private ) {
                return true;
            }
            if ( preg_match( '/^' . preg_quote( $private, '/' ) . '-\d+$/', $slug ) ) {
                return true;
            }
        }
        return false;
    }

    /* ================================================================
       RUNTIME EMISSION
       ================================================================ */

    public static function emit_noindex_meta() {
        if ( self::is_current_request_private() ) {
            echo '<meta name="robots" content="noindex, nofollow">' . "\n";
        }
    }

    public static function filter_rank_math_robots( $robots ) {
        if ( self::is_current_request_private() ) {
            if ( ! is_array( $robots ) ) {
                $robots = array();
            }
            $robots['index']  = 'noindex';
            $robots['follow'] = 'nofollow';
        }
        return $robots;
    }

    private static function is_current_request_private() {
        if ( is_admin() ) {
            return false;
        }
        if ( ! is_singular( 'page' ) ) {
            return false;
        }
        $post_id = get_queried_object_id();
        if ( ! $post_id ) {
            return false;
        }
        $slug = (string) get_post_field( 'post_name', $post_id );
        return self::slug_is_private( $slug );
    }

    /* ================================================================
       SITEMAP EXCLUSION (WP CORE)
       ================================================================ */

    public static function exclude_from_core_sitemap( $args, $post_type ) {
        if ( 'page' !== $post_type ) {
            return $args;
        }
        $ids = self::find_private_page_ids();
        if ( empty( $ids ) ) {
            return $args;
        }
        $existing = isset( $args['post__not_in'] ) ? (array) $args['post__not_in'] : array();
        $args['post__not_in'] = array_values( array_unique( array_merge( $existing, $ids ) ) );
        return $args;
    }

    /* ================================================================
       ONE-SHOT MIGRATION — stamp rank_math_robots meta
       ================================================================ */

    public static function maybe_migrate_rank_math_meta() {
        if ( get_option( self::MIGRATION_OPTION ) ) {
            return;
        }
        // Keep this out of customer frontend responses — run only in
        // admin or cron contexts so the LIKE on wp_posts can't land on
        // a buyer's page-render request.
        if ( ! is_admin() && ! wp_doing_cron() && ! ( defined( 'WP_CLI' ) && WP_CLI ) ) {
            return;
        }

        $ids = self::find_private_page_ids();
        foreach ( $ids as $id ) {
            $existing = get_post_meta( $id, 'rank_math_robots', true );
            $robots   = is_array( $existing ) ? $existing : array();
            if ( ! in_array( 'noindex', $robots, true ) ) {
                $robots[] = 'noindex';
            }
            if ( ! in_array( 'nofollow', $robots, true ) ) {
                $robots[] = 'nofollow';
            }
            update_post_meta( $id, 'rank_math_robots', array_values( array_unique( $robots ) ) );
        }

        update_option( self::MIGRATION_OPTION, time(), false );

        // If Rank Math is active, poke its sitemap cache so the very
        // next request regenerates without the excluded URLs.
        if ( class_exists( '\\RankMath\\Sitemap\\Cache' ) && method_exists( '\\RankMath\\Sitemap\\Cache', 'invalidate_storage' ) ) {
            \RankMath\Sitemap\Cache::invalidate_storage();
        }
    }

    /* ================================================================
       LOOKUP
       ================================================================ */

    /**
     * Find every page ID whose slug is exactly one of PRIVATE_SLUGS
     * or a {slug}-<digits> variant. Includes trashed/draft/pending
     * pages so that the sitemap exclusion and the migration catch them
     * even if someone trashed the page without deleting it.
     *
     * Cached briefly so repeated sitemap pings don't re-run the query.
     */
    private static function find_private_page_ids() {
        $cached = get_transient( self::ID_CACHE_TRANSIENT );
        if ( is_array( $cached ) ) {
            return $cached;
        }

        global $wpdb;
        $clauses = array();
        foreach ( self::PRIVATE_SLUGS as $slug ) {
            // Defensive: our constants only contain [a-z0-9-], but
            // strip anything else in case a future editor adds a
            // weird slug — REGEXP runs on this string directly.
            $safe = preg_replace( '/[^a-z0-9-]/', '', $slug );
            if ( $safe === '' ) {
                continue;
            }
            $clauses[] = $wpdb->prepare( 'post_name = %s', $safe );
            $clauses[] = "post_name REGEXP '^" . $safe . "-[0-9]+$'";
        }
        if ( empty( $clauses ) ) {
            set_transient( self::ID_CACHE_TRANSIENT, array(), self::ID_CACHE_TTL );
            return array();
        }
        $where = implode( ' OR ', $clauses );
        $sql   = "SELECT ID FROM {$wpdb->posts}
                  WHERE post_type = 'page'
                    AND post_status IN ( 'publish', 'future', 'draft', 'pending', 'private', 'trash' )
                    AND ( $where )";
        $ids   = array_map( 'intval', (array) $wpdb->get_col( $sql ) );

        set_transient( self::ID_CACHE_TRANSIENT, $ids, self::ID_CACHE_TTL );
        return $ids;
    }

    public static function flush_caches() {
        delete_transient( self::ID_CACHE_TRANSIENT );
    }
}