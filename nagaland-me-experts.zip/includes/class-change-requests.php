<?php
/**
 * NME_Change_Requests
 *
 * Handles expert-initiated change requests for:
 *   1. Profile picture  — SELF-SERVICE with a 30-day cooldown (no admin approval).
 *   2. Bank account     — Admin-approved, OTP-verified, rate-limited, payout-frozen
 *                         while pending.
 *
 * DB tables used:
 *   {$prefix}nme_change_requests  (new — created in NME_Database)
 *   {$prefix}nme_experts          (adds profile_photo_updated_at column)
 *   {$prefix}nme_audit_log        (reuses existing)
 *
 * Shortcodes:
 *   [nme_change_profile_photo]  → /change-profile-photo/
 *   [nme_edit_bank_account]     → /edit-bank-account/
 *
 * Admin surfaces:
 *   Expert Requests queue (rendered by NME_Admin via self::render_admin_queue)
 *
 * Public API (used by dashboard / admin / payouts):
 *   NME_Change_Requests::has_pending_bank_request( $expert_id ) : bool
 *   NME_Change_Requests::get_pending_banner_html( $expert )     : string
 *   NME_Change_Requests::get_recent_changes_log( $expert_id )   : string
 *   NME_Change_Requests::count_pending_admin_queue()            : int
 *
 * @package NagalandMeExperts
 * @since   0.4.0
 *
 * 0.4.1 — Production hardening:
 *   - Capability default aligned with admin class ('nme_approve_experts').
 *   - Held-payout release on approve / reject / cancel (no more stuck freezes).
 *   - Race-safe create_request via MySQL GET_LOCK + re-check.
 *   - OTP request rate-limit (5/hour per expert, 10/hour per IP).
 *   - OTP delivery verified (wp_mail + SMS return values checked / logged).
 *   - Cancel uses POST (CSRF-safe).
 *   - Profile-photo: extra getimagesize() validation + old attachment auto-deleted.
 *   - IFSC lookup: 5s timeout + soft-fail fallback (non-blocking UX).
 *   - UPI ID format validation.
 *   - Dead TYPE_PROFILE_PHOTO branch removed from approve_request.
 *
 * 0.5.1 — Registered address self-service:
 *   - TYPE_ADDRESS branch: expert can update street / village / PIN via OTP-gated
 *     flow (no admin approval — KYC data, not money movement).
 *   - 30-day cooldown between address changes (same cadence as profile photo).
 *   - On verify, writes directly to experts table AND pushes update to Razorpay
 *     Route linked account (v2 API) when one exists, so KYC stays in sync.
 *   - dispatch_otp() generalised with $args so each flow (bank / address)
 *     controls its own email body + SMS template.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class NME_Change_Requests {

    /* ============================================================
       CONSTANTS
       ============================================================ */

    const TYPE_PROFILE_PHOTO = 'profile_photo';
    const TYPE_BANK_ACCOUNT  = 'bank_account';
    const TYPE_ADDRESS       = 'address';

    const STATUS_PENDING   = 'pending';
    const STATUS_APPROVED  = 'approved';
    const STATUS_REJECTED  = 'rejected';
    const STATUS_CANCELLED = 'cancelled';

    /** Profile picture cooldown (days). Enforced server-side on submission. */
    const PROFILE_PHOTO_COOLDOWN_DAYS = 30;

    /** Registered-address cooldown (days). Same cadence as profile photo — experts
     *  should not be updating their KYC address constantly. */
    const ADDRESS_COOLDOWN_DAYS = 30;

    /** Max approved bank-change requests allowed per expert in a 90-day rolling window. */
    const BANK_MAX_APPROVED_PER_90_DAYS = 3;

    /** OTP time-to-live, in seconds. */
    const OTP_TTL_SECONDS = 600; // 10 minutes

    /** Max OTP verification attempts before the OTP is invalidated. */
    const OTP_MAX_ATTEMPTS = 3;

    /* ============================================================
       INIT
       ============================================================ */

    public static function init() {
        // Shortcodes
        add_shortcode( 'nme_change_profile_photo', array( __CLASS__, 'render_profile_photo_page' ) );
        add_shortcode( 'nme_edit_bank_account',    array( __CLASS__, 'render_bank_account_page' ) );
        add_shortcode( 'nme_edit_address',         array( __CLASS__, 'render_address_page' ) );

        // Expert-facing handlers
        add_action( 'admin_post_nme_submit_profile_photo',    array( __CLASS__, 'handle_submit_profile_photo' ) );
        add_action( 'admin_post_nme_request_bank_change',     array( __CLASS__, 'handle_request_bank_change' ) );
        add_action( 'admin_post_nme_verify_bank_otp',         array( __CLASS__, 'handle_verify_bank_otp' ) );
        add_action( 'admin_post_nme_request_address_change',  array( __CLASS__, 'handle_request_address_change' ) );
        add_action( 'admin_post_nme_verify_address_otp',      array( __CLASS__, 'handle_verify_address_otp' ) );
        add_action( 'admin_post_nme_cancel_change_request',   array( __CLASS__, 'handle_cancel_change_request' ) );

        // Admin-facing handlers (capability-gated inside)
        add_action( 'admin_post_nme_approve_change_request', array( __CLASS__, 'handle_approve_change_request' ) );
        add_action( 'admin_post_nme_reject_change_request',  array( __CLASS__, 'handle_reject_change_request' ) );
    }

    /* ============================================================
       SAFE HELPERS
       ============================================================ */

    private static function table() {
        return NME_Database::table( 'change_requests' );
    }

    private static function experts_table() {
        return NME_Database::table( 'experts' );
    }

    private static function current_expert() {
        if ( ! is_user_logged_in() || ! class_exists( 'NME_Experts' ) ) return null;
        $e = NME_Experts::get_by_user( get_current_user_id() );
        return ( $e && is_object( $e ) ) ? $e : null;
    }

    private static function admin_capability() {
        // Must match the capability declared in admin/class-admin.php so that users with
        // 'nme_approve_experts' (but not 'manage_options') can actually approve/reject.
        return apply_filters( 'nme_change_request_admin_cap', 'nme_approve_experts' );
    }

    private static function mask_account( $acct ) {
        $acct = (string) $acct;
        if ( strlen( $acct ) <= 4 ) return str_repeat( '●', max( 0, strlen( $acct ) ) );
        return str_repeat( '●', strlen( $acct ) - 4 ) . substr( $acct, -4 );
    }

    private static function redirect_with_flash( $url, $type, $msg ) {
        $url = add_query_arg( array(
            'nme_cr_status' => $type,
            'nme_cr_msg'    => urlencode( $msg ),
        ), $url );
        wp_safe_redirect( $url );
        exit;
    }

    /* ============================================================
       PUBLIC QUERY HELPERS — safe to call from anywhere.
       ============================================================ */

    /**
     * Used by payouts + dashboard + admin. Return true if this expert has
     * a bank-change request in 'pending' status.
     */
    public static function has_pending_bank_request( $expert_id ) {
        global $wpdb;
        $expert_id = (int) $expert_id;
        if ( $expert_id <= 0 ) return false;
        $table = self::table();
        if ( ! self::table_exists() ) return false;
        $row = $wpdb->get_var( $wpdb->prepare(
            "SELECT id FROM {$table} WHERE expert_id = %d AND type = %s AND status = %s LIMIT 1",
            $expert_id,
            self::TYPE_BANK_ACCOUNT,
            self::STATUS_PENDING
        ) );
        return ! empty( $row );
    }

    /** Total pending rows across all experts (for admin menu badge). */
    public static function count_pending_admin_queue() {
        global $wpdb;
        if ( ! self::table_exists() ) return 0;
        $table = self::table();
        return (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$table} WHERE status = %s",
            self::STATUS_PENDING
        ) );
    }

    /** Get a single request by id (returns object or null). */
    public static function get_request( $id ) {
        global $wpdb;
        if ( ! self::table_exists() ) return null;
        $id = (int) $id;
        if ( $id <= 0 ) return null;
        $table = self::table();
        return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $id ) );
    }

    /**
     * List change requests — used by admin queue and expert dashboard.
     * $args: status, type, expert_id, limit, offset
     */
    public static function list_requests( $args = array() ) {
        global $wpdb;
        if ( ! self::table_exists() ) return array();

        $args = wp_parse_args( $args, array(
            'status'    => '',
            'type'      => '',
            'expert_id' => 0,
            'limit'     => 50,
            'offset'    => 0,
        ) );

        $table = self::table();
        $where = array( '1=1' );
        $params = array();

        if ( $args['status'] && in_array( $args['status'], array(
            self::STATUS_PENDING, self::STATUS_APPROVED, self::STATUS_REJECTED, self::STATUS_CANCELLED
        ), true ) ) {
            $where[] = 'status = %s';
            $params[] = $args['status'];
        }
        if ( $args['type'] && in_array( $args['type'], array(
            self::TYPE_PROFILE_PHOTO, self::TYPE_BANK_ACCOUNT
        ), true ) ) {
            $where[] = 'type = %s';
            $params[] = $args['type'];
        }
        if ( (int) $args['expert_id'] > 0 ) {
            $where[] = 'expert_id = %d';
            $params[] = (int) $args['expert_id'];
        }

        $where_sql = implode( ' AND ', $where );
        $limit  = max( 1, min( 200, (int) $args['limit'] ) );
        $offset = max( 0, (int) $args['offset'] );

        $sql = "SELECT * FROM {$table} WHERE {$where_sql} ORDER BY requested_at DESC LIMIT %d OFFSET %d";
        $params[] = $limit;
        $params[] = $offset;

        if ( empty( $params ) ) {
            return $wpdb->get_results( $sql );
        }
        return $wpdb->get_results( $wpdb->prepare( $sql, $params ) );
    }

    /** Count approved bank changes in the last 90 days (for rate limit). */
    private static function count_bank_changes_last_90_days( $expert_id ) {
        global $wpdb;
        if ( ! self::table_exists() ) return 0;
        $table = self::table();
        return (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$table}
             WHERE expert_id = %d AND type = %s AND status = %s
             AND reviewed_at IS NOT NULL
             AND reviewed_at >= DATE_SUB( NOW(), INTERVAL 90 DAY )",
            (int) $expert_id,
            self::TYPE_BANK_ACCOUNT,
            self::STATUS_APPROVED
        ) );
    }

    /** Defensive check in case migration hasn't run yet. */
    private static function table_exists() {
        global $wpdb;
        $table = self::table();
        return $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $table ) ) === $table;
    }

    /** Days left in the 30-day profile-photo cooldown, or 0 if available. */
    public static function profile_photo_days_remaining( $expert ) {
        $last = is_object( $expert ) ? ( $expert->profile_photo_updated_at ?? null ) : null;
        if ( empty( $last ) ) return 0;
        $last_ts = strtotime( $last );
        if ( ! $last_ts ) return 0;
        $elapsed_days = floor( ( current_time( 'timestamp' ) - $last_ts ) / DAY_IN_SECONDS );
        $remaining = self::PROFILE_PHOTO_COOLDOWN_DAYS - $elapsed_days;
        return max( 0, (int) $remaining );
    }

    /** Human-readable next-available date for profile photo changes. */
    public static function profile_photo_next_available_date( $expert ) {
        $last = is_object( $expert ) ? ( $expert->profile_photo_updated_at ?? null ) : null;
        if ( empty( $last ) ) return '';
        $ts = strtotime( $last );
        if ( ! $ts ) return '';
        return date_i18n( 'F j, Y', $ts + ( self::PROFILE_PHOTO_COOLDOWN_DAYS * DAY_IN_SECONDS ) );
    }

    /* ============================================================
       DASHBOARD WIDGETS — rendered by class-dashboard.php
       ============================================================ */

    /**
     * Returns an HTML banner listing the expert's currently pending change
     * requests (or empty string if none).
     */
    public static function get_pending_banner_html( $expert ) {
        if ( ! is_object( $expert ) ) return '';
        $pending = self::list_requests( array(
            'expert_id' => (int) $expert->id,
            'status'    => self::STATUS_PENDING,
            'limit'     => 5,
        ) );
        if ( empty( $pending ) ) return '';

        ob_start();
        echo '<div class="nme-card nme-mt-3" style="background:#FFFBEB;border-left:4px solid #F59E0B;">';
        echo '<div style="font-weight:700;color:#92400E;margin-bottom:8px;">⏳ You have ' . count( $pending ) . ' pending request' . ( count( $pending ) === 1 ? '' : 's' ) . ' awaiting admin review</div>';
        echo '<ul style="margin:0;padding-left:18px;color:#92400E;">';
        foreach ( $pending as $r ) {
            $label = ( $r->type === self::TYPE_BANK_ACCOUNT ) ? 'Bank account change' : 'Profile picture change';
            $when  = mysql2date( get_option( 'date_format' ), $r->requested_at );
            echo '<li style="margin-bottom:4px;">' . esc_html( $label ) . ' &mdash; submitted ' . esc_html( $when );
            // POST form (not GET) so a crafted link cannot cancel the request.
            echo ' <form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="display:inline;margin-left:8px;" onsubmit="return confirm(\'Cancel this request?\');">';
            echo '<input type="hidden" name="action" value="nme_cancel_change_request">';
            echo '<input type="hidden" name="request_id" value="' . (int) $r->id . '">';
            echo wp_nonce_field( 'nme_cancel_change_request_' . (int) $r->id, '_wpnonce', true, false );
            echo '<button type="submit" style="background:none;border:0;padding:0;color:#991B1B;font-size:0.85rem;cursor:pointer;text-decoration:underline;">Cancel</button>';
            echo '</form>';
            echo '</li>';
        }
        echo '</ul></div>';
        return ob_get_clean();
    }

    /**
     * Returns an HTML block summarising the expert's recent change history
     * (last 10 events: profile photo changes + bank change requests).
     */
    public static function get_recent_changes_log( $expert_id, $limit = 10 ) {
        $expert_id = (int) $expert_id;
        if ( $expert_id <= 0 ) return '';

        $rows = self::list_requests( array( 'expert_id' => $expert_id, 'limit' => (int) $limit ) );

        // Also pull self-service audit events (photo + address updates) — these
        // don't create a change_requests row but should still appear in history.
        global $wpdb;
        $audit_table = NME_Database::table( 'audit_log' );
        $photo_rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT action, created_at FROM {$audit_table}
             WHERE object_type = %s AND object_id = %d
             AND action IN ('profile_photo_updated','profile_photo_cooldown_blocked')
             ORDER BY created_at DESC LIMIT %d",
            'expert',
            $expert_id,
            (int) $limit
        ) );
        $address_rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT action, created_at FROM {$audit_table}
             WHERE object_type = %s AND object_id = %d
             AND action IN ('address_updated','address_cooldown_blocked')
             ORDER BY created_at DESC LIMIT %d",
            'expert',
            $expert_id,
            (int) $limit
        ) );

        if ( empty( $rows ) && empty( $photo_rows ) && empty( $address_rows ) ) return '';

        ob_start();
        ?>
        <div class="nme-card nme-mt-3">
            <h3 style="margin-top:0;">📋 Recent account changes</h3>
            <table style="width:100%;border-collapse:collapse;font-size:0.92rem;">
                <thead>
                    <tr style="background:#F9FAFB;">
                        <th style="text-align:left;padding:8px;border-bottom:1px solid #E5E7EB;">When</th>
                        <th style="text-align:left;padding:8px;border-bottom:1px solid #E5E7EB;">Change</th>
                        <th style="text-align:left;padding:8px;border-bottom:1px solid #E5E7EB;">Status</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ( $rows as $r ) :
                    $label = ( $r->type === self::TYPE_BANK_ACCOUNT ) ? 'Bank account' : 'Profile picture';
                    $status_colors = array(
                        self::STATUS_PENDING   => array( '#92400E', '#FEF3C7', 'Pending review' ),
                        self::STATUS_APPROVED  => array( '#065F46', '#D1FAE5', 'Approved' ),
                        self::STATUS_REJECTED  => array( '#991B1B', '#FEE2E2', 'Rejected' ),
                        self::STATUS_CANCELLED => array( '#4B5563', '#E5E7EB', 'Cancelled' ),
                    );
                    $sc = $status_colors[ $r->status ] ?? $status_colors[ self::STATUS_PENDING ];
                ?>
                    <tr>
                        <td style="padding:8px;border-bottom:1px solid #F3F4F6;"><?php echo esc_html( mysql2date( 'j M Y, g:i a', $r->requested_at ) ); ?></td>
                        <td style="padding:8px;border-bottom:1px solid #F3F4F6;"><?php echo esc_html( $label ); ?></td>
                        <td style="padding:8px;border-bottom:1px solid #F3F4F6;"><span style="background:<?php echo esc_attr( $sc[1] ); ?>;color:<?php echo esc_attr( $sc[0] ); ?>;padding:2px 10px;border-radius:999px;font-size:0.8rem;font-weight:600;"><?php echo esc_html( $sc[2] ); ?></span></td>
                    </tr>
                <?php endforeach; ?>
                <?php foreach ( $photo_rows as $p ) :
                    $is_block = ( $p->action === 'profile_photo_cooldown_blocked' );
                ?>
                    <tr>
                        <td style="padding:8px;border-bottom:1px solid #F3F4F6;"><?php echo esc_html( mysql2date( 'j M Y, g:i a', $p->created_at ) ); ?></td>
                        <td style="padding:8px;border-bottom:1px solid #F3F4F6;">Profile picture</td>
                        <td style="padding:8px;border-bottom:1px solid #F3F4F6;">
                            <?php if ( $is_block ) : ?>
                                <span style="background:#FEF3C7;color:#92400E;padding:2px 10px;border-radius:999px;font-size:0.8rem;font-weight:600;">Blocked (cooldown)</span>
                            <?php else : ?>
                                <span style="background:#D1FAE5;color:#065F46;padding:2px 10px;border-radius:999px;font-size:0.8rem;font-weight:600;">Updated</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                <?php foreach ( $address_rows as $a ) :
                    $is_block = ( $a->action === 'address_cooldown_blocked' );
                ?>
                    <tr>
                        <td style="padding:8px;border-bottom:1px solid #F3F4F6;"><?php echo esc_html( mysql2date( 'j M Y, g:i a', $a->created_at ) ); ?></td>
                        <td style="padding:8px;border-bottom:1px solid #F3F4F6;">Registered address</td>
                        <td style="padding:8px;border-bottom:1px solid #F3F4F6;">
                            <?php if ( $is_block ) : ?>
                                <span style="background:#FEF3C7;color:#92400E;padding:2px 10px;border-radius:999px;font-size:0.8rem;font-weight:600;">Blocked (cooldown)</span>
                            <?php else : ?>
                                <span style="background:#D1FAE5;color:#065F46;padding:2px 10px;border-radius:999px;font-size:0.8rem;font-weight:600;">Updated</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php
        return ob_get_clean();
    }

    /* ============================================================
       SHORTCODE — [nme_change_profile_photo]
       ============================================================ */

    public static function render_profile_photo_page( $atts = array() ) {
        if ( ! is_user_logged_in() ) {
            return '<div class="nme-card"><p>Please <a href="' . esc_url( wp_login_url( get_permalink() ) ) . '">log in</a>.</p></div>';
        }
        $expert = self::current_expert();
        if ( ! $expert ) {
            return '<div class="nme-card"><p>Expert profile not found.</p></div>';
        }

        $flash = self::flash_messages();
        $remaining = self::profile_photo_days_remaining( $expert );
        $next_date = self::profile_photo_next_available_date( $expert );
        $current_photo = $expert->profile_photo ?? '';

        ob_start();
        ?>
        <section class="nme-section">
            <div class="nme-container" style="max-width:680px;">
                <p><a href="<?php echo esc_url( home_url( '/expert-dashboard/' ) ); ?>" style="color:var(--nme-emerald,#0A7558);">← Back to Dashboard</a></p>
                <h2>📸 Change profile picture</h2>
                <p style="color:#6B7280;">Your profile picture is what buyers see first. Keep it clear, professional, and recognisable.</p>

                <?php echo $flash; ?>

                <div class="nme-card">
                    <div style="display:flex;gap:24px;align-items:center;flex-wrap:wrap;margin-bottom:20px;">
                        <div style="flex-shrink:0;">
                            <?php if ( $current_photo ) : ?>
                                <img src="<?php echo esc_url( $current_photo ); ?>" style="width:120px;height:120px;border-radius:50%;object-fit:cover;border:3px solid #E5E7EB;" alt="Current profile picture">
                            <?php else : ?>
                                <div style="width:120px;height:120px;border-radius:50%;background:#F3F4F6;display:flex;align-items:center;justify-content:center;font-size:2.5rem;color:#9CA3AF;border:3px solid #E5E7EB;">👤</div>
                            <?php endif; ?>
                        </div>
                        <div style="flex:1;min-width:200px;">
                            <div style="color:#6B7280;font-size:0.9rem;">Current picture</div>
                            <h3 style="margin:4px 0 8px;"><?php echo esc_html( $expert->full_name ); ?></h3>
                            <div style="color:#6B7280;font-size:0.85rem;">JPG or PNG · square format works best · max 5 MB</div>
                        </div>
                    </div>

                    <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" enctype="multipart/form-data" id="nme-photo-form">
                        <input type="hidden" name="action" value="nme_submit_profile_photo">
                        <?php wp_nonce_field( 'nme_submit_profile_photo', 'nme_photo_nonce' ); ?>

                        <div id="nme-photo-dropzone" style="border:2px dashed #D1D5DB;border-radius:12px;padding:28px;text-align:center;background:#F9FAFB;cursor:pointer;transition:all 0.15s;">
                            <div id="nme-photo-preview" style="display:none;margin-bottom:12px;"><img id="nme-photo-preview-img" style="max-width:160px;max-height:160px;border-radius:50%;border:3px solid var(--nme-gold,#D4A843);"></div>
                            <div id="nme-photo-prompt">
                                <div style="font-size:2.2rem;margin-bottom:6px;">📤</div>
                                <div style="font-weight:600;">Click to choose a new profile picture</div>
                                <div style="color:#9CA3AF;font-size:0.85rem;margin-top:4px;">Or drag and drop a file here</div>
                            </div>
                            <input type="file" name="profile_photo" id="nme-photo-input" accept="image/jpeg,image/png" style="display:none;" required>
                        </div>

                        <p style="margin-top:18px;text-align:center;">
                            <button type="submit" class="nme-btn nme-btn-gold" style="padding:12px 34px;font-size:1rem;">💾 Save new picture</button>
                        </p>
                    </form>
                </div>

                <?php if ( $remaining > 0 ) : ?>
                    <div class="nme-card nme-mt-3" style="background:#FFFBEB;border-left:4px solid #F59E0B;">
                        <strong style="color:#92400E;">Heads up:</strong>
                        <span style="color:#92400E;">You last updated your picture within the last <?php echo self::PROFILE_PHOTO_COOLDOWN_DAYS; ?> days. You can change it again on <strong><?php echo esc_html( $next_date ); ?></strong> (in <?php echo (int) $remaining; ?> day<?php echo $remaining === 1 ? '' : 's'; ?>). Submitting before then will be blocked.</span>
                    </div>
                <?php endif; ?>
            </div>
        </section>

        <script>
        (function() {
            var zone  = document.getElementById('nme-photo-dropzone');
            var input = document.getElementById('nme-photo-input');
            var prev  = document.getElementById('nme-photo-preview');
            var img   = document.getElementById('nme-photo-preview-img');
            var prompt= document.getElementById('nme-photo-prompt');
            if ( ! zone || ! input ) return;

            zone.addEventListener('click', function() { input.click(); });
            ['dragenter','dragover'].forEach(function(ev){ zone.addEventListener(ev,function(e){e.preventDefault();zone.style.borderColor='#10B981';zone.style.background='#F0FDF4';}); });
            ['dragleave','drop'].forEach(function(ev){ zone.addEventListener(ev,function(e){e.preventDefault();zone.style.borderColor='#D1D5DB';zone.style.background='#F9FAFB';}); });
            zone.addEventListener('drop', function(e){ if (e.dataTransfer && e.dataTransfer.files[0]) { input.files = e.dataTransfer.files; showPreview(e.dataTransfer.files[0]); } });
            input.addEventListener('change', function(){ if (input.files[0]) showPreview(input.files[0]); });

            function showPreview(file) {
                if ( file.size > 5 * 1024 * 1024 ) { alert('File too large. Max 5 MB.'); input.value=''; return; }
                if ( ['image/jpeg','image/png'].indexOf(file.type) === -1 ) { alert('Only JPG or PNG allowed.'); input.value=''; return; }
                var reader = new FileReader();
                reader.onload = function(e){ img.src = e.target.result; prev.style.display='block'; prompt.style.display='none'; };
                reader.readAsDataURL(file);
            }
        })();
        </script>
        <?php
        return ob_get_clean();
    }

    /**
     * Handler: expert submits a new profile photo.
     * Enforces 30-day cooldown. No admin approval required.
     */
    public static function handle_submit_profile_photo() {
        if ( ! is_user_logged_in() ) wp_die( 'Login required.' );
        if ( ! isset( $_POST['nme_photo_nonce'] ) || ! wp_verify_nonce( $_POST['nme_photo_nonce'], 'nme_submit_profile_photo' ) ) {
            wp_die( 'Security check failed.' );
        }
        $expert = self::current_expert();
        if ( ! $expert ) wp_die( 'Expert account not found.' );

        $referer = wp_get_referer() ?: home_url( '/change-profile-photo/' );

        // 30-day cooldown check
        $remaining = self::profile_photo_days_remaining( $expert );
        if ( $remaining > 0 ) {
            $next_date = self::profile_photo_next_available_date( $expert );
            NME_Database::audit_log( 'profile_photo_cooldown_blocked', 'expert', $expert->id, array(
                'days_remaining' => $remaining,
            ) );
            self::redirect_with_flash(
                $referer,
                'error',
                sprintf( 'You can change your profile picture only after 30 days since your last change. You can change it again on %s (%d day%s remaining).',
                    $next_date, $remaining, $remaining === 1 ? '' : 's' )
            );
        }

        // File validation
        if ( empty( $_FILES['profile_photo'] ) || ! is_uploaded_file( $_FILES['profile_photo']['tmp_name'] ) ) {
            self::redirect_with_flash( $referer, 'error', 'Please choose an image to upload.' );
        }
        $file = $_FILES['profile_photo'];
        if ( $file['error'] !== UPLOAD_ERR_OK ) {
            self::redirect_with_flash( $referer, 'error', 'Upload failed. Please try again.' );
        }
        if ( $file['size'] > 5 * 1024 * 1024 ) {
            self::redirect_with_flash( $referer, 'error', 'File must be under 5 MB.' );
        }
        $finfo = finfo_open( FILEINFO_MIME_TYPE );
        $mime  = finfo_file( $finfo, $file['tmp_name'] );
        finfo_close( $finfo );
        if ( ! in_array( $mime, array( 'image/jpeg', 'image/png' ), true ) ) {
            self::redirect_with_flash( $referer, 'error', 'Only JPG or PNG images are allowed.' );
        }
        // Defence-in-depth: finfo can be fooled by crafted headers. getimagesize()
        // actually decodes the image header, so a malicious PHP file won't pass.
        $size_info = @getimagesize( $file['tmp_name'] );
        if ( ! $size_info || ! in_array( (int) $size_info[2], array( IMAGETYPE_JPEG, IMAGETYPE_PNG ), true ) ) {
            self::redirect_with_flash( $referer, 'error', 'File is not a valid image.' );
        }

        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';
        require_once ABSPATH . 'wp-admin/includes/media.php';

        $movefile = wp_handle_upload( $file, array(
            'test_form' => false,
            'mimes'     => array( 'jpg|jpeg' => 'image/jpeg', 'png' => 'image/png' ),
        ) );
        if ( ! $movefile || isset( $movefile['error'] ) ) {
            self::redirect_with_flash( $referer, 'error', $movefile['error'] ?? 'Could not save file.' );
        }

        $attachment = array(
            'post_mime_type' => $movefile['type'],
            'post_title'     => 'Profile photo — ' . ( $expert->full_name ?? 'Expert' ),
            'post_content'   => '',
            'post_status'    => 'inherit',
            'post_author'    => get_current_user_id(),
        );
        $att_id = wp_insert_attachment( $attachment, $movefile['file'] );
        if ( ! is_wp_error( $att_id ) ) {
            $att_data = wp_generate_attachment_metadata( $att_id, $movefile['file'] );
            wp_update_attachment_metadata( $att_id, $att_data );
        }

        global $wpdb;
        $table = self::experts_table();
        $old_photo_url = (string) ( $expert->profile_photo ?? '' );
        $update = array(
            'profile_photo' => $movefile['url'],
        );
        // Only write the timestamp if the column exists (defensive — migration may not have run yet)
        $has_col = $wpdb->get_var( "SHOW COLUMNS FROM {$table} LIKE 'profile_photo_updated_at'" );
        if ( $has_col ) {
            $update['profile_photo_updated_at'] = current_time( 'mysql' );
        }
        $result = $wpdb->update( $table, $update, array( 'id' => (int) $expert->id ) );

        if ( $result === false ) {
            // New upload is already in media library — drop it so we don't leak storage.
            if ( ! empty( $att_id ) && ! is_wp_error( $att_id ) ) {
                wp_delete_attachment( (int) $att_id, true );
            }
            self::redirect_with_flash( $referer, 'error', 'Could not save. Please try again.' );
        }

        // DB update succeeded — now safe to delete the previous photo from the media
        // library so storage does not bloat over time. Only deletes if we can resolve
        // the URL to a WP attachment owned by this site.
        if ( $old_photo_url && $old_photo_url !== $movefile['url'] ) {
            $old_att_id = attachment_url_to_postid( $old_photo_url );
            if ( $old_att_id ) {
                wp_delete_attachment( (int) $old_att_id, true );
            }
        }

        NME_Database::audit_log( 'profile_photo_updated', 'expert', (int) $expert->id, array(
            'url' => $movefile['url'],
        ) );

        self::redirect_with_flash(
            home_url( '/expert-dashboard/' ),
            'success',
            'Profile picture updated successfully. Next change available in 30 days.'
        );
    }

    /* ============================================================
       SHORTCODE — [nme_edit_bank_account]
       ============================================================ */

    public static function render_bank_account_page( $atts = array() ) {
        if ( ! is_user_logged_in() ) {
            return '<div class="nme-card"><p>Please <a href="' . esc_url( wp_login_url( get_permalink() ) ) . '">log in</a>.</p></div>';
        }
        $expert = self::current_expert();
        if ( ! $expert ) {
            return '<div class="nme-card"><p>Expert profile not found.</p></div>';
        }

        $flash = self::flash_messages();
        $kyc_status = $expert->kyc_status ?? 'not_started';

        // Require verified KYC before letting the expert change bank details.
        // First-time bank setup is handled by /kyc/ — this page is for CHANGES only.
        if ( $kyc_status !== 'verified' ) {
            ob_start();
            ?>
            <section class="nme-section">
                <div class="nme-container" style="max-width:680px;">
                    <p><a href="<?php echo esc_url( home_url( '/expert-dashboard/' ) ); ?>" style="color:var(--nme-emerald,#0A7558);">← Back to Dashboard</a></p>
                    <h2>🏦 Edit bank account</h2>
                    <div class="nme-card" style="background:#FEF3C7;border-left:4px solid #F59E0B;">
                        <p style="color:#92400E;margin:0;"><strong>KYC verification required.</strong> You must complete and pass KYC before you can change your bank details. Once verified, any bank change will be reviewed by our admin team for your security.</p>
                        <p class="nme-mt-3"><a class="nme-btn nme-btn-gold" href="<?php echo esc_url( home_url( '/kyc/' ) ); ?>">Complete KYC</a></p>
                    </div>
                </div>
            </section>
            <?php
            return ob_get_clean();
        }

        // Block if there's already a pending request.
        if ( self::has_pending_bank_request( (int) $expert->id ) ) {
            ob_start();
            ?>
            <section class="nme-section">
                <div class="nme-container" style="max-width:680px;">
                    <p><a href="<?php echo esc_url( home_url( '/expert-dashboard/' ) ); ?>" style="color:var(--nme-emerald,#0A7558);">← Back to Dashboard</a></p>
                    <h2>🏦 Edit bank account</h2>
                    <div class="nme-card" style="background:#EFF6FF;border-left:4px solid #3B82F6;">
                        <p style="color:#1E40AF;margin:0;"><strong>You already have a pending bank-change request.</strong> Our team will review it within 1–2 business days. You can cancel it from your dashboard if you need to resubmit.</p>
                    </div>
                </div>
            </section>
            <?php
            return ob_get_clean();
        }

        // Rate limit: 3 approved changes per 90 days.
        if ( self::count_bank_changes_last_90_days( (int) $expert->id ) >= self::BANK_MAX_APPROVED_PER_90_DAYS ) {
            ob_start();
            ?>
            <section class="nme-section">
                <div class="nme-container" style="max-width:680px;">
                    <p><a href="<?php echo esc_url( home_url( '/expert-dashboard/' ) ); ?>" style="color:var(--nme-emerald,#0A7558);">← Back to Dashboard</a></p>
                    <h2>🏦 Edit bank account</h2>
                    <div class="nme-card" style="background:#FEE2E2;border-left:4px solid #EF4444;">
                        <p style="color:#991B1B;margin:0;"><strong>Change limit reached.</strong> For your security, bank account changes are limited to <?php echo (int) self::BANK_MAX_APPROVED_PER_90_DAYS; ?> in any 90-day window. Please contact support if you need an exception.</p>
                    </div>
                </div>
            </section>
            <?php
            return ob_get_clean();
        }

        // Are we in step 2 (OTP entry)? Transient is set after step 1 succeeds.
        $otp_pending = get_transient( self::otp_transient_key( (int) $expert->id ) );

        ob_start();
        ?>
        <section class="nme-section">
            <div class="nme-container" style="max-width:680px;">
                <p><a href="<?php echo esc_url( home_url( '/expert-dashboard/' ) ); ?>" style="color:var(--nme-emerald,#0A7558);">← Back to Dashboard</a></p>
                <h2>🏦 Edit bank account</h2>
                <p style="color:#6B7280;">Bank account changes are reviewed by our admin team to protect you from fraud. Payouts are paused while your request is under review.</p>
                <?php echo $flash; ?>

                <?php if ( empty( $otp_pending ) ) : ?>
                    <?php echo self::render_bank_step1( $expert ); ?>
                <?php else : ?>
                    <?php echo self::render_bank_step2( $expert, $otp_pending ); ?>
                <?php endif; ?>

                <div class="nme-card nme-mt-3" style="background:#F9FAFB;">
                    <h4 style="margin-top:0;">Your current bank details on file</h4>
                    <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;font-size:0.95rem;">
                        <div><div style="color:#6B7280;font-size:0.8rem;">Account holder</div><div><?php echo esc_html( $expert->bank_account_holder ?: '—' ); ?></div></div>
                        <div><div style="color:#6B7280;font-size:0.8rem;">Account number</div><div><?php echo esc_html( self::mask_account( $expert->bank_account_number ?? '' ) ?: '—' ); ?></div></div>
                        <div><div style="color:#6B7280;font-size:0.8rem;">IFSC</div><div><?php echo esc_html( $expert->bank_ifsc ?: '—' ); ?></div></div>
                        <div><div style="color:#6B7280;font-size:0.8rem;">UPI</div><div><?php echo esc_html( $expert->upi_id ?: '—' ); ?></div></div>
                    </div>
                </div>
            </div>
        </section>
        <?php
        return ob_get_clean();
    }

    private static function render_bank_step1( $expert ) {
        ob_start();
        ?>
        <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="nme-card" id="nme-bank-form">
            <input type="hidden" name="action" value="nme_request_bank_change">
            <?php wp_nonce_field( 'nme_request_bank_change', 'nme_bank_nonce' ); ?>

            <h3 style="margin-top:0;">Step 1 of 2 · New bank details</h3>

            <p>
                <label>Account Holder Name *</label>
                <input type="text" name="bank_account_holder" required placeholder="As per bank records">
            </p>

            <div class="nme-grid nme-grid-2">
                <p>
                    <label>Bank Account Number *</label>
                    <input type="text" name="bank_account_number" id="nme-ba-acct" required>
                </p>
                <p>
                    <label>Confirm Account Number *</label>
                    <input type="text" id="nme-ba-acct-confirm" required>
                    <small id="nme-ba-match" style="display:none;"></small>
                </p>
            </div>

            <div class="nme-grid nme-grid-2">
                <p>
                    <label>IFSC Code *</label>
                    <input type="text" name="bank_ifsc" id="nme-ba-ifsc" required maxlength="11" style="text-transform:uppercase;" placeholder="ABCD0123456">
                </p>
                <p>
                    <label>&nbsp;</label>
                    <div id="nme-ba-ifsc-result" style="padding:10px 0;font-size:0.9rem;color:#6B7280;">Enter IFSC to verify bank &amp; branch</div>
                </p>
            </div>

            <p>
                <label>UPI ID (optional alternative)</label>
                <input type="text" name="upi_id" placeholder="yourname@bank">
            </p>

            <p class="nme-text-center nme-mt-4">
                <button type="submit" class="nme-btn nme-btn-gold" style="font-size:1rem;padding:12px 32px;">Send OTP to my phone &amp; email →</button>
            </p>
            <p style="text-align:center;color:#6B7280;font-size:0.8rem;margin:0;">We'll send a 6-digit code to verify this is really you.</p>
        </form>

        <script>
        (function() {
            var a = document.getElementById('nme-ba-acct');
            var c = document.getElementById('nme-ba-acct-confirm');
            var m = document.getElementById('nme-ba-match');
            var ifsc = document.getElementById('nme-ba-ifsc');
            var out  = document.getElementById('nme-ba-ifsc-result');
            var form = document.getElementById('nme-bank-form');

            function match() {
                if (!a || !c || !m) return;
                if (!c.value) { m.style.display='none'; return; }
                m.style.display='block';
                if (a.value.trim() === c.value.trim()) { m.textContent='✅ Account numbers match'; m.style.color='#065F46'; }
                else { m.textContent='❌ Account numbers do not match'; m.style.color='#991B1B'; }
            }
            if (a) a.addEventListener('input', match);
            if (c) c.addEventListener('input', match);
            if (form) form.addEventListener('submit', function(e){
                if (a && c && a.value.trim() && a.value.trim() !== c.value.trim()) {
                    e.preventDefault(); alert('Account numbers do not match.'); c.focus();
                }
            });

            var t = null;
            function lookup() {
                if (!ifsc) return;
                var code = (ifsc.value||'').trim().toUpperCase();
                if (code.length !== 11) { out.innerHTML = '<span style="color:#6B7280;">IFSC must be 11 characters</span>'; return; }
                out.innerHTML = '<span style="color:#3B82F6;">🔍 Looking up...</span>';
                // Client-side lookup is a UX nicety only; server-side regex validates the
                // format regardless. Add a 5s timeout so the page doesn't hang if the
                // third-party API is slow/down, and fall back to a soft-warn message
                // rather than blocking submission.
                var timedOut = false;
                var tid = setTimeout(function(){
                    timedOut = true;
                    out.innerHTML = '<span style="color:#6B7280;">ℹ️ Bank lookup unavailable — format will be verified on submit.</span>';
                }, 5000);
                fetch('https://ifsc.razorpay.com/' + encodeURIComponent(code))
                    .then(function(r){ if (timedOut) return; clearTimeout(tid); if(!r.ok) throw 0; return r.json(); })
                    .then(function(d){ if (timedOut || !d) return;
                        out.innerHTML = '<span style="color:#065F46;">✅ <strong>'+(d.BANK||'')+'</strong><br>'+(d.BRANCH||'')+', '+(d.CITY||'')+', '+(d.STATE||'')+'</span>';
                    })
                    .catch(function(){
                        if (timedOut) return;
                        clearTimeout(tid);
                        // Soft warning: don't block the form — server will validate format.
                        out.innerHTML = '<span style="color:#B45309;">⚠️ Could not verify this IFSC online. Double-check before submitting.</span>';
                    });
            }
            if (ifsc) {
                ifsc.addEventListener('input', function(){ clearTimeout(t); t=setTimeout(lookup, 500); });
                ifsc.addEventListener('blur', lookup);
            }
        })();
        </script>
        <?php
        return ob_get_clean();
    }

    private static function render_bank_step2( $expert, $otp_pending ) {
        $expires_at = isset( $otp_pending['expires'] ) ? (int) $otp_pending['expires'] : 0;
        $seconds_left = max( 0, $expires_at - time() );

        ob_start();
        ?>
        <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="nme-card" id="nme-otp-form">
            <input type="hidden" name="action" value="nme_verify_bank_otp">
            <?php wp_nonce_field( 'nme_verify_bank_otp', 'nme_otp_nonce' ); ?>

            <h3 style="margin-top:0;">Step 2 of 2 · Verify it's you</h3>
            <p style="color:#6B7280;">We've sent a 6-digit code to:</p>
            <ul style="color:#374151;">
                <?php if ( ! empty( $expert->phone ) ) : ?><li>📱 <strong><?php echo esc_html( self::mask_phone( $expert->phone ) ); ?></strong> (SMS)</li><?php endif; ?>
                <?php if ( ! empty( $expert->email ) ) : ?><li>✉️  <strong><?php echo esc_html( self::mask_email( $expert->email ) ); ?></strong> (Email)</li><?php endif; ?>
            </ul>

            <p style="margin-top:20px;">
                <label>Enter 6-digit code *</label>
                <input type="text" name="otp_code" required pattern="[0-9]{6}" maxlength="6" inputmode="numeric" autocomplete="one-time-code"
                       style="font-size:1.6rem;letter-spacing:10px;text-align:center;font-family:monospace;width:100%;max-width:280px;"
                       placeholder="••••••">
            </p>

            <p style="color:#6B7280;font-size:0.85rem;">
                Code expires in <span id="nme-otp-countdown"><?php echo (int) $seconds_left; ?></span> seconds.
            </p>

            <p class="nme-text-center nme-mt-4">
                <button type="submit" class="nme-btn nme-btn-gold" style="font-size:1rem;padding:12px 32px;">Verify &amp; submit request</button>
            </p>
            <p style="text-align:center;"><a href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=nme_cancel_change_request&cancel_otp=1' ), 'nme_cancel_otp' ) ); ?>" style="color:#6B7280;font-size:0.85rem;">Cancel and start over</a></p>
        </form>

        <script>
        (function() {
            var el = document.getElementById('nme-otp-countdown');
            if (!el) return;
            var s = parseInt(el.textContent, 10) || 0;
            var t = setInterval(function(){ s--; if (s <= 0) { clearInterval(t); el.textContent='0 (expired — please request again)'; return; } el.textContent = s; }, 1000);
        })();
        </script>
        <?php
        return ob_get_clean();
    }

    /* ============================================================
       HANDLERS — bank change (step 1 + step 2) + cancel
       ============================================================ */

    /**
     * Step 1: validate input, generate OTP, store payload in transient, send OTP.
     */
    public static function handle_request_bank_change() {
        if ( ! is_user_logged_in() ) wp_die( 'Login required.' );
        if ( ! isset( $_POST['nme_bank_nonce'] ) || ! wp_verify_nonce( $_POST['nme_bank_nonce'], 'nme_request_bank_change' ) ) {
            wp_die( 'Security check failed.' );
        }
        $expert = self::current_expert();
        if ( ! $expert ) wp_die( 'Expert account not found.' );

        $referer = wp_get_referer() ?: home_url( '/edit-bank-account/' );

        // Re-check eligibility (defence in depth — UI already checks these).
        if ( ( $expert->kyc_status ?? '' ) !== 'verified' ) {
            self::redirect_with_flash( $referer, 'error', 'KYC must be verified before changing bank details.' );
        }
        if ( self::has_pending_bank_request( (int) $expert->id ) ) {
            self::redirect_with_flash( $referer, 'error', 'You already have a pending bank-change request.' );
        }
        if ( self::count_bank_changes_last_90_days( (int) $expert->id ) >= self::BANK_MAX_APPROVED_PER_90_DAYS ) {
            self::redirect_with_flash( $referer, 'error', 'Bank change limit reached for the 90-day window.' );
        }

        $holder = sanitize_text_field( $_POST['bank_account_holder'] ?? '' );
        $acct   = sanitize_text_field( $_POST['bank_account_number'] ?? '' );
        $ifsc   = strtoupper( sanitize_text_field( $_POST['bank_ifsc'] ?? '' ) );
        $upi    = sanitize_text_field( $_POST['upi_id'] ?? '' );

        $errors = array();
        if ( $holder === '' ) $errors[] = 'Account holder name is required.';
        if ( $acct === '' )   $errors[] = 'Account number is required.';
        if ( ! preg_match( '/^[0-9]{6,20}$/', $acct ) ) $errors[] = 'Account number must be 6–20 digits.';
        if ( ! preg_match( '/^[A-Z]{4}0[A-Z0-9]{6}$/', $ifsc ) ) $errors[] = 'IFSC format is invalid (ABCD0123456).';
        // UPI is optional; if provided, validate the shape (NPCI spec: handle@psp).
        if ( $upi !== '' && ! preg_match( '/^[A-Za-z0-9._\-]{2,256}@[A-Za-z][A-Za-z0-9]{2,64}$/', $upi ) ) {
            $errors[] = 'UPI ID format is invalid (e.g. yourname@bank).';
        }
        if ( ! empty( $errors ) ) {
            self::redirect_with_flash( $referer, 'error', implode( ' ', $errors ) );
        }

        // --- Rate-limit OTP requests -----------------------------------
        // Prevent OTP spam / brute-force of the OTP generator itself.
        //   - max 5 requests per hour per expert
        //   - max 10 requests per hour per originating IP
        $rl_expert_key   = 'nme_otp_rl_expert_' . (int) $expert->id;
        $rl_expert_count = (int) get_transient( $rl_expert_key );
        if ( $rl_expert_count >= 5 ) {
            self::redirect_with_flash( $referer, 'error', 'Too many verification-code requests. Please try again in an hour.' );
        }
        $ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( $_SERVER['REMOTE_ADDR'] ) : '';
        if ( $ip !== '' ) {
            $rl_ip_key   = 'nme_otp_rl_ip_' . md5( $ip );
            $rl_ip_count = (int) get_transient( $rl_ip_key );
            if ( $rl_ip_count >= 10 ) {
                self::redirect_with_flash( $referer, 'error', 'Too many verification-code requests from this device. Please try again later.' );
            }
            set_transient( $rl_ip_key, $rl_ip_count + 1, HOUR_IN_SECONDS );
        }
        set_transient( $rl_expert_key, $rl_expert_count + 1, HOUR_IN_SECONDS );

        // Generate OTP + persist pending payload.
        $otp  = self::generate_otp();
        $key  = self::otp_transient_key( (int) $expert->id );
        $data = array(
            'hash'     => wp_hash_password( $otp ),
            'attempts' => 0,
            'expires'  => time() + self::OTP_TTL_SECONDS,
            'payload'  => array(
                'bank_account_holder' => $holder,
                'bank_account_number' => $acct,
                'bank_ifsc'           => $ifsc,
                'upi_id'              => $upi,
            ),
        );
        set_transient( $key, $data, self::OTP_TTL_SECONDS );

        $delivery = self::dispatch_otp( $expert, $otp );
        // If we couldn't deliver via email OR SMS, the expert has no way to verify — fail loudly.
        if ( empty( $delivery['email'] ) && empty( $delivery['sms'] ) ) {
            delete_transient( $key );
            NME_Database::audit_log( 'bank_change_otp_delivery_failed', 'expert', (int) $expert->id );
            self::redirect_with_flash( $referer, 'error', 'We could not send your verification code. Please contact support.' );
        }
        NME_Database::audit_log( 'bank_change_otp_sent', 'expert', (int) $expert->id, array(
            'email' => ! empty( $delivery['email'] ),
            'sms'   => ! empty( $delivery['sms'] ),
        ) );

        self::redirect_with_flash( $referer, 'success', 'A 6-digit code has been sent to your phone and email. Please enter it below.' );
    }

    /**
     * Step 2: verify OTP, create the change request, notify admin.
     */
    public static function handle_verify_bank_otp() {
        if ( ! is_user_logged_in() ) wp_die( 'Login required.' );
        if ( ! isset( $_POST['nme_otp_nonce'] ) || ! wp_verify_nonce( $_POST['nme_otp_nonce'], 'nme_verify_bank_otp' ) ) {
            wp_die( 'Security check failed.' );
        }
        $expert = self::current_expert();
        if ( ! $expert ) wp_die( 'Expert account not found.' );

        $referer = wp_get_referer() ?: home_url( '/edit-bank-account/' );
        $code    = preg_replace( '/\D/', '', (string) ( $_POST['otp_code'] ?? '' ) );

        $key  = self::otp_transient_key( (int) $expert->id );
        $data = get_transient( $key );
        if ( empty( $data ) || empty( $data['hash'] ) ) {
            self::redirect_with_flash( $referer, 'error', 'Your code has expired. Please submit the form again.' );
        }

        if ( (int) ( $data['attempts'] ?? 0 ) >= self::OTP_MAX_ATTEMPTS ) {
            delete_transient( $key );
            self::redirect_with_flash( $referer, 'error', 'Too many incorrect attempts. Please submit the form again.' );
        }
        if ( ! wp_check_password( $code, $data['hash'] ) ) {
            $data['attempts'] = (int) $data['attempts'] + 1;
            set_transient( $key, $data, max( 60, $data['expires'] - time() ) );
            self::redirect_with_flash( $referer, 'error', 'Incorrect code. Please try again.' );
        }

        // OTP valid — create the change-request row.
        $old_snapshot = array(
            'bank_account_holder' => $expert->bank_account_holder ?? '',
            'bank_account_number' => $expert->bank_account_number ?? '',
            'bank_ifsc'           => $expert->bank_ifsc ?? '',
            'upi_id'              => $expert->upi_id ?? '',
        );

        $request_id = self::create_request(
            (int) $expert->id,
            self::TYPE_BANK_ACCOUNT,
            $data['payload'],
            $old_snapshot
        );

        delete_transient( $key );

        if ( ! $request_id ) {
            self::redirect_with_flash( $referer, 'error', 'Could not save request. Please try again.' );
        }

        // Notify expert + admin
        if ( class_exists( 'NME_Emails' ) ) {
            if ( method_exists( 'NME_Emails', 'send_change_request_received' ) ) {
                NME_Emails::send_change_request_received( $expert, self::TYPE_BANK_ACCOUNT );
            }
            if ( method_exists( 'NME_Emails', 'send_change_request_admin_notice' ) ) {
                NME_Emails::send_change_request_admin_notice( $expert, self::TYPE_BANK_ACCOUNT, $request_id );
            }
        }

        NME_Database::audit_log( 'bank_change_requested', 'expert', (int) $expert->id, array( 'request_id' => $request_id ) );

        self::redirect_with_flash(
            home_url( '/expert-dashboard/' ),
            'success',
            'Bank-change request submitted. Our team will review within 1–2 business days. Payouts are paused until approval.'
        );
    }

    /**
     * Expert cancels their own pending request (or their in-flight OTP step).
     */
    public static function handle_cancel_change_request() {
        if ( ! is_user_logged_in() ) wp_die( 'Login required.' );
        $expert = self::current_expert();
        if ( ! $expert ) wp_die( 'Expert account not found.' );
        $referer = wp_get_referer() ?: home_url( '/expert-dashboard/' );

        // Case A: cancel mid-OTP (no request row yet — just clear the transient).
        // This path is low-risk (transient is re-creatable); allow GET with nonce.
        if ( ! empty( $_GET['cancel_otp'] ) ) {
            if ( ! isset( $_GET['_wpnonce'] ) || ! wp_verify_nonce( $_GET['_wpnonce'], 'nme_cancel_otp' ) ) {
                wp_die( 'Security check failed.' );
            }
            $cr_type = isset( $_GET['cr_type'] ) ? sanitize_key( $_GET['cr_type'] ) : 'bank';
            if ( $cr_type === 'address' ) {
                delete_transient( self::address_otp_transient_key( (int) $expert->id ) );
                self::redirect_with_flash( home_url( '/edit-address/' ), 'success', 'Cancelled. You can start over.' );
            }
            delete_transient( self::otp_transient_key( (int) $expert->id ) );
            self::redirect_with_flash( home_url( '/edit-bank-account/' ), 'success', 'Cancelled. You can start over.' );
        }

        // Case B: cancel a pending request row. REQUIRE POST so a crafted link cannot
        // trick a logged-in expert into cancelling their own request.
        if ( 'POST' !== strtoupper( (string) ( $_SERVER['REQUEST_METHOD'] ?? '' ) ) ) {
            wp_die( 'Invalid request method.' );
        }
        $request_id = isset( $_POST['request_id'] ) ? (int) $_POST['request_id'] : 0;
        if ( $request_id <= 0 || ! isset( $_POST['_wpnonce'] ) || ! wp_verify_nonce( $_POST['_wpnonce'], 'nme_cancel_change_request_' . $request_id ) ) {
            wp_die( 'Security check failed.' );
        }

        $req = self::get_request( $request_id );
        if ( ! $req || (int) $req->expert_id !== (int) $expert->id ) {
            wp_die( 'Not allowed.' );
        }
        if ( $req->status !== self::STATUS_PENDING ) {
            self::redirect_with_flash( $referer, 'error', 'That request is no longer pending.' );
        }

        global $wpdb;
        $wpdb->update( self::table(),
            array( 'status' => self::STATUS_CANCELLED, 'reviewed_at' => current_time( 'mysql' ) ),
            array( 'id' => $request_id )
        );
        NME_Database::audit_log( 'change_request_cancelled', 'change_request', $request_id, array( 'by' => 'expert' ) );

        // If this was a bank-change cancellation, release any held payouts so the
        // expert isn't frozen waiting for a request they've now withdrawn.
        if ( $req->type === self::TYPE_BANK_ACCOUNT
             && class_exists( 'NMEP_Payouts' )
             && method_exists( 'NMEP_Payouts', 'release_held_for_expert' ) ) {
            NMEP_Payouts::release_held_for_expert( (int) $req->expert_id );
        }

        self::redirect_with_flash( $referer, 'success', 'Request cancelled.' );
    }

    /* ============================================================
       OTP HELPERS
       ============================================================ */

    private static function otp_transient_key( $expert_id ) {
        return 'nme_bank_otp_' . (int) $expert_id;
    }

    /** Separate OTP transient for address so a pending bank OTP doesn't clash. */
    private static function address_otp_transient_key( $expert_id ) {
        return 'nme_addr_otp_' . (int) $expert_id;
    }

    private static function generate_otp() {
        return str_pad( (string) wp_rand( 0, 999999 ), 6, '0', STR_PAD_LEFT );
    }

    /**
     * Last successful address update timestamp for this expert (or null).
     * Read from the audit_log so we don't need another schema column.
     */
    private static function address_last_updated_at( $expert_id ) {
        global $wpdb;
        $audit_table = NME_Database::table( 'audit_log' );
        $ts = $wpdb->get_var( $wpdb->prepare(
            "SELECT MAX(created_at) FROM {$audit_table}
             WHERE object_type = %s AND object_id = %d AND action = %s",
            'expert',
            (int) $expert_id,
            'address_updated'
        ) );
        return $ts ?: null;
    }

    /** Days left in the 30-day address cooldown, or 0 if available. */
    public static function address_days_remaining( $expert ) {
        if ( ! is_object( $expert ) || empty( $expert->id ) ) return 0;
        $last = self::address_last_updated_at( (int) $expert->id );
        if ( empty( $last ) ) return 0;
        $last_ts = strtotime( $last );
        if ( ! $last_ts ) return 0;
        $elapsed_days = floor( ( current_time( 'timestamp' ) - $last_ts ) / DAY_IN_SECONDS );
        return max( 0, (int) ( self::ADDRESS_COOLDOWN_DAYS - $elapsed_days ) );
    }

    /** Human-readable next-available date for address changes. */
    public static function address_next_available_date( $expert ) {
        if ( ! is_object( $expert ) || empty( $expert->id ) ) return '';
        $last = self::address_last_updated_at( (int) $expert->id );
        if ( empty( $last ) ) return '';
        $ts = strtotime( $last );
        if ( ! $ts ) return '';
        return date_i18n( 'F j, Y', $ts + ( self::ADDRESS_COOLDOWN_DAYS * DAY_IN_SECONDS ) );
    }

    /**
     * Send OTP to the expert's phone (via NMEP_SMS if available) AND email.
     *
     * $args (all optional, defaults to bank-change copy for back-compat):
     *   email_subject    : string — mail subject line
     *   email_intro      : string — one-line description above the code
     *   sms_template     : string — sprintf template with single %s for the code
     *   sms_log_context  : string — passed to NMEP_SMS::send for analytics
     *   audit_email_fail : string — audit_log action key on email failure
     *   audit_sms_fail   : string — audit_log action key on SMS failure
     *
     * @return array{email:bool, sms:bool} delivery result per channel.
     */
    private static function dispatch_otp( $expert, $otp, $args = array() ) {
        $defaults = array(
            'email_subject'    => 'Your Nagaland Me Experts verification code',
            'email_intro'      => 'Your 6-digit code to confirm your bank account change is:',
            'sms_template'     => 'Nagaland Me Experts: Your bank-change code is %s. Valid 10 min. Do NOT share.',
            'sms_log_context'  => 'bank_change_otp',
            'audit_email_fail' => 'otp_email_failed',
            'audit_sms_fail'   => 'otp_sms_failed',
        );
        $args = wp_parse_args( $args, $defaults );

        $email_sent = false;
        $sms_sent   = false;

        // Email
        if ( ! empty( $expert->email ) ) {
            $body = '<p>Hi ' . esc_html( $expert->full_name ?? 'there' ) . ',</p>'
                  . '<p>' . esc_html( $args['email_intro'] ) . '</p>'
                  . '<p style="font-size:26px;letter-spacing:8px;font-weight:700;font-family:monospace;margin:20px 0;color:#0A7558;">' . esc_html( $otp ) . '</p>'
                  . '<p>This code expires in 10 minutes. If you did not request this change, please ignore this email and contact support immediately.</p>'
                  . '<p>— Nagaland Me Experts</p>';
            $email_sent = (bool) wp_mail(
                $expert->email,
                $args['email_subject'],
                $body,
                array( 'From: Nagaland Me Experts <noreply@nagaland.me>', 'Content-Type: text/html; charset=UTF-8' )
            );
            if ( ! $email_sent && class_exists( 'NME_Database' ) ) {
                NME_Database::audit_log( $args['audit_email_fail'], 'expert', (int) $expert->id, array(
                    'to' => $expert->email,
                ) );
            }
        }

        // SMS (via payments plugin's MSG91 integration, if present)
        if ( ! empty( $expert->phone ) && class_exists( 'NMEP_SMS' ) && method_exists( 'NMEP_SMS', 'send' ) ) {
            $text = sprintf( $args['sms_template'], $otp );
            // Safe to call — NMEP_SMS::send returns WP_Error if disabled, doesn't throw.
            $sms_result = NMEP_SMS::send( $expert->phone, $text, $args['sms_log_context'] );
            $sms_sent   = ! is_wp_error( $sms_result ) && false !== $sms_result;
            if ( ! $sms_sent && class_exists( 'NME_Database' ) ) {
                NME_Database::audit_log( $args['audit_sms_fail'], 'expert', (int) $expert->id, array(
                    'reason' => is_wp_error( $sms_result ) ? $sms_result->get_error_message() : 'unknown',
                ) );
            }
        }

        return array( 'email' => $email_sent, 'sms' => $sms_sent );
    }

    private static function mask_phone( $phone ) {
        $phone = preg_replace( '/\D/', '', (string) $phone );
        $len = strlen( $phone );
        if ( $len < 4 ) return $phone;
        return str_repeat( '•', $len - 4 ) . substr( $phone, -4 );
    }

    private static function mask_email( $email ) {
        $parts = explode( '@', (string) $email );
        if ( count( $parts ) !== 2 ) return (string) $email;
        $name = $parts[0];
        $masked = strlen( $name ) <= 2 ? $name : substr( $name, 0, 2 ) . str_repeat( '•', max( 1, strlen( $name ) - 2 ) );
        return $masked . '@' . $parts[1];
    }

    /* ============================================================
       DATA LAYER — create / approve / reject
       ============================================================ */

    public static function create_request( $expert_id, $type, $payload, $old_snapshot = array() ) {
        global $wpdb;
        if ( ! self::table_exists() ) return 0;

        $expert_id = (int) $expert_id;
        // Lock name must be <=64 chars for MySQL. expert_id + truncated hash of type.
        $lock_name = substr( 'nme_cr_' . $expert_id . '_' . md5( (string) $type ), 0, 60 );

        // Serialize concurrent submissions from the same expert (e.g. double-click /
        // network retry). GET_LOCK is session-scoped and atomic in MySQL.
        $locked = (int) $wpdb->get_var( $wpdb->prepare( "SELECT GET_LOCK(%s, %d)", $lock_name, 5 ) );
        if ( 1 !== $locked ) {
            // Another insert is in flight for this expert; treat as a no-op dup.
            return 0;
        }

        try {
            // Re-check inside the lock to defeat the classic check-then-insert race.
            if ( $type === self::TYPE_BANK_ACCOUNT && self::has_pending_bank_request( $expert_id ) ) {
                return 0;
            }

            $ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( $_SERVER['REMOTE_ADDR'] ) : null;
            $ok = $wpdb->insert( self::table(), array(
                'expert_id'    => $expert_id,
                'type'         => $type,
                'payload'      => wp_json_encode( (array) $payload ),
                'old_snapshot' => wp_json_encode( (array) $old_snapshot ),
                'status'       => self::STATUS_PENDING,
                'requested_at' => current_time( 'mysql' ),
                'ip_address'   => $ip,
            ) );
            return $ok ? (int) $wpdb->insert_id : 0;
        } finally {
            $wpdb->query( $wpdb->prepare( "DO RELEASE_LOCK(%s)", $lock_name ) );
        }
    }

    /**
     * Admin approves: applies the change to nme_experts and marks the row.
     * Returns true on success.
     */
    public static function approve_request( $request_id, $admin_id ) {
        global $wpdb;
        $req = self::get_request( $request_id );
        if ( ! $req || $req->status !== self::STATUS_PENDING ) return false;

        $payload = json_decode( (string) $req->payload, true );
        if ( ! is_array( $payload ) ) $payload = array();

        $update = array();
        if ( $req->type === self::TYPE_BANK_ACCOUNT ) {
            foreach ( array( 'bank_account_holder', 'bank_account_number', 'bank_ifsc', 'upi_id' ) as $k ) {
                if ( isset( $payload[ $k ] ) ) $update[ $k ] = sanitize_text_field( $payload[ $k ] );
            }
        } else {
            // Profile-photo changes are self-service and never create a request row,
            // so any non-bank type is unknown — reject safely.
            return false;
        }

        if ( ! empty( $update ) ) {
            $wpdb->update( self::experts_table(), $update, array( 'id' => (int) $req->expert_id ) );

            // Let the payments plugin push the new bank to Razorpay. Fired only
            // after the DB write so subscribers can read the fresh values via
            // NME_Experts::get(). Subscribers must handle their own failures —
            // an error here does NOT roll back the approval (the bank is valid
            // locally; the downstream sync just needs retry).
            if ( $req->type === self::TYPE_BANK_ACCOUNT ) {
                do_action( 'nme_after_bank_change_approved', (int) $req->expert_id, $update );
            }
        }

        $wpdb->update( self::table(), array(
            'status'      => self::STATUS_APPROVED,
            'reviewed_at' => current_time( 'mysql' ),
            'reviewed_by' => (int) $admin_id,
        ), array( 'id' => (int) $request_id ) );

        NME_Database::audit_log( 'change_request_approved', 'change_request', (int) $request_id, array(
            'expert_id' => (int) $req->expert_id,
            'type'      => $req->type,
            'by'        => (int) $admin_id,
        ) );

        // Release held payouts now that the bank change has been applied.
        if ( $req->type === self::TYPE_BANK_ACCOUNT
             && class_exists( 'NMEP_Payouts' )
             && method_exists( 'NMEP_Payouts', 'release_held_for_expert' ) ) {
            NMEP_Payouts::release_held_for_expert( (int) $req->expert_id );
        }

        // Notify expert
        if ( class_exists( 'NME_Experts' ) && class_exists( 'NME_Emails' ) && method_exists( 'NME_Emails', 'send_change_request_approved' ) ) {
            $expert = NME_Experts::get( (int) $req->expert_id );
            if ( $expert ) NME_Emails::send_change_request_approved( $expert, $req->type );
        }
        return true;
    }

    public static function reject_request( $request_id, $admin_id, $reason = '' ) {
        global $wpdb;
        $req = self::get_request( $request_id );
        if ( ! $req || $req->status !== self::STATUS_PENDING ) return false;

        $wpdb->update( self::table(), array(
            'status'       => self::STATUS_REJECTED,
            'reviewed_at'  => current_time( 'mysql' ),
            'reviewed_by'  => (int) $admin_id,
            'admin_reason' => sanitize_textarea_field( $reason ),
        ), array( 'id' => (int) $request_id ) );

        NME_Database::audit_log( 'change_request_rejected', 'change_request', (int) $request_id, array(
            'expert_id' => (int) $req->expert_id,
            'type'      => $req->type,
            'by'        => (int) $admin_id,
            'reason'    => $reason,
        ) );

        // Bank change rejected — release held payouts so the expert gets paid again
        // on their PREVIOUS (still-valid) bank details.
        if ( $req->type === self::TYPE_BANK_ACCOUNT
             && class_exists( 'NMEP_Payouts' )
             && method_exists( 'NMEP_Payouts', 'release_held_for_expert' ) ) {
            NMEP_Payouts::release_held_for_expert( (int) $req->expert_id );
        }

        if ( class_exists( 'NME_Experts' ) && class_exists( 'NME_Emails' ) && method_exists( 'NME_Emails', 'send_change_request_rejected' ) ) {
            $expert = NME_Experts::get( (int) $req->expert_id );
            if ( $expert ) NME_Emails::send_change_request_rejected( $expert, $req->type, $reason );
        }
        return true;
    }

    /* ============================================================
       SHORTCODE — [nme_edit_address]
       Expert-side self-service registered-address editor.
       No admin approval: OTP is proof-of-possession for the expert's
       email/phone, and address changes don't move money. On verify
       we write directly to nme_experts AND push the update to Razorpay
       Route so the linked account's KYC stays in sync.
       ============================================================ */

    public static function render_address_page( $atts = array() ) {
        if ( ! is_user_logged_in() ) {
            return '<div class="nme-card"><p>Please <a href="' . esc_url( wp_login_url( get_permalink() ) ) . '">log in</a>.</p></div>';
        }
        $expert = self::current_expert();
        if ( ! $expert ) {
            return '<div class="nme-card"><p>Expert profile not found.</p></div>';
        }

        $flash     = self::flash_messages();
        $remaining = self::address_days_remaining( $expert );
        $next_date = self::address_next_available_date( $expert );

        // Step 2 if there's a pending OTP transient for address.
        $otp_pending = get_transient( self::address_otp_transient_key( (int) $expert->id ) );

        ob_start();
        ?>
        <section class="nme-section">
            <div class="nme-container" style="max-width:680px;">
                <p><a href="<?php echo esc_url( home_url( '/expert-dashboard/' ) ); ?>" style="color:var(--nme-emerald,#0A7558);">← Back to Dashboard</a></p>
                <h2>🏠 Update registered address</h2>
                <p style="color:#6B7280;">This is the address Razorpay uses for KYC and tax records. It is never shown on your public profile.</p>

                <?php echo $flash; ?>

                <div class="nme-card nme-mt-3" style="background:#F9FAFB;">
                    <h4 style="margin-top:0;">Your current address on file</h4>
                    <div style="font-size:0.95rem;line-height:1.6;">
                        <?php echo esc_html( $expert->street_address ?: '—' ); ?><br>
                        <?php echo esc_html( $expert->village_locality ?: '' ); ?><?php if ( ! empty( $expert->village_locality ) ) : ?>, <?php endif; ?>
                        <?php echo esc_html( $expert->district ?: '' ); ?><br>
                        <?php echo esc_html( $expert->state ?: 'Nagaland' ); ?> &nbsp;·&nbsp; PIN <?php echo esc_html( $expert->postal_code ?: '—' ); ?>
                    </div>
                </div>

                <?php if ( $remaining > 0 && empty( $otp_pending ) ) : ?>
                    <div class="nme-card nme-mt-3" style="background:#FFFBEB;border-left:4px solid #F59E0B;">
                        <strong style="color:#92400E;">Change limit in effect:</strong>
                        <span style="color:#92400E;">You updated your address recently. You can change it again on <strong><?php echo esc_html( $next_date ); ?></strong> (in <?php echo (int) $remaining; ?> day<?php echo $remaining === 1 ? '' : 's'; ?>).</span>
                    </div>
                <?php elseif ( empty( $otp_pending ) ) : ?>
                    <?php echo self::render_address_step1( $expert ); ?>
                <?php else : ?>
                    <?php echo self::render_address_step2( $expert, $otp_pending ); ?>
                <?php endif; ?>
            </div>
        </section>
        <?php
        return ob_get_clean();
    }

    private static function render_address_step1( $expert ) {
        ob_start();
        ?>
        <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="nme-card nme-mt-3" id="nme-addr-form">
            <input type="hidden" name="action" value="nme_request_address_change">
            <?php wp_nonce_field( 'nme_request_address_change', 'nme_addr_nonce' ); ?>

            <h3 style="margin-top:0;">Step 1 of 2 · New address</h3>

            <p>
                <label>Street address *</label>
                <input type="text" name="street_address" required maxlength="160"
                       value="<?php echo esc_attr( $expert->street_address ?? '' ); ?>"
                       placeholder="House / building, street, area">
                <small style="color:#6B7280;">Up to 160 characters.</small>
            </p>

            <p>
                <label>Village / Locality *</label>
                <input type="text" name="village_locality" required maxlength="120"
                       value="<?php echo esc_attr( $expert->village_locality ?? '' ); ?>"
                       placeholder="e.g. Kohima Village">
            </p>

            <div class="nme-grid nme-grid-2">
                <p>
                    <label>PIN code *</label>
                    <input type="text" name="postal_code" required inputmode="numeric" pattern="\d{6}" maxlength="6"
                           value="<?php echo esc_attr( $expert->postal_code ?? '' ); ?>"
                           placeholder="797001">
                    <small style="color:#6B7280;">Exactly 6 digits.</small>
                </p>
                <p>
                    <label>State</label>
                    <input type="text" value="Nagaland" readonly style="background:#F3F4F6;color:#6B7280;">
                    <small style="color:#6B7280;">Currently India / Nagaland only.</small>
                </p>
            </div>

            <p class="nme-text-center nme-mt-4">
                <button type="submit" class="nme-btn nme-btn-gold" style="font-size:1rem;padding:12px 32px;">Send OTP to my phone &amp; email →</button>
            </p>
            <p style="text-align:center;color:#6B7280;font-size:0.8rem;margin:0;">We'll send a 6-digit code to verify this is really you.</p>
        </form>
        <?php
        return ob_get_clean();
    }

    private static function render_address_step2( $expert, $otp_pending ) {
        $expires_at   = isset( $otp_pending['expires'] ) ? (int) $otp_pending['expires'] : 0;
        $seconds_left = max( 0, $expires_at - time() );

        ob_start();
        ?>
        <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="nme-card nme-mt-3" id="nme-addr-otp-form">
            <input type="hidden" name="action" value="nme_verify_address_otp">
            <?php wp_nonce_field( 'nme_verify_address_otp', 'nme_addr_otp_nonce' ); ?>

            <h3 style="margin-top:0;">Step 2 of 2 · Verify it's you</h3>
            <p style="color:#6B7280;">We've sent a 6-digit code to:</p>
            <ul style="color:#374151;">
                <?php if ( ! empty( $expert->phone ) ) : ?><li>📱 <strong><?php echo esc_html( self::mask_phone( $expert->phone ) ); ?></strong> (SMS)</li><?php endif; ?>
                <?php if ( ! empty( $expert->email ) ) : ?><li>✉️  <strong><?php echo esc_html( self::mask_email( $expert->email ) ); ?></strong> (Email)</li><?php endif; ?>
            </ul>

            <p style="margin-top:20px;">
                <label>Enter 6-digit code *</label>
                <input type="text" name="otp_code" required pattern="[0-9]{6}" maxlength="6" inputmode="numeric" autocomplete="one-time-code"
                       style="font-size:1.6rem;letter-spacing:10px;text-align:center;font-family:monospace;width:100%;max-width:280px;"
                       placeholder="••••••">
            </p>

            <p style="color:#6B7280;font-size:0.85rem;">
                Code expires in <span id="nme-addr-otp-countdown"><?php echo (int) $seconds_left; ?></span> seconds.
            </p>

            <p class="nme-text-center nme-mt-4">
                <button type="submit" class="nme-btn nme-btn-gold" style="font-size:1rem;padding:12px 32px;">Verify &amp; update address</button>
            </p>
            <p style="text-align:center;"><a href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=nme_cancel_change_request&cancel_otp=1&cr_type=address' ), 'nme_cancel_otp' ) ); ?>" style="color:#6B7280;font-size:0.85rem;">Cancel and start over</a></p>
        </form>

        <script>
        (function() {
            var el = document.getElementById('nme-addr-otp-countdown');
            if (!el) return;
            var s = parseInt(el.textContent, 10) || 0;
            var t = setInterval(function(){ s--; if (s <= 0) { clearInterval(t); el.textContent='0 (expired — please request again)'; return; } el.textContent = s; }, 1000);
        })();
        </script>
        <?php
        return ob_get_clean();
    }

    /* ============================================================
       HANDLERS — address change (step 1 + step 2)
       ============================================================ */

    /**
     * Step 1: validate input, enforce cooldown + rate limits, send OTP.
     */
    public static function handle_request_address_change() {
        if ( ! is_user_logged_in() ) wp_die( 'Login required.' );
        if ( ! isset( $_POST['nme_addr_nonce'] ) || ! wp_verify_nonce( $_POST['nme_addr_nonce'], 'nme_request_address_change' ) ) {
            wp_die( 'Security check failed.' );
        }
        $expert = self::current_expert();
        if ( ! $expert ) wp_die( 'Expert account not found.' );

        $referer = wp_get_referer() ?: home_url( '/edit-address/' );

        // 30-day cooldown (defence in depth — UI already hides the form).
        $remaining = self::address_days_remaining( $expert );
        if ( $remaining > 0 ) {
            $next_date = self::address_next_available_date( $expert );
            NME_Database::audit_log( 'address_cooldown_blocked', 'expert', (int) $expert->id, array(
                'days_remaining' => $remaining,
            ) );
            self::redirect_with_flash(
                $referer,
                'error',
                sprintf( 'You can update your address once every %d days. Next available: %s (%d day%s remaining).',
                    self::ADDRESS_COOLDOWN_DAYS, $next_date, $remaining, $remaining === 1 ? '' : 's' )
            );
        }

        // Sanitize + validate.
        $street  = sanitize_text_field( $_POST['street_address'] ?? '' );
        $village = sanitize_text_field( $_POST['village_locality'] ?? '' );
        $pin     = preg_replace( '/\D/', '', (string) ( $_POST['postal_code'] ?? '' ) );

        $errors = array();
        if ( $street === '' )                   $errors[] = 'Street address is required.';
        elseif ( mb_strlen( $street ) > 160 )   $errors[] = 'Street address must be 160 characters or fewer.';
        if ( $village === '' )                  $errors[] = 'Village / locality is required.';
        elseif ( mb_strlen( $village ) > 120 )  $errors[] = 'Village / locality must be 120 characters or fewer.';
        if ( ! preg_match( '/^\d{6}$/', $pin ) ) $errors[] = 'PIN code must be exactly 6 digits.';

        if ( ! empty( $errors ) ) {
            self::redirect_with_flash( $referer, 'error', implode( ' ', $errors ) );
        }

        // No-op detection: if nothing actually changed, don't burn an OTP.
        $current_street  = (string) ( $expert->street_address ?? '' );
        $current_village = (string) ( $expert->village_locality ?? '' );
        $current_pin     = (string) ( $expert->postal_code ?? '' );
        if ( $street === $current_street && $village === $current_village && $pin === $current_pin ) {
            self::redirect_with_flash( $referer, 'error', 'No changes detected — your address is already saved as entered.' );
        }

        // --- Rate-limit OTP requests (shared across OTP types per expert/IP) -----
        $rl_expert_key   = 'nme_otp_rl_expert_' . (int) $expert->id;
        $rl_expert_count = (int) get_transient( $rl_expert_key );
        if ( $rl_expert_count >= 5 ) {
            self::redirect_with_flash( $referer, 'error', 'Too many verification-code requests. Please try again in an hour.' );
        }
        $ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( $_SERVER['REMOTE_ADDR'] ) : '';
        if ( $ip !== '' ) {
            $rl_ip_key   = 'nme_otp_rl_ip_' . md5( $ip );
            $rl_ip_count = (int) get_transient( $rl_ip_key );
            if ( $rl_ip_count >= 10 ) {
                self::redirect_with_flash( $referer, 'error', 'Too many verification-code requests from this device. Please try again later.' );
            }
            set_transient( $rl_ip_key, $rl_ip_count + 1, HOUR_IN_SECONDS );
        }
        set_transient( $rl_expert_key, $rl_expert_count + 1, HOUR_IN_SECONDS );

        // Generate + store the pending OTP alongside the proposed payload.
        $otp  = self::generate_otp();
        $key  = self::address_otp_transient_key( (int) $expert->id );
        $data = array(
            'hash'     => wp_hash_password( $otp ),
            'attempts' => 0,
            'expires'  => time() + self::OTP_TTL_SECONDS,
            'payload'  => array(
                'street_address'   => $street,
                'village_locality' => $village,
                'postal_code'      => $pin,
            ),
        );
        set_transient( $key, $data, self::OTP_TTL_SECONDS );

        // Dispatch — either the dedicated email helper (if present) or the generic
        // OTP dispatcher. Both keep the same wp_mail + SMS fan-out semantics.
        $delivery = array( 'email' => false, 'sms' => false );
        if ( class_exists( 'NME_Emails' ) && method_exists( 'NME_Emails', 'send_address_change_otp' ) ) {
            $email_ok = (bool) NME_Emails::send_address_change_otp( $expert, $otp );
            // Still push SMS via dispatch_otp's SMS leg (email=false means it'll
            // only hit SMS and skip sending a duplicate email).
            $sms_only = self::dispatch_otp(
                (object) array_merge( (array) $expert, array( 'email' => '' ) ),
                $otp,
                array(
                    'sms_template'     => 'Nagaland Me Experts: Your address-update code is %s. Valid 10 min. Do NOT share.',
                    'sms_log_context'  => 'address_change_otp',
                    'audit_sms_fail'   => 'otp_sms_failed_address',
                )
            );
            $delivery = array( 'email' => $email_ok, 'sms' => ! empty( $sms_only['sms'] ) );
        } else {
            $delivery = self::dispatch_otp( $expert, $otp, array(
                'email_subject'    => 'Your Nagaland Me Experts address-update code',
                'email_intro'      => 'Your 6-digit code to confirm your registered-address change is:',
                'sms_template'     => 'Nagaland Me Experts: Your address-update code is %s. Valid 10 min. Do NOT share.',
                'sms_log_context'  => 'address_change_otp',
                'audit_email_fail' => 'otp_email_failed_address',
                'audit_sms_fail'   => 'otp_sms_failed_address',
            ) );
        }

        if ( empty( $delivery['email'] ) && empty( $delivery['sms'] ) ) {
            delete_transient( $key );
            NME_Database::audit_log( 'address_change_otp_delivery_failed', 'expert', (int) $expert->id );
            self::redirect_with_flash( $referer, 'error', 'We could not send your verification code. Please contact support.' );
        }

        NME_Database::audit_log( 'address_change_otp_sent', 'expert', (int) $expert->id, array(
            'email' => ! empty( $delivery['email'] ),
            'sms'   => ! empty( $delivery['sms'] ),
        ) );

        self::redirect_with_flash( $referer, 'success', 'A 6-digit code has been sent to your phone and email. Please enter it below.' );
    }

    /**
     * Step 2: verify OTP, write the new address directly to nme_experts,
     * and push the update to Razorpay Route so KYC stays in sync.
     */
    public static function handle_verify_address_otp() {
        if ( ! is_user_logged_in() ) wp_die( 'Login required.' );
        if ( ! isset( $_POST['nme_addr_otp_nonce'] ) || ! wp_verify_nonce( $_POST['nme_addr_otp_nonce'], 'nme_verify_address_otp' ) ) {
            wp_die( 'Security check failed.' );
        }
        $expert = self::current_expert();
        if ( ! $expert ) wp_die( 'Expert account not found.' );

        $referer = wp_get_referer() ?: home_url( '/edit-address/' );
        $code    = preg_replace( '/\D/', '', (string) ( $_POST['otp_code'] ?? '' ) );

        $key  = self::address_otp_transient_key( (int) $expert->id );
        $data = get_transient( $key );
        if ( empty( $data ) || empty( $data['hash'] ) ) {
            self::redirect_with_flash( $referer, 'error', 'Your code has expired. Please submit the form again.' );
        }

        if ( (int) ( $data['attempts'] ?? 0 ) >= self::OTP_MAX_ATTEMPTS ) {
            delete_transient( $key );
            self::redirect_with_flash( $referer, 'error', 'Too many incorrect attempts. Please submit the form again.' );
        }
        if ( ! wp_check_password( $code, $data['hash'] ) ) {
            $data['attempts'] = (int) $data['attempts'] + 1;
            set_transient( $key, $data, max( 60, $data['expires'] - time() ) );
            self::redirect_with_flash( $referer, 'error', 'Incorrect code. Please try again.' );
        }

        // OTP valid — apply the change. No admin approval queue.
        $payload = isset( $data['payload'] ) && is_array( $data['payload'] ) ? $data['payload'] : array();
        $new = array(
            'street_address'   => sanitize_text_field( $payload['street_address']   ?? '' ),
            'village_locality' => sanitize_text_field( $payload['village_locality'] ?? '' ),
            'postal_code'      => preg_replace( '/\D/', '', (string) ( $payload['postal_code'] ?? '' ) ),
        );
        // Re-validate shape in case transient was tampered with or the column
        // constraints changed between step 1 and step 2.
        if ( $new['street_address'] === '' || mb_strlen( $new['street_address'] ) > 160
             || $new['village_locality'] === '' || mb_strlen( $new['village_locality'] ) > 120
             || ! preg_match( '/^\d{6}$/', $new['postal_code'] ) ) {
            delete_transient( $key );
            self::redirect_with_flash( $referer, 'error', 'Stored data failed validation. Please start over.' );
        }

        global $wpdb;
        $old = array(
            'street_address'   => (string) ( $expert->street_address ?? '' ),
            'village_locality' => (string) ( $expert->village_locality ?? '' ),
            'postal_code'      => (string) ( $expert->postal_code ?? '' ),
        );
        $result = $wpdb->update( self::experts_table(), $new, array( 'id' => (int) $expert->id ) );
        if ( false === $result ) {
            self::redirect_with_flash( $referer, 'error', 'Could not save the new address. Please try again.' );
        }

        delete_transient( $key );

        NME_Database::audit_log( 'address_updated', 'expert', (int) $expert->id, array(
            'old' => $old,
            'new' => $new,
        ) );

        // Sync the change to Razorpay Route (v2) if a linked account exists.
        // Non-blocking: any failure is logged and surfaced as a warning so the
        // expert still sees their new address saved locally.
        $razorpay_note = self::sync_address_to_razorpay( (int) $expert->id, $new );

        // Notify expert that the change landed.
        if ( class_exists( 'NME_Experts' ) && class_exists( 'NME_Emails' ) && method_exists( 'NME_Emails', 'send_address_changed' ) ) {
            $fresh_expert = NME_Experts::get( (int) $expert->id );
            if ( $fresh_expert ) NME_Emails::send_address_changed( $fresh_expert, $old, $new );
        }

        $msg = 'Your registered address has been updated.';
        if ( $razorpay_note !== '' ) $msg .= ' ' . $razorpay_note;

        self::redirect_with_flash( home_url( '/expert-dashboard/' ), 'success', $msg );
    }

    /**
     * Push address change to Razorpay Route linked account (v2 API) when one
     * exists for this expert. Returns a human-readable note for the expert
     * (empty string if nothing notable happened).
     */
    private static function sync_address_to_razorpay( $expert_id, $new_address ) {
        if ( ! class_exists( 'NMEP_Linked_Accounts' ) ) {
            return ''; // Payments plugin not loaded — nothing to sync.
        }

        $la = null;
        if ( method_exists( 'NMEP_Linked_Accounts', 'get_for_expert' ) ) {
            $la = NMEP_Linked_Accounts::get_for_expert( (int) $expert_id );
        }
        if ( empty( $la ) || empty( $la->razorpay_account_id ) ) {
            return ''; // No linked account yet — will pick up the new address on first creation.
        }

        if ( ! class_exists( 'NMEP_Razorpay_Client' ) || ! method_exists( 'NMEP_Razorpay_Client', 'update_linked_account' ) ) {
            NME_Database::audit_log( 'address_razorpay_sync_skipped', 'expert', (int) $expert_id, array(
                'reason' => 'razorpay_client_unavailable',
            ) );
            return 'Razorpay sync will happen automatically on the next payout attempt.';
        }

        $patch = array(
            'profile' => array(
                'addresses' => array(
                    'registered' => array(
                        'street1'     => $new_address['street_address'],
                        'street2'     => $new_address['village_locality'],
                        'city'        => $new_address['village_locality'],
                        'state'       => 'NAGALAND',
                        'postal_code' => $new_address['postal_code'],
                        'country'     => 'IN',
                    ),
                ),
            ),
        );

        $response = NMEP_Razorpay_Client::update_linked_account( $la->razorpay_account_id, $patch );
        if ( is_wp_error( $response ) ) {
            NME_Database::audit_log( 'address_razorpay_sync_failed', 'expert', (int) $expert_id, array(
                'account_id' => $la->razorpay_account_id,
                'error'      => $response->get_error_message(),
            ) );
            return 'Your Razorpay account could not be updated automatically — our team will retry.';
        }

        NME_Database::audit_log( 'address_razorpay_sync_ok', 'expert', (int) $expert_id, array(
            'account_id' => $la->razorpay_account_id,
        ) );
        return 'Your Razorpay payout account has also been updated.';
    }

    /* ============================================================
       ADMIN HANDLERS
       ============================================================ */

    public static function handle_approve_change_request() {
        if ( ! current_user_can( self::admin_capability() ) ) wp_die( 'Permission denied.' );
        $id = isset( $_POST['request_id'] ) ? (int) $_POST['request_id'] : 0;
        if ( ! wp_verify_nonce( $_POST['_wpnonce'] ?? '', 'nme_approve_change_' . $id ) ) wp_die( 'Security check failed.' );

        self::approve_request( $id, get_current_user_id() );
        wp_safe_redirect( admin_url( 'admin.php?page=nme-change-requests&approved=1' ) );
        exit;
    }

    public static function handle_reject_change_request() {
        if ( ! current_user_can( self::admin_capability() ) ) wp_die( 'Permission denied.' );
        $id = isset( $_POST['request_id'] ) ? (int) $_POST['request_id'] : 0;
        if ( ! wp_verify_nonce( $_POST['_wpnonce'] ?? '', 'nme_reject_change_' . $id ) ) wp_die( 'Security check failed.' );
        $reason = sanitize_textarea_field( $_POST['reason'] ?? '' );

        self::reject_request( $id, get_current_user_id(), $reason );
        wp_safe_redirect( admin_url( 'admin.php?page=nme-change-requests&rejected=1' ) );
        exit;
    }

    /* ============================================================
       ADMIN QUEUE RENDERER — called by NME_Admin
       ============================================================ */

    public static function render_admin_queue() {
        if ( ! current_user_can( self::admin_capability() ) ) {
            echo '<div class="wrap"><h1>Expert Requests</h1><p>Permission denied.</p></div>';
            return;
        }
        $status = isset( $_GET['status'] ) ? sanitize_key( $_GET['status'] ) : self::STATUS_PENDING;
        $type   = isset( $_GET['type'] )   ? sanitize_key( $_GET['type'] )   : '';
        $items  = self::list_requests( array( 'status' => $status, 'type' => $type, 'limit' => 100 ) );

        $flash = '';
        if ( ! empty( $_GET['approved'] ) ) $flash = '<div class="notice notice-success"><p>Request approved and applied.</p></div>';
        if ( ! empty( $_GET['rejected'] ) ) $flash = '<div class="notice notice-warning"><p>Request rejected. Expert has been notified.</p></div>';

        ?>
        <div class="wrap nme-admin">
            <h1>Expert Requests</h1>
            <?php echo $flash; ?>
            <p>Review and approve or reject change requests submitted by experts. Bank-account changes require your approval before they apply.</p>

            <ul class="subsubsub">
                <li><a href="?page=nme-change-requests&status=pending" <?php echo $status === 'pending' ? 'class="current"' : ''; ?>>Pending <span class="count">(<?php echo (int) self::count_pending_admin_queue(); ?>)</span></a> |</li>
                <li><a href="?page=nme-change-requests&status=approved" <?php echo $status === 'approved' ? 'class="current"' : ''; ?>>Approved</a> |</li>
                <li><a href="?page=nme-change-requests&status=rejected" <?php echo $status === 'rejected' ? 'class="current"' : ''; ?>>Rejected</a> |</li>
                <li><a href="?page=nme-change-requests&status=cancelled" <?php echo $status === 'cancelled' ? 'class="current"' : ''; ?>>Cancelled</a></li>
            </ul>

            <table class="wp-list-table widefat fixed striped" style="margin-top:16px;">
                <thead>
                    <tr>
                        <th style="width:60px;">ID</th>
                        <th>Expert</th>
                        <th>Type</th>
                        <th>Submitted</th>
                        <th>Details</th>
                        <th style="width:260px;">Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php if ( empty( $items ) ) : ?>
                    <tr><td colspan="6" style="text-align:center;padding:30px;color:#6B7280;">No <?php echo esc_html( $status ); ?> requests.</td></tr>
                <?php else :
                    foreach ( $items as $r ) :
                        $expert = class_exists( 'NME_Experts' ) ? NME_Experts::get( (int) $r->expert_id ) : null;
                        $payload = json_decode( (string) $r->payload, true ) ?: array();
                        $old     = json_decode( (string) $r->old_snapshot, true ) ?: array();
                ?>
                    <tr>
                        <td>#<?php echo (int) $r->id; ?></td>
                        <td>
                            <?php if ( $expert ) : ?>
                                <strong><?php echo esc_html( $expert->full_name ); ?></strong><br>
                                <small><?php echo esc_html( $expert->email ); ?></small><br>
                                <a href="<?php echo esc_url( admin_url( 'admin.php?page=nme-experts&action=view&id=' . (int) $expert->id ) ); ?>">View expert →</a>
                            <?php else : ?>
                                <em>Expert #<?php echo (int) $r->expert_id; ?></em>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if ( $r->type === self::TYPE_BANK_ACCOUNT ) : ?>
                                🏦 Bank account
                            <?php else : ?>
                                📸 Profile photo
                            <?php endif; ?>
                        </td>
                        <td><?php echo esc_html( mysql2date( 'd M Y H:i', $r->requested_at ) ); ?></td>
                        <td>
                            <?php if ( $r->type === self::TYPE_BANK_ACCOUNT ) : ?>
                                <details>
                                    <summary>Compare old → new</summary>
                                    <table style="font-size:0.85rem;margin-top:8px;">
                                        <tr><td><strong>Holder:</strong></td><td><s><?php echo esc_html( $old['bank_account_holder'] ?? '—' ); ?></s> → <?php echo esc_html( $payload['bank_account_holder'] ?? '—' ); ?></td></tr>
                                        <tr><td><strong>A/c #:</strong></td><td><s><?php echo esc_html( self::mask_account( $old['bank_account_number'] ?? '' ) ); ?></s> → <?php echo esc_html( $payload['bank_account_number'] ?? '—' ); ?></td></tr>
                                        <tr><td><strong>IFSC:</strong></td><td><s><?php echo esc_html( $old['bank_ifsc'] ?? '—' ); ?></s> → <?php echo esc_html( $payload['bank_ifsc'] ?? '—' ); ?></td></tr>
                                        <tr><td><strong>UPI:</strong></td><td><s><?php echo esc_html( $old['upi_id'] ?? '—' ); ?></s> → <?php echo esc_html( $payload['upi_id'] ?? '—' ); ?></td></tr>
                                    </table>
                                </details>
                            <?php else : ?>
                                <?php if ( ! empty( $payload['profile_photo'] ) ) : ?>
                                    <img src="<?php echo esc_url( $payload['profile_photo'] ); ?>" style="max-width:80px;max-height:80px;border-radius:50%;">
                                <?php endif; ?>
                            <?php endif; ?>
                            <?php if ( $status !== 'pending' && ! empty( $r->admin_reason ) ) : ?>
                                <div style="margin-top:8px;color:#991B1B;font-size:0.85rem;"><strong>Reason:</strong> <?php echo esc_html( $r->admin_reason ); ?></div>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if ( $r->status === self::STATUS_PENDING ) : ?>
                                <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline-block;margin-bottom:6px;">
                                    <input type="hidden" name="action" value="nme_approve_change_request">
                                    <input type="hidden" name="request_id" value="<?php echo (int) $r->id; ?>">
                                    <?php wp_nonce_field( 'nme_approve_change_' . (int) $r->id ); ?>
                                    <button type="submit" class="button button-primary" onclick="return confirm('Approve and apply this change?');">✅ Approve</button>
                                </form>
                                <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                                    <input type="hidden" name="action" value="nme_reject_change_request">
                                    <input type="hidden" name="request_id" value="<?php echo (int) $r->id; ?>">
                                    <?php wp_nonce_field( 'nme_reject_change_' . (int) $r->id ); ?>
                                    <textarea name="reason" placeholder="Reason (shown to expert)" style="width:100%;" rows="2"></textarea>
                                    <button type="submit" class="button" style="color:#991B1B;">❌ Reject</button>
                                </form>
                            <?php else : ?>
                                <em style="color:#6B7280;"><?php echo esc_html( ucfirst( $r->status ) ); ?><?php if ( ! empty( $r->reviewed_at ) ) : ?> on <?php echo esc_html( mysql2date( 'd M Y', $r->reviewed_at ) ); ?><?php endif; ?></em>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
        <?php
    }

    /* ============================================================
       FLASH MESSAGES
       ============================================================ */

    private static function flash_messages() {
        if ( ! isset( $_GET['nme_cr_status'] ) ) return '';
        $type = sanitize_key( $_GET['nme_cr_status'] );
        $msg  = isset( $_GET['nme_cr_msg'] ) ? sanitize_text_field( urldecode( $_GET['nme_cr_msg'] ) ) : '';
        if ( $msg === '' ) return '';
        if ( $type === 'success' ) {
            return '<div class="nme-card" style="border-left:4px solid #10B981;background:#F0FDF4;"><p style="margin:0;color:#065F46;">' . esc_html( $msg ) . '</p></div>';
        }
        return '<div class="nme-card" style="border-left:4px solid #EF4444;background:#FEF2F2;"><p style="margin:0;color:#991B1B;">' . esc_html( $msg ) . '</p></div>';
    }
}