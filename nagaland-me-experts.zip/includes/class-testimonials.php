<?php
/**
 * NME_Testimonials
 *
 * Manages customer testimonials/reviews with:
 * - Database table for storing testimonials
 * - Admin panel to add/edit/delete/reorder
 * - [nme_testimonials] shortcode: auto-scrolling carousel
 *
 * @version 1.0.0
 */
if ( ! defined( 'ABSPATH' ) ) exit;

class NME_Testimonials {

    const TABLE = 'nme_testimonials';
    const VERSION_KEY = 'nme_testimonials_db_version';
    const DB_VERSION = '1.0';

    public static function init() {
        add_action( 'admin_init', array( __CLASS__, 'maybe_create_table' ) );
        add_shortcode( 'nme_testimonials', array( __CLASS__, 'render_carousel' ) );

        // Admin
       add_action( 'admin_menu', array( __CLASS__, 'register_admin_menu' ), 20 );
        add_action( 'admin_post_nme_save_testimonial', array( __CLASS__, 'handle_save' ) );
        add_action( 'admin_post_nme_delete_testimonial', array( __CLASS__, 'handle_delete' ) );
        add_action( 'admin_post_nme_toggle_testimonial', array( __CLASS__, 'handle_toggle' ) );
    }

    /* ============================================================
       DATABASE
       ============================================================ */
    public static function table() {
        global $wpdb;
        return $wpdb->prefix . self::TABLE;
    }

    public static function maybe_create_table() {
        if ( get_option( self::VERSION_KEY ) === self::DB_VERSION ) return;

        global $wpdb;
        $table = self::table();
        $charset = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE IF NOT EXISTS $table (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            reviewer_name VARCHAR(120) NOT NULL,
            reviewer_location VARCHAR(120) DEFAULT '',
            reviewer_photo VARCHAR(500) DEFAULT '',
            service_type VARCHAR(200) DEFAULT '',
            rating TINYINT UNSIGNED NOT NULL DEFAULT 5,
            review_text TEXT NOT NULL,
            is_active TINYINT(1) NOT NULL DEFAULT 1,
            is_featured TINYINT(1) NOT NULL DEFAULT 0,
            sort_order INT NOT NULL DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY idx_active_sort (is_active, sort_order)
        ) $charset;";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta( $sql );
        update_option( self::VERSION_KEY, self::DB_VERSION );
    }

    /* ============================================================
       DATA ACCESS
       ============================================================ */
    public static function get_all() {
        global $wpdb;
        return $wpdb->get_results( "SELECT * FROM " . self::table() . " ORDER BY sort_order ASC, id DESC" );
    }

    public static function get_active( $limit = 20 ) {
        global $wpdb;
        return $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM " . self::table() . " WHERE is_active = 1 ORDER BY sort_order ASC, id DESC LIMIT %d",
            $limit
        ) );
    }

    public static function get( $id ) {
        global $wpdb;
        return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM " . self::table() . " WHERE id = %d", $id ) );
    }

    public static function count_active() {
        global $wpdb;
        return (int) $wpdb->get_var( "SELECT COUNT(*) FROM " . self::table() . " WHERE is_active = 1" );
    }

    /* ============================================================
       ADMIN MENU
       ============================================================ */
    public static function register_admin_menu() {
        add_submenu_page(
            'nagaland-me-experts',
            'Testimonials',
            'Testimonials',
            'manage_options',
            'nme-testimonials',
            array( __CLASS__, 'render_admin_page' )
        );
    }

    /* ============================================================
       ADMIN PAGE
       ============================================================ */
    public static function render_admin_page() {
        $action = isset( $_GET['action'] ) ? sanitize_key( $_GET['action'] ) : '';
        $id = isset( $_GET['id'] ) ? (int) $_GET['id'] : 0;

        if ( $action === 'new' || $action === 'edit' ) {
            self::render_admin_form( $id );
            return;
        }

        self::render_admin_list();
    }

    private static function render_admin_list() {
        $testimonials = self::get_all();

        if ( isset( $_GET['saved'] ) ) echo '<div class="notice notice-success is-dismissible"><p>Testimonial saved.</p></div>';
        if ( isset( $_GET['deleted'] ) ) echo '<div class="notice notice-warning is-dismissible"><p>Testimonial deleted.</p></div>';
        if ( isset( $_GET['toggled'] ) ) echo '<div class="notice notice-info is-dismissible"><p>Testimonial visibility updated.</p></div>';
        ?>
        <div class="wrap">
            <h1>
                Testimonials
                <a href="?page=nme-testimonials&action=new" class="page-title-action">+ Add New</a>
            </h1>
            <p>Manage customer testimonials shown on the site via <code>[nme_testimonials]</code> shortcode.</p>

            <?php if ( empty( $testimonials ) ) : ?>
                <div style="text-align:center;padding:60px 20px;">
                    <h3>No testimonials yet</h3>
                    <p>Add your first testimonial to get started.</p>
                    <a href="?page=nme-testimonials&action=new" class="button button-primary">+ Add Testimonial</a>
                </div>
            <?php else : ?>
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th style="width:40px;">#</th>
                            <th>Name</th>
                            <th>Service</th>
                            <th>Rating</th>
                            <th>Review (preview)</th>
                            <th style="width:80px;">Active</th>
                            <th style="width:60px;">Order</th>
                            <th style="width:160px;">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ( $testimonials as $t ) : ?>
                            <tr style="<?php echo ! $t->is_active ? 'opacity:0.5;' : ''; ?>">
                                <td><?php echo (int) $t->id; ?></td>
                                <td>
                                    <strong><?php echo esc_html( $t->reviewer_name ); ?></strong>
                                    <?php if ( $t->reviewer_location ) : ?>
                                        <br><small style="color:#6B7280;"><?php echo esc_html( $t->reviewer_location ); ?></small>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo esc_html( $t->service_type ?: '—' ); ?></td>
                                <td><?php echo str_repeat( '⭐', (int) $t->rating ); ?></td>
                                <td><?php echo esc_html( mb_substr( $t->review_text, 0, 80 ) ); ?><?php echo mb_strlen( $t->review_text ) > 80 ? '…' : ''; ?></td>
                                <td>
                                    <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline;">
                                        <input type="hidden" name="action" value="nme_toggle_testimonial">
                                        <input type="hidden" name="id" value="<?php echo (int) $t->id; ?>">
                                        <?php wp_nonce_field( 'nme_toggle_' . $t->id ); ?>
                                        <button type="submit" class="button button-small" title="<?php echo $t->is_active ? 'Click to hide' : 'Click to show'; ?>">
                                            <?php echo $t->is_active ? '🟢 On' : '🔴 Off'; ?>
                                        </button>
                                    </form>
                                </td>
                                <td><?php echo (int) $t->sort_order; ?></td>
                                <td>
                                    <a href="?page=nme-testimonials&action=edit&id=<?php echo (int) $t->id; ?>" class="button button-small">Edit</a>
                                    <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline;">
                                        <input type="hidden" name="action" value="nme_delete_testimonial">
                                        <input type="hidden" name="id" value="<?php echo (int) $t->id; ?>">
                                        <?php wp_nonce_field( 'nme_delete_' . $t->id ); ?>
                                        <button type="submit" class="button button-small" style="color:#991B1B;" onclick="return confirm('Delete this testimonial?');">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>

            <div style="margin-top:24px;padding:16px;background:#F9FAFB;border-radius:8px;">
                <h3 style="margin-top:0;">Usage</h3>
                <p>Add this shortcode to any page:</p>
                <code style="font-size:1.1rem;background:#fff;padding:8px 16px;border-radius:4px;display:inline-block;">[nme_testimonials]</code>
                <p style="margin-top:8px;">Optional: <code>[nme_testimonials limit="6" speed="4000"]</code></p>
            </div>
        </div>
        <?php
    }

    private static function render_admin_form( $id = 0 ) {
        $t = $id ? self::get( $id ) : null;
        $is_edit = (bool) $t;
        ?>
        <div class="wrap">
            <h1>
                <?php echo $is_edit ? 'Edit Testimonial' : 'Add New Testimonial'; ?>
                <a href="?page=nme-testimonials" class="page-title-action">← Back to List</a>
            </h1>

            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="max-width:720px;">
                <input type="hidden" name="action" value="nme_save_testimonial">
                <input type="hidden" name="id" value="<?php echo (int) $id; ?>">
                <?php wp_nonce_field( 'nme_save_testimonial' ); ?>

                <table class="form-table">
                    <tr>
                        <th><label>Reviewer Name *</label></th>
                        <td><input type="text" name="reviewer_name" required maxlength="120" style="width:100%;"
                                   value="<?php echo esc_attr( $t->reviewer_name ?? '' ); ?>" placeholder="e.g., Imli Jamir"></td>
                    </tr>
                    <tr>
                        <th><label>Location</label></th>
                        <td><input type="text" name="reviewer_location" maxlength="120" style="width:100%;"
                                   value="<?php echo esc_attr( $t->reviewer_location ?? '' ); ?>" placeholder="e.g., Mokokchung, Nagaland"></td>
                    </tr>
                    <tr>
                        <th><label>Photo URL</label></th>
                        <td><input type="url" name="reviewer_photo" style="width:100%;"
                                   value="<?php echo esc_attr( $t->reviewer_photo ?? '' ); ?>" placeholder="https://... (optional)">
                            <p class="description">Leave blank for initials avatar.</p></td>
                    </tr>
                    <tr>
                        <th><label>Service Type</label></th>
                        <td><input type="text" name="service_type" maxlength="200" style="width:100%;"
                                   value="<?php echo esc_attr( $t->service_type ?? '' ); ?>" placeholder="e.g., YouTube Monetization, Thumbnail Design"></td>
                    </tr>
                    <tr>
                        <th><label>Rating *</label></th>
                        <td>
                            <select name="rating" required>
                                <?php for ( $i = 5; $i >= 1; $i-- ) : ?>
                                    <option value="<?php echo $i; ?>" <?php selected( (int) ( $t->rating ?? 5 ), $i ); ?>>
                                        <?php echo str_repeat( '⭐', $i ); ?> (<?php echo $i; ?>)
                                    </option>
                                <?php endfor; ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th><label>Review Text *</label></th>
                        <td><textarea name="review_text" rows="5" required style="width:100%;" placeholder="Their exact words or close to it..."><?php echo esc_textarea( $t->review_text ?? '' ); ?></textarea></td>
                    </tr>
                    <tr>
                        <th><label>Sort Order</label></th>
                        <td><input type="number" name="sort_order" min="0" max="999" style="width:100px;"
                                   value="<?php echo (int) ( $t->sort_order ?? 0 ); ?>">
                            <p class="description">Lower numbers show first. 0 = automatic.</p></td>
                    </tr>
                    <tr>
                        <th><label>Active</label></th>
                        <td><label><input type="checkbox" name="is_active" value="1" <?php checked( $t->is_active ?? 1, 1 ); ?>> Show on website</label></td>
                    </tr>
                </table>

                <?php submit_button( $is_edit ? 'Update Testimonial' : 'Add Testimonial' ); ?>
            </form>
        </div>
        <?php
    }

    /* ============================================================
       ADMIN HANDLERS
       ============================================================ */
    public static function handle_save() {
        if ( ! current_user_can( 'nme_approve_experts' ) || ! wp_verify_nonce( $_POST['_wpnonce'], 'nme_save_testimonial' ) ) {
            wp_die( 'Permission denied.' );
        }

        $id = (int) ( $_POST['id'] ?? 0 );
        $data = array(
            'reviewer_name'     => sanitize_text_field( $_POST['reviewer_name'] ?? '' ),
            'reviewer_location' => sanitize_text_field( $_POST['reviewer_location'] ?? '' ),
            'reviewer_photo'    => esc_url_raw( $_POST['reviewer_photo'] ?? '' ),
            'service_type'      => sanitize_text_field( $_POST['service_type'] ?? '' ),
            'rating'            => max( 1, min( 5, (int) ( $_POST['rating'] ?? 5 ) ) ),
            'review_text'       => sanitize_textarea_field( $_POST['review_text'] ?? '' ),
            'sort_order'        => (int) ( $_POST['sort_order'] ?? 0 ),
            'is_active'         => isset( $_POST['is_active'] ) ? 1 : 0,
        );

        global $wpdb;
        if ( $id > 0 ) {
            $wpdb->update( self::table(), $data, array( 'id' => $id ) );
        } else {
            $wpdb->insert( self::table(), $data );
        }

        wp_safe_redirect( admin_url( 'admin.php?page=nme-testimonials&saved=1' ) );
        exit;
    }

    public static function handle_delete() {
        $id = (int) ( $_POST['id'] ?? 0 );
        if ( ! current_user_can( 'nme_approve_experts' ) || ! wp_verify_nonce( $_POST['_wpnonce'], 'nme_delete_' . $id ) ) {
            wp_die( 'Permission denied.' );
        }

        global $wpdb;
        $wpdb->delete( self::table(), array( 'id' => $id ) );

        wp_safe_redirect( admin_url( 'admin.php?page=nme-testimonials&deleted=1' ) );
        exit;
    }

    public static function handle_toggle() {
        $id = (int) ( $_POST['id'] ?? 0 );
        if ( ! current_user_can( 'nme_approve_experts' ) || ! wp_verify_nonce( $_POST['_wpnonce'], 'nme_toggle_' . $id ) ) {
            wp_die( 'Permission denied.' );
        }

        $t = self::get( $id );
        if ( $t ) {
            global $wpdb;
            $wpdb->update( self::table(), array( 'is_active' => $t->is_active ? 0 : 1 ), array( 'id' => $id ) );
        }

        wp_safe_redirect( admin_url( 'admin.php?page=nme-testimonials&toggled=1' ) );
        exit;
    }

    /* ============================================================
       SHORTCODE — [nme_testimonials]
       Auto-scrolling carousel with pause on hover.
       ============================================================ */
    public static function render_carousel( $atts = array() ) {
        $a = shortcode_atts( array(
            'limit' => 20,
            'speed' => 4000,
        ), $atts );

        $testimonials = self::get_active( (int) $a['limit'] );
        if ( empty( $testimonials ) ) return '';

        $speed = max( 2000, (int) $a['speed'] );
        $uid = 'nme-testi-' . wp_rand( 1000, 9999 );
        $count = count( $testimonials );

        ob_start();
        ?>
        <section class="nme-section">
            <div class="nme-container">
                <div class="nme-text-center nme-mb-4">
                    <h2>What our clients say</h2>
                    <p style="color: var(--nme-text-light);">Real people. Real results.</p>
                </div>

                <div class="nme-testi-wrap" id="<?php echo esc_attr( $uid ); ?>">
                    <div class="nme-testi-track">
                        <?php foreach ( $testimonials as $t ) : ?>
                            <div class="nme-testi-slide">
                                <div class="nme-testi-card">
                                    <div class="nme-testi-stars">
                                        <?php echo str_repeat( '<span class="nme-testi-star">★</span>', (int) $t->rating ); ?>
                                        <?php echo str_repeat( '<span class="nme-testi-star nme-testi-star-empty">★</span>', 5 - (int) $t->rating ); ?>
                                    </div>
                                    <blockquote class="nme-testi-quote"><?php echo esc_html( $t->review_text ); ?></blockquote>
                                    <div class="nme-testi-author">
                                        <?php if ( $t->reviewer_photo ) : ?>
                                            <img src="<?php echo esc_url( $t->reviewer_photo ); ?>" alt="<?php echo esc_attr( $t->reviewer_name ); ?>" class="nme-testi-avatar">
                                        <?php else :
                                            $initials = '';
                                            $parts = explode( ' ', trim( $t->reviewer_name ) );
                                            $initials = mb_strtoupper( mb_substr( $parts[0], 0, 1 ) );
                                            if ( count( $parts ) > 1 ) $initials .= mb_strtoupper( mb_substr( end( $parts ), 0, 1 ) );
                                        ?>
                                            <div class="nme-testi-avatar nme-testi-initials"><?php echo esc_html( $initials ); ?></div>
                                        <?php endif; ?>
                                        <div>
                                            <div class="nme-testi-name"><?php echo esc_html( $t->reviewer_name ); ?></div>
                                            <?php if ( $t->service_type || $t->reviewer_location ) : ?>
                                                <div class="nme-testi-meta">
                                                    <?php
                                                    $parts = array();
                                                    if ( $t->service_type ) $parts[] = $t->service_type;
                                                    if ( $t->reviewer_location ) $parts[] = $t->reviewer_location;
                                                    echo esc_html( implode( ' · ', $parts ) );
                                                    ?>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>

                    <!-- Navigation dots -->
                    <?php if ( $count > 1 ) : ?>
                        <div class="nme-testi-dots">
                            <?php for ( $i = 0; $i < $count; $i++ ) : ?>
                                <button class="nme-testi-dot <?php echo $i === 0 ? 'nme-testi-dot-active' : ''; ?>" data-index="<?php echo $i; ?>"></button>
                            <?php endfor; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </section>

        <style>
            .nme-testi-wrap {
                position: relative;
                overflow: hidden;
                border-radius: 16px;
                max-width: 1000px;
                margin: 0 auto;
            }
            .nme-testi-track {
                display: flex;
                transition: transform 0.6s cubic-bezier(0.25, 0.1, 0.25, 1);
                will-change: transform;
            }
            .nme-testi-slide {
                min-width: 100%;
                padding: 0 12px;
                box-sizing: border-box;
            }
            @media (min-width: 768px) {
                .nme-testi-slide { min-width: 50%; }
            }
            .nme-testi-card {
                background: var(--nme-white, #FFFFFF);
                border: 1.5px solid var(--nme-border, #E5E7EB);
                border-radius: 16px;
                padding: 32px;
                height: 100%;
                display: flex;
                flex-direction: column;
                transition: border-color 0.3s, box-shadow 0.3s;
            }
            .nme-testi-card:hover {
                border-color: var(--nme-gold, #D4A843);
                box-shadow: 0 8px 30px rgba(15, 36, 25, 0.08);
            }
            .nme-testi-stars {
                margin-bottom: 16px;
                font-size: 1.2rem;
                letter-spacing: 2px;
            }
            .nme-testi-star { color: #F59E0B; }
            .nme-testi-star-empty { color: #E5E7EB; }
            .nme-testi-quote {
                font-size: 1.05rem;
                line-height: 1.7;
                color: var(--nme-text, #374151);
                margin: 0 0 24px;
                padding: 0;
                border: none;
                flex: 1;
                font-style: italic;
            }
            .nme-testi-quote::before { content: '"'; font-size: 2rem; color: var(--nme-gold, #D4A843); font-family: Georgia, serif; line-height: 0; vertical-align: -0.4em; margin-right: 4px; }
            .nme-testi-quote::after { content: '"'; font-size: 2rem; color: var(--nme-gold, #D4A843); font-family: Georgia, serif; line-height: 0; vertical-align: -0.4em; margin-left: 4px; }
            .nme-testi-author {
                display: flex;
                align-items: center;
                gap: 14px;
                padding-top: 20px;
                border-top: 1px solid var(--nme-border, #E5E7EB);
            }
            .nme-testi-avatar {
                width: 48px;
                height: 48px;
                border-radius: 50%;
                object-fit: cover;
                flex-shrink: 0;
                border: 2px solid var(--nme-gold, #D4A843);
            }
            .nme-testi-initials {
                display: flex;
                align-items: center;
                justify-content: center;
                background: var(--nme-forest, #0F2419);
                color: var(--nme-gold, #D4A843);
                font-weight: 700;
                font-size: 1rem;
                letter-spacing: 1px;
            }
            .nme-testi-name {
                font-weight: 700;
                color: var(--nme-forest, #0F2419);
                font-size: 0.95rem;
            }
            .nme-testi-meta {
                color: var(--nme-text-light, #6B7280);
                font-size: 0.8rem;
                margin-top: 2px;
            }
            .nme-testi-dots {
                display: flex;
                justify-content: center;
                gap: 8px;
                margin-top: 24px;
            }
            .nme-testi-dot {
                width: 10px;
                height: 10px;
                border-radius: 50%;
                border: 2px solid var(--nme-emerald, #10B981);
                background: transparent;
                cursor: pointer;
                padding: 0;
                transition: background 0.3s;
            }
            .nme-testi-dot-active {
                background: var(--nme-emerald, #10B981);
            }
            .nme-testi-dot:hover {
                background: var(--nme-emerald, #10B981);
                opacity: 0.7;
            }
        </style>

        <script>
        (function() {
            var wrap = document.getElementById('<?php echo esc_js( $uid ); ?>');
            if (!wrap) return;

            var track = wrap.querySelector('.nme-testi-track');
            var slides = wrap.querySelectorAll('.nme-testi-slide');
            var dots = wrap.querySelectorAll('.nme-testi-dot');
            var total = slides.length;
            var current = 0;
            var paused = false;
            var speed = <?php echo (int) $speed; ?>;
            var timer;

            function slidesPerView() {
                return window.innerWidth >= 768 ? 2 : 1;
            }

            function maxIndex() {
                return Math.max(0, total - slidesPerView());
            }

            function goTo(index) {
                current = Math.min(index, maxIndex());
                var pct = current * (100 / slidesPerView());
                track.style.transform = 'translateX(-' + pct + '%)';
                dots.forEach(function(d, i) {
                    d.classList.toggle('nme-testi-dot-active', i === current);
                });
            }

            function next() {
                if (paused) return;
                var nextIdx = current + 1;
                if (nextIdx > maxIndex()) nextIdx = 0;
                goTo(nextIdx);
            }

            function startTimer() {
                clearInterval(timer);
                timer = setInterval(next, speed);
            }

            // Dot click
            dots.forEach(function(dot) {
                dot.addEventListener('click', function() {
                    goTo(parseInt(dot.getAttribute('data-index')));
                    startTimer();
                });
            });

            // Pause on hover
            wrap.addEventListener('mouseenter', function() { paused = true; });
            wrap.addEventListener('mouseleave', function() { paused = false; });

            // Touch swipe
            var touchStartX = 0;
            var touchEndX = 0;
            wrap.addEventListener('touchstart', function(e) {
                touchStartX = e.changedTouches[0].screenX;
                paused = true;
            }, { passive: true });
            wrap.addEventListener('touchend', function(e) {
                touchEndX = e.changedTouches[0].screenX;
                var diff = touchStartX - touchEndX;
                if (Math.abs(diff) > 50) {
                    if (diff > 0 && current < maxIndex()) goTo(current + 1);
                    else if (diff < 0 && current > 0) goTo(current - 1);
                }
                paused = false;
                startTimer();
            }, { passive: true });

            // Resize handler
            var resizeTimer;
            window.addEventListener('resize', function() {
                clearTimeout(resizeTimer);
                resizeTimer = setTimeout(function() { goTo(Math.min(current, maxIndex())); }, 200);
            });

            // Start
            startTimer();
        })();
        </script>
        <?php
        return ob_get_clean();
    }
}