<?php
/**
 * NME_Registration
 * Handles expert application form submissions.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class NME_Registration {

    public static function init() {
        add_action( 'admin_post_nme_submit_application', array( __CLASS__, 'handle_submission' ) );
        add_action( 'admin_post_nopriv_nme_submit_application', array( __CLASS__, 'handle_submission' ) );

        // v0.7.0 — resubmit-after-rejection flow. Logged-in only; nopriv is
        // deliberately not registered so unauthenticated POSTs hit WP's
        // default 400 instead of silently redirecting.
        add_action( 'admin_post_nme_edit_application', array( __CLASS__, 'handle_edit_application' ) );

        // v0.8.0 — self-service profile edit for approved experts.
        // Separate handler because it MUST NOT flip status back to pending
        // and MUST NOT touch identity/KYC fields.
        add_action( 'admin_post_nme_edit_profile', array( __CLASS__, 'handle_edit_profile' ) );
    }

    /**
     * Handle the registration form POST
     */
    public static function handle_submission() {

        // Verify nonce
        if ( ! isset( $_POST['nme_nonce'] ) || ! wp_verify_nonce( $_POST['nme_nonce'], 'nme_expert_application' ) ) {
            self::redirect_with_error( 'Security check failed. Please try again.' );
            return;
        }

        // Sanitize all fields
        $data = self::sanitize_input( $_POST );

        // Validate required fields
        $errors = self::validate( $data );
        if ( ! empty( $errors ) ) {
            self::redirect_with_error( implode( ' ', $errors ) );
            return;
        }

        // Check email isn't already an expert
        global $wpdb;
        $existing = $wpdb->get_var( $wpdb->prepare(
            "SELECT id FROM " . NME_Database::table( 'experts' ) . " WHERE email = %s",
            $data['email']
        ) );

        if ( $existing ) {
            self::redirect_with_error( 'An application with this email already exists. Please contact us if you need to update it.' );
            return;
        }

        // Create or get WordPress user
        $user_id = self::find_or_create_user( $data );
        if ( is_wp_error( $user_id ) ) {
            self::redirect_with_error( $user_id->get_error_message() );
            return;
        }

        $data['user_id'] = $user_id;

        // Handle file uploads
        $upload_result = self::handle_file_uploads( $data );
        if ( is_wp_error( $upload_result ) ) {
            self::redirect_with_error( $upload_result->get_error_message() );
            return;
        }
        $data = array_merge( $data, $upload_result );

        // Create the expert application
        $expert_id = NME_Experts::create( $data );

        if ( ! $expert_id ) {
            self::redirect_with_error( 'Could not save your application. Please try again.' );
            return;
        }

        // Send notifications
        if ( class_exists( 'NME_Emails' ) ) {
            NME_Emails::send_application_received( $data );
            NME_Emails::send_admin_notification( $data, $expert_id );
        }

        // Redirect to success
        $success_url = add_query_arg( 'nme_status', 'application_received', wp_get_referer() );
        wp_safe_redirect( $success_url );
        exit;
    }

    /**
     * v0.7.0 — handle the edit-and-resubmit form POST.
     *
     * Gate order:
     *   1. Logged-in check
     *   2. Per-expert nonce check (includes the expert_id so a stolen nonce
     *      for row A cannot be replayed against row B)
     *   3. Ownership check: the logged-in user's ID must match the row's
     *      user_id — this prevents horizontal privilege escalation where
     *      someone tampers with expert_id in the form
     *   4. Status check: only 'rejected' or 'pending' rows can be edited
     *      through this flow; 'approved' rows must go through the regulated
     *      change-request workflow
     *   5. Same sanitize + validate as handle_submission() — reused verbatim
     *      because the field schema is identical
     *   6. File upload (optional — only replaces profile_photo if provided)
     *   7. Persist via NME_Experts::update_application() which strips identity-
     *      critical fields defensively, flips status back to pending, sets
     *      resubmitted_at, clears rejection_reason and emails the admin
     */
    public static function handle_edit_application() {
        // 1. Logged-in gate.
        if ( ! is_user_logged_in() ) {
            self::redirect_with_error( 'You must be logged in to edit your application.' );
            return;
        }

        $expert_id = isset( $_POST['expert_id'] ) ? (int) $_POST['expert_id'] : 0;
        if ( $expert_id <= 0 ) {
            self::redirect_with_error( 'Invalid application reference.' );
            return;
        }

        // 2. Nonce check — per-expert key.
        if ( ! isset( $_POST['nme_nonce'] ) || ! wp_verify_nonce( $_POST['nme_nonce'], 'nme_edit_application_' . $expert_id ) ) {
            self::redirect_with_error( 'Security check failed. Please reload the page and try again.' );
            return;
        }

        // 3. Ownership check.
        $expert = NME_Experts::get( $expert_id );
        if ( ! $expert ) {
            self::redirect_with_error( 'Application not found.' );
            return;
        }
        if ( (int) $expert->user_id !== (int) get_current_user_id() ) {
            self::redirect_with_error( 'You are not allowed to edit this application.' );
            return;
        }

        // 4. Status gate.
        $editable_statuses = array( NME_Experts::STATUS_REJECTED, NME_Experts::STATUS_PENDING );
        if ( ! in_array( $expert->status, $editable_statuses, true ) ) {
            self::redirect_with_error( 'This application can no longer be edited here. Please contact support.' );
            return;
        }

        // 5. Sanitize + validate (identical to first-time submission).
        $data = self::sanitize_input( $_POST );

        // Email is immutable through this flow — keep the row's existing email
        // for validation and for any downstream rules that read it.
        $data['email'] = $expert->email;

        $errors = self::validate( $data );
        if ( ! empty( $errors ) ) {
            self::redirect_with_error( implode( ' ', $errors ) );
            return;
        }

        // 6. Optional file upload (profile photo). Only overwrite if a new
        // file was actually provided — otherwise keep whatever is on the row.
        $upload_result = self::handle_file_uploads( $data );
        if ( is_wp_error( $upload_result ) ) {
            self::redirect_with_error( $upload_result->get_error_message() );
            return;
        }
        $data = array_merge( $data, $upload_result );

        // Drop fields the update layer must never touch (defence in depth —
        // update_application() also strips these, but we do it here too so
        // downstream debugging is obvious).
        unset( $data['email'], $data['user_id'], $data['id'], $data['status'], $data['applied_at'] );

        // 7. Persist.
        $ok = NME_Experts::update_application( $expert_id, $data );
        if ( ! $ok ) {
            self::redirect_with_error( 'Could not save your changes. Please try again.' );
            return;
        }

        // Success → dashboard with a flash so the expert sees a clear
        // confirmation instead of landing back on an empty edit form.
        $success_url = add_query_arg(
            'nme_status',
            'application_resubmitted',
            home_url( '/expert-dashboard/' )
        );
        wp_safe_redirect( $success_url );
        exit;
    }

    /**
     * v0.8.0 — Self-service profile edit for approved experts.
     *
     * This is intentionally separate from handle_edit_application():
     *   - Only runs for experts whose status is already "approved"
     *   - Does NOT flip status back to pending (no re-review)
     *   - Only writes a whitelist of public-profile fields
     *     (tagline, bio, languages, portfolio_url, youtube_channel, facebook_page)
     *   - Never touches email, phone, name, district, KYC, bank, or photo
     *
     * Post target: admin-post.php with action=nme_edit_profile.
     * Nonce: nme_edit_profile_{expert_id}.
     */
    public static function handle_edit_profile() {
        // 1. Logged-in gate.
        if ( ! is_user_logged_in() ) {
            self::redirect_with_error( 'You must be logged in to edit your profile.');
            return;
        }

        $expert_id = isset( $_POST['expert_id'] ) ? (int) $_POST['expert_id'] : 0;
        if ( $expert_id <= 0 ) {
            self::redirect_with_error( 'Invalid profile reference.');
            return;
        }

        // 2. Nonce check — per-expert key.
        if ( ! isset( $_POST['nme_nonce'] ) || ! wp_verify_nonce( $_POST['nme_nonce'], 'nme_edit_profile_' . $expert_id ) ) {
            self::redirect_with_error( 'Security check failed. Please reload the page and try again.');
            return;
        }

        // 3. Ownership check.
        $expert = NME_Experts::get( $expert_id );
        if ( ! $expert ) {
            self::redirect_with_error( 'Profile not found.');
            return;
        }
        if ( (int) $expert->user_id !== (int) get_current_user_id() ) {
            self::redirect_with_error( 'You are not allowed to edit this profile.');
            return;
        }

        // 4. Status gate — this form is ONLY for approved experts. Pending /
        // rejected applicants must use /edit-application/ which goes through
        // the re-review pipeline.
        if ( $expert->status !== NME_Experts::STATUS_APPROVED ) {
            self::redirect_with_error( 'This form is for approved experts only. Use your dashboard to manage a pending or rejected application.');
            return;
        }

        // 5. Sanitize the whitelisted fields only.
        $clean = array(
            'tagline'         => sanitize_text_field( $_POST['tagline'] ?? '' ),
            'bio'             => sanitize_textarea_field( $_POST['bio'] ?? '' ),
            'languages'       => sanitize_text_field( $_POST['languages'] ?? '' ),
            'portfolio_url'   => esc_url_raw( $_POST['portfolio_url'] ?? '' ),
            'youtube_channel' => esc_url_raw( $_POST['youtube_channel'] ?? '' ),
            'facebook_page'   => esc_url_raw( $_POST['facebook_page'] ?? '' ),
        );

        // 6. Validate.
        $errors = array();
        if ( empty( $clean['bio'] ) ) {
            $errors[] = 'Please write a short about/bio.';
        } elseif ( mb_strlen( $clean['bio'] ) < 30 ) {
            $errors[] = 'Your bio must be at least 30 characters so buyers know what you do.';
        }
        if ( mb_strlen( $clean['tagline'] ) > 160 ) {
            $errors[] = 'Tagline must be 160 characters or fewer.';
        }
        if ( empty( $clean['languages'] ) ) {
            $errors[] = 'Please list at least one language you speak.';
        }
        if ( ! empty( $errors ) ) {
            self::redirect_with_error( implode( ' ', $errors ));
            return;
        }

        // 7. Persist via the whitelisted writer.
        $ok = NME_Experts::update_profile_fields( $expert_id, $clean );
        if ( ! $ok ) {
            self::redirect_with_error( 'Could not save your changes. Please try again.');
            return;
        }

        $success_url = add_query_arg(
            'nme_status',
            'profile_updated',
            home_url( '/edit-profile/' )
        );
        wp_safe_redirect( $success_url );
        exit;
    }

    /**
     * Sanitize all form input
     */
    private static function sanitize_input( $post ) {
        return array(
            'full_name'              => sanitize_text_field( $post['full_name'] ?? '' ),
            'email'                  => sanitize_email( $post['email'] ?? '' ),
            'phone'                  => sanitize_text_field( $post['phone'] ?? '' ),
            'whatsapp'               => sanitize_text_field( $post['whatsapp'] ?? '' ),
            'district'               => sanitize_text_field( $post['district'] ?? '' ),
            'state'                  => sanitize_text_field( $post['state'] ?? 'Nagaland' ),
            // Registered address — required by Razorpay Route KYC (schema v0.5.0)
            'street_address'         => sanitize_text_field( $post['street_address'] ?? '' ),
            'village_locality'       => sanitize_text_field( $post['village_locality'] ?? '' ),
            'postal_code'            => preg_replace( '/\D/', '', (string) ( $post['postal_code'] ?? '' ) ),
            'primary_category_id'    => (int) ( $post['primary_category_id'] ?? 0 ),
            'secondary_category_id'  => (int) ( $post['secondary_category_id'] ?? 0 ) ?: null,
            'tagline'                => sanitize_text_field( $post['tagline'] ?? '' ),
            'bio'                    => sanitize_textarea_field( $post['bio'] ?? '' ),
            'languages'              => sanitize_text_field( $post['languages'] ?? '' ),
            'years_experience'       => (int) ( $post['years_experience'] ?? 0 ),
            'portfolio_url'          => esc_url_raw( $post['portfolio_url'] ?? '' ),
            'youtube_channel'        => esc_url_raw( $post['youtube_channel'] ?? '' ),
            'facebook_page'          => esc_url_raw( $post['facebook_page'] ?? '' ),
            // KYC + Payout moved to dashboard — not collected at registration
        );
    }

    /**
     * Validate required fields
     */
    private static function validate( $data ) {
        $errors = array();

        if ( empty( $data['full_name'] ) ) {
            $errors[] = 'Full name is required.';
        }
        if ( empty( $data['email'] ) || ! is_email( $data['email'] ) ) {
            $errors[] = 'Valid email is required.';
        }
        if ( empty( $data['phone'] ) ) {
            $errors[] = 'Phone number is required.';
        }
        if ( empty( $data['primary_category_id'] ) ) {
            $errors[] = 'Please select a primary category.';
        }
        if ( empty( $data['bio'] ) ) {
            $errors[] = 'Please write a short bio about yourself.';
        }
        // Registered address — Razorpay Route KYC cannot proceed without it,
        // so we block at application time rather than letting an approved
        // expert get stuck waiting for admin to fill it in later.
        if ( empty( $data['street_address'] ) ) {
            $errors[] = 'Street address is required.';
        } elseif ( mb_strlen( $data['street_address'] ) > 160 ) {
            $errors[] = 'Street address must be 160 characters or fewer.';
        }
        if ( empty( $data['village_locality'] ) ) {
            $errors[] = 'Village / locality is required.';
        } elseif ( mb_strlen( $data['village_locality'] ) > 120 ) {
            $errors[] = 'Village / locality must be 120 characters or fewer.';
        }
        if ( ! preg_match( '/^\d{6}$/', (string) $data['postal_code'] ) ) {
            $errors[] = 'PIN code must be exactly 6 digits.';
        }
        // KYC + Payout validation moved to dashboard (completed after registration)

        return $errors;
    }

    /**
     * Find existing WP user by email or create new one
     */
    private static function find_or_create_user( $data ) {
        $user = get_user_by( 'email', $data['email'] );

        if ( $user ) {
            return $user->ID;
        }

        // Create new user
        $username = self::generate_username( $data['full_name'], $data['email'] );
        $password = wp_generate_password( 16, true );

        $user_id = wp_create_user( $username, $password, $data['email'] );

        if ( is_wp_error( $user_id ) ) {
            return $user_id;
        }

        wp_update_user( array(
            'ID'           => $user_id,
            'display_name' => $data['full_name'],
            'first_name'   => $data['full_name'],
        ) );

        return $user_id;
    }

    /**
     * Generate a unique username from name + email
     */
    private static function generate_username( $name, $email ) {
        $base = sanitize_user( strtolower( str_replace( ' ', '_', $name ) ), true );
        if ( empty( $base ) ) {
            $base = sanitize_user( substr( $email, 0, strpos( $email, '@' ) ), true );
        }

        $username = $base;
        $i = 1;
        while ( username_exists( $username ) ) {
            $username = $base . '_' . $i;
            $i++;
        }

        return $username;
    }

    /**
     * Handle uploads for profile photo and ID proof
     */
    private static function handle_file_uploads( $data ) {
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';
        require_once ABSPATH . 'wp-admin/includes/media.php';

        $result = array();

        // Profile photo
        if ( ! empty( $_FILES['profile_photo']['name'] ) ) {
            $upload = wp_handle_upload( $_FILES['profile_photo'], array( 'test_form' => false ) );
            if ( isset( $upload['error'] ) ) {
                return new WP_Error( 'upload_error', 'Profile photo upload failed: ' . $upload['error'] );
            }
            $result['profile_photo'] = $upload['url'];
        }

        // ID proof
        if ( ! empty( $_FILES['id_proof']['name'] ) ) {
            $upload = wp_handle_upload( $_FILES['id_proof'], array( 'test_form' => false ) );
            if ( isset( $upload['error'] ) ) {
                return new WP_Error( 'upload_error', 'ID proof upload failed: ' . $upload['error'] );
            }
            $result['id_proof_url'] = $upload['url'];
        }

        return $result;
    }

    /**
     * Redirect with error message
     */
    private static function redirect_with_error( $message ) {
        $url = add_query_arg(
            array(
                'nme_status' => 'error',
                'nme_message' => urlencode( $message ),
            ),
            wp_get_referer()
        );
        wp_safe_redirect( $url );
        exit;
    }
}