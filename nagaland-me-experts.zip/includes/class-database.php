<?php
/**
 * NME_Database
 * Handles all database tables for the marketplace.
 *
 * v0.4.0 — adds nme_change_requests table + profile_photo_updated_at column
 *          on nme_experts (used by NME_Change_Requests).
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class NME_Database {

    /**
     * Get prefixed table name
     */
    public static function table( $name ) {
        global $wpdb;
        return $wpdb->prefix . 'nme_' . $name;
    }

    /**
     * Create all plugin tables
     */
    public static function create_tables() {
        global $wpdb;

        $charset_collate = $wpdb->get_charset_collate();
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        // === EXPERTS TABLE ===
        $sql_experts = "CREATE TABLE " . self::table( 'experts' ) . " (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id BIGINT(20) UNSIGNED NOT NULL,
            full_name VARCHAR(120) NOT NULL,
            email VARCHAR(120) NOT NULL,
            phone VARCHAR(20) NOT NULL,
            whatsapp VARCHAR(20) DEFAULT NULL,
            district VARCHAR(80) DEFAULT NULL,
            state VARCHAR(80) DEFAULT 'Nagaland',
            street_address VARCHAR(160) DEFAULT NULL,
            village_locality VARCHAR(120) DEFAULT NULL,
            postal_code VARCHAR(10) DEFAULT NULL,
            primary_category_id BIGINT(20) UNSIGNED DEFAULT NULL,
            secondary_category_id BIGINT(20) UNSIGNED DEFAULT NULL,
            tagline VARCHAR(160) DEFAULT NULL,
            bio TEXT DEFAULT NULL,
            languages VARCHAR(255) DEFAULT NULL,
            years_experience TINYINT(3) DEFAULT 0,
            portfolio_url TEXT DEFAULT NULL,
            youtube_channel VARCHAR(255) DEFAULT NULL,
            facebook_page VARCHAR(255) DEFAULT NULL,
            profile_photo VARCHAR(255) DEFAULT NULL,
            profile_photo_updated_at DATETIME DEFAULT NULL,
            pan_number VARCHAR(15) DEFAULT NULL,
            pan_verified TINYINT(1) DEFAULT 0,
            pan_card_url VARCHAR(255) DEFAULT NULL,
            id_proof_url VARCHAR(255) DEFAULT NULL,
            id_proof_back_url VARCHAR(255) DEFAULT NULL,
            id_proof_type VARCHAR(40) DEFAULT NULL,
            kyc_status VARCHAR(20) DEFAULT 'not_started',
            kyc_submitted_at DATETIME DEFAULT NULL,
            kyc_verified_at DATETIME DEFAULT NULL,
            kyc_verified_by BIGINT(20) UNSIGNED DEFAULT NULL,
            kyc_rejection_reason TEXT DEFAULT NULL,
            bank_account_holder VARCHAR(120) DEFAULT NULL,
            bank_account_number VARCHAR(40) DEFAULT NULL,
            bank_ifsc VARCHAR(20) DEFAULT NULL,
            upi_id VARCHAR(80) DEFAULT NULL,
            tier VARCHAR(20) DEFAULT 'new',
            status VARCHAR(20) DEFAULT 'pending',
            rejection_reason TEXT DEFAULT NULL,
            is_founding_expert TINYINT(1) DEFAULT 0,
            commission_rate DECIMAL(5,2) DEFAULT 15.00,
            total_orders INT(11) DEFAULT 0,
            total_earned DECIMAL(12,2) DEFAULT 0.00,
            avg_rating DECIMAL(3,2) DEFAULT 0.00,
            response_time_hours INT(11) DEFAULT 0,
            applied_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            approved_at DATETIME DEFAULT NULL,
            approved_by BIGINT(20) UNSIGNED DEFAULT NULL,
            resubmitted_at DATETIME DEFAULT NULL,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            UNIQUE KEY user_id (user_id),
            KEY status (status),
            KEY tier (tier),
            KEY primary_category_id (primary_category_id)
        ) $charset_collate;";

        // === CATEGORIES TABLE ===
        $sql_categories = "CREATE TABLE " . self::table( 'categories' ) . " (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            parent_id BIGINT(20) UNSIGNED DEFAULT 0,
            slug VARCHAR(80) NOT NULL,
            name VARCHAR(120) NOT NULL,
            icon VARCHAR(20) DEFAULT NULL,
            description TEXT DEFAULT NULL,
            sort_order INT(11) DEFAULT 0,
            is_active TINYINT(1) DEFAULT 1,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            UNIQUE KEY slug (slug),
            KEY parent_id (parent_id)
        ) $charset_collate;";

        // === SERVICES (GIGS) TABLE ===
        $sql_services = "CREATE TABLE " . self::table( 'services' ) . " (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            expert_id BIGINT(20) UNSIGNED NOT NULL,
            category_id BIGINT(20) UNSIGNED NOT NULL,
            slug VARCHAR(120) NOT NULL,
            title VARCHAR(160) NOT NULL,
            short_description VARCHAR(300) DEFAULT NULL,
            description LONGTEXT DEFAULT NULL,
            cover_image VARCHAR(255) DEFAULT NULL,
            gallery_images TEXT DEFAULT NULL,
            video_url VARCHAR(255) DEFAULT NULL,
            basic_title VARCHAR(80) DEFAULT 'Basic',
            basic_price DECIMAL(10,2) DEFAULT 0.00,
            basic_delivery_days INT(11) DEFAULT 3,
            basic_revisions INT(11) DEFAULT 1,
            basic_features TEXT DEFAULT NULL,
            standard_title VARCHAR(80) DEFAULT 'Standard',
            standard_price DECIMAL(10,2) DEFAULT 0.00,
            standard_delivery_days INT(11) DEFAULT 5,
            standard_revisions INT(11) DEFAULT 2,
            standard_features TEXT DEFAULT NULL,
            premium_title VARCHAR(80) DEFAULT 'Premium',
            premium_price DECIMAL(10,2) DEFAULT 0.00,
            premium_delivery_days INT(11) DEFAULT 7,
            premium_revisions INT(11) DEFAULT 3,
            premium_features TEXT DEFAULT NULL,
            requirements TEXT DEFAULT NULL,
            faqs TEXT DEFAULT NULL,
            tags VARCHAR(255) DEFAULT NULL,
            views INT(11) DEFAULT 0,
            orders_count INT(11) DEFAULT 0,
            avg_rating DECIMAL(3,2) DEFAULT 0.00,
            status VARCHAR(20) DEFAULT 'draft',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            UNIQUE KEY slug (slug),
            KEY expert_id (expert_id),
            KEY category_id (category_id),
            KEY status (status)
        ) $charset_collate;";

        // === AUDIT LOG TABLE ===
        $sql_audit = "CREATE TABLE " . self::table( 'audit_log' ) . " (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id BIGINT(20) UNSIGNED DEFAULT NULL,
            action VARCHAR(80) NOT NULL,
            object_type VARCHAR(40) DEFAULT NULL,
            object_id BIGINT(20) UNSIGNED DEFAULT NULL,
            details TEXT DEFAULT NULL,
            ip_address VARCHAR(45) DEFAULT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY user_id (user_id),
            KEY action (action),
            KEY object_type (object_type)
        ) $charset_collate;";

        // === CHANGE REQUESTS TABLE (v0.4.0) ===
        // Stores expert-initiated account-change requests that need admin review
        // (bank-account changes). Profile-photo changes are self-service and
        // write directly to nme_experts — they are NOT stored here.
        $sql_change_requests = "CREATE TABLE " . self::table( 'change_requests' ) . " (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            expert_id BIGINT(20) UNSIGNED NOT NULL,
            type VARCHAR(40) NOT NULL,
            payload LONGTEXT NOT NULL,
            old_snapshot LONGTEXT DEFAULT NULL,
            status VARCHAR(20) NOT NULL DEFAULT 'pending',
            admin_reason TEXT DEFAULT NULL,
            ip_address VARCHAR(45) DEFAULT NULL,
            requested_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            reviewed_at DATETIME DEFAULT NULL,
            reviewed_by BIGINT(20) UNSIGNED DEFAULT NULL,
            PRIMARY KEY  (id),
            KEY expert_id (expert_id),
            KEY status (status),
            KEY type (type),
            KEY requested_at (requested_at)
        ) $charset_collate;";

        dbDelta( $sql_experts );
        dbDelta( $sql_categories );
        dbDelta( $sql_services );
        dbDelta( $sql_audit );
        dbDelta( $sql_change_requests );

        // === v0.2.0 migration for existing installs ===
        $current_version = get_option( 'nme_db_version', '0.0.0' );
        if ( version_compare( $current_version, '0.2.0', '<' ) ) {
            $experts_table = self::table( 'experts' );

            // Add secondary_category_id
            $col = $wpdb->get_var( "SHOW COLUMNS FROM $experts_table LIKE 'secondary_category_id'" );
            if ( ! $col ) {
                $wpdb->query( "ALTER TABLE $experts_table ADD COLUMN secondary_category_id BIGINT(20) UNSIGNED DEFAULT NULL AFTER primary_category_id" );
            }
            // Add id_proof_back_url
            $col = $wpdb->get_var( "SHOW COLUMNS FROM $experts_table LIKE 'id_proof_back_url'" );
            if ( ! $col ) {
                $wpdb->query( "ALTER TABLE $experts_table ADD COLUMN id_proof_back_url VARCHAR(255) DEFAULT NULL AFTER id_proof_url" );
            }
            // Add kyc_status fields
            $col = $wpdb->get_var( "SHOW COLUMNS FROM $experts_table LIKE 'kyc_status'" );
            if ( ! $col ) {
                $wpdb->query( "ALTER TABLE $experts_table ADD COLUMN kyc_status VARCHAR(20) DEFAULT 'not_started' AFTER id_proof_type" );
                $wpdb->query( "ALTER TABLE $experts_table ADD COLUMN kyc_submitted_at DATETIME DEFAULT NULL AFTER kyc_status" );
                $wpdb->query( "ALTER TABLE $experts_table ADD COLUMN kyc_verified_at DATETIME DEFAULT NULL AFTER kyc_submitted_at" );
                $wpdb->query( "ALTER TABLE $experts_table ADD COLUMN kyc_verified_by BIGINT(20) UNSIGNED DEFAULT NULL AFTER kyc_verified_at" );
                $wpdb->query( "ALTER TABLE $experts_table ADD COLUMN kyc_rejection_reason TEXT DEFAULT NULL AFTER kyc_verified_by" );
            }
            // Set existing experts who have PAN as kyc_status = 'submitted'
            $wpdb->query( "UPDATE $experts_table SET kyc_status = 'submitted' WHERE pan_number IS NOT NULL AND pan_number != '' AND kyc_status = 'not_started'" );

            update_option( 'nme_db_version', '0.2.0' );
        }

        // === v0.4.0 migration — profile_photo_updated_at + change_requests ===
        if ( version_compare( get_option( 'nme_db_version', '0.0.0' ), '0.4.0', '<' ) ) {
            $experts_table = self::table( 'experts' );

            // Add profile_photo_updated_at column (30-day cooldown tracker)
            $col = $wpdb->get_var( "SHOW COLUMNS FROM $experts_table LIKE 'profile_photo_updated_at'" );
            if ( ! $col ) {
                $wpdb->query( "ALTER TABLE $experts_table ADD COLUMN profile_photo_updated_at DATETIME DEFAULT NULL AFTER profile_photo" );
            }
            // nme_change_requests table is created above by dbDelta().

            update_option( 'nme_db_version', '0.4.0' );
        }

        // === v0.5.0 migration — full postal address for Razorpay Route KYC ===
        // Razorpay's /v2/accounts endpoint requires non-empty street1, street2
        // and a real postal_code. Prior to v0.5.0 the expert schema only stored
        // district + state, so the payments plugin had to send empty/fallback
        // values that Razorpay rejects. These columns let experts supply a real
        // registered address.
        if ( version_compare( get_option( 'nme_db_version', '0.0.0' ), '0.5.0', '<' ) ) {
            $experts_table = self::table( 'experts' );

            $col = $wpdb->get_var( "SHOW COLUMNS FROM $experts_table LIKE 'street_address'" );
            if ( ! $col ) {
                $wpdb->query( "ALTER TABLE $experts_table ADD COLUMN street_address VARCHAR(160) DEFAULT NULL AFTER state" );
            }
            $col = $wpdb->get_var( "SHOW COLUMNS FROM $experts_table LIKE 'village_locality'" );
            if ( ! $col ) {
                $wpdb->query( "ALTER TABLE $experts_table ADD COLUMN village_locality VARCHAR(120) DEFAULT NULL AFTER street_address" );
            }
            $col = $wpdb->get_var( "SHOW COLUMNS FROM $experts_table LIKE 'postal_code'" );
            if ( ! $col ) {
                $wpdb->query( "ALTER TABLE $experts_table ADD COLUMN postal_code VARCHAR(10) DEFAULT NULL AFTER village_locality" );
            }

            update_option( 'nme_db_version', '0.5.0' );
        }

        // === v0.6.0 migration — PAN card image upload ===
        // Admins may need to replace an expert's PAN (e.g. expert typed a
        // business PAN by mistake and Razorpay is rejecting it). Storing a
        // scanned PAN card lets the admin visually confirm what's on the
        // physical card before saving a new PAN number, and provides an
        // audit artefact if Razorpay later asks for proof.
        if ( version_compare( get_option( 'nme_db_version', '0.0.0' ), '0.6.0', '<' ) ) {
            $experts_table = self::table( 'experts' );

            $col = $wpdb->get_var( "SHOW COLUMNS FROM $experts_table LIKE 'pan_card_url'" );
            if ( ! $col ) {
                $wpdb->query( "ALTER TABLE $experts_table ADD COLUMN pan_card_url VARCHAR(255) DEFAULT NULL AFTER pan_verified" );
            }

            update_option( 'nme_db_version', '0.6.0' );
        }

        // === v0.7.0 migration — resubmit-after-rejection flow ===
        // When an admin rejects an application we now keep the row so the
        // applicant can log in to their dashboard, address the feedback and
        // resubmit. This column records the last resubmit time so admins can
        // distinguish first-time applications from revised ones in the list
        // table (🔄 Resubmitted badge).
        if ( version_compare( get_option( 'nme_db_version', '0.0.0' ), '0.7.0', '<' ) ) {
            $experts_table = self::table( 'experts' );

            $col = $wpdb->get_var( "SHOW COLUMNS FROM $experts_table LIKE 'resubmitted_at'" );
            if ( ! $col ) {
                $wpdb->query( "ALTER TABLE $experts_table ADD COLUMN resubmitted_at DATETIME DEFAULT NULL AFTER approved_by" );
            }

            update_option( 'nme_db_version', '0.7.0' );
        }
    }

    /**
     * Audit log helper
     */
    public static function audit_log( $action, $object_type = null, $object_id = null, $details = null ) {
        global $wpdb;

        $wpdb->insert( self::table( 'audit_log' ), array(
            'user_id'     => get_current_user_id(),
            'action'      => $action,
            'object_type' => $object_type,
            'object_id'   => $object_id,
            'details'     => is_array( $details ) ? wp_json_encode( $details ) : $details,
            'ip_address'  => isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( $_SERVER['REMOTE_ADDR'] ) : null,
        ) );
    }
}