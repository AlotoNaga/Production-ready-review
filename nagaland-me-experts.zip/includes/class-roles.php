<?php
/**
 * NME_Roles
 * Manages custom user roles for the marketplace.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class NME_Roles {

    const ROLE_BUYER     = 'nme_buyer';
    const ROLE_EXPERT    = 'nme_expert';
    const ROLE_MODERATOR = 'nme_moderator';

    /**
     * Add custom roles on plugin activation
     */
    public static function add_roles() {

        // Buyer role
        add_role( self::ROLE_BUYER, 'NME Buyer', array(
            'read'              => true,
            'nme_place_orders'  => true,
            'nme_leave_reviews' => true,
            'nme_open_disputes' => true,
        ) );

        // Expert role
        add_role( self::ROLE_EXPERT, 'NME Expert', array(
            'read'                  => true,
            'nme_create_services'   => true,
            'nme_manage_own_orders' => true,
            'nme_deliver_orders'    => true,
            'nme_withdraw_funds'    => true,
            'nme_leave_reviews'     => true,
        ) );

        // Moderator role
        add_role( self::ROLE_MODERATOR, 'NME Moderator', array(
            'read'                   => true,
            'nme_approve_experts'    => true,
            'nme_handle_disputes'    => true,
            'nme_view_all_orders'    => true,
            'nme_moderate_content'   => true,
        ) );

        // Add admin capabilities to the administrator role
        $admin = get_role( 'administrator' );
        if ( $admin ) {
            $admin->add_cap( 'nme_approve_experts' );
            $admin->add_cap( 'nme_handle_disputes' );
            $admin->add_cap( 'nme_view_all_orders' );
            $admin->add_cap( 'nme_moderate_content' );
            $admin->add_cap( 'nme_manage_settings' );
        }
    }

    /**
     * Remove custom roles (for deactivation cleanup if needed)
     */
    public static function remove_roles() {
        remove_role( self::ROLE_BUYER );
        remove_role( self::ROLE_EXPERT );
        remove_role( self::ROLE_MODERATOR );
    }

    /**
     * Check if user is an approved expert
     */
    public static function is_approved_expert( $user_id = null ) {
        global $wpdb;
        if ( ! $user_id ) {
            $user_id = get_current_user_id();
        }
        if ( ! $user_id ) return false;

        $expert = $wpdb->get_row( $wpdb->prepare(
            "SELECT status FROM " . NME_Database::table( 'experts' ) . " WHERE user_id = %d",
            $user_id
        ) );

        return $expert && $expert->status === 'approved';
    }
}
