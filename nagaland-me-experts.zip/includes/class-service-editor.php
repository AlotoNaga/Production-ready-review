<?php
/**
 * NME_Service_Editor
 *
 * Frontend service creation/edit shortcode [nme_service_editor].
 *
 * All heavy lifting (validation, persistence, admin review workflow)
 * lives in NMEP_Services over in the payments plugin. This class only
 * renders a form that POSTs to admin-post.php with action=nmep_save_service
 * so the existing handler does the work.
 *
 * Features:
 *   - Three pricing tiers (Basic / Standard / Premium) — at least one
 *     price is required by payments-side validation.
 *   - Cover image URL + video URL (URL-based to avoid having to wire
 *     up the WP media library cross-plugin).
 *   - Tags field used as a free-text "specialisation" hint.
 *   - Once a draft service exists, the form also exposes the
 *     service-extras (add-ons) editor which POSTs to NMEP_Service_Extras.
 *
 * @package NagalandMeExperts
 * @since   0.3.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class NME_Service_Editor {

    public static function init() {
        add_shortcode( 'nme_service_editor', array( __CLASS__, 'render' ) );
    }

    public static function render( $atts = array() ) {
        // Access gates
        if ( ! is_user_logged_in() ) {
            return self::notice( 'Please log in to manage services.' );
        }
        if ( ! class_exists( 'NME_Payments_Bridge' ) || ! NME_Payments_Bridge::has_services() ) {
            return self::notice( 'The payments plugin must be active to create services.' );
        }
        $expert = NME_Experts::get_by_user( get_current_user_id() );
        if ( ! $expert ) {
            return self::notice( 'No expert profile found for your account.' );
        }
        if ( $expert->status !== NME_Experts::STATUS_APPROVED ) {
            return self::notice( 'Only approved experts can create services. Please wait for your application review.' );
        }

        $service_id = isset( $_GET['service_id'] ) ? (int) $_GET['service_id'] : 0;
        $service    = null;
        if ( $service_id > 0 ) {
            $service = NMEP_Services::get( $service_id );
            if ( ! $service || (int) $service->expert_id !== (int) $expert->id ) {
                return self::notice( 'Service not found, or it does not belong to you.' );
            }
        }

        $categories = NME_Categories::get_all();
        $is_edit    = (bool) $service;
        $status_msg = self::flash_from_query();

        ob_start();
        ?>
        <section class="nme-section">
            <div class="nme-container" style="max-width: 880px;">

                <?php echo $status_msg; ?>

                <div class="nme-card">
                    <h1 style="margin-top:0;"><?php echo $is_edit ? 'Edit service' : 'Create a new service'; ?></h1>
                    <?php if ( $is_edit ) : ?>
                        <p style="color:#6B7280;margin-top:-4px;">
                            Status: <strong><?php echo esc_html( ucfirst( str_replace( '_', ' ', (string) $service->status ) ) ); ?></strong>
                            <?php if ( ! empty( $service->rejection_reason ) ) : ?>
                                — <span style="color:#991B1B;">Reviewer note: <?php echo esc_html( $service->rejection_reason ); ?></span>
                            <?php endif; ?>
                        </p>
                    <?php else : ?>
                        <p style="color:#6B7280;margin-top:-4px;">
                            Drafts save immediately. You submit for admin review once you're ready to go live.
                        </p>
                    <?php endif; ?>

                    <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" novalidate>
                        <input type="hidden" name="action" value="nmep_save_service">
                        <?php if ( $is_edit ) : ?>
                            <input type="hidden" name="service_id" value="<?php echo (int) $service->id; ?>">
                        <?php endif; ?>
                        <?php wp_nonce_field( 'nmep_save_service', 'nmep_nonce' ); ?>

                        <h3>1. Basics</h3>

                        <p>
                            <label>Service title * <small style="color:#6B7280;">(10–200 characters)</small></label>
                            <input type="text" name="title" required minlength="10" maxlength="200"
                                   value="<?php echo esc_attr( $service->title ?? '' ); ?>"
                                   placeholder="e.g. I will set up AdSense and fix monetisation for your YouTube channel">
                        </p>

                        <div class="nme-grid nme-grid-2">
                            <p>
                                <label>Category *</label>
                                <select name="category_id" required>
                                    <option value="">— Select —</option>
                                    <?php foreach ( $categories as $c ) : ?>
                                        <option value="<?php echo (int) $c->id; ?>"
                                            <?php selected( (int) ( $service->category_id ?? 0 ), (int) $c->id ); ?>>
                                            <?php echo esc_html( trim( ( $c->icon ? $c->icon . ' ' : '' ) . $c->name ) ); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </p>
                            <p>
                                <label>Tags <small style="color:#6B7280;">(comma-separated keywords)</small></label>
                                <input type="text" name="tags" maxlength="255" value="<?php echo esc_attr( $service->tags ?? '' ); ?>"
                                       placeholder="youtube, adsense, monetization, strike appeal">
                            </p>
                        </div>

                        <p>
                            <label>Short description * <small style="color:#6B7280;">(30+ characters — shown in search results)</small></label>
                            <textarea name="short_description" rows="2" required minlength="30"><?php echo esc_textarea( $service->short_description ?? '' ); ?></textarea>
                        </p>

                        <p>
                            <label>Full description</label>
                            <textarea name="description" rows="6" placeholder="Walk the buyer through what you deliver, your process, and what makes your work stand out."><?php echo esc_textarea( $service->description ?? '' ); ?></textarea>
                        </p>

                        <div class="nme-grid nme-grid-2">
                            <p>
                                <label>Cover image URL</label>
                                <input type="url" name="cover_image" value="<?php echo esc_attr( $service->cover_image ?? '' ); ?>" placeholder="https://…/cover.jpg">
                                <small style="color:#6B7280;">Upload to WordPress Media first, then paste the URL.</small>
                            </p>
                            <p>
                                <label>Intro video URL</label>
                                <input type="url" name="video_url" value="<?php echo esc_attr( $service->video_url ?? '' ); ?>" placeholder="https://youtu.be/…">
                            </p>
                        </div>

                        <?php echo self::render_tier_fields( 'basic',    'Basic',    $service, 3, 1 ); ?>
                        <?php echo self::render_tier_fields( 'standard', 'Standard', $service, 5, 2 ); ?>
                        <?php echo self::render_tier_fields( 'premium',  'Premium',  $service, 7, 3 ); ?>

                        <h3 class="nme-mt-4">5. Buyer requirements</h3>
                        <p>
                            <label>What you need from the buyer to start</label>
                            <textarea name="requirements" rows="3" placeholder="e.g. YouTube channel URL, admin access email, a brief summary of the issue"><?php echo esc_textarea( $service->requirements ?? '' ); ?></textarea>
                        </p>

                        <p class="nme-text-center nme-mt-4">
                            <button type="submit" class="nme-btn nme-btn-gold" style="font-size:1.05rem;padding:14px 40px;">
                                <?php echo $is_edit ? 'Save changes' : 'Save as draft'; ?>
                            </button>
                        </p>
                    </form>
                </div>

                <?php if ( $is_edit ) : ?>
                    <?php echo self::render_submit_for_review( $service ); ?>
                    <?php echo self::render_extras_panel( $service ); ?>
                <?php endif; ?>

            </div>
        </section>
        <?php
        return ob_get_clean();
    }

    /* ============================================================
       PARTIALS
       ============================================================ */

    private static function render_tier_fields( $key, $label, $service, $default_days, $default_rev ) {
        $title    = $service->{ $key . '_title' }    ?? $label;
        $price    = $service->{ $key . '_price' }    ?? '';
        $days     = $service->{ $key . '_delivery_days' } ?? $default_days;
        $revs     = $service->{ $key . '_revisions' } ?? $default_rev;
        $features = $service->{ $key . '_features' } ?? '';

        ob_start();
        ?>
        <h3 class="nme-mt-4"><?php echo esc_html( $label ); ?> package
            <small style="color:#6B7280;font-weight:400;">(at least one tier must have a price)</small>
        </h3>
        <div class="nme-grid nme-grid-2">
            <p>
                <label>Package name</label>
                <input type="text" name="<?php echo $key; ?>_title" maxlength="80" value="<?php echo esc_attr( $title ); ?>">
            </p>
            <p>
                <label>Price (₹)</label>
                <input type="number" min="0" step="1" name="<?php echo $key; ?>_price" value="<?php echo esc_attr( $price ); ?>">
            </p>
        </div>
        <div class="nme-grid nme-grid-2">
            <p>
                <label>Delivery (days)</label>
                <input type="number" min="1" name="<?php echo $key; ?>_delivery_days" value="<?php echo (int) $days; ?>">
            </p>
            <p>
                <label>Revisions</label>
                <input type="number" min="0" name="<?php echo $key; ?>_revisions" value="<?php echo (int) $revs; ?>">
            </p>
        </div>
        <p>
            <label>What's included (one per line)</label>
            <textarea name="<?php echo $key; ?>_features" rows="3" placeholder="e.g.&#10;Channel audit&#10;AdSense re-application&#10;30-minute strategy call"><?php echo esc_textarea( $features ); ?></textarea>
        </p>
        <?php
        return ob_get_clean();
    }

    private static function render_submit_for_review( $service ) {
        $status = (string) $service->status;
        ob_start();
        ?>
        <div class="nme-card nme-mt-3" style="background:#F0FDF4;border-left:4px solid #10B981;">
            <h3 style="margin-top:0;">Ready to go live?</h3>
            <?php if ( $status === 'draft' || $status === 'rejected' ) : ?>
                <p>When you submit, our team will review the listing and either approve it or send it back with notes. Typically within 1–2 business days.</p>
                <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                    <input type="hidden" name="action" value="nmep_submit_service">
                    <input type="hidden" name="service_id" value="<?php echo (int) $service->id; ?>">
                    <?php wp_nonce_field( 'nmep_submit_service_' . (int) $service->id ); ?>
                    <button type="submit" class="nme-btn nme-btn-gold">Submit for review</button>
                </form>
            <?php elseif ( $status === 'pending_review' ) : ?>
                <p>Your service is in the review queue. We'll email you once it's approved.</p>
            <?php elseif ( $status === 'active' ) : ?>
                <p>This service is <strong>live</strong>. Editing it will send it back to pending review.</p>
            <?php elseif ( $status === 'paused' ) : ?>
                <p>This service is paused. Resume it from your dashboard to make it bookable again.</p>
            <?php else : ?>
                <p>Status: <?php echo esc_html( $status ); ?></p>
            <?php endif; ?>
        </div>
        <?php
        return ob_get_clean();
    }

    private static function render_extras_panel( $service ) {
        if ( ! class_exists( 'NMEP_Service_Extras' ) ) return '';
        $extras = NMEP_Service_Extras::list_for_service( (int) $service->id, false );
        $action = esc_url( admin_url( 'admin-post.php' ) );

        ob_start();
        ?>
        <div class="nme-card nme-mt-3" id="extras">
            <h2 style="margin-top:0;">Add-ons (extras)</h2>
            <p style="color:#6B7280;margin-top:-6px;">
                Optional paid upgrades the buyer can select at checkout — e.g. "Rush delivery +₹500", "Extra revision +₹200".
            </p>

            <form method="post" action="<?php echo $action; ?>" style="margin-bottom:18px;padding:14px;border:1px solid #E5E7EB;border-radius:10px;">
                <input type="hidden" name="action" value="nmep_save_service_extra">
                <input type="hidden" name="service_id" value="<?php echo (int) $service->id; ?>">
                <?php wp_nonce_field( 'nmep_save_service_extra' ); ?>
                <h4 style="margin-top:0;">Add a new add-on</h4>
                <div class="nme-grid nme-grid-2">
                    <p>
                        <label>Title *</label>
                        <input type="text" name="title" required maxlength="120" placeholder="e.g. Rush delivery (24h)">
                    </p>
                    <p>
                        <label>Price (₹) *</label>
                        <input type="number" name="price" required min="0" step="1">
                    </p>
                </div>
                <div class="nme-grid nme-grid-2">
                    <p>
                        <label>Extra delivery days</label>
                        <input type="number" name="extra_delivery_days" min="0" value="0">
                    </p>
                    <p>
                        <label>Sort order</label>
                        <input type="number" name="sort_order" value="0">
                    </p>
                </div>
                <p>
                    <label>Short description</label>
                    <input type="text" name="description" maxlength="400" placeholder="Optional — what the buyer gets">
                </p>
                <p>
                    <label><input type="checkbox" name="is_active" value="1" checked> Active</label>
                </p>
                <p><button type="submit" class="nme-btn nme-btn-gold">Add add-on</button></p>
            </form>

            <?php if ( empty( $extras ) ) : ?>
                <p style="color:#6B7280;">No add-ons yet.</p>
            <?php else : ?>
                <table style="width:100%;border-collapse:collapse;font-size:0.95rem;">
                    <thead>
                        <tr style="background:#F9FAFB;">
                            <th style="text-align:left;padding:8px;border-bottom:1px solid #E5E7EB;">Title</th>
                            <th style="text-align:right;padding:8px;border-bottom:1px solid #E5E7EB;">Price</th>
                            <th style="text-align:right;padding:8px;border-bottom:1px solid #E5E7EB;">+Days</th>
                            <th style="text-align:left;padding:8px;border-bottom:1px solid #E5E7EB;">Active</th>
                            <th style="padding:8px;border-bottom:1px solid #E5E7EB;"></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ( $extras as $x ) : ?>
                            <tr>
                                <td style="padding:8px;border-bottom:1px solid #F3F4F6;">
                                    <strong><?php echo esc_html( $x->title ); ?></strong>
                                    <?php if ( ! empty( $x->description ) ) : ?>
                                        <div style="color:#6B7280;font-size:0.85rem;"><?php echo esc_html( $x->description ); ?></div>
                                    <?php endif; ?>
                                </td>
                                <td style="padding:8px;border-bottom:1px solid #F3F4F6;text-align:right;">₹<?php echo number_format( (float) $x->price ); ?></td>
                                <td style="padding:8px;border-bottom:1px solid #F3F4F6;text-align:right;"><?php echo (int) $x->extra_delivery_days; ?></td>
                                <td style="padding:8px;border-bottom:1px solid #F3F4F6;"><?php echo (int) $x->is_active ? 'Yes' : '—'; ?></td>
                                <td style="padding:8px;border-bottom:1px solid #F3F4F6;">
                                    <form method="post" action="<?php echo $action; ?>" onsubmit="return confirm('Delete add-on?');" style="display:inline;">
                                        <input type="hidden" name="action" value="nmep_delete_service_extra">
                                        <input type="hidden" name="id" value="<?php echo (int) $x->id; ?>">
                                        <?php wp_nonce_field( 'nmep_delete_service_extra_' . (int) $x->id ); ?>
                                        <button type="submit" class="nme-btn" style="padding:4px 10px;font-size:0.8rem;color:#D63638;">Remove</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
        <?php
        return ob_get_clean();
    }

    /* ============================================================
       HELPERS
       ============================================================ */

    private static function notice( $msg ) {
        return '<section class="nme-section"><div class="nme-container" style="max-width:720px;"><div class="nme-card nme-text-center"><p>' . esc_html( $msg ) . '</p></div></div></section>';
    }

    private static function flash_from_query() {
        $status = isset( $_GET['nmep_status'] ) ? sanitize_key( wp_unslash( $_GET['nmep_status'] ) ) : '';
        $msg    = isset( $_GET['nmep_msg'] )    ? sanitize_text_field( urldecode( wp_unslash( $_GET['nmep_msg'] ) ) ) : '';
        if ( ! $msg ) return '';
        $is_err = ( $status === 'error' );
        $bg     = $is_err ? '#FEF2F2' : '#F0FDF4';
        $color  = $is_err ? '#991B1B' : '#065F46';
        $bar    = $is_err ? '#DC2626' : '#10B981';
        return '<div class="nme-card" style="background:' . $bg . ';border-left:4px solid ' . $bar . ';color:' . $color . ';margin-bottom:20px;">' . esc_html( $msg ) . '</div>';
    }
}
