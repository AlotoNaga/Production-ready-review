<?php
/**
 * NME_KYC
 *
 * KYC verification + payout details — managed from the expert dashboard.
 * Front + back document upload, PAN validation, bank/UPI, status tracking.
 *
 * DEFENSIVE CODING: All $expert property accesses use ?? fallbacks because
 * the kyc_status / id_proof_back_url columns may not exist in the DB yet
 * (migration runs after init on first activation).
 *
 * @version 0.3.0
 *
 * v0.4.0 — when NME_Change_Requests is active, the verified view no longer
 *          exposes the inline "Update Payout Details" form. Instead the
 *          expert is linked to /edit-bank-account/ which runs the OTP +
 *          admin-review workflow. The old inline form is kept as a
 *          fallback (only rendered when the companion class is absent), so
 *          the file remains self-contained if applied out of order.
 */
if ( ! defined( 'ABSPATH' ) ) exit;

class NME_KYC {

    public static function init() {
        add_shortcode( 'nme_kyc_form', array( __CLASS__, 'render_kyc_page' ) );
        add_action( 'admin_post_nme_submit_kyc', array( __CLASS__, 'handle_kyc_submission' ) );
        add_action( 'wp_ajax_nme_upload_id_proof', array( __CLASS__, 'handle_id_proof_upload' ) );
        add_action( 'admin_post_nme_update_payout', array( __CLASS__, 'handle_update_payout' ) );
        add_action( 'admin_post_nme_request_doc_deletion', array( __CLASS__, 'handle_request_doc_deletion' ) );
    }

    /* ============================================================
       SAFE HELPERS — prevent crashes from missing columns
       ============================================================ */

    /**
     * Safely get kyc_status from expert object.
     * Returns 'not_started' if column doesn't exist or is null.
     */
    private static function get_status( $expert ) {
        if ( ! is_object( $expert ) ) return 'not_started';
        return $expert->kyc_status ?? 'not_started';
    }

    /**
     * Safely get any expert property with fallback.
     */
    private static function get_prop( $expert, $key, $fallback = '' ) {
        if ( ! is_object( $expert ) ) return $fallback;
        return $expert->$key ?? $fallback;
    }

    /**
     * Safely get the expert object for current user.
     * Returns null if class doesn't exist or user not found.
     */
    private static function get_current_expert() {
        if ( ! class_exists( 'NME_Experts' ) ) return null;
        if ( ! is_user_logged_in() ) return null;
        $expert = NME_Experts::get_by_user( get_current_user_id() );
        if ( ! $expert || ! is_object( $expert ) ) return null;
        return $expert;
    }

    /* ============================================================
       SHORTCODE — [nme_kyc_form]
       ============================================================ */
    public static function render_kyc_page( $atts = array() ) {
        if ( ! is_user_logged_in() ) {
            return '<div class="nme-card"><p>Please <a href="' . esc_url( wp_login_url( get_permalink() ) ) . '">log in</a> to complete your KYC.</p></div>';
        }

        $expert = self::get_current_expert();
        if ( ! $expert ) {
            return '<div class="nme-card"><p>Expert profile not found. <a href="/expert-register/">Apply here</a>.</p></div>';
        }

        $upload_nonce = wp_create_nonce( 'nme_upload_id_proof' );
        $status = self::get_status( $expert );

        // Flash messages
        $status_html = '';
        if ( isset( $_GET['nme_kyc_status'] ) ) {
            $type = sanitize_key( $_GET['nme_kyc_status'] );
            $msg  = isset( $_GET['nme_kyc_msg'] ) ? sanitize_text_field( urldecode( $_GET['nme_kyc_msg'] ) ) : '';
            if ( $type === 'success' ) {
                $status_html = '<div class="nme-card" style="border-left:4px solid #10B981;background:#F0FDF4;"><p style="margin:0;color:#065F46;">' . esc_html( $msg ) . '</p></div>';
            } elseif ( $type === 'error' ) {
                $status_html = '<div class="nme-card" style="border-left:4px solid #EF4444;background:#FEF2F2;"><p style="margin:0;color:#991B1B;">' . esc_html( $msg ) . '</p></div>';
            }
        }

        ob_start();
        ?>
        <section class="nme-section">
            <div class="nme-container" style="max-width:820px;">

                <p><a href="<?php echo esc_url( home_url( '/expert-dashboard/' ) ); ?>" style="color:var(--nme-emerald);">← Back to Dashboard</a></p>

                <h2>🛡️ KYC Verification & Payout Details</h2>
                <p style="color:var(--nme-text-light);">Complete your identity verification to start receiving payments. Your information is kept strictly confidential and encrypted.</p>

                <?php echo $status_html; ?>

                <?php echo self::render_status_card( $expert ); ?>

                <?php if ( in_array( $status, array( 'not_started', 'rejected' ), true ) ) : ?>
                    <?php echo self::render_kyc_form( $expert, $upload_nonce ); ?>
                <?php elseif ( $status === 'submitted' ) : ?>
                    <?php echo self::render_submitted_view( $expert ); ?>
                <?php elseif ( $status === 'verified' ) : ?>
                    <?php echo self::render_verified_view( $expert ); ?>
                <?php endif; ?>

            </div>
        </section>
        <?php
        return ob_get_clean();
    }

    /* ============================================================
       STATUS CARD
       ============================================================ */
    private static function render_status_card( $expert ) {
        $status = self::get_status( $expert );
        $rejection_reason = self::get_prop( $expert, 'kyc_rejection_reason' );

        $statuses = array(
            'not_started' => array( 'icon' => '⚠️',  'label' => 'Not Started',  'color' => '#F59E0B', 'bg' => '#FFFBEB',  'text' => 'Complete your KYC below to start receiving payments.' ),
            'submitted'   => array( 'icon' => '⏳',  'label' => 'Under Review', 'color' => '#3B82F6', 'bg' => '#EFF6FF',  'text' => 'Your documents are being reviewed. This usually takes 1-2 business days.' ),
            'verified'    => array( 'icon' => '✅',  'label' => 'Verified',     'color' => '#10B981', 'bg' => '#F0FDF4',  'text' => 'Your identity is verified. You can receive payments!' ),
            'rejected'    => array( 'icon' => '❌',  'label' => 'Rejected',     'color' => '#EF4444', 'bg' => '#FEF2F2',  'text' => $rejection_reason ? 'Reason: ' . $rejection_reason : 'Please re-submit with corrected documents.' ),
        );

        $s = $statuses[ $status ] ?? $statuses['not_started'];

        ob_start();
        ?>
        <div class="nme-card" style="border-left:5px solid <?php echo esc_attr( $s['color'] ); ?>;background:<?php echo esc_attr( $s['bg'] ); ?>;margin-bottom:24px;">
            <div style="display:flex;align-items:center;gap:12px;">
                <span style="font-size:2rem;line-height:1;"><?php echo $s['icon']; ?></span>
                <div>
                    <div style="font-weight:700;font-size:1.1rem;color:<?php echo esc_attr( $s['color'] ); ?>;">
                        KYC Status: <?php echo esc_html( $s['label'] ); ?>
                    </div>
                    <div style="color:#4B5563;font-size:0.9rem;margin-top:2px;">
                        <?php echo esc_html( $s['text'] ); ?>
                    </div>
                </div>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }

    /* ============================================================
       KYC FORM (editable)
       ============================================================ */
    private static function render_kyc_form( $expert, $upload_nonce ) {
        ob_start();
        ?>
        <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="nme-card" id="nme-kyc-form">
            <input type="hidden" name="action" value="nme_submit_kyc">
            <?php wp_nonce_field( 'nme_submit_kyc', 'nme_kyc_nonce' ); ?>

            <h3 style="margin-top:0;">1. Identity Verification</h3>

            <p>
                <label>PAN Number *</label>
                <input type="text" name="pan_number" required maxlength="10"
                       value="<?php echo esc_attr( self::get_prop( $expert, 'pan_number' ) ); ?>"
                       placeholder="ABCDE1234F" style="text-transform:uppercase;">
                <small style="color:var(--nme-text-light);">Indian PAN card number (10 characters). Required for tax compliance.</small>
            </p>

            <!-- PAN CARD PHOTO -->
            <div style="margin:20px 0;">
                <label style="font-weight:600;">PAN Card Photo *</label>
                <small style="color:var(--nme-text-light);display:block;margin-bottom:6px;">Upload a clear photo or scan of your PAN card so we can verify the number against the card. We delete the image after verification — only the number is kept.</small>
                <?php
                $pan_card_url = self::get_prop( $expert, 'pan_card_url' );
                echo self::render_upload_widget( 'pan_card', $pan_card_url, $upload_nonce, 'Upload your PAN card photo' );
                ?>
                <input type="hidden" name="pan_card_url" id="nme-pan-card-url" value="<?php echo esc_attr( $pan_card_url ); ?>">
            </div>

            <p>
                <label>ID Proof Type *</label>
                <select name="id_proof_type" required>
                    <option value="">— Select document type —</option>
                    <?php
                    $current_type = self::get_prop( $expert, 'id_proof_type' );
                    $types = array( 'aadhaar' => 'Aadhaar Card', 'voter_id' => 'Voter ID', 'passport' => 'Passport', 'driving_license' => 'Driving License' );
                    foreach ( $types as $val => $label ) :
                    ?>
                        <option value="<?php echo esc_attr( $val ); ?>" <?php selected( $current_type, $val ); ?>><?php echo esc_html( $label ); ?></option>
                    <?php endforeach; ?>
                </select>
            </p>

            <!-- FRONT SIDE -->
            <div style="margin:20px 0;">
                <label style="font-weight:600;">ID Proof — Front Side *</label>
                <?php
                $front_url = self::get_prop( $expert, 'id_proof_url' );
                echo self::render_upload_widget( 'id_proof_front', $front_url, $upload_nonce, 'Upload front side of your ID document' );
                ?>
                <input type="hidden" name="id_proof_url" id="nme-id-proof-front-url" value="<?php echo esc_attr( $front_url ); ?>">
            </div>

            <!-- BACK SIDE -->
            <div style="margin:20px 0;">
                <label style="font-weight:600;">ID Proof — Back Side *</label>
                <?php
                $back_url = self::get_prop( $expert, 'id_proof_back_url' );
                echo self::render_upload_widget( 'id_proof_back', $back_url, $upload_nonce, 'Upload back side of your ID document' );
                ?>
                <input type="hidden" name="id_proof_back_url" id="nme-id-proof-back-url" value="<?php echo esc_attr( $back_url ); ?>">
            </div>

            <h3 class="nme-mt-4">2. Payout Details</h3>
            <p style="color:var(--nme-text-light);font-size:0.9rem;">Provide either bank account OR UPI ID. Bank is preferred for larger payouts.</p>

            <p>
                <label>Account Holder Name</label>
                <input type="text" name="bank_account_holder"
                       value="<?php echo esc_attr( self::get_prop( $expert, 'bank_account_holder' ) ); ?>"
                       placeholder="As per bank records">
            </p>

            <div class="nme-grid nme-grid-2">
                <p>
                    <label>Bank Account Number</label>
                    <input type="text" name="bank_account_number" id="nme-init-acct"
                           value="<?php echo esc_attr( self::get_prop( $expert, 'bank_account_number' ) ); ?>">
                </p>
                <p>
                    <label>Confirm Account Number *</label>
                    <input type="text" id="nme-init-acct-confirm" placeholder="Re-enter account number">
                    <small id="nme-init-match" style="display:none;"></small>
                </p>
            </div>

            <div class="nme-grid nme-grid-2">
                <p>
                    <label>IFSC Code</label>
                    <input type="text" name="bank_ifsc" id="nme-init-ifsc" style="text-transform:uppercase;"
                           value="<?php echo esc_attr( self::get_prop( $expert, 'bank_ifsc' ) ); ?>"
                           placeholder="ABCD0123456" maxlength="11">
                </p>
                <p>
                    <label>&nbsp;</label>
                    <div id="nme-init-ifsc-result" style="padding:10px 0;font-size:0.9rem;color:#6B7280;">
                        Enter IFSC to verify bank & branch
                    </div>
                </p>
            </div>

            <p>
                <label>UPI ID (alternative)</label>
                <input type="text" name="upi_id"
                       value="<?php echo esc_attr( self::get_prop( $expert, 'upi_id' ) ); ?>"
                       placeholder="yourname@bank">
            </p>

            <p class="nme-text-center nme-mt-4">
                <button type="submit" class="nme-btn nme-btn-gold" style="font-size:1.05rem;padding:14px 40px;">
                    🛡️ Submit for Verification
                </button>
            </p>
        </form>

        <!-- Account confirm + IFSC lookup for initial KYC form -->
        <script>
        (function() {
            var acct    = document.getElementById('nme-init-acct');
            var cnf     = document.getElementById('nme-init-acct-confirm');
            var matchEl = document.getElementById('nme-init-match');
            var ifscIn  = document.getElementById('nme-init-ifsc');
            var ifscOut = document.getElementById('nme-init-ifsc-result');

            if (!acct || !cnf) return;

            // === CONFIRM ACCOUNT NUMBER ===
            function checkMatch() {
                var a = (acct.value || '').trim();
                var c = (cnf.value || '').trim();
                if (!c) { matchEl.style.display = 'none'; return; }
                matchEl.style.display = 'block';
                if (a === c) {
                    matchEl.textContent = '✅ Account numbers match';
                    matchEl.style.color = '#065F46';
                } else {
                    matchEl.textContent = '❌ Account numbers do not match';
                    matchEl.style.color = '#991B1B';
                }
            }
            cnf.addEventListener('input', checkMatch);
            acct.addEventListener('input', checkMatch);

            // Pre-fill if value exists
            if (acct.value) { cnf.value = acct.value; checkMatch(); }

            // Block submit if mismatch
            var form = document.getElementById('nme-kyc-form');
            if (form) {
                form.addEventListener('submit', function(e) {
                    var a = (acct.value || '').trim();
                    var c = (cnf.value || '').trim();
                    if (a && a !== c) {
                        e.preventDefault();
                        alert('Bank account numbers do not match. Please re-check.');
                        cnf.focus();
                    }
                });
            }

            // === IFSC AUTO-LOOKUP ===
            if (!ifscIn) return;
            var timer = null;
            function lookupIFSC() {
                var code = (ifscIn.value || '').trim().toUpperCase();
                if (code.length !== 11) {
                    ifscOut.innerHTML = '<span style="color:#6B7280;">IFSC must be 11 characters</span>';
                    return;
                }
                ifscOut.innerHTML = '<span style="color:#3B82F6;">🔍 Looking up...</span>';
                fetch('https://ifsc.razorpay.com/' + encodeURIComponent(code))
                    .then(function(r) { if (!r.ok) throw new Error('Not found'); return r.json(); })
                    .then(function(data) {
                        ifscOut.innerHTML = '<span style="color:#065F46;">✅ <strong>' + (data.BANK || '') + '</strong><br>' + (data.BRANCH || '') + ', ' + (data.CITY || '') + ', ' + (data.STATE || '') + '</span>';
                    })
                    .catch(function() {
                        ifscOut.innerHTML = '<span style="color:#991B1B;">❌ Invalid IFSC code. Please check and re-enter.</span>';
                    });
            }
            ifscIn.addEventListener('input', function() { clearTimeout(timer); timer = setTimeout(lookupIFSC, 500); });
            ifscIn.addEventListener('blur', lookupIFSC);
            if (ifscIn.value && ifscIn.value.trim().length === 11) setTimeout(lookupIFSC, 300);
        })();
        </script>

        <?php echo self::render_upload_script( $upload_nonce ); ?>
        <?php
        return ob_get_clean();
    }

    /* ============================================================
       UPLOAD WIDGET
       ============================================================ */
    private static function render_upload_widget( $id, $existing_url, $nonce, $placeholder_text ) {
        ob_start();
        ?>
        <div class="nme-kyc-uploader" id="nme-uploader-<?php echo esc_attr( $id ); ?>"
             data-field="<?php echo esc_attr( $id ); ?>"
             style="border:2px dashed #D1D5DB;border-radius:12px;padding:20px;text-align:center;background:#F9FAFB;cursor:pointer;transition:all 0.2s;margin-top:8px;">

            <div class="nme-kyc-preview" style="<?php echo $existing_url ? '' : 'display:none;'; ?>margin-bottom:10px;">
                <?php if ( $existing_url ) : ?>
                    <img src="<?php echo esc_url( $existing_url ); ?>" style="max-width:100%;max-height:200px;border-radius:8px;border:1.5px solid #E5E7EB;" alt="Document preview">
                <?php endif; ?>
            </div>

            <div class="nme-kyc-prompt" style="<?php echo $existing_url ? 'display:none;' : ''; ?>">
                <div style="font-size:2rem;margin-bottom:6px;">📄</div>
                <div style="font-weight:600;color:var(--nme-forest,#0F2419);font-size:0.95rem;"><?php echo esc_html( $placeholder_text ); ?></div>
                <div style="color:#9CA3AF;font-size:0.8rem;margin-top:4px;">JPG, PNG, or PDF · Max 5MB</div>
            </div>

            <div class="nme-kyc-actions" style="<?php echo $existing_url ? '' : 'display:none;'; ?>margin-top:8px;">
                <button type="button" class="nme-btn nme-btn-outline nme-kyc-replace" style="font-size:0.8rem;">🔄 Replace</button>
                <button type="button" class="nme-btn nme-kyc-remove" style="background:#FEE2E2;color:#991B1B;font-size:0.8rem;">🗑️ Remove</button>
            </div>

            <div class="nme-kyc-progress" style="display:none;margin-top:10px;">
                <div style="background:#E5E7EB;border-radius:4px;height:6px;overflow:hidden;">
                    <div class="nme-kyc-bar" style="background:var(--nme-emerald,#10B981);height:100%;width:0%;transition:width 0.3s;"></div>
                </div>
                <small style="color:#6B7280;">Uploading…</small>
            </div>

            <div class="nme-kyc-error" style="display:none;margin-top:10px;color:#991B1B;background:#FEE2E2;padding:8px;border-radius:6px;font-size:0.85rem;"></div>
        </div>
        <input type="file" class="nme-kyc-file-input" data-field="<?php echo esc_attr( $id ); ?>"
               accept="image/jpeg,image/png,application/pdf" style="display:none;">
        <?php
        return ob_get_clean();
    }

    /* ============================================================
       UPLOAD SCRIPT
       ============================================================ */
    private static function render_upload_script( $nonce ) {
        ob_start();
        ?>
        <script>
        (function() {
            var ajaxUrl = '<?php echo esc_url_raw( admin_url( 'admin-ajax.php' ) ); ?>';
            var nonce = '<?php echo esc_js( $nonce ); ?>';

            document.querySelectorAll('.nme-kyc-uploader').forEach(function(uploader) {
                var field = uploader.getAttribute('data-field');
                var fileInput = document.querySelector('.nme-kyc-file-input[data-field="' + field + '"]');
                var preview = uploader.querySelector('.nme-kyc-preview');
                var prompt = uploader.querySelector('.nme-kyc-prompt');
                var actions = uploader.querySelector('.nme-kyc-actions');
                var progress = uploader.querySelector('.nme-kyc-progress');
                var bar = uploader.querySelector('.nme-kyc-bar');
                var errBox = uploader.querySelector('.nme-kyc-error');
                var hiddenInput = document.getElementById('nme-' + field.replace(/_/g, '-') + '-url');

                function showUploaded(url) {
                    preview.innerHTML = '<img src="' + url + '" style="max-width:100%;max-height:200px;border-radius:8px;border:1.5px solid #E5E7EB;">';
                    preview.style.display = '';
                    prompt.style.display = 'none';
                    actions.style.display = '';
                    progress.style.display = 'none';
                    errBox.style.display = 'none';
                    if (hiddenInput) hiddenInput.value = url;
                }

                function clearImage() {
                    preview.innerHTML = '';
                    preview.style.display = 'none';
                    actions.style.display = 'none';
                    prompt.style.display = '';
                    errBox.style.display = 'none';
                    if (hiddenInput) hiddenInput.value = '';
                }

                function showError(msg) {
                    errBox.textContent = msg;
                    errBox.style.display = 'block';
                    progress.style.display = 'none';
                }

                function uploadFile(file) {
                    if (!file) return;
                    if (file.size > 5 * 1024 * 1024) { showError('File must be under 5MB.'); return; }
                    var allowed = ['image/jpeg', 'image/png', 'application/pdf'];
                    if (allowed.indexOf(file.type) === -1) { showError('Only JPG, PNG, or PDF allowed.'); return; }

                    errBox.style.display = 'none';
                    progress.style.display = 'block';
                    bar.style.width = '0%';

                    var fd = new FormData();
                    fd.append('action', 'nme_upload_id_proof');
                    fd.append('nonce', nonce);
                    fd.append('field', field);
                    fd.append('id_proof_file', file);

                    var xhr = new XMLHttpRequest();
                    xhr.upload.addEventListener('progress', function(e) {
                        if (e.lengthComputable) bar.style.width = Math.round((e.loaded / e.total) * 100) + '%';
                    });
                    xhr.addEventListener('load', function() {
                        try {
                            var res = JSON.parse(xhr.responseText);
                            if (res.success && res.data && res.data.url) {
                                showUploaded(res.data.url);
                            } else {
                                showError((res.data && res.data.message) || 'Upload failed.');
                            }
                        } catch(e) { showError('Server error.'); }
                    });
                    xhr.addEventListener('error', function() { showError('Connection error.'); });
                    xhr.open('POST', ajaxUrl);
                    xhr.send(fd);
                }

                uploader.addEventListener('click', function(e) {
                    if (e.target.closest('.nme-kyc-replace') || e.target.closest('.nme-kyc-remove')) return;
                    fileInput.click();
                });
                var replaceBtn = uploader.querySelector('.nme-kyc-replace');
                var removeBtn = uploader.querySelector('.nme-kyc-remove');
                if (replaceBtn) replaceBtn.addEventListener('click', function(e) { e.stopPropagation(); fileInput.click(); });
                if (removeBtn) removeBtn.addEventListener('click', function(e) { e.stopPropagation(); clearImage(); });
                fileInput.addEventListener('change', function() { if (fileInput.files[0]) uploadFile(fileInput.files[0]); });

                ['dragenter','dragover'].forEach(function(ev) {
                    uploader.addEventListener(ev, function(e) { e.preventDefault(); uploader.style.borderColor = 'var(--nme-emerald,#10B981)'; uploader.style.background = '#F0FDF4'; });
                });
                ['dragleave','drop'].forEach(function(ev) {
                    uploader.addEventListener(ev, function(e) { e.preventDefault(); uploader.style.borderColor = '#D1D5DB'; uploader.style.background = '#F9FAFB'; });
                });
                uploader.addEventListener('drop', function(e) { if (e.dataTransfer && e.dataTransfer.files[0]) uploadFile(e.dataTransfer.files[0]); });
            });
        })();
        </script>
        <?php
        return ob_get_clean();
    }

    /* ============================================================
       SUBMITTED VIEW (read-only)
       ============================================================ */
    private static function render_submitted_view( $expert ) {
        ob_start();
        ?>
        <div class="nme-card">
            <h3 style="margin-top:0;">Your Submitted Documents</h3>
            <p style="color:var(--nme-text-light);">We're reviewing your documents. You'll be notified once verified.</p>

            <div class="nme-grid nme-grid-2" style="margin-top:16px;">
                <div>
                    <label style="font-weight:600;color:#374151;">PAN Number</label>
                    <div style="font-size:1.1rem;font-weight:700;letter-spacing:1px;margin-top:4px;"><?php echo esc_html( self::get_prop( $expert, 'pan_number', '—' ) ); ?></div>
                </div>
                <div>
                    <label style="font-weight:600;color:#374151;">ID Type</label>
                    <div style="margin-top:4px;"><?php echo esc_html( ucwords( str_replace( '_', ' ', self::get_prop( $expert, 'id_proof_type', '—' ) ) ) ); ?></div>
                </div>
            </div>

            <div class="nme-grid nme-grid-2" style="margin-top:20px;">
                <?php $front = self::get_prop( $expert, 'id_proof_url' ); if ( $front ) : ?>
                    <div>
                        <label style="font-weight:600;color:#374151;">Front Side</label>
                        <div style="margin-top:8px;border:1.5px solid #E5E7EB;border-radius:10px;overflow:hidden;">
                            <img src="<?php echo esc_url( $front ); ?>" style="width:100%;display:block;" alt="ID Front">
                        </div>
                    </div>
                <?php endif; ?>
                <?php $back = self::get_prop( $expert, 'id_proof_back_url' ); if ( $back ) : ?>
                    <div>
                        <label style="font-weight:600;color:#374151;">Back Side</label>
                        <div style="margin-top:8px;border:1.5px solid #E5E7EB;border-radius:10px;overflow:hidden;">
                            <img src="<?php echo esc_url( $back ); ?>" style="width:100%;display:block;" alt="ID Back">
                        </div>
                    </div>
                <?php endif; ?>
            </div>

            <?php $bank = self::get_prop( $expert, 'bank_account_number' ); $upi = self::get_prop( $expert, 'upi_id' ); ?>
            <?php if ( $bank || $upi ) : ?>
                <h4 style="margin-top:24px;">Payout Details</h4>
                <div class="nme-grid nme-grid-2">
                    <?php if ( $bank ) : ?>
                        <div>
                            <label style="color:#6B7280;">Bank Account</label>
                            <div>●●●●●●<?php echo esc_html( substr( $bank, -4 ) ); ?> (<?php echo esc_html( self::get_prop( $expert, 'bank_ifsc', '—' ) ); ?>)</div>
                        </div>
                    <?php endif; ?>
                    <?php if ( $upi ) : ?>
                        <div>
                            <label style="color:#6B7280;">UPI</label>
                            <div><?php echo esc_html( $upi ); ?></div>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
        <?php
        return ob_get_clean();
    }

    /* ============================================================
       VERIFIED VIEW
       ============================================================ */
    private static function render_verified_view( $expert ) {
        $verified_at = self::get_prop( $expert, 'kyc_verified_at' );
        $verified_date = $verified_at ? date( 'F j, Y', strtotime( $verified_at ) ) : 'recently';
        $front = self::get_prop( $expert, 'id_proof_url' );
        $back  = self::get_prop( $expert, 'id_proof_back_url' );
        $has_docs = ( $front || $back );

        ob_start();
        ?>
        <div class="nme-card" style="text-align:center;">
            <div style="font-size:3rem;margin-bottom:12px;">🎉</div>
            <h3 style="color:#065F46;margin-top:0;">Your KYC is Verified!</h3>
            <p style="color:#4B5563;">
                Verified on <?php echo esc_html( $verified_date ); ?>.
                You can now receive payments from your services.
            </p>
        </div>

        <!-- PAYOUT DETAILS (view + edit) -->
        <div class="nme-card" style="margin-top:20px;">
            <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px;">
                <h3 style="margin:0;color:#374151;">💰 Your Payout Details</h3>
                <?php if ( class_exists( 'NME_Change_Requests' ) ) : ?>
                    <a href="<?php echo esc_url( home_url( '/edit-bank-account/' ) ); ?>" class="nme-btn nme-btn-outline" style="font-size:0.85rem;">
                        ✏️ Update Payout Details
                    </a>
                <?php else : ?>
                    <button type="button" id="nme-payout-edit-btn" onclick="document.getElementById('nme-payout-view').style.display='none';document.getElementById('nme-payout-form').style.display='block';this.style.display='none';" class="nme-btn nme-btn-outline" style="font-size:0.85rem;">
                        ✏️ Update Payout Details
                    </button>
                <?php endif; ?>
            </div>

            <!-- VIEW MODE -->
            <div id="nme-payout-view" style="margin-top:16px;">
                <div class="nme-grid nme-grid-2">
                    <?php $holder = self::get_prop( $expert, 'bank_account_holder' ); if ( $holder ) : ?>
                        <div>
                            <label style="color:#6B7280;font-size:0.85rem;">Account Holder</label>
                            <div style="font-weight:600;"><?php echo esc_html( $holder ); ?></div>
                        </div>
                    <?php endif; ?>
                    <?php $bank = self::get_prop( $expert, 'bank_account_number' ); if ( $bank ) : ?>
                        <div>
                            <label style="color:#6B7280;font-size:0.85rem;">Bank Account</label>
                            <div style="font-weight:600;">●●●●●●<?php echo esc_html( substr( $bank, -4 ) ); ?></div>
                            <div style="font-size:0.85rem;color:#6B7280;"><?php echo esc_html( self::get_prop( $expert, 'bank_ifsc', '—' ) ); ?></div>
                        </div>
                    <?php endif; ?>
                    <?php $upi = self::get_prop( $expert, 'upi_id' ); if ( $upi ) : ?>
                        <div>
                            <label style="color:#6B7280;font-size:0.85rem;">UPI ID</label>
                            <div style="font-weight:600;"><?php echo esc_html( $upi ); ?></div>
                        </div>
                    <?php endif; ?>
                </div>
                <?php if ( ! $bank && ! $upi ) : ?>
                    <p style="color:#9CA3AF;">No payout details added yet. Click "Update Payout Details" to add.</p>
                <?php endif; ?>
                <?php if ( class_exists( 'NME_Change_Requests' ) ) : ?>
                    <p style="margin-top:14px;color:#6B7280;font-size:0.85rem;background:#F9FAFB;padding:10px 12px;border-radius:8px;">
                        🔐 For your security, bank-account changes require OTP verification and admin approval (typically 1–2 business days). Payouts are paused for your account while a request is pending.
                    </p>
                <?php endif; ?>
            </div>

            <!-- EDIT MODE (hidden by default) — fallback for installs without NME_Change_Requests -->
            <?php if ( ! class_exists( 'NME_Change_Requests' ) ) : ?>
            <div id="nme-payout-form" style="display:none;margin-top:16px;">
                <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                    <input type="hidden" name="action" value="nme_update_payout">
                    <?php wp_nonce_field( 'nme_update_payout', 'nme_payout_nonce' ); ?>

                    <p>
                        <label>Account Holder Name</label>
                        <input type="text" name="bank_account_holder"
                               value="<?php echo esc_attr( self::get_prop( $expert, 'bank_account_holder' ) ); ?>"
                               placeholder="As per bank records">
                    </p>

                    <div class="nme-grid nme-grid-2">
                        <p>
                            <label>Bank Account Number</label>
                            <input type="text" name="bank_account_number" id="nme-bank-acct"
                                   value="<?php echo esc_attr( self::get_prop( $expert, 'bank_account_number' ) ); ?>">
                        </p>
                        <p>
                            <label>Confirm Account Number *</label>
                            <input type="text" id="nme-bank-acct-confirm" placeholder="Re-enter account number">
                            <small id="nme-acct-match" style="display:none;"></small>
                        </p>
                    </div>

                    <div class="nme-grid nme-grid-2">
                        <p>
                            <label>IFSC Code</label>
                            <input type="text" name="bank_ifsc" id="nme-ifsc-input" style="text-transform:uppercase;"
                                   value="<?php echo esc_attr( self::get_prop( $expert, 'bank_ifsc' ) ); ?>"
                                   placeholder="ABCD0123456" maxlength="11">
                        </p>
                        <p>
                            <label>&nbsp;</label>
                            <div id="nme-ifsc-result" style="padding:10px 0;font-size:0.9rem;color:#6B7280;">
                                Enter IFSC to verify bank & branch
                            </div>
                        </p>
                    </div>

                    <p>
                        <label>UPI ID (alternative)</label>
                        <input type="text" name="upi_id"
                               value="<?php echo esc_attr( self::get_prop( $expert, 'upi_id' ) ); ?>"
                               placeholder="yourname@bank">
                    </p>

                    <div style="display:flex;gap:12px;margin-top:16px;">
                        <button type="submit" id="nme-payout-submit" class="nme-btn nme-btn-gold">💾 Save Payout Details</button>
                        <button type="button" class="nme-btn nme-btn-outline" onclick="document.getElementById('nme-payout-form').style.display='none';document.getElementById('nme-payout-view').style.display='block';document.getElementById('nme-payout-edit-btn').style.display='';">
                            Cancel
                        </button>
                    </div>
                </form>

                <!-- Account confirm + IFSC lookup script -->
                <script>
                (function() {
                    var acct    = document.getElementById('nme-bank-acct');
                    var confirm = document.getElementById('nme-bank-acct-confirm');
                    var matchEl = document.getElementById('nme-acct-match');
                    var ifscIn  = document.getElementById('nme-ifsc-input');
                    var ifscOut = document.getElementById('nme-ifsc-result');
                    var submitBtn = document.getElementById('nme-payout-submit');

                    // === 1. CONFIRM ACCOUNT NUMBER ===
                    function checkMatch() {
                        var a = (acct.value || '').trim();
                        var c = (confirm.value || '').trim();
                        if (!c) { matchEl.style.display = 'none'; return; }
                        matchEl.style.display = 'block';
                        if (a === c) {
                            matchEl.textContent = '✅ Account numbers match';
                            matchEl.style.color = '#065F46';
                        } else {
                            matchEl.textContent = '❌ Account numbers do not match';
                            matchEl.style.color = '#991B1B';
                        }
                    }
                    if (confirm) confirm.addEventListener('input', checkMatch);
                    if (acct) acct.addEventListener('input', checkMatch);

                    // Pre-fill confirm if account already has a value
                    if (acct && acct.value) {
                        confirm.value = acct.value;
                        checkMatch();
                    }

                    // Block submit if accounts don't match
                    if (submitBtn) {
                        submitBtn.closest('form').addEventListener('submit', function(e) {
                            var a = (acct.value || '').trim();
                            var c = (confirm.value || '').trim();
                            if (a && a !== c) {
                                e.preventDefault();
                                alert('Bank account numbers do not match. Please re-check.');
                                confirm.focus();
                            }
                        });
                    }

                    // === 2. IFSC AUTO-LOOKUP ===
                    var ifscTimer = null;
                    function lookupIFSC() {
                        var code = (ifscIn.value || '').trim().toUpperCase();
                        if (code.length !== 11) {
                            ifscOut.innerHTML = '<span style="color:#6B7280;">IFSC must be 11 characters</span>';
                            return;
                        }
                        ifscOut.innerHTML = '<span style="color:#3B82F6;">🔍 Looking up...</span>';

                        fetch('https://ifsc.razorpay.com/' + encodeURIComponent(code))
                            .then(function(r) {
                                if (!r.ok) throw new Error('Not found');
                                return r.json();
                            })
                            .then(function(data) {
                                ifscOut.innerHTML = '<span style="color:#065F46;">✅ <strong>' + (data.BANK || '') + '</strong><br>' + (data.BRANCH || '') + ', ' + (data.CITY || '') + ', ' + (data.STATE || '') + '</span>';
                            })
                            .catch(function() {
                                ifscOut.innerHTML = '<span style="color:#991B1B;">❌ Invalid IFSC code. Please check and re-enter.</span>';
                            });
                    }

                    if (ifscIn) {
                        ifscIn.addEventListener('input', function() {
                            clearTimeout(ifscTimer);
                            ifscTimer = setTimeout(lookupIFSC, 500);
                        });
                        ifscIn.addEventListener('blur', lookupIFSC);
                        // Auto-lookup on page load if IFSC already filled
                        if (ifscIn.value && ifscIn.value.trim().length === 11) {
                            setTimeout(lookupIFSC, 300);
                        }
                    }
                })();
                </script>
            </div>
            <?php endif; // ! class_exists( 'NME_Change_Requests' ) ?>
        </div>

        <!-- IDENTITY INFO (locked after verification) -->
        <div class="nme-card" style="margin-top:20px;">
            <h3 style="margin:0 0 12px;color:#374151;">🔒 Verified Identity</h3>
            <p style="color:#6B7280;font-size:0.85rem;margin-bottom:16px;">PAN number and ID type are locked after verification. Contact support if you need to change them.</p>

            <div class="nme-grid nme-grid-2">
                <div>
                    <label style="color:#6B7280;font-size:0.85rem;">PAN Number</label>
                    <div style="font-weight:700;font-size:1.1rem;letter-spacing:1px;"><?php echo esc_html( self::get_prop( $expert, 'pan_number', '—' ) ); ?></div>
                </div>
                <div>
                    <label style="color:#6B7280;font-size:0.85rem;">ID Type</label>
                    <div style="font-weight:600;"><?php echo esc_html( ucwords( str_replace( '_', ' ', self::get_prop( $expert, 'id_proof_type', '—' ) ) ) ); ?></div>
                </div>
            </div>

            <?php if ( $has_docs ) : ?>
                <!-- Document deletion request -->
                <div style="margin-top:20px;padding-top:16px;border-top:1px solid #E5E7EB;">
                    <details>
                        <summary style="cursor:pointer;color:#6B7280;font-size:0.9rem;">
                            🗑️ Request document deletion (privacy)
                        </summary>
                        <div style="margin-top:12px;background:#FEF2F2;padding:16px;border-radius:10px;">
                            <p style="color:#991B1B;font-size:0.9rem;margin:0 0 12px;">
                                <strong>What happens:</strong> Your uploaded ID document images will be permanently deleted from our servers.
                                Your KYC verified status will remain — only the actual document files are removed.
                            </p>
                            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                                <input type="hidden" name="action" value="nme_request_doc_deletion">
                                <?php wp_nonce_field( 'nme_request_doc_deletion', 'nme_doc_del_nonce' ); ?>
                                <label style="display:flex;align-items:start;gap:8px;margin-bottom:12px;font-size:0.85rem;color:#374151;">
                                    <input type="checkbox" required style="width:auto;margin-top:3px;">
                                    I understand my documents will be permanently deleted and cannot be recovered.
                                </label>
                                <button type="submit" class="nme-btn" style="background:#EF4444;color:#fff;font-size:0.85rem;" onclick="return confirm('Are you sure? This cannot be undone.');">
                                    🗑️ Delete My Documents
                                </button>
                            </form>
                        </div>
                    </details>
                </div>
            <?php else : ?>
                <p style="margin-top:16px;color:#065F46;background:#F0FDF4;padding:10px 14px;border-radius:8px;font-size:0.85rem;">
                    ✅ Documents have been removed. Your verification status is preserved.
                </p>
            <?php endif; ?>
        </div>
        <?php
        return ob_get_clean();
    }

    /* ============================================================
       FORM HANDLER
       ============================================================ */
    public static function handle_kyc_submission() {
        if ( ! is_user_logged_in() ) wp_die( 'Login required.' );

        if ( ! isset( $_POST['nme_kyc_nonce'] ) || ! wp_verify_nonce( $_POST['nme_kyc_nonce'], 'nme_submit_kyc' ) ) {
            wp_die( 'Security check failed.' );
        }

        $expert = self::get_current_expert();
        if ( ! $expert ) wp_die( 'Expert account not found.' );

        // Sanitize
        $pan     = strtoupper( sanitize_text_field( $_POST['pan_number'] ?? '' ) );
        $id_type = sanitize_text_field( $_POST['id_proof_type'] ?? '' );
        $front   = esc_url_raw( $_POST['id_proof_url'] ?? '' );
        $back    = esc_url_raw( $_POST['id_proof_back_url'] ?? '' );
        $holder  = sanitize_text_field( $_POST['bank_account_holder'] ?? '' );
        $acct    = sanitize_text_field( $_POST['bank_account_number'] ?? '' );
        $ifsc    = strtoupper( sanitize_text_field( $_POST['bank_ifsc'] ?? '' ) );
        $upi     = sanitize_text_field( $_POST['upi_id'] ?? '' );

        // Validate
        $errors = array();
        if ( empty( $pan ) || ! preg_match( '/^[A-Z]{5}[0-9]{4}[A-Z]{1}$/', $pan ) ) {
            $errors[] = 'Valid PAN number required (ABCDE1234F).';
        }
        if ( empty( $id_type ) ) {
            $errors[] = 'Please select an ID proof type.';
        }
        if ( empty( $front ) ) {
            $errors[] = 'Please upload the front side of your ID document.';
        }
        if ( empty( $back ) ) {
            $errors[] = 'Please upload the back side of your ID document.';
        }
        // v0.6.0 — require PAN card photo only if the column exists (older
        // installs that never ran the 0.6 migration shouldn't fail to submit).
        if ( class_exists( 'NME_Database' ) ) {
            global $wpdb;
            $table = NME_Database::table( 'experts' );
            $has_pan_card_col = $wpdb->get_var( "SHOW COLUMNS FROM $table LIKE 'pan_card_url'" );
            if ( $has_pan_card_col && empty( $_POST['pan_card_url'] ) ) {
                $errors[] = 'Please upload a photo of your PAN card.';
            }
        }
        if ( empty( $acct ) && empty( $upi ) ) {
            $errors[] = 'Either bank account or UPI ID is required for payouts.';
        }
        if ( ! empty( $acct ) && empty( $ifsc ) ) {
            $errors[] = 'IFSC code is required with bank account number.';
        }

        if ( ! empty( $errors ) ) {
            $url = add_query_arg( array(
                'nme_kyc_status' => 'error',
                'nme_kyc_msg'    => urlencode( implode( ' ', $errors ) ),
            ), wp_get_referer() );
            wp_safe_redirect( $url );
            exit;
        }

        // Build update data — only include columns that exist
        $update_data = array(
            'pan_number'          => $pan,
            'id_proof_type'       => $id_type,
            'id_proof_url'        => $front,
            'bank_account_holder' => $holder,
            'bank_account_number' => $acct,
            'bank_ifsc'           => $ifsc,
            'upi_id'              => $upi,
        );

        // Only set new columns if they exist in the table
        if ( class_exists( 'NME_Database' ) ) {
            global $wpdb;
            $table = NME_Database::table( 'experts' );

            $has_back = $wpdb->get_var( "SHOW COLUMNS FROM $table LIKE 'id_proof_back_url'" );
            if ( $has_back ) {
                $update_data['id_proof_back_url'] = $back;
            }

            // v0.6.0 — PAN card photo column (may not exist on pre-0.6 installs).
            $has_pan_card = $wpdb->get_var( "SHOW COLUMNS FROM $table LIKE 'pan_card_url'" );
            if ( $has_pan_card ) {
                $update_data['pan_card_url'] = esc_url_raw( $_POST['pan_card_url'] ?? '' );
            }

            $has_kyc = $wpdb->get_var( "SHOW COLUMNS FROM $table LIKE 'kyc_status'" );
            if ( $has_kyc ) {
                $update_data['kyc_status'] = 'submitted';
                $update_data['kyc_submitted_at'] = current_time( 'mysql' );
            }

            $result = $wpdb->update( $table, $update_data, array( 'id' => $expert->id ) );
        } else {
            $result = false;
        }

        if ( $result === false ) {
            $url = add_query_arg( array(
                'nme_kyc_status' => 'error',
                'nme_kyc_msg'    => urlencode( 'Could not save. Please try again.' ),
            ), wp_get_referer() );
        } else {
            if ( class_exists( 'NME_Database' ) ) {
                NME_Database::audit_log( 'kyc_submitted', 'expert', $expert->id );
            }

            if ( class_exists( 'NME_Emails' ) && method_exists( 'NME_Emails', 'send_admin_notification' ) ) {
                $data = (array) $expert;
                $data['subject_override'] = 'KYC Submitted: ' . ( $expert->full_name ?? 'Expert' );
                NME_Emails::send_admin_notification( $data, $expert->id );
            }

            $url = add_query_arg( array(
                'nme_kyc_status' => 'success',
                'nme_kyc_msg'    => urlencode( 'KYC submitted successfully! We\'ll review within 1-2 business days.' ),
            ), wp_get_referer() );
        }

        wp_safe_redirect( $url );
        exit;
    }

    /* ============================================================
       AJAX HANDLER — ID proof upload
       ============================================================ */
    public static function handle_id_proof_upload() {
        if ( ! check_ajax_referer( 'nme_upload_id_proof', 'nonce', false ) ) {
            wp_send_json_error( array( 'message' => 'Security check failed.' ) );
        }
        if ( ! is_user_logged_in() ) {
            wp_send_json_error( array( 'message' => 'You must be logged in.' ) );
        }

        $expert = self::get_current_expert();
        if ( ! $expert ) {
            wp_send_json_error( array( 'message' => 'Expert account not found.' ) );
        }

        if ( empty( $_FILES['id_proof_file'] ) || ! is_uploaded_file( $_FILES['id_proof_file']['tmp_name'] ) ) {
            wp_send_json_error( array( 'message' => 'No file uploaded.' ) );
        }

        $file = $_FILES['id_proof_file'];

        if ( $file['error'] !== UPLOAD_ERR_OK ) {
            wp_send_json_error( array( 'message' => 'Upload error. Please try again.' ) );
        }

        if ( $file['size'] > 5 * 1024 * 1024 ) {
            wp_send_json_error( array( 'message' => 'File must be under 5MB.' ) );
        }

        $allowed = array( 'image/jpeg', 'image/png', 'application/pdf' );
        $finfo = finfo_open( FILEINFO_MIME_TYPE );
        $mime = finfo_file( $finfo, $file['tmp_name'] );
        finfo_close( $finfo );

        if ( ! in_array( $mime, $allowed, true ) ) {
            wp_send_json_error( array( 'message' => 'Only JPG, PNG, or PDF files allowed.' ) );
        }

        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';
        require_once ABSPATH . 'wp-admin/includes/media.php';

        $movefile = wp_handle_upload( $file, array(
            'test_form' => false,
            'mimes'     => array( 'jpg|jpeg' => 'image/jpeg', 'png' => 'image/png', 'pdf' => 'application/pdf' ),
        ) );

        if ( ! $movefile || isset( $movefile['error'] ) ) {
            wp_send_json_error( array( 'message' => $movefile['error'] ?? 'Could not save file.' ) );
        }

        $expert_name = is_object( $expert ) ? ( $expert->full_name ?? 'Expert' ) : 'Expert';
        $field_name = sanitize_key( $_POST['field'] ?? 'doc' );

        $attachment = array(
            'post_mime_type' => $movefile['type'],
            'post_title'     => 'KYC Document — ' . $expert_name . ' — ' . $field_name,
            'post_content'   => '',
            'post_status'    => 'private',
            'post_author'    => get_current_user_id(),
        );
        $att_id = wp_insert_attachment( $attachment, $movefile['file'] );
        if ( ! is_wp_error( $att_id ) ) {
            $att_data = wp_generate_attachment_metadata( $att_id, $movefile['file'] );
            wp_update_attachment_metadata( $att_id, $att_data );
        }

        wp_send_json_success( array(
            'url'     => $movefile['url'],
            'message' => 'Document uploaded successfully!',
        ) );
    }

    /* ============================================================
       HANDLER — Update payout details (after KYC verified)
       Expert can change bank/UPI anytime without re-verification.
       ============================================================ */
    public static function handle_update_payout() {
        if ( ! is_user_logged_in() ) wp_die( 'Login required.' );

        if ( ! isset( $_POST['nme_payout_nonce'] ) || ! wp_verify_nonce( $_POST['nme_payout_nonce'], 'nme_update_payout' ) ) {
            wp_die( 'Security check failed.' );
        }

        $expert = self::get_current_expert();
        if ( ! $expert ) wp_die( 'Expert account not found.' );

        // Only allow payout updates when KYC is verified
        $status = self::get_status( $expert );
        if ( $status !== 'verified' ) {
            $url = add_query_arg( array(
                'nme_kyc_status' => 'error',
                'nme_kyc_msg'    => urlencode( 'Payout details can only be updated after KYC verification.' ),
            ), wp_get_referer() );
            wp_safe_redirect( $url );
            exit;
        }

        // Sanitize
        $holder = sanitize_text_field( $_POST['bank_account_holder'] ?? '' );
        $acct   = sanitize_text_field( $_POST['bank_account_number'] ?? '' );
        $ifsc   = strtoupper( sanitize_text_field( $_POST['bank_ifsc'] ?? '' ) );
        $upi    = sanitize_text_field( $_POST['upi_id'] ?? '' );

        // Validate: need at least one payout method
        if ( empty( $acct ) && empty( $upi ) ) {
            $url = add_query_arg( array(
                'nme_kyc_status' => 'error',
                'nme_kyc_msg'    => urlencode( 'Please provide either a bank account or UPI ID.' ),
            ), wp_get_referer() );
            wp_safe_redirect( $url );
            exit;
        }

        if ( ! empty( $acct ) && empty( $ifsc ) ) {
            $url = add_query_arg( array(
                'nme_kyc_status' => 'error',
                'nme_kyc_msg'    => urlencode( 'IFSC code is required with bank account number.' ),
            ), wp_get_referer() );
            wp_safe_redirect( $url );
            exit;
        }

        // Update only payout fields (not PAN, not documents, not KYC status)
        global $wpdb;
        $result = $wpdb->update(
            NME_Database::table( 'experts' ),
            array(
                'bank_account_holder' => $holder,
                'bank_account_number' => $acct,
                'bank_ifsc'           => $ifsc,
                'upi_id'              => $upi,
            ),
            array( 'id' => $expert->id )
        );

        if ( $result === false ) {
            $url = add_query_arg( array(
                'nme_kyc_status' => 'error',
                'nme_kyc_msg'    => urlencode( 'Could not save. Please try again.' ),
            ), wp_get_referer() );
        } else {
            if ( class_exists( 'NME_Database' ) ) {
                NME_Database::audit_log( 'payout_details_updated', 'expert', $expert->id );
            }
            $url = add_query_arg( array(
                'nme_kyc_status' => 'success',
                'nme_kyc_msg'    => urlencode( 'Payout details updated successfully!' ),
            ), wp_get_referer() );
        }

        wp_safe_redirect( $url );
        exit;
    }

    /* ============================================================
       HANDLER — Request document deletion (privacy)
       Expert can delete their uploaded ID documents after verification.
       KYC status + PAN + verification record is preserved.
       ============================================================ */
    public static function handle_request_doc_deletion() {
        if ( ! is_user_logged_in() ) wp_die( 'Login required.' );

        if ( ! isset( $_POST['nme_doc_del_nonce'] ) || ! wp_verify_nonce( $_POST['nme_doc_del_nonce'], 'nme_request_doc_deletion' ) ) {
            wp_die( 'Security check failed.' );
        }

        $expert = self::get_current_expert();
        if ( ! $expert ) wp_die( 'Expert account not found.' );

        // Only allow deletion when KYC is verified
        $status = self::get_status( $expert );
        if ( $status !== 'verified' ) {
            $url = add_query_arg( array(
                'nme_kyc_status' => 'error',
                'nme_kyc_msg'    => urlencode( 'Documents can only be deleted after KYC verification.' ),
            ), wp_get_referer() );
            wp_safe_redirect( $url );
            exit;
        }

        // Clear document URLs from database
        global $wpdb;
        $table = NME_Database::table( 'experts' );

        $update = array( 'id_proof_url' => '' );

        $has_back = $wpdb->get_var( "SHOW COLUMNS FROM $table LIKE 'id_proof_back_url'" );
        if ( $has_back ) {
            $update['id_proof_back_url'] = '';
        }

        $result = $wpdb->update( $table, $update, array( 'id' => $expert->id ) );

        if ( $result === false ) {
            $url = add_query_arg( array(
                'nme_kyc_status' => 'error',
                'nme_kyc_msg'    => urlencode( 'Could not delete documents. Please try again.' ),
            ), wp_get_referer() );
        } else {
            if ( class_exists( 'NME_Database' ) ) {
                NME_Database::audit_log( 'kyc_docs_deleted_by_expert', 'expert', $expert->id );
            }
            $url = add_query_arg( array(
                'nme_kyc_status' => 'success',
                'nme_kyc_msg'    => urlencode( 'Your documents have been permanently deleted. Your verification status is preserved.' ),
            ), wp_get_referer() );
        }

        wp_safe_redirect( $url );
        exit;
    }

    /* ============================================================
       DASHBOARD PROMPT — safe for calling from any context
       ============================================================ */
    public static function get_dashboard_prompt( $expert ) {
        if ( ! $expert || ! is_object( $expert ) ) return '';

        $status = self::get_status( $expert );
        if ( $status === 'verified' ) return '';

        $kyc_url = home_url( '/expert-dashboard/?action=kyc' );

        $rejection_reason = self::get_prop( $expert, 'kyc_rejection_reason' );

        $messages = array(
            'not_started' => array(
                'bg'     => '#FFFBEB',
                'border' => '#F59E0B',
                'icon'   => '⚠️',
                'text'   => '<strong>Complete your KYC</strong> to start receiving payments from your services.',
                'btn'    => 'Complete KYC →',
            ),
            'submitted' => array(
                'bg'     => '#EFF6FF',
                'border' => '#3B82F6',
                'icon'   => '⏳',
                'text'   => '<strong>KYC Under Review</strong> — We\'re reviewing your documents. This usually takes 1-2 business days.',
                'btn'    => 'View Status',
            ),
            'rejected' => array(
                'bg'     => '#FEF2F2',
                'border' => '#EF4444',
                'icon'   => '❌',
                'text'   => '<strong>KYC Rejected</strong> — Please re-submit with corrected documents.' . ( $rejection_reason ? ' Reason: ' . esc_html( $rejection_reason ) : '' ),
                'btn'    => 'Re-submit KYC →',
            ),
        );

        $m = $messages[ $status ] ?? $messages['not_started'];

        return sprintf(
            '<div class="nme-card" style="border-left:5px solid %s;background:%s;margin-bottom:20px;">
                <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px;">
                    <div style="display:flex;align-items:center;gap:10px;">
                        <span style="font-size:1.5rem;">%s</span>
                        <span>%s</span>
                    </div>
                    <a href="%s" class="nme-btn nme-btn-outline" style="white-space:nowrap;">%s</a>
                </div>
            </div>',
            esc_attr( $m['border'] ),
            esc_attr( $m['bg'] ),
            $m['icon'],
            $m['text'],
            esc_url( $kyc_url ),
            esc_html( $m['btn'] )
        );
    }
}