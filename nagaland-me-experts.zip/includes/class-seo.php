<?php
/**
 * NME_SEO
 *
 * Emits JSON-LD structured data on expert profile pages so Google
 * shows rich cards (Person with aggregateRating + offerCatalog),
 * and exposes /experts-sitemap.xml so search engines discover new
 * experts without waiting for the core WP sitemap to pick them up.
 *
 * OG / Twitter / <meta description> / canonical are already emitted
 * by NME_Frontend::emit_head_meta (Phase C2) — this class is purely
 * additive.
 *
 * @package NagalandMeExperts
 * @since   0.3.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class NME_SEO {

    public static function init() {
        add_action( 'wp_head',          array( __CLASS__, 'emit_jsonld' ), 15 );
        add_action( 'wp_head',          array( __CLASS__, 'emit_noindex_on_filtered_directory' ), 3 );
        add_action( 'init',             array( __CLASS__, 'register_sitemap_rewrite' ) );
        add_filter( 'query_vars',       array( __CLASS__, 'add_query_var' ) );
        add_action( 'template_redirect', array( __CLASS__, 'serve_sitemap' ) );
        add_filter( 'robots_txt',        array( __CLASS__, 'append_sitemap_to_robots' ), 10, 2 );
    }

    /**
     * Emit noindex,follow on filtered / paginated directory URLs so
     * Google indexes only the canonical /experts/ page and doesn't
     * waste crawl budget on every combination of filters.
     */
    public static function emit_noindex_on_filtered_directory() {
        if ( is_admin() ) return;
        $filter_keys = array( 'q', 'category', 'district', 'tier', 'language', 'online', 'paged' );
        foreach ( $filter_keys as $k ) {
            if ( isset( $_GET[ $k ] ) && $_GET[ $k ] !== '' ) {
                echo "<meta name=\"robots\" content=\"noindex,follow\">\n";
                return;
            }
        }
    }

    /* ============================================================
       JSON-LD on /expert/{slug}/
       ============================================================ */

    public static function emit_jsonld() {
        $expert = class_exists( 'NME_Frontend' ) ? NME_Frontend::current_expert() : null;
        if ( ! $expert ) return;

        $url  = NME_Frontend::get_profile_url( $expert );
        $desc = $expert->tagline ?: ( $expert->bio ? wp_trim_words( wp_strip_all_tags( $expert->bio ), 40, '…' ) : '' );

        $person = array(
            '@context'    => 'https://schema.org',
            '@type'       => 'Person',
            '@id'         => $url . '#person',
            'name'        => $expert->full_name,
            'url'         => $url,
            'description' => $desc,
        );

        if ( ! empty( $expert->profile_photo ) ) {
            $person['image'] = $expert->profile_photo;
        }
        if ( ! empty( $expert->district ) ) {
            $person['address'] = array(
                '@type'           => 'PostalAddress',
                'addressLocality' => (string) $expert->district,
                'addressRegion'   => (string) ( $expert->state ?: 'Nagaland' ),
                'addressCountry'  => 'IN',
            );
        }

        $same_as = array_values( array_filter( array(
            $expert->youtube_channel ?? '',
            $expert->facebook_page   ?? '',
            $expert->portfolio_url   ?? '',
        ) ) );
        if ( ! empty( $same_as ) ) $person['sameAs'] = $same_as;

        // Spoken languages (detailed when available, legacy string as fallback).
        $langs = array();
        if ( class_exists( 'NME_Payments_Bridge' ) ) {
            foreach ( NME_Payments_Bridge::get_languages( (int) $expert->id ) as $l ) {
                $langs[] = (string) $l->language;
            }
        }
        if ( empty( $langs ) && ! empty( $expert->languages ) ) {
            $langs = array_map( 'trim', explode( ',', (string) $expert->languages ) );
        }
        $langs = array_values( array_filter( $langs ) );
        if ( ! empty( $langs ) ) $person['knowsLanguage'] = $langs;

        // Aggregate rating — only emit when we have real signal.
        $rating  = (float) ( $expert->avg_rating   ?? 0 );
        $reviews = (int)   ( $expert->total_orders ?? 0 );
        if ( $rating > 0 && $reviews > 0 ) {
            $person['aggregateRating'] = array(
                '@type'       => 'AggregateRating',
                'ratingValue' => round( $rating, 1 ),
                'reviewCount' => $reviews,
                'bestRating'  => 5,
                'worstRating' => 1,
            );
        }

        // offerCatalog from live services (payments-owned).
        if ( class_exists( 'NME_Payments_Bridge' ) ) {
            $services = NME_Payments_Bridge::get_active_services( (int) $expert->id );
            if ( ! empty( $services ) ) {
                $items = array();
                foreach ( $services as $s ) {
                    $price = NME_Payments_Bridge::service_starting_price( $s );
                    $item  = array(
                        '@type' => 'Offer',
                        'name'  => (string) $s->title,
                        'url'   => NME_Payments_Bridge::service_url( $s ),
                    );
                    if ( $price ) {
                        $item['price']         = (string) $price;
                        $item['priceCurrency'] = 'INR';
                    }
                    if ( ! empty( $s->short_description ) ) {
                        $item['description'] = (string) $s->short_description;
                    }
                    $items[] = $item;
                }
                $person['makesOffer'] = $items;
            }
        }

        // Also emit a Breadcrumb list so the profile shows up with
        // Home › Experts › Name in SERPs.
        $breadcrumb = array(
            '@context'        => 'https://schema.org',
            '@type'           => 'BreadcrumbList',
            'itemListElement' => array(
                array( '@type' => 'ListItem', 'position' => 1, 'name' => 'Home',    'item' => home_url( '/' ) ),
                array( '@type' => 'ListItem', 'position' => 2, 'name' => 'Experts', 'item' => home_url( '/experts/' ) ),
                array( '@type' => 'ListItem', 'position' => 3, 'name' => (string) $expert->full_name, 'item' => $url ),
            ),
        );

        echo "\n<!-- Nagaland Me Experts: JSON-LD -->\n";
        echo '<script type="application/ld+json">' . wp_json_encode( $person,     JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . "</script>\n";
        echo '<script type="application/ld+json">' . wp_json_encode( $breadcrumb, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . "</script>\n";
    }

    /* ============================================================
       /experts-sitemap.xml
       ============================================================ */

    public static function register_sitemap_rewrite() {
        add_rewrite_rule( '^experts-sitemap\.xml$', 'index.php?nme_experts_sitemap=1', 'top' );
    }

    public static function add_query_var( $vars ) {
        $vars[] = 'nme_experts_sitemap';
        return $vars;
    }

    public static function serve_sitemap() {
        if ( ! get_query_var( 'nme_experts_sitemap' ) ) return;

        global $wpdb;
        $rows = $wpdb->get_results(
            "SELECT full_name, updated_at FROM " . NME_Database::table( 'experts' ) . "
             WHERE status = 'approved'
             ORDER BY updated_at DESC
             LIMIT 50000"
        );

        nocache_headers();
        header( 'Content-Type: application/xml; charset=utf-8' );
        echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
        echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
        foreach ( (array) $rows as $r ) {
            $slug = sanitize_title( (string) $r->full_name );
            if ( ! $slug ) continue;
            $url  = home_url( '/expert/' . $slug . '/' );
            $mod  = ! empty( $r->updated_at ) ? mysql2date( 'Y-m-d\TH:i:sP', $r->updated_at, false ) : gmdate( 'c' );
            echo '  <url>' . "\n";
            echo '    <loc>' . esc_url( $url ) . '</loc>' . "\n";
            echo '    <lastmod>' . esc_html( $mod ) . '</lastmod>' . "\n";
            echo '    <changefreq>weekly</changefreq>' . "\n";
            echo '  </url>' . "\n";
        }
        echo '</urlset>' . "\n";
        exit;
    }

    public static function append_sitemap_to_robots( $output, $public ) {
        if ( ! $public ) return $output;
        $output .= "\nSitemap: " . home_url( '/experts-sitemap.xml' ) . "\n";
        return $output;
    }
}
