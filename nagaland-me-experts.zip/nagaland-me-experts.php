<?php
/**
 * Plugin Name:       Nagaland Me Experts
 * Plugin URI:        https://experts.nagaland.me
 * Description:       The marketplace plugin for Nagaland Me Experts. v0.4 — profile-photo self-service (30-day cooldown) + bank-account change requests with OTP + admin review queue.
 * Version:           0.4.0
 * Author:            Nagaland Me
 * Author URI:        https://nagaland.me
 * License:           GPL v2 or later
 * Text Domain:       nagaland-me-experts
 *
 * @package NagalandMeExperts
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // No direct access
}

/* ============================================================
   CONSTANTS
   ============================================================ */
define( 'NME_VERSION', '0.8.0' );
define( 'NME_PLUGIN_FILE', __FILE__ );
define( 'NME_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'NME_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'NME_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );

/* ============================================================
   AUTOLOAD INCLUDES
   ============================================================ */
require_once NME_PLUGIN_DIR . 'includes/class-database.php';
require_once NME_PLUGIN_DIR . 'includes/class-roles.php';
require_once NME_PLUGIN_DIR . 'includes/class-categories.php';
require_once NME_PLUGIN_DIR . 'includes/class-experts.php';
require_once NME_PLUGIN_DIR . 'includes/class-registration.php';
require_once NME_PLUGIN_DIR . 'includes/class-frontend.php';
require_once NME_PLUGIN_DIR . 'includes/class-shortcodes.php';
require_once NME_PLUGIN_DIR . 'includes/class-emails.php';
require_once NME_PLUGIN_DIR . 'includes/class-kyc.php';
require_once NME_PLUGIN_DIR . 'includes/class-auth-ux.php';
require_once NME_PLUGIN_DIR . 'admin/class-admin.php';
require_once NME_PLUGIN_DIR . 'includes/class-testimonials.php';
require_once NME_PLUGIN_DIR . 'includes/class-nme-payments-bridge.php';
require_once NME_PLUGIN_DIR . 'includes/class-dashboard.php';
require_once NME_PLUGIN_DIR . 'includes/class-service-editor.php';
require_once NME_PLUGIN_DIR . 'includes/class-seo.php';
require_once NME_PLUGIN_DIR . 'includes/class-change-requests.php'; // v0.4.0
require_once NME_PLUGIN_DIR . 'includes/class-service-review-notify.php'; // v0.8.1 — admin email + banner when a service enters pending_review
require_once NME_PLUGIN_DIR . 'includes/class-badges-extensions.php'; // v0.8.2 — Premium Buyer badge + disable broken auto-awards + retire verified_buyer
require_once NME_PLUGIN_DIR . 'includes/class-presence.php'; // v0.8.3 — online / last-seen presence + "typically replies in Xh"
require_once NME_PLUGIN_DIR . 'includes/class-seo-private-pages.php'; // v0.8.4 — noindex + sitemap exclusion for dashboard/account pages
NME_Testimonials::init();
NME_Payments_Bridge::init();
NME_Dashboard::init();
NME_Service_Editor::init();
NME_SEO::init();
NME_Change_Requests::init(); // v0.4.0
NME_Service_Review_Notify::init(); // v0.8.1
NME_Badges_Extensions::init(); // v0.8.2
NME_Presence::init(); // v0.8.3
NME_SEO_Private_Pages::init(); // v0.8.4

/* ============================================================
   ACTIVATION & DEACTIVATION
   ============================================================ */
register_activation_hook( __FILE__, 'nme_activate_plugin' );
function nme_activate_plugin() {
    NME_Database::create_tables();
    NME_Roles::add_roles();
    NME_Categories::seed_categories();

    // Create required pages if they don't exist
    nme_create_required_pages();

    // Flush rewrite rules for custom endpoints
    flush_rewrite_rules();

    // Set version
    update_option( 'nme_version', NME_VERSION );
}

register_deactivation_hook( __FILE__, 'nme_deactivate_plugin' );
function nme_deactivate_plugin() {
    flush_rewrite_rules();
}

/**
 * Does a page with this slug already exist in any non-autodraft status?
 *
 * Uses a direct DB query rather than get_page_by_path() because
 * get_page_by_path() is backed by a permalink cache that can return
 * stale nulls right after a page insert, AND because we want to
 * count trashed/draft/pending pages too — otherwise a trashed
 * edit-profile page would get duplicated on every deploy.
 */
function nme_page_slug_exists( $slug ) {
    $slug = sanitize_title( (string) $slug );
    if ( $slug === '' ) {
        // Refuse to create anything if we can't sanitise the slug.
        return true;
    }
    global $wpdb;
    $id = (int) $wpdb->get_var( $wpdb->prepare(
        "SELECT ID FROM {$wpdb->posts}
          WHERE post_type   = 'page'
            AND post_name   = %s
            AND post_status <> 'auto-draft'
          LIMIT 1",
        $slug
    ) );
    return $id > 0;
}

/**
 * Create the required WordPress pages if they don't exist.
 *
 * CONCURRENCY: guarded by a transient lock so that two simultaneous
 * requests (e.g., plugin activation + a frontend init hook firing in
 * parallel) can't both see "slug doesn't exist → insert" at the same
 * time. Without this, wp_insert_post's wp_unique_post_slug() quietly
 * auto-suffixes the slug (edit-profile → edit-profile-2 → -3 → …),
 * polluting the sitemap with duplicate dashboard pages.
 */
function nme_create_required_pages() {
    // Lock for up to 60s. Expires on its own if the function fatal's.
    if ( get_transient( 'nme_creating_required_pages' ) ) {
        return;
    }
    set_transient( 'nme_creating_required_pages', 1, MINUTE_IN_SECONDS );

    $pages = array(
        'expert-register'  => array(
            'title'   => 'Become an Expert — Apply',
            'content' => '[nme_expert_registration_form]',
        ),
        'experts'          => array(
            'title'   => 'Browse Experts',
            'content' => '[nme_experts_directory]',
        ),
        'expert-dashboard' => array(
            'title'   => 'Expert Dashboard',
            'content' => '[nme_expert_dashboard]',
        ),
        'kyc'              => array(
            'title'   => 'KYC Verification',
            'content' => '[nme_kyc_form]',
        ),
        'create-service'   => array(
            'title'   => 'Create Service',
            'content' => '[nme_service_editor]',
        ),
        // v0.4.0 — change request shortcodes
        'change-profile-photo' => array(
            'title'   => 'Change Profile Picture',
            'content' => '[nme_change_profile_photo]',
        ),
        'edit-bank-account'    => array(
            'title'   => 'Edit Bank Account',
            'content' => '[nme_edit_bank_account]',
        ),
        'edit-address'         => array(
            'title'   => 'Update Registered Address',
            'content' => '[nme_edit_address]',
        ),
        // v0.7.0 — resubmit-after-rejection
        'edit-application'     => array(
            'title'   => 'Edit Your Application',
            'content' => '[nme_expert_edit_application]',
        ),
        // v0.8.0 — self-service profile editor for approved experts
        'edit-profile'         => array(
            'title'   => 'Edit Your Public Profile',
            'content' => '[nme_edit_profile]',
        ),
        // v0.7.2 — Premium Buyer program (public sales landing).
        // The shortcode lives in the nme-payments plugin (NMEP_Buyer_Premium); the page
        // is auto-created here so the header menu's dynamic Premium link always resolves.
        'buyer-premium'        => array(
            'title'   => 'Nagaland Me Premium',
            'content' => '[nmep_buyer_premium]',
        ),
    );

    foreach ( $pages as $slug => $data ) {
        if ( nme_page_slug_exists( $slug ) ) {
            continue;
        }
        wp_insert_post( array(
            'post_title'   => $data['title'],
            'post_name'    => $slug,
            'post_content' => $data['content'],
            'post_status'  => 'publish',
            'post_type'    => 'page',
            'post_author'  => 1,
        ) );
    }

    // v0.7.2 — /my-account/premium/ is a nested page (parent: my-account), so it needs
    // its own insert: wp_insert_post sanitises the '/' out of post_name, meaning we
    // can't pass a path-style slug through the simple loop above. We create (or reuse)
    // a /my-account/ parent first, then a 'premium' child under it.
    $parent = get_page_by_path( 'my-account' );
    if ( ! $parent ) {
        // The loop above owns the 'my-account' slug; if the parent isn't found
        // here it wasn't created this run either (existing-but-not-cached, or a
        // concurrent insert lost the race). Bail on the child so we never create
        // a parentless 'premium' page that WP would auto-uniqueify to
        // 'my-account-premium' at the root.
        $parent_id = 0;
    } else {
        $parent_id = (int) $parent->ID;
    }

    if ( $parent_id ) {
        // Direct-DB check keyed on (post_parent, post_name) — mirrors the
        // semantics of get_page_by_path('my-account/premium') but without
        // the permalink-cache staleness we hit on a fresh install.
        global $wpdb;
        $existing_child = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT ID FROM {$wpdb->posts}
              WHERE post_type   = 'page'
                AND post_parent = %d
                AND post_name   = %s
                AND post_status <> 'auto-draft'
              LIMIT 1",
            $parent_id,
            'premium'
        ) );
        if ( ! $existing_child ) {
            wp_insert_post( array(
                'post_title'   => 'My Premium',
                'post_name'    => 'premium',
                'post_parent'  => $parent_id,
                'post_content' => '[nmep_my_premium]',
                'post_status'  => 'publish',
                'post_type'    => 'page',
                'post_author'  => 1,
            ) );
        }
    }

    delete_transient( 'nme_creating_required_pages' );
}

/* ============================================================
   INITIALIZE PLUGIN
   ============================================================ */
add_action( 'plugins_loaded', 'nme_init_plugin' );
function nme_init_plugin() {
    // Initialize all components
    NME_Frontend::init();
    NME_Shortcodes::init();
    NME_Auth_UX::init();
    NME_Registration::init();
    NME_KYC::init();

    if ( is_admin() ) {
        NME_Admin::init();
    }

    // Version upgrade path is deferred to `init` (priority 20) so that
    // wp_insert_post() inside nme_create_required_pages() runs AFTER
    // WordPress has registered the built-in `page` post type. Running it
    // on plugins_loaded (where nme_init_plugin fires) is unsafe because
    // default post types aren't registered until the init hook.
    add_action( 'init', 'nme_run_upgrade_check', 20 );
}

function nme_run_upgrade_check() {
    $installed_version = get_option( 'nme_version', '0.0.0' );
    if ( version_compare( $installed_version, NME_VERSION, '<' ) ) {
        NME_Database::create_tables();
        // Ensure any newly-introduced required pages exist. nme_create_required_pages()
        // is idempotent — it skips slugs that already exist — so this is safe to run
        // on every version bump.
        nme_create_required_pages();
        update_option( 'nme_version', NME_VERSION );
    }
}

/* ============================================================
   ENQUEUE FRONTEND ASSETS
   ============================================================ */
add_action( 'wp_enqueue_scripts', 'nme_enqueue_frontend_assets' );
function nme_enqueue_frontend_assets() {
    wp_enqueue_style(
        'nme-frontend',
        NME_PLUGIN_URL . 'assets/css/frontend.css',
        array(),
        NME_VERSION
    );

    wp_enqueue_script(
        'nme-frontend',
        NME_PLUGIN_URL . 'assets/js/frontend.js',
        array( 'jquery' ),
        NME_VERSION,
        true
    );

    wp_localize_script( 'nme-frontend', 'nme_ajax', array(
        'url'   => admin_url( 'admin-ajax.php' ),
        'nonce' => wp_create_nonce( 'nme_ajax_nonce' ),
    ) );
}

/* ============================================================
   ENQUEUE ADMIN ASSETS
   ============================================================ */
add_action( 'admin_enqueue_scripts', 'nme_enqueue_admin_assets' );
function nme_enqueue_admin_assets( $hook ) {
    if ( strpos( $hook, 'nagaland-me-experts' ) === false && strpos( $hook, 'nme-' ) === false ) {
        return;
    }

    wp_enqueue_style(
        'nme-admin',
        NME_PLUGIN_URL . 'assets/css/admin.css',
        array(),
        NME_VERSION
    );

    wp_enqueue_script(
        'nme-admin',
        NME_PLUGIN_URL . 'assets/js/admin.js',
        array( 'jquery' ),
        NME_VERSION,
        true
    );
}