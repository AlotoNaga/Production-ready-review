Nagaland Me Experts Child Theme
Version 1.2.11

v1.2.11 changelog:
- Mobile logo polish: wordmark and pills now white-space:nowrap so
  NAGALAND / ME / EXPERTS never break across lines inside their
  boxes. Smaller badge + font sizes on <600px and <380px screens.
  On very narrow screens the gold EXPERTS pill gracefully hides
  (the badge still carries the EXPERTS identity).

Version 1.2.10

v1.2.10 changelog:
- Mobile: logo now appears in the mobile header. JS injection
  updated to find every Astra header container (desktop + mobile
  + above + below), de-duplicated so each wrap gets one logo.
- Closed the thin white gap between the header and the first hero
  on dark-background pages. Body bg now transparent + zero top
  margin/padding on all first-child wrappers below the masthead.
  The gold header divider is retained and now sits flush against
  the hero as an intentional premium gold rule.

Version 1.2.9

v1.2.9 changelog:
- Added JavaScript DOM-injection fallback for Astra Header Builder
  layouts that have no Site Identity element placed in any header
  row. JS finds the rendered header and inserts the compact-light
  logo as the first child of the first header row. Guarantees the
  logo appears regardless of Astra layout or builder mode.

v1.2.8

v1.2.8 changelog:
- Bumped logo-injection filter priorities to 999 so nothing else can
  override the auto-injected logo.
- Added Astra-specific fallback (astra_masthead_branding hook) so the
  logo still renders even on Astra header-builder layouts that skip
  the core get_custom_logo path.

v1.2.7 changelog:
- Auto-inject [nme_logo] into the Astra site header. Uses WordPress
  core get_custom_logo / has_custom_logo filters so the compact light
  logo lockup renders in the header branding slot automatically — no
  shortcode paste required. Astra's default site title and tagline
  are suppressed so they don't duplicate alongside our logo.

  To disable and restore Astra's default logo behaviour, add to
  functions.php or a custom plugin:
      add_filter( 'nme_auto_header_logo', '__return_false' );

v1.2.6 changelog:
- New [nme_logo] shortcode — premium brand mark for experts.nagaland.me,
  distinct from the parent nagaland.me magenta/play logo. Inline SVG
  badge (forest→emerald gradient + gold checkmark + ascending arrow)
  paired with NAGALAND.ME wordmark and gold "EXPERTS" pill/kicker.

  Usage:
    [nme_logo]                              full lockup (default)
    [nme_logo variant="compact"]            badge + wordmark on one line (header)
    [nme_logo variant="inline"]             wordmark only (footer / emails)
    [nme_logo variant="mark"]               badge only (favicon / mobile)
    [nme_logo theme="light"]                cream text for forest backgrounds
    [nme_logo link="no"]                    no link wrapper
    [nme_logo href="https://..."]           custom link target

  Recommended placements:
  - Site header  : [nme_logo variant="compact" theme="light"]
  - Page footer  : [nme_logo variant="full"]
  - Email footer : [nme_logo variant="inline"]
  - Favicon      : screenshot the [nme_logo variant="mark"] output and upload

v1.2.5 changelog:
- CSS-only cleanup to remove the "stacked paper / piles of pages" visual
  artifact that appeared at the top and sides of every page. Root cause was
  Astra's nested container wrappers (site-content > ast-container > article
  > content-area) each rendering their own padding/border/shadow. v1.2.5
  flattens every wrapper to a single seamless surface. Additive-only — no
  existing rules were changed, no shortcode behavior altered.

This is the Astra child theme for experts.nagaland.me

Files included:
- style.css       (theme stylesheet with brand foundation)
- functions.php   (theme functions, shortcodes, customizations)

Installation:
1. Upload this entire folder to /wp-content/themes/
2. In WordPress admin → Appearance → Themes → activate "Nagaland Me Experts Child"
3. Make sure the parent Astra theme is also installed (free from WordPress repository)

Available shortcodes:
- [nme_hero]              — Homepage hero (forest gradient)
- [nme_trust_strip]       — 4-column trust statistics strip
- [nme_categories]        — 8-category grid (SVG icons). Atts: title, subtitle
- [nme_how_it_works]      — 4-step explanation
- [nme_cta_section]       — Forest-green CTA section
- [nme_expert_hero]       — Become-an-Expert hero (emerald→forest diagonal)
- [nme_expert_why]        — 6 SVG benefit cards for experts
- [nme_expert_founding]   — Founding Expert Program (two cards, SVG checks)
- [nme_expert_cta]        — Final apply CTA (SVG document icon)
- [nme_why_choose_us]     — Homepage "Why choose us" (buyer-facing, 6 SVG cards). Atts: title, subtitle
- [nme_about_hero]        — About Us editorial hero (cream, kicker, gold divider). Atts: kicker, title, subtitle
- [nme_about_values]      — 6 SVG value cards ("What we believe in")
- [nme_about_family]      — 6 Nagaland Me family site cards with real logos, linked
- [nme_trust_hero]        — Trust & Safety hero (forest + gold-glow, inverse of expert hero)
- [nme_trust_verify]      — 6 SVG verification cards ("How we verify experts")
- [nme_trust_guarantees]  — 6 SVG-check buyer-guarantee cards

Recommended Become-an-Expert page content:

[nme_expert_hero]
[nme_expert_why]
[nme_expert_founding]
[nme_categories title="What you can sell" subtitle="Eight categories. Pick the one you're best at."]
[nme_testimonials limit="6" speed="5000"]
[nme_expert_cta]

Brand colors:
- Forest:  #0F2419
- Green:   #0A7558
- Emerald: #10B981
- Gold:    #D4A843
- Cream:   #FAF7F0

Fonts:
- Headings: Cormorant Garamond
- Body:     Outfit
