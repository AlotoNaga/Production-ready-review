<?php
/**
 * NMEB Cron — daily auto-award scheduler
 *
 * @version 1.0.0
 */
if ( ! defined( 'ABSPATH' ) ) exit;

class NMEB_Cron {

    public static function init() {
        add_action( 'nmeb_daily_auto_award', array( __CLASS__, 'run_daily' ) );
    }

    /**
     * Daily cron entry point
     */
    public static function run_daily() {
        if ( ! class_exists( 'NMEB_Engine' ) ) return;

        $stats = NMEB_Engine::run_auto_awards();

        // Save stats for admin display
        update_option( 'nmeb_last_cron_run', array(
            'time'  => current_time( 'mysql' ),
            'stats' => $stats,
        ) );
    }
}
