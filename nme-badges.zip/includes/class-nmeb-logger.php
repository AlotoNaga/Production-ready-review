<?php
/**
 * NMEB Logger
 * Logs to wp-content/uploads/nmeb-logs/ when WP_DEBUG enabled.
 * Falls back to error_log() otherwise.
 */
if ( ! defined( 'ABSPATH' ) ) exit;

class NMEB_Logger {

    const LEVEL_INFO  = 'info';
    const LEVEL_WARN  = 'warn';
    const LEVEL_ERROR = 'error';

    public static function info( $message, $context = array() ) {
        self::log( self::LEVEL_INFO, $message, $context );
    }

    public static function warn( $message, $context = array() ) {
        self::log( self::LEVEL_WARN, $message, $context );
    }

    public static function error( $message, $context = array() ) {
        self::log( self::LEVEL_ERROR, $message, $context );
    }

    private static function log( $level, $message, $context = array() ) {
        $entry = sprintf(
            '[%s] [NMEB %s] %s %s',
            current_time( 'mysql' ),
            strtoupper( $level ),
            $message,
            ! empty( $context ) ? wp_json_encode( $context ) : ''
        );

        if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
            $upload = wp_upload_dir();
            $log_dir = trailingslashit( $upload['basedir'] ) . 'nmeb-logs';
            if ( ! file_exists( $log_dir ) ) {
                wp_mkdir_p( $log_dir );
                // Protect log dir from web access
                @file_put_contents( $log_dir . '/index.html', '' );
                @file_put_contents( $log_dir . '/.htaccess', "Order deny,allow\nDeny from all" );
            }
            @file_put_contents(
                $log_dir . '/badges-' . date( 'Y-m-d' ) . '.log',
                $entry . "\n",
                FILE_APPEND | LOCK_EX
            );
        } else {
            error_log( $entry );
        }
    }
}
