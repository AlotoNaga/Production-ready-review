<?php
/**
 * NMEB Engine
 *
 * Award/revoke logic + user metric calculations.
 * - award_badge( $user_id, $slug, $awarded_by ) — grant a badge
 * - revoke_badge( $user_id, $slug ) — revoke a badge
 * - get_user_badges( $user_id ) — list earned badges
 * - run_auto_awards() — daily cron entry point: scan all users, auto-award eligible badges
 *
 * Reads order/review data from the nme-payments tables via NMEP_Database::table()
 *
 * @version 1.0.0
 */
if ( ! defined( 'ABSPATH' ) ) exit;

class NMEB_Engine {

    public static function init() {
        // Payments events are fired via NMEP_Events::emit() with these signatures:
        //   nmep_order_completed ( $order_id, $reason )
        //   nmep_order_auto_released ( $order_id )
        //   nmep_review_submitted ( $review_id, $order_id, $rating )
        add_action( 'nmep_order_completed',      array( __CLASS__, 'on_order_completed' ), 10, 1 );
        add_action( 'nmep_order_auto_released',  array( __CLASS__, 'on_order_completed' ), 10, 1 );
        add_action( 'nmep_review_submitted',     array( __CLASS__, 'on_review_submitted' ), 10, 2 );

        // Core plugin doesn't emit a hook on expert approval yet, so listen to
        // WP's role-change event as a reliable fallback.
        add_action( 'set_user_role',             array( __CLASS__, 'on_user_role_set' ), 10, 2 );
    }

    /* ============================================================
       PUBLIC API
       ============================================================ */

    /**
     * Award a badge to a user.
     *
     * @param int    $user_id    WP user ID
     * @param string $slug       Badge slug
     * @param string $awarded_by 'auto' or 'admin'
     * @param int    $admin_id   If awarded_by='admin', the admin's user_id
     * @param string $notes      Optional reason/note
     * @return int|false  Award ID on success, false on failure (already exists, badge not found)
     */
    public static function award_badge( $user_id, $slug, $awarded_by = 'auto', $admin_id = 0, $notes = '' ) {
        global $wpdb;

        $user_id = (int) $user_id;
        if ( $user_id <= 0 ) return false;

        $badge = NMEB_Badges::get_by_slug( $slug );
        if ( ! $badge ) {
            NMEB_Logger::warn( "award_badge: badge slug not found", array( 'slug' => $slug ) );
            return false;
        }

        $table = NMEB_Database::table( 'user_badges' );

        // Check if already awarded (and not revoked)
        $existing = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM $table WHERE user_id = %d AND badge_id = %d LIMIT 1",
            $user_id, $badge->id
        ) );

        if ( $existing ) {
            // If revoked, un-revoke (re-award)
            if ( $existing->is_revoked ) {
                $wpdb->update( $table, array(
                    'is_revoked'        => 0,
                    'revoked_at'        => null,
                    'revoked_by_admin_id' => null,
                    'revoked_reason'    => null,
                    'awarded_at'        => current_time( 'mysql' ),
                    'awarded_by'        => $awarded_by,
                    'awarded_by_admin_id' => $awarded_by === 'admin' ? (int) $admin_id : null,
                    'notes'             => $notes,
                ), array( 'id' => $existing->id ) );
                NMEB_Logger::info( "Re-awarded badge after revoke", array(
                    'user_id' => $user_id, 'slug' => $slug, 'by' => $awarded_by,
                ) );
                return (int) $existing->id;
            }
            // Already has it, no action
            return (int) $existing->id;
        }

        // Insert new award
        $result = $wpdb->insert( $table, array(
            'user_id'             => $user_id,
            'badge_id'            => (int) $badge->id,
            'awarded_by'          => $awarded_by,
            'awarded_by_admin_id' => $awarded_by === 'admin' ? (int) $admin_id : null,
            'awarded_at'          => current_time( 'mysql' ),
            'notes'               => $notes,
            'is_revoked'          => 0,
        ) );

        if ( ! $result ) {
            NMEB_Logger::error( "award_badge: insert failed", array(
                'user_id' => $user_id, 'badge_id' => $badge->id,
                'db_error' => $wpdb->last_error,
            ) );
            return false;
        }

        $award_id = (int) $wpdb->insert_id;

        // For mutually exclusive expert level badges, revoke lower levels
        // (e.g., when promoted to Pro Expert, auto-revoke Rising Expert)
        if ( $badge->badge_type === 'expert_level' && (int) $badge->tier_rank > 1 ) {
            self::revoke_lower_level_badges( $user_id, $badge );
        }

        NMEB_Logger::info( "Awarded badge", array(
            'user_id' => $user_id, 'slug' => $slug, 'by' => $awarded_by,
        ) );

        // Trigger action hook for emails or other listeners
        do_action( 'nmeb_badge_awarded', $user_id, $badge, $awarded_by );

        return $award_id;
    }

    /**
     * Revoke a badge from a user
     */
    public static function revoke_badge( $user_id, $slug, $admin_id = 0, $reason = '' ) {
        global $wpdb;

        $badge = NMEB_Badges::get_by_slug( $slug );
        if ( ! $badge ) return false;

        $table = NMEB_Database::table( 'user_badges' );

        $result = $wpdb->update( $table, array(
            'is_revoked'          => 1,
            'revoked_at'          => current_time( 'mysql' ),
            'revoked_by_admin_id' => $admin_id ? (int) $admin_id : null,
            'revoked_reason'      => $reason,
        ), array(
            'user_id'    => (int) $user_id,
            'badge_id'   => (int) $badge->id,
            'is_revoked' => 0,
        ) );

        if ( $result ) {
            NMEB_Logger::info( "Revoked badge", array(
                'user_id' => $user_id, 'slug' => $slug,
            ) );
            do_action( 'nmeb_badge_revoked', $user_id, $badge );
        }

        return (bool) $result;
    }

    /**
     * Revoke level badges with lower tier_rank than the given badge
     * (Used when expert is promoted: New Expert → Rising Expert auto-revokes New)
     */
    private static function revoke_lower_level_badges( $user_id, $new_level_badge ) {
        $expert_levels = NMEB_Badges::get_expert_levels_by_rank();
        foreach ( $expert_levels as $level ) {
            if ( (int) $level->tier_rank < (int) $new_level_badge->tier_rank ) {
                if ( self::user_has_badge( $user_id, $level->slug ) ) {
                    self::revoke_badge( $user_id, $level->slug, 0, 'Promoted to higher level: ' . $new_level_badge->name );
                }
            }
        }
    }

    /**
     * Check if user has a specific badge (active, not revoked)
     */
    public static function user_has_badge( $user_id, $slug ) {
        global $wpdb;
        $badge = NMEB_Badges::get_by_slug( $slug );
        if ( ! $badge ) return false;

        $table = NMEB_Database::table( 'user_badges' );
        $found = $wpdb->get_var( $wpdb->prepare(
            "SELECT id FROM $table WHERE user_id = %d AND badge_id = %d AND is_revoked = 0 LIMIT 1",
            (int) $user_id, (int) $badge->id
        ) );
        return (bool) $found;
    }

    /**
     * Get all active badges for a user (joined with badge definitions)
     * Returns array of objects with all badge fields + award metadata
     */
    public static function get_user_badges( $user_id ) {
        global $wpdb;
        $b_table  = NMEB_Database::table( 'badges' );
        $ub_table = NMEB_Database::table( 'user_badges' );

        return $wpdb->get_results( $wpdb->prepare(
            "SELECT b.*, ub.awarded_at, ub.awarded_by, ub.notes
             FROM $ub_table ub
             INNER JOIN $b_table b ON b.id = ub.badge_id
             WHERE ub.user_id = %d
               AND ub.is_revoked = 0
               AND ( ub.expires_at IS NULL OR ub.expires_at > %s )
               AND b.is_visible = 1
             ORDER BY b.display_order ASC, b.tier_rank DESC",
            (int) $user_id,
            current_time( 'mysql' )
        ) );
    }

    /**
     * Bulk: get all user_ids who have a specific badge slug
     */
    public static function get_users_with_badge( $slug ) {
        global $wpdb;
        $badge = NMEB_Badges::get_by_slug( $slug );
        if ( ! $badge ) return array();

        $table = NMEB_Database::table( 'user_badges' );
        return $wpdb->get_col( $wpdb->prepare(
            "SELECT user_id FROM $table WHERE badge_id = %d AND is_revoked = 0",
            (int) $badge->id
        ) );
    }

    /* ============================================================
       AUTO-AWARD ENGINE — Daily cron entry point
       ============================================================ */

    /**
     * Daily cron: scan all approved experts + active buyers, auto-award eligible badges
     * This is THE main loop. Triggered by WordPress cron.
     */
    public static function run_auto_awards() {
        $start = microtime( true );
        $stats = array( 'experts_scanned' => 0, 'buyers_scanned' => 0, 'badges_awarded' => 0 );

        // === EXPERTS ===
        $experts = self::get_all_approved_experts();
        foreach ( $experts as $expert ) {
            $stats['experts_scanned']++;
            $awarded = self::evaluate_expert( $expert );
            $stats['badges_awarded'] += $awarded;
        }

        // === BUYERS ===
        $buyer_ids = self::get_all_buyer_user_ids();
        foreach ( $buyer_ids as $buyer_id ) {
            $stats['buyers_scanned']++;
            $awarded = self::evaluate_buyer( $buyer_id );
            $stats['badges_awarded'] += $awarded;
        }

        $duration = round( microtime( true ) - $start, 2 );
        NMEB_Logger::info( "Daily auto-award completed in {$duration}s", $stats );

        return $stats;
    }

    /**
     * Evaluate ONE expert and award eligible badges. Returns # of badges newly awarded.
     */
    public static function evaluate_expert( $expert ) {
        if ( ! $expert || empty( $expert->user_id ) ) return 0;
        $user_id = (int) $expert->user_id;
        $awarded = 0;

        // Compute metrics once for this expert
        $metrics = self::compute_expert_metrics( $expert );

        // === Founding Expert (first 50 experts) ===
        if ( ! self::user_has_badge( $user_id, 'founding_expert' ) ) {
            if ( self::is_first_n_expert( $expert, 50 ) ) {
                if ( self::award_badge( $user_id, 'founding_expert', 'auto' ) ) $awarded++;
            }
        }

        // === New Expert (default for approved experts) ===
        // Only award if they have NO level badge yet
        $has_any_level = false;
        foreach ( array( 'new_expert', 'rising_expert', 'pro_expert', 'top_pro' ) as $level_slug ) {
            if ( self::user_has_badge( $user_id, $level_slug ) ) {
                $has_any_level = true;
                break;
            }
        }
        if ( ! $has_any_level ) {
            if ( self::award_badge( $user_id, 'new_expert', 'auto' ) ) $awarded++;
        }

        // === Level promotion ladder ===
        // Check Rising → Pro → Top Pro in order
        if ( self::expert_meets_criteria( $metrics, 'rising_expert' ) ) {
            if ( self::award_badge( $user_id, 'rising_expert', 'auto' ) ) $awarded++;
        }
        if ( self::expert_meets_criteria( $metrics, 'pro_expert' ) ) {
            if ( self::award_badge( $user_id, 'pro_expert', 'auto' ) ) $awarded++;
        }
        // Top Pro is admin-only; not auto-awarded

        // === Verified Expert (KYC done + 5+ orders) ===
        if ( ! self::user_has_badge( $user_id, 'verified_expert' ) ) {
            if ( $metrics['completed_orders'] >= 5 && self::expert_has_kyc( $expert ) ) {
                if ( self::award_badge( $user_id, 'verified_expert', 'auto' ) ) $awarded++;
            }
        }

        // === Achievement badges (one-off) ===
        if ( ! self::user_has_badge( $user_id, 'first_sale' ) && $metrics['completed_orders'] >= 1 ) {
            if ( self::award_badge( $user_id, 'first_sale', 'auto' ) ) $awarded++;
        }
        if ( ! self::user_has_badge( $user_id, 'quick_responder' ) && $metrics['response_rate_30d'] >= 90 ) {
            if ( self::award_badge( $user_id, 'quick_responder', 'auto' ) ) $awarded++;
        }
        if ( ! self::user_has_badge( $user_id, 'five_star_streak' ) && $metrics['consecutive_5_star'] >= 10 ) {
            if ( self::award_badge( $user_id, 'five_star_streak', 'auto' ) ) $awarded++;
        }
        if ( ! self::user_has_badge( $user_id, 'on_time_master' ) && $metrics['on_time_rate_30d'] >= 100 && $metrics['delivered_in_30d'] >= 5 ) {
            if ( self::award_badge( $user_id, 'on_time_master', 'auto' ) ) $awarded++;
        }
        if ( ! self::user_has_badge( $user_id, 'great_communicator' ) && $metrics['response_rate_30d'] >= 95 && $metrics['avg_rating'] >= 4.9 && $metrics['completed_orders'] >= 5 ) {
            if ( self::award_badge( $user_id, 'great_communicator', 'auto' ) ) $awarded++;
        }
        if ( ! self::user_has_badge( $user_id, 'niche_expert' ) && $metrics['max_orders_in_category'] >= 20 ) {
            if ( self::award_badge( $user_id, 'niche_expert', 'auto' ) ) $awarded++;
        }
        if ( ! self::user_has_badge( $user_id, 'pan_india_reach' ) && $metrics['unique_buyer_states'] >= 5 ) {
            if ( self::award_badge( $user_id, 'pan_india_reach', 'auto' ) ) $awarded++;
        }

        return $awarded;
    }

    /**
     * Evaluate ONE buyer and award eligible badges. Returns # of badges newly awarded.
     */
    public static function evaluate_buyer( $user_id ) {
        $user_id = (int) $user_id;
        if ( $user_id <= 0 ) return 0;
        $awarded = 0;

        $metrics = self::compute_buyer_metrics( $user_id );
        if ( $metrics['completed_orders'] === 0 ) return 0;

        // === New Buyer (gets it on first order) ===
        if ( ! self::user_has_badge( $user_id, 'new_buyer' ) ) {
            if ( self::award_badge( $user_id, 'new_buyer', 'auto' ) ) $awarded++;
        }

        // === Active Buyer (3+) ===
        if ( ! self::user_has_badge( $user_id, 'active_buyer' ) && $metrics['completed_orders'] >= 3 ) {
            if ( self::award_badge( $user_id, 'active_buyer', 'auto' ) ) $awarded++;
        }

        // === Power Buyer (10+) ===
        if ( ! self::user_has_badge( $user_id, 'power_buyer' ) && $metrics['completed_orders'] >= 10 ) {
            if ( self::award_badge( $user_id, 'power_buyer', 'auto' ) ) $awarded++;
        }

        // === Verified Buyer (email verified + 1+ order) ===
        if ( ! self::user_has_badge( $user_id, 'verified_buyer' ) && $metrics['completed_orders'] >= 1 && self::buyer_has_verified_email( $user_id ) ) {
            if ( self::award_badge( $user_id, 'verified_buyer', 'auto' ) ) $awarded++;
        }

        // === Loyal Customer (3+ orders to same expert) ===
        if ( ! self::user_has_badge( $user_id, 'loyal_customer' ) && $metrics['max_repeat_same_expert'] >= 3 ) {
            if ( self::award_badge( $user_id, 'loyal_customer', 'auto' ) ) $awarded++;
        }

        // === Early Supporter (first 200 buyers) ===
        if ( ! self::user_has_badge( $user_id, 'early_supporter' ) ) {
            if ( self::is_first_n_buyer( $user_id, 200 ) ) {
                if ( self::award_badge( $user_id, 'early_supporter', 'auto' ) ) $awarded++;
            }
        }

        // === Quality Reviewer (5+ detailed reviews of 50+ chars) ===
        if ( ! self::user_has_badge( $user_id, 'quality_reviewer' ) && $metrics['detailed_reviews_count'] >= 5 ) {
            if ( self::award_badge( $user_id, 'quality_reviewer', 'auto' ) ) $awarded++;
        }

        return $awarded;
    }

    /* ============================================================
       METRIC COMPUTATION
       ============================================================ */

    /**
     * Compute all metrics needed to evaluate expert badges
     * Reads from nme-payments tables
     */
    public static function compute_expert_metrics( $expert ) {
        global $wpdb;

        if ( ! $expert || empty( $expert->id ) ) {
            return self::empty_expert_metrics();
        }

        $expert_id = (int) $expert->id;
        $orders_table = NMEP_Database::table( 'orders' );
        $reviews_table = NMEP_Database::table( 'reviews' );

        $m = self::empty_expert_metrics();

        // Completed orders count
        $m['completed_orders'] = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM $orders_table WHERE expert_id = %d AND status IN ('completed', 'auto_released')",
            $expert_id
        ) );

        // Avg rating
        $avg = $wpdb->get_var( $wpdb->prepare(
            "SELECT AVG(rating) FROM $reviews_table WHERE expert_id = %d AND status = 'published'",
            $expert_id
        ) );
        $m['avg_rating'] = $avg !== null ? round( (float) $avg, 2 ) : 0;

        // Days active (since approval)
        if ( ! empty( $expert->updated_at ) ) {
            $approved_ts = strtotime( $expert->updated_at );
            $m['days_active'] = max( 0, floor( ( time() - $approved_ts ) / 86400 ) );
        }

        // Response rate — placeholder (would need message-table tracking)
        // For v1.0: use a sensible default of 90% if they have any orders
        $m['response_rate']     = $m['completed_orders'] > 0 ? 90 : 0;
        $m['response_rate_30d'] = $m['response_rate'];

        // Consecutive 5-star reviews (most recent stretch)
        $m['consecutive_5_star'] = self::count_consecutive_5_star( $expert_id );

        // On-time delivery rate (past 30 days) — count orders delivered on or before due date
        $m['on_time_rate_30d'] = self::compute_on_time_rate_30d( $expert_id );
        $m['delivered_in_30d'] = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM $orders_table
             WHERE expert_id = %d AND status IN ('completed','auto_released','delivered')
               AND updated_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)",
            $expert_id
        ) );

        // Max orders in single category
        $services_table = NMEP_Database::table( 'services' );
        $m['max_orders_in_category'] = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COALESCE(MAX(cnt), 0) FROM (
                SELECT s.category_id, COUNT(o.id) AS cnt
                FROM $orders_table o
                INNER JOIN $services_table s ON s.id = o.service_id
                WHERE o.expert_id = %d AND o.status IN ('completed','auto_released')
                GROUP BY s.category_id
             ) c",
            $expert_id
        ) );

        // Unique buyer states — placeholder (need buyer location data; default 0 for now)
        $m['unique_buyer_states'] = 0;

        return $m;
    }

    private static function empty_expert_metrics() {
        return array(
            'completed_orders'         => 0,
            'avg_rating'               => 0,
            'response_rate'            => 0,
            'response_rate_30d'        => 0,
            'days_active'              => 0,
            'consecutive_5_star'       => 0,
            'on_time_rate_30d'         => 0,
            'delivered_in_30d'         => 0,
            'max_orders_in_category'   => 0,
            'unique_buyer_states'      => 0,
        );
    }

    /**
     * Count current streak of consecutive 5-star reviews (working backwards from most recent)
     */
    private static function count_consecutive_5_star( $expert_id ) {
        global $wpdb;
        $reviews_table = NMEP_Database::table( 'reviews' );

        $reviews = $wpdb->get_col( $wpdb->prepare(
            "SELECT rating FROM $reviews_table
             WHERE expert_id = %d AND status = 'published'
             ORDER BY id DESC LIMIT 50",
            (int) $expert_id
        ) );

        $streak = 0;
        foreach ( $reviews as $r ) {
            if ( (float) $r >= 5.0 ) {
                $streak++;
            } else {
                break;
            }
        }
        return $streak;
    }

    /**
     * On-time delivery rate over past 30 days
     */
    private static function compute_on_time_rate_30d( $expert_id ) {
        global $wpdb;
        $orders_table = NMEP_Database::table( 'orders' );

        // Total delivered in past 30 days
        $total = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM $orders_table
             WHERE expert_id = %d
               AND status IN ('completed','auto_released','delivered')
               AND updated_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)",
            (int) $expert_id
        ) );
        if ( $total === 0 ) return 0;

        // Delivered ON TIME (delivered_at <= delivery_due_at). Missing timestamps count as on-time.
        $on_time = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM $orders_table
             WHERE expert_id = %d
               AND status IN ('completed','auto_released','delivered')
               AND updated_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
               AND ( delivery_due_at IS NULL OR delivered_at IS NULL OR delivered_at <= delivery_due_at )",
            (int) $expert_id
        ) );

        return (int) round( ( $on_time / $total ) * 100 );
    }

    /**
     * Compute buyer metrics
     */
    public static function compute_buyer_metrics( $user_id ) {
        global $wpdb;
        $user_id = (int) $user_id;

        $orders_table  = NMEP_Database::table( 'orders' );
        $reviews_table = NMEP_Database::table( 'reviews' );

        $m = array(
            'completed_orders'        => 0,
            'max_repeat_same_expert'  => 0,
            'detailed_reviews_count'  => 0,
        );

        $m['completed_orders'] = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM $orders_table
             WHERE buyer_user_id = %d AND status IN ('completed','auto_released')",
            $user_id
        ) );

        // Max times bought from same expert
        $m['max_repeat_same_expert'] = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COALESCE(MAX(cnt), 0) FROM (
                SELECT expert_id, COUNT(*) AS cnt FROM $orders_table
                WHERE buyer_user_id = %d AND status IN ('completed','auto_released')
                GROUP BY expert_id
             ) e",
            $user_id
        ) );

        // Detailed reviews (50+ chars in comment)
        $m['detailed_reviews_count'] = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM $reviews_table
             WHERE buyer_user_id = %d AND status = 'published'
               AND CHAR_LENGTH(comment) >= 50",
            $user_id
        ) );

        return $m;
    }

    /* ============================================================
       CRITERIA EVALUATION
       ============================================================ */

    /**
     * Check if expert metrics meet a specific badge's auto-criteria
     */
    private static function expert_meets_criteria( $metrics, $badge_slug ) {
        $badge = NMEB_Badges::get_by_slug( $badge_slug );
        if ( ! $badge || ! $badge->criteria_json ) return false;

        $criteria = json_decode( $badge->criteria_json, true );
        if ( ! is_array( $criteria ) ) return false;

        if ( isset( $criteria['min_completed_orders'] ) && $metrics['completed_orders'] < $criteria['min_completed_orders'] ) return false;
        if ( isset( $criteria['min_avg_rating'] ) && $metrics['avg_rating'] < $criteria['min_avg_rating'] ) return false;
        if ( isset( $criteria['min_response_rate'] ) && $metrics['response_rate'] < $criteria['min_response_rate'] ) return false;
        if ( isset( $criteria['min_response_rate_30d'] ) && $metrics['response_rate_30d'] < $criteria['min_response_rate_30d'] ) return false;
        if ( isset( $criteria['min_days_active'] ) && $metrics['days_active'] < $criteria['min_days_active'] ) return false;
        if ( isset( $criteria['consecutive_5_star'] ) && $metrics['consecutive_5_star'] < $criteria['consecutive_5_star'] ) return false;
        if ( isset( $criteria['on_time_rate_30d'] ) && $metrics['on_time_rate_30d'] < $criteria['on_time_rate_30d'] ) return false;
        if ( isset( $criteria['min_orders_in_category'] ) && $metrics['max_orders_in_category'] < $criteria['min_orders_in_category'] ) return false;
        if ( isset( $criteria['min_unique_buyer_states'] ) && $metrics['unique_buyer_states'] < $criteria['min_unique_buyer_states'] ) return false;

        return true;
    }

    /* ============================================================
       USER QUERY HELPERS (fetches from nme-payments)
       ============================================================ */

    /**
     * All approved experts (from base experts table)
     */
    private static function get_all_approved_experts() {
        if ( ! class_exists( 'NMEP_Compat' ) ) return array();
        global $wpdb;
        $table = NMEP_Compat::base_table( 'experts' );
        return $wpdb->get_results( "SELECT * FROM $table WHERE status = 'approved'" );
    }

    /**
     * All distinct buyer user_ids who have at least one completed order
     */
    private static function get_all_buyer_user_ids() {
        global $wpdb;
        $orders_table = NMEP_Database::table( 'orders' );
        return $wpdb->get_col(
            "SELECT DISTINCT buyer_user_id FROM $orders_table
             WHERE buyer_user_id > 0 AND status IN ('completed', 'auto_released')"
        );
    }

    /**
     * Is this expert one of the first N approved experts on the platform?
     */
    private static function is_first_n_expert( $expert, $n ) {
        if ( ! class_exists( 'NMEP_Compat' ) ) return false;
        global $wpdb;
        $table = NMEP_Compat::base_table( 'experts' );
        $rank = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM $table WHERE status = 'approved' AND id <= %d",
            (int) $expert->id
        ) );
        return $rank > 0 && $rank <= $n;
    }

    /**
     * Is this buyer one of the first N buyers on the platform?
     */
    private static function is_first_n_buyer( $user_id, $n ) {
        global $wpdb;
        $orders_table = NMEP_Database::table( 'orders' );
        // Get the first order from this buyer
        $first_order_id = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT MIN(id) FROM $orders_table WHERE buyer_user_id = %d",
            (int) $user_id
        ) );
        if ( $first_order_id === 0 ) return false;

        // How many distinct buyers had a smaller-or-equal first order?
        $rank = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM (
                SELECT MIN(id) AS first_id FROM $orders_table
                WHERE buyer_user_id > 0
                GROUP BY buyer_user_id
                HAVING first_id <= $first_order_id
             ) ranked"
        );
        return $rank > 0 && $rank <= $n;
    }

    /**
     * Does this expert have KYC done?
     */
    private static function expert_has_kyc( $expert ) {
        // Check if KYC fields are filled in the experts table
        if ( ! empty( $expert->kyc_pan ) && ! empty( $expert->kyc_bank_account ) ) {
            return true;
        }
        // Fallback: check linked account (Razorpay Route requires KYC)
        if ( class_exists( 'NMEP_Linked_Accounts' ) && method_exists( 'NMEP_Linked_Accounts', 'get_for_expert' ) ) {
            $la = NMEP_Linked_Accounts::get_for_expert( $expert->id );
            if ( $la && ! empty( $la->status ) && $la->status === 'activated' ) {
                return true;
            }
        }
        return false;
    }

    /**
     * Does this WP user have a verified email?
     * WordPress doesn't have native email verification, so we check user_registered + activation key
     */
    private static function buyer_has_verified_email( $user_id ) {
        $user = get_userdata( $user_id );
        if ( ! $user ) return false;
        // If the activation key is empty, the user has logged in (i.e., verified)
        $activation_key = get_user_meta( $user_id, '_user_activation_key', true );
        return empty( $activation_key );
    }

    /* ============================================================
       EVENT HOOKS — Triggered by nme-payments
       ============================================================ */

    /**
     * When an order is completed / auto-released, evaluate badges for both sides.
     * Payload is $order_id (int) — look up the order.
     */
    public static function on_order_completed( $order_id ) {
        $order_id = (int) $order_id;
        if ( $order_id <= 0 || ! class_exists( 'NMEP_Orders' ) ) return;

        $order = NMEP_Orders::get( $order_id );
        if ( ! $order ) return;

        // Re-evaluate expert
        if ( ! empty( $order->expert_id ) && class_exists( 'NMEP_Compat' ) ) {
            $expert = NMEP_Compat::get_expert( $order->expert_id );
            if ( $expert ) self::evaluate_expert( $expert );
        }

        // Re-evaluate buyer
        if ( ! empty( $order->buyer_user_id ) ) {
            self::evaluate_buyer( (int) $order->buyer_user_id );
        }
    }

    /**
     * Core plugin fallback — when a WP user gains the expert role, evaluate badges.
     * This covers instant "New Expert" / "Founding Expert" awards on approval.
     */
    public static function on_user_role_set( $user_id, $role ) {
        if ( 'nme_expert' !== $role ) return;
        if ( ! class_exists( 'NMEP_Compat' ) ) return;
        $expert = NMEP_Compat::get_expert_by_user( (int) $user_id );
        if ( $expert ) self::evaluate_expert( $expert );
    }

    /**
     * When a review is submitted, re-evaluate the relevant expert.
     *
     * Payments emits this in two different arg orders depending on the call
     * site — (review_id, order_id) from reviews-v2 vs (order_id, review_id)
     * from the REST API. We probe both arguments defensively so the expert
     * still gets re-evaluated either way.
     */
    public static function on_review_submitted( $arg1 = 0, $arg2 = 0 ) {
        if ( ! class_exists( 'NMEP_Orders' ) ) return;

        $order = null;
        foreach ( array( (int) $arg2, (int) $arg1 ) as $candidate_id ) {
            if ( $candidate_id <= 0 ) continue;
            $maybe = NMEP_Orders::get( $candidate_id );
            if ( $maybe && ! empty( $maybe->expert_id ) ) {
                $order = $maybe;
                break;
            }
        }
        if ( ! $order ) return;

        if ( class_exists( 'NMEP_Compat' ) ) {
            $expert = NMEP_Compat::get_expert( $order->expert_id );
            if ( $expert ) self::evaluate_expert( $expert );
        }
    }
}
