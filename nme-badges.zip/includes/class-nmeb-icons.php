<?php
/**
 * NMEB_Icons — premium business-grade badge marks (v2.0)
 *
 * Design language:
 *   • Hex seal      — expert level badges (New / Rising / Pro / Top Pro)
 *   • Crest shield  — trust / verification (Verified Expert, Verified Buyer)
 *   • Medallion     — achievement + buyer recognition (all others)
 *
 * Every mark is a 32×32 SVG with a monogram or emblem. No pictorial metaphors
 * (no sprouts, trophies, rockets, hearts, carts, etc.) — keyboard-emoji vibes
 * are explicitly avoided. Aesthetic: corporate certification / loyalty tier.
 *
 * Palette (all inline):
 *   --emerald #10B981   --forest  #0A7558   --gold   #D4A843
 *   --graphite #1F2937  --slate   #475569   --ivory  #F5F1E6
 *
 * Call: NMEB_Icons::get( 'badge_slug', $size );
 *
 * @version 2.0.0
 */
if ( ! defined( 'ABSPATH' ) ) exit;

class NMEB_Icons {

    /* ============================================================
       PALETTE — keep it tight.
       ============================================================ */
    const C_EMERALD  = '#10B981';
    const C_FOREST   = '#0A7558';
    const C_FOREST_D = '#064E3B';
    const C_GOLD     = '#D4A843';
    const C_GOLD_D   = '#A87E2A';
    const C_GRAPHITE = '#1F2937';
    const C_SLATE    = '#475569';
    const C_IVORY    = '#F5F1E6';
    const C_WHITE    = '#FFFFFF';

    /**
     * Get SVG markup for a badge.
     *
     * @param string $slug  Badge slug.
     * @param int    $size  Display size in px (default 24).
     * @param string $color (unused, kept for backwards-compat; every mark has
     *                      its own disciplined palette).
     */
    public static function get( $slug, $size = 24, $color = '' ) {
        $method = 'icon_' . str_replace( '-', '_', sanitize_key( $slug ) );
        if ( method_exists( __CLASS__, $method ) ) {
            return self::$method( (int) $size );
        }
        return self::icon_fallback( $slug, (int) $size );
    }

    /* ============================================================
       SHARED SHAPE BUILDERS
       ============================================================ */

    private static function wrap( $inner, $size ) {
        $size = max( 10, (int) $size );
        return '<svg xmlns="http://www.w3.org/2000/svg" width="' . $size . '" height="' . $size . '" viewBox="0 0 32 32" aria-hidden="true" focusable="false" style="display:inline-block;vertical-align:middle;flex-shrink:0;">' . $inner . '</svg>';
    }

    /**
     * Hex seal — flat-top hexagon with an outer hairline + inner disk. Used
     * for expert level badges. $fill is the body color, $stroke the outline.
     */
    private static function hex_seal( $fill, $stroke, $monogram, $text_color = '#FFFFFF', $ornament = '' ) {
        // Flat-top hexagon (points at left/right), centered on 16,16.
        $hex = 'M16 2 L28 9 L28 23 L16 30 L4 23 L4 9 Z';
        return
            '<path d="' . $hex . '" fill="' . $fill . '" stroke="' . $stroke . '" stroke-width="1.2" stroke-linejoin="round"/>' .
            '<path d="' . $hex . '" fill="none" stroke="' . self::C_IVORY . '" stroke-width="0.6" stroke-linejoin="round" transform="translate(0,0) scale(0.78) translate(4.5,4.5)" opacity="0.55"/>' .
            $ornament .
            '<text x="16" y="20.2" text-anchor="middle" font-family="Georgia, serif" font-size="11" font-weight="700" letter-spacing="0.4" fill="' . $text_color . '">' . $monogram . '</text>';
    }

    /**
     * Crest shield — classical pointed shield, used for trust/verification.
     */
    private static function shield( $fill, $stroke, $emblem ) {
        // Rounded-shoulder shield with chiseled point.
        $shield = 'M16 3 L27 6.5 L27 16 C27 22.5 22.2 27.5 16 29.5 C9.8 27.5 5 22.5 5 16 L5 6.5 Z';
        return
            '<path d="' . $shield . '" fill="' . $fill . '" stroke="' . $stroke . '" stroke-width="1.2" stroke-linejoin="round"/>' .
            // Inner highlight band
            '<path d="M16 5.5 L25 8.2 L25 15.5 C25 21.2 21 25.5 16 27.3 C11 25.5 7 21.2 7 15.5 L7 8.2 Z" fill="none" stroke="' . self::C_IVORY . '" stroke-width="0.5" opacity="0.55"/>' .
            $emblem;
    }

    /**
     * Medallion — circle with a decorative outer ring and an inner disk.
     * Used for achievement + buyer recognition badges.
     */
    private static function medallion( $fill, $stroke, $emblem, $ring_style = 'solid' ) {
        $ring = ( $ring_style === 'dashed' )
            ? '<circle cx="16" cy="16" r="14" fill="none" stroke="' . $stroke . '" stroke-width="0.9" stroke-dasharray="1.6 1.6" opacity="0.55"/>'
            : '<circle cx="16" cy="16" r="14" fill="none" stroke="' . $stroke . '" stroke-width="0.9" opacity="0.55"/>';
        return
            $ring .
            '<circle cx="16" cy="16" r="11.5" fill="' . $fill . '" stroke="' . $stroke . '" stroke-width="0.9"/>' .
            // Slim ivory inner bevel for depth
            '<circle cx="16" cy="16" r="10" fill="none" stroke="' . self::C_IVORY . '" stroke-width="0.5" opacity="0.5"/>' .
            $emblem;
    }

    /**
     * Monogram text — centered inside a medallion or hex.
     */
    private static function monogram( $text, $color = '#FFFFFF', $size = 11, $y = 20.2 ) {
        $text = esc_html( $text );
        return '<text x="16" y="' . $y . '" text-anchor="middle" font-family="Georgia, \'Times New Roman\', serif" font-size="' . $size . '" font-weight="700" letter-spacing="0.3" fill="' . $color . '">' . $text . '</text>';
    }

    /**
     * Laurel ornament — two gentle curved strokes flanking the monogram.
     */
    private static function laurel( $color ) {
        return
            '<path d="M7 11 C6 15 7 20 10 23" fill="none" stroke="' . $color . '" stroke-width="1.1" stroke-linecap="round" opacity="0.75"/>' .
            '<path d="M25 11 C26 15 25 20 22 23" fill="none" stroke="' . $color . '" stroke-width="1.1" stroke-linecap="round" opacity="0.75"/>' .
            // Small leaf ticks
            '<path d="M7.5 13 L9 13.4 M7 16 L8.6 16 M7.5 19 L9 18.6" stroke="' . $color . '" stroke-width="0.8" stroke-linecap="round" opacity="0.75"/>' .
            '<path d="M24.5 13 L23 13.4 M25 16 L23.4 16 M24.5 19 L23 18.6" stroke="' . $color . '" stroke-width="0.8" stroke-linecap="round" opacity="0.75"/>';
    }

    /**
     * Ribbon banner — horizontal banner across lower medallion, used for
     * "founding" / "early" distinction.
     */
    private static function ribbon( $fill, $stroke, $label ) {
        return
            '<path d="M3 20 L29 20 L27 26 L5 26 Z" fill="' . $fill . '" stroke="' . $stroke . '" stroke-width="0.7" stroke-linejoin="round"/>' .
            '<path d="M3 20 L1 22 L5 26 Z M29 20 L31 22 L27 26 Z" fill="' . $stroke . '" opacity="0.8"/>' .
            '<text x="16" y="24.3" text-anchor="middle" font-family="Georgia, serif" font-size="4.2" font-weight="700" letter-spacing="1.2" fill="' . self::C_IVORY . '">' . esc_html( $label ) . '</text>';
    }

    /* ============================================================
       EXPERT LEVEL — HEX SEALS
       ============================================================ */

    public static function icon_new_expert( $s = 24 ) {
        return self::wrap( self::hex_seal( self::C_EMERALD, self::C_FOREST_D, 'N' ), $s );
    }

    public static function icon_rising_expert( $s = 24 ) {
        // Forest with gold inner accent + upward chevron above the N-monogram (minimal).
        $ornament =
            '<path d="M12 13 L16 9 L20 13" fill="none" stroke="' . self::C_GOLD . '" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/>';
        return self::wrap( self::hex_seal( self::C_FOREST, self::C_FOREST_D, 'R', self::C_IVORY, $ornament ), $s );
    }

    public static function icon_pro_expert( $s = 24 ) {
        // Gold with dark-gold outline + laurel flank.
        $ornament = self::laurel( self::C_GOLD_D );
        return self::wrap( self::hex_seal( self::C_GOLD, self::C_GOLD_D, 'P', self::C_GRAPHITE, $ornament ), $s );
    }

    public static function icon_top_pro( $s = 24 ) {
        // Premium tier: graphite seal, gold inner crown dots, "TP" monogram in gold.
        $crown =
            '<circle cx="10" cy="9.5" r="1" fill="' . self::C_GOLD . '"/>' .
            '<circle cx="16" cy="8"   r="1.2" fill="' . self::C_GOLD . '"/>' .
            '<circle cx="22" cy="9.5" r="1" fill="' . self::C_GOLD . '"/>' .
            '<path d="M10 9.5 L16 8 L22 9.5" fill="none" stroke="' . self::C_GOLD . '" stroke-width="0.8" stroke-linecap="round" opacity="0.9"/>';
        $body =
            '<path d="M16 2 L28 9 L28 23 L16 30 L4 23 L4 9 Z" fill="' . self::C_GRAPHITE . '" stroke="' . self::C_GOLD_D . '" stroke-width="1.2" stroke-linejoin="round"/>' .
            '<path d="M16 4.5 L25.8 10.2 L25.8 21.8 L16 27.5 L6.2 21.8 L6.2 10.2 Z" fill="none" stroke="' . self::C_GOLD . '" stroke-width="0.6" opacity="0.7"/>' .
            $crown .
            '<text x="16" y="23" text-anchor="middle" font-family="Georgia, serif" font-size="9.5" font-weight="700" letter-spacing="0.4" fill="' . self::C_GOLD . '">TP</text>';
        return self::wrap( $body, $s );
    }

    /* ============================================================
       TRUST — CREST SHIELDS
       ============================================================ */

    public static function icon_verified_expert( $s = 24 ) {
        // Forest shield + crisp check. The trust anchor.
        $emblem = '<path d="M11.2 16.5 L14.5 19.6 L21 12.8" fill="none" stroke="' . self::C_IVORY . '" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/>';
        return self::wrap( self::shield( self::C_FOREST, self::C_FOREST_D, $emblem ), $s );
    }

    public static function icon_verified_buyer( $s = 24 ) {
        // Slate shield — smaller/quieter trust signal than the expert one.
        $emblem = '<path d="M11.2 16.5 L14.5 19.6 L21 12.8" fill="none" stroke="' . self::C_IVORY . '" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/>';
        return self::wrap( self::shield( self::C_SLATE, self::C_GRAPHITE, $emblem ), $s );
    }

    /* ============================================================
       EXPERT ACHIEVEMENTS — MEDALLIONS
       ============================================================ */

    public static function icon_first_sale( $s = 24 ) {
        // Emerald medallion, numeral "1" monogram.
        $emblem = self::monogram( '1', self::C_IVORY, 14, 21 );
        return self::wrap( self::medallion( self::C_EMERALD, self::C_FOREST_D, $emblem, 'dashed' ), $s );
    }

    public static function icon_quick_responder( $s = 24 ) {
        // Forest medallion with a minute-sweep arc — reads as speed, not a cartoon bolt.
        $emblem =
            '<path d="M16 9 A7 7 0 1 1 9 16" fill="none" stroke="' . self::C_IVORY . '" stroke-width="2" stroke-linecap="round"/>' .
            '<path d="M12 9 L9 16 L13 15" fill="' . self::C_GOLD . '" stroke="' . self::C_GOLD_D . '" stroke-width="0.5" stroke-linejoin="round"/>';
        return self::wrap( self::medallion( self::C_FOREST, self::C_FOREST_D, $emblem ), $s );
    }

    public static function icon_five_star_streak( $s = 24 ) {
        // Gold medallion with a single sharp 5-point star + "5" tucked below.
        $emblem =
            '<polygon points="16,8.5 17.6,13 22.3,13 18.4,15.7 20,20.2 16,17.5 12,20.2 13.6,15.7 9.7,13 14.4,13" fill="' . self::C_IVORY . '" opacity="0.95"/>' .
            '<circle cx="16" cy="15" r="1.3" fill="' . self::C_GOLD_D . '"/>';
        return self::wrap( self::medallion( self::C_GOLD, self::C_GOLD_D, $emblem ), $s );
    }

    public static function icon_founding_expert( $s = 24 ) {
        // Graphite medallion with gold ribbon banner reading "FOUNDING".
        $emblem =
            '<text x="16" y="15" text-anchor="middle" font-family="Georgia, serif" font-size="9" font-weight="700" fill="' . self::C_GOLD . '">F</text>' .
            self::ribbon( self::C_GOLD, self::C_GOLD_D, 'FOUNDING' );
        return self::wrap( self::medallion( self::C_GRAPHITE, self::C_GOLD_D, $emblem ), $s );
    }

    public static function icon_on_time_master( $s = 24 ) {
        // Forest medallion — clean clock-face with crisp hands. Not a cartoon clock.
        $emblem =
            '<circle cx="16" cy="16" r="7.5" fill="none" stroke="' . self::C_IVORY . '" stroke-width="1.2"/>' .
            '<line x1="16" y1="16" x2="16" y2="10.5" stroke="' . self::C_IVORY . '" stroke-width="1.6" stroke-linecap="round"/>' .
            '<line x1="16" y1="16" x2="20" y2="16" stroke="' . self::C_GOLD . '" stroke-width="1.6" stroke-linecap="round"/>' .
            '<circle cx="16" cy="16" r="1" fill="' . self::C_IVORY . '"/>';
        return self::wrap( self::medallion( self::C_FOREST, self::C_FOREST_D, $emblem ), $s );
    }

    public static function icon_great_communicator( $s = 24 ) {
        // Slate medallion — three justified typographic bars (reads as "clear speech").
        $emblem =
            '<line x1="10" y1="13.5" x2="22" y2="13.5" stroke="' . self::C_IVORY . '" stroke-width="1.6" stroke-linecap="round"/>' .
            '<line x1="10" y1="17"   x2="19" y2="17"   stroke="' . self::C_IVORY . '" stroke-width="1.6" stroke-linecap="round"/>' .
            '<line x1="10" y1="20.5" x2="21" y2="20.5" stroke="' . self::C_IVORY . '" stroke-width="1.6" stroke-linecap="round"/>' .
            '<circle cx="24" cy="20.5" r="1.3" fill="' . self::C_GOLD . '"/>';
        return self::wrap( self::medallion( self::C_SLATE, self::C_GRAPHITE, $emblem ), $s );
    }

    public static function icon_niche_expert( $s = 24 ) {
        // Forest medallion — concentric specialization rings + center dot.
        $emblem =
            '<circle cx="16" cy="16" r="7" fill="none" stroke="' . self::C_IVORY . '" stroke-width="1" opacity="0.75"/>' .
            '<circle cx="16" cy="16" r="4.5" fill="none" stroke="' . self::C_IVORY . '" stroke-width="1" opacity="0.9"/>' .
            '<circle cx="16" cy="16" r="2.2" fill="' . self::C_GOLD . '"/>';
        return self::wrap( self::medallion( self::C_FOREST, self::C_FOREST_D, $emblem ), $s );
    }

    public static function icon_pan_india_reach( $s = 24 ) {
        // Slate medallion — a cartographer's compass cross (no globe, no pin).
        $emblem =
            '<line x1="16" y1="8.5" x2="16" y2="23.5" stroke="' . self::C_IVORY . '" stroke-width="1.4" stroke-linecap="round"/>' .
            '<line x1="8.5" y1="16" x2="23.5" y2="16" stroke="' . self::C_IVORY . '" stroke-width="1.4" stroke-linecap="round"/>' .
            '<circle cx="16" cy="16" r="3" fill="none" stroke="' . self::C_GOLD . '" stroke-width="1.3"/>' .
            '<circle cx="16" cy="16" r="1.2" fill="' . self::C_GOLD . '"/>';
        return self::wrap( self::medallion( self::C_SLATE, self::C_GRAPHITE, $emblem ), $s );
    }

    /* ============================================================
       BUYER BADGES — MEDALLIONS (quieter palette)
       ============================================================ */

    public static function icon_new_buyer( $s = 24 ) {
        $emblem = self::monogram( 'N', self::C_IVORY, 12, 20.5 );
        return self::wrap( self::medallion( self::C_EMERALD, self::C_FOREST_D, $emblem, 'dashed' ), $s );
    }

    public static function icon_active_buyer( $s = 24 ) {
        $emblem = self::monogram( 'A', self::C_IVORY, 12, 20.5 );
        return self::wrap( self::medallion( self::C_FOREST, self::C_FOREST_D, $emblem ), $s );
    }

    public static function icon_power_buyer( $s = 24 ) {
        $emblem = self::monogram( 'P', self::C_GRAPHITE, 12, 20.5 );
        return self::wrap( self::medallion( self::C_GOLD, self::C_GOLD_D, $emblem ), $s );
    }

    public static function icon_loyal_customer( $s = 24 ) {
        // Gold medallion with a slim vertical ribbon accent — loyalty ribbon.
        $emblem =
            self::monogram( 'L', self::C_GRAPHITE, 11, 19 ) .
            '<rect x="15" y="20" width="2" height="6" fill="' . self::C_GOLD_D . '"/>' .
            '<path d="M15 26 L14 27.5 L16 26.8 L18 27.5 L17 26" fill="' . self::C_GOLD_D . '"/>';
        return self::wrap( self::medallion( self::C_GOLD, self::C_GOLD_D, $emblem ), $s );
    }

    public static function icon_early_supporter( $s = 24 ) {
        // Graphite medallion + gold "EARLY" ribbon banner.
        $emblem =
            '<text x="16" y="15" text-anchor="middle" font-family="Georgia, serif" font-size="9" font-weight="700" fill="' . self::C_GOLD . '">E</text>' .
            self::ribbon( self::C_GOLD, self::C_GOLD_D, 'EARLY' );
        return self::wrap( self::medallion( self::C_GRAPHITE, self::C_GOLD_D, $emblem ), $s );
    }

    public static function icon_quality_reviewer( $s = 24 ) {
        // Slate medallion with a small 5-point star + "Q" — sharp and editorial.
        $emblem =
            '<polygon points="16,10 17,13 20.2,13 17.6,14.8 18.6,17.8 16,16 13.4,17.8 14.4,14.8 11.8,13 15,13" fill="' . self::C_GOLD . '"/>' .
            '<text x="16" y="26" text-anchor="middle" font-family="Georgia, serif" font-size="8" font-weight="700" fill="' . self::C_IVORY . '">Q</text>';
        return self::wrap( self::medallion( self::C_SLATE, self::C_GRAPHITE, $emblem ), $s );
    }

    /* ============================================================
       FALLBACK
       ============================================================ */

    private static function icon_fallback( $slug, $size ) {
        $letter = strtoupper( substr( str_replace( array( '_', '-' ), '', (string) $slug ), 0, 1 ) ) ?: 'N';
        $emblem = self::monogram( $letter, self::C_IVORY, 12, 20.5 );
        return self::wrap( self::medallion( self::C_SLATE, self::C_GRAPHITE, $emblem ), $size );
    }
}
