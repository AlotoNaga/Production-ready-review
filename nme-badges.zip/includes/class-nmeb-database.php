<?php
/**
 * NMEB Database
 *
 * Two tables:
 * - wp_nmeb_badges       — Badge definitions (slug, name, icon, criteria)
 * - wp_nmeb_user_badges  — Awarded badges (user_id ↔ badge_id with award metadata)
 *
 * @version 1.0.0
 */
if ( ! defined( 'ABSPATH' ) ) exit;

class NMEB_Database {

    public static function init() {
        // Nothing to register on init - tables created on activation
    }

    /**
     * Returns prefixed table name
     */
    public static function table( $name ) {
        global $wpdb;
        return $wpdb->prefix . 'nmeb_' . $name;
    }

    /**
     * Create / update tables (called on activation)
     */
    public static function install() {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        $charset_collate = $wpdb->get_charset_collate();

        // === BADGES TABLE — definitions ===
        $sql_badges = "CREATE TABLE " . self::table( 'badges' ) . " (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            slug VARCHAR(60) NOT NULL,
            name VARCHAR(120) NOT NULL,
            icon VARCHAR(20) DEFAULT NULL,
            color VARCHAR(20) DEFAULT '#10B981',
            badge_type VARCHAR(40) NOT NULL DEFAULT 'expert_achievement',
            tier_rank INT(11) DEFAULT 0,
            description TEXT DEFAULT NULL,
            criteria_json TEXT DEFAULT NULL,
            is_admin_only TINYINT(1) DEFAULT 0,
            is_visible TINYINT(1) DEFAULT 1,
            display_order INT(11) DEFAULT 100,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            UNIQUE KEY slug (slug),
            KEY badge_type (badge_type),
            KEY display_order (display_order)
        ) $charset_collate;";

        // === USER_BADGES TABLE — awarded badges ===
        $sql_user_badges = "CREATE TABLE " . self::table( 'user_badges' ) . " (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id BIGINT(20) UNSIGNED NOT NULL,
            badge_id BIGINT(20) UNSIGNED NOT NULL,
            awarded_by VARCHAR(20) NOT NULL DEFAULT 'auto',
            awarded_by_admin_id BIGINT(20) UNSIGNED DEFAULT NULL,
            awarded_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            expires_at DATETIME DEFAULT NULL,
            notes TEXT DEFAULT NULL,
            is_revoked TINYINT(1) DEFAULT 0,
            revoked_at DATETIME DEFAULT NULL,
            revoked_by_admin_id BIGINT(20) UNSIGNED DEFAULT NULL,
            revoked_reason TEXT DEFAULT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY unique_user_badge (user_id, badge_id),
            KEY user_id (user_id),
            KEY badge_id (badge_id),
            KEY is_revoked (is_revoked),
            KEY awarded_at (awarded_at)
        ) $charset_collate;";

        dbDelta( $sql_badges );
        dbDelta( $sql_user_badges );

        NMEB_Logger::info( 'Database tables created/updated', array( 'version' => NMEB_DB_VERSION ) );
    }

    /**
     * Drop tables (only used during uninstall, never deactivation)
     */
    public static function uninstall() {
        global $wpdb;
        $wpdb->query( "DROP TABLE IF EXISTS " . self::table( 'user_badges' ) );
        $wpdb->query( "DROP TABLE IF EXISTS " . self::table( 'badges' ) );
        delete_option( 'nmeb_version' );
        delete_option( 'nmeb_db_version' );
    }
}
