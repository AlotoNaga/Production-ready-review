<?php
/**
 * NMEB Display v2.0
 *
 * Premium badge rendering:
 * - Custom SVG icons (via NMEB_Icons class)
 * - Circular badge chips with subtle backgrounds
 * - Hover tooltips with description
 * - Verified/Top Pro get special glow
 * - Responsive sizing
 *
 * @version 2.0.0
 */
if ( ! defined( 'ABSPATH' ) ) exit;

class NMEB_Display {

    public static function init() {
        add_filter( 'nmep_expert_profile_after_name',  array( __CLASS__, 'append_expert_badges_to_profile' ), 10, 2 );
        add_filter( 'nmep_service_card_after_expert',  array( __CLASS__, 'append_expert_badges_to_card' ), 10, 2 );
        add_filter( 'nmep_review_after_buyer_name',    array( __CLASS__, 'append_buyer_badges_to_review' ), 10, 2 );
    }

    /* ============================================================
       PUBLIC API — render badge chips (SVG version)
       ============================================================ */

    /**
     * Render badges for a user — premium SVG chips
     *
     * @param int   $user_id
     * @param array $args  Options:
     *   'limit'          => max badges (default 5)
     *   'size'           => 'sm'(20) | 'md'(28) | 'lg'(36) — icon size in px
     *   'show_label'     => bool (default false for sm, true for md/lg)
     *   'badge_type'     => filter by type
     *   'layout'         => 'inline' | 'stack' (inline = horizontal, stack = vertical cards)
     */
    public static function render_user_badges( $user_id, $args = array() ) {
        $defaults = array(
            'limit'          => 5,
            'size'           => 'sm',
            'show_label'     => null,
            'badge_type'     => '',
            'layout'         => 'inline',
            'priority_first' => array( 'verified_expert', 'top_pro', 'pro_expert', 'founding_expert' ),
        );
        $args = wp_parse_args( $args, $defaults );

        // Auto show_label based on size if not specified
        if ( $args['show_label'] === null ) {
            $args['show_label'] = in_array( $args['size'], array( 'md', 'lg' ), true );
        }

        $badges = NMEB_Engine::get_user_badges( $user_id );
        if ( empty( $badges ) ) return '';

        // Filter by type
        if ( $args['badge_type'] ) {
            $badges = array_filter( $badges, function( $b ) use ( $args ) {
                return $b->badge_type === $args['badge_type'];
            } );
        }

        // Sort priority first
        usort( $badges, function( $a, $b ) use ( $args ) {
            $a_pri = array_search( $a->slug, $args['priority_first'], true );
            $b_pri = array_search( $b->slug, $args['priority_first'], true );
            if ( $a_pri === false ) $a_pri = PHP_INT_MAX;
            if ( $b_pri === false ) $b_pri = PHP_INT_MAX;
            if ( $a_pri !== $b_pri ) return $a_pri - $b_pri;
            return (int) $a->display_order - (int) $b->display_order;
        } );

        if ( $args['limit'] > 0 ) {
            $badges = array_slice( $badges, 0, $args['limit'] );
        }
        if ( empty( $badges ) ) return '';

        // Sizing map
        $sizes = array(
            'sm' => array( 'icon' => 18, 'font' => '0.7rem',  'pad' => '3px 8px',   'gap' => '4px' ),
            'md' => array( 'icon' => 24, 'font' => '0.8rem',  'pad' => '5px 12px',  'gap' => '6px' ),
            'lg' => array( 'icon' => 32, 'font' => '0.9rem',  'pad' => '6px 14px',  'gap' => '8px' ),
        );
        $sz = $sizes[ $args['size'] ] ?? $sizes['sm'];

        if ( $args['layout'] === 'stack' ) {
            return self::render_stacked( $badges, $sz, $args );
        }

        ob_start();
        ?>
        <span class="nmeb-badges-row" style="display:inline-flex;gap:<?php echo $sz['gap']; ?>;flex-wrap:wrap;align-items:center;vertical-align:middle;">
            <?php foreach ( $badges as $badge ) : ?>
                <?php echo self::render_single_chip( $badge, $sz, $args['show_label'] ); ?>
            <?php endforeach; ?>
        </span>
        <?php
        return ob_get_clean();
    }

    /**
     * Render ONE badge chip with SVG icon
     */
    public static function render_single_chip( $badge, $sz = null, $show_label = true ) {
        if ( ! $badge ) return '';

        if ( ! $sz ) {
            $sz = array( 'icon' => 24, 'font' => '0.8rem', 'pad' => '5px 12px', 'gap' => '6px' );
        }

        $color     = esc_attr( $badge->color ?? '#6B7280' );
        $slug      = esc_attr( $badge->slug ?? '' );
        $name_html = esc_html( $badge->name ?? '' );
        $name_attr = esc_attr( $badge->name ?? '' );
        $desc_attr = esc_attr( wp_strip_all_tags( $badge->description ?? '' ) );

        // Get SVG icon
        $svg = NMEB_Icons::get( $badge->slug, $sz['icon'], $badge->color );

        // Special glow classes
        $special = '';
        if ( in_array( $badge->slug, array( 'verified_expert', 'verified_buyer' ), true ) ) {
            $special = 'nmeb-verified';
        } elseif ( in_array( $badge->slug, array( 'top_pro' ), true ) ) {
            $special = 'nmeb-top-pro';
        }

        ob_start();
        ?>
        <span class="nmeb-chip <?php echo esc_attr( $special ); ?>"
              data-badge="<?php echo $slug; ?>"
              title="<?php echo $name_attr . ' — ' . $desc_attr; ?>"
              style="display:inline-flex;align-items:center;gap:5px;
                     background:<?php echo $color; ?>0D;
                     border:1.5px solid <?php echo $color; ?>30;
                     padding:<?php echo esc_attr( $sz['pad'] ); ?>;
                     border-radius:100px;
                     font-size:<?php echo esc_attr( $sz['font'] ); ?>;
                     font-weight:600;
                     color:<?php echo $color; ?>;
                     line-height:1;
                     white-space:nowrap;
                     transition:all 0.2s ease;
                     cursor:default;">
            <?php echo $svg; ?>
            <?php if ( $show_label ) : ?>
                <span><?php echo $name_html; ?></span>
            <?php endif; ?>
        </span>
        <?php
        return ob_get_clean();
    }

    /**
     * Render stacked badge cards (used in profile, all badges page)
     */
    private static function render_stacked( $badges, $sz, $args ) {
        ob_start();
        ?>
        <div class="nmeb-badges-stack" style="display:flex;flex-direction:column;gap:8px;">
            <?php foreach ( $badges as $badge ) :
                $svg = NMEB_Icons::get( $badge->slug, 36, $badge->color );
                $color = esc_attr( $badge->color );
            ?>
                <div class="nmeb-badge-card" style="display:flex;align-items:center;gap:14px;padding:12px 16px;border-radius:12px;background:<?php echo $color; ?>08;border:1.5px solid <?php echo $color; ?>20;transition:all 0.2s;">
                    <div style="flex-shrink:0;"><?php echo $svg; ?></div>
                    <div style="min-width:0;">
                        <div style="font-weight:700;font-size:0.95rem;color:<?php echo $color; ?>;line-height:1.2;"><?php echo esc_html( $badge->name ); ?></div>
                        <div style="font-size:0.8rem;color:#6B7280;line-height:1.4;margin-top:2px;"><?php echo esc_html( $badge->description ); ?></div>
                        <?php if ( ! empty( $badge->awarded_at ) ) : ?>
                            <div style="font-size:0.7rem;color:#9CA3AF;margin-top:4px;">Earned <?php echo esc_html( human_time_diff( strtotime( $badge->awarded_at ), time() ) ); ?> ago</div>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
        <?php
        return ob_get_clean();
    }

    /**
     * Render a single badge as a chip (used in admin tables etc.)
     * Replaces the v1 emoji version
     */
    public static function render_badge_chip( $badge, $size = 'sm', $show_label = true ) {
        $sizes = array(
            'sm' => array( 'icon' => 18, 'font' => '0.75rem', 'pad' => '3px 10px', 'gap' => '4px' ),
            'md' => array( 'icon' => 24, 'font' => '0.85rem', 'pad' => '4px 12px', 'gap' => '6px' ),
            'lg' => array( 'icon' => 32, 'font' => '0.95rem', 'pad' => '6px 14px', 'gap' => '8px' ),
        );
        $sz = $sizes[ $size ] ?? $sizes['sm'];
        return self::render_single_chip( $badge, $sz, $show_label );
    }

    /* ============================================================
       NMEP FILTER HOOKS
       ============================================================ */

    public static function append_expert_badges_to_profile( $html, $expert ) {
        if ( ! $expert || empty( $expert->user_id ) ) return $html;
        $badges_html = self::render_user_badges( $expert->user_id, array(
            'limit' => 6, 'size' => 'md', 'show_label' => true,
        ) );
        return $html . ( $badges_html ? '<div style="margin-top:10px;">' . $badges_html . '</div>' : '' );
    }

    public static function append_expert_badges_to_card( $html, $expert_user_id ) {
        if ( ! $expert_user_id ) return $html;
        $badges_html = self::render_user_badges( (int) $expert_user_id, array(
            'limit' => 3, 'size' => 'sm', 'show_label' => false,
        ) );
        return $html . $badges_html;
    }

    public static function append_buyer_badges_to_review( $html, $buyer_user_id ) {
        if ( ! $buyer_user_id ) return $html;
        $badges_html = self::render_user_badges( (int) $buyer_user_id, array(
            'limit' => 2, 'size' => 'sm', 'show_label' => false, 'badge_type' => 'buyer_level',
        ) );
        return $html . ( $badges_html ? ' ' . $badges_html : '' );
    }

    /* ============================================================
       BUYER PROGRESS BAR
       ============================================================ */

    public static function render_buyer_progress( $user_id ) {
        $metrics = NMEB_Engine::compute_buyer_metrics( $user_id );
        $orders  = $metrics['completed_orders'];

        if ( $orders === 0 ) {
            return '<div style="background:#F0FDF4;border:1.5px solid #BBF7D0;border-radius:12px;padding:20px;text-align:center;color:#065F46;">
                ' . NMEB_Icons::get( 'new_buyer', 40 ) . '
                <p style="margin:12px 0 0;font-weight:600;">Complete your first order to start earning badges!</p>
            </div>';
        }

        $next = null;
        if ( $orders < 3 ) {
            $next = array( 'name' => 'Active Buyer', 'slug' => 'active_buyer', 'remaining' => 3 - $orders, 'pct' => round( ( $orders / 3 ) * 100 ) );
        } elseif ( $orders < 10 ) {
            $next = array( 'name' => 'Power Buyer', 'slug' => 'power_buyer', 'remaining' => 10 - $orders, 'pct' => round( ( $orders / 10 ) * 100 ) );
        } else {
            return '<div style="background:#F0FDF4;border:1.5px solid #BBF7D0;border-radius:12px;padding:20px;text-align:center;">
                ' . NMEB_Icons::get( 'power_buyer', 48 ) . '
                <p style="margin:12px 0 0;font-weight:700;color:#065F46;">You\'ve reached the highest buyer level — Power Buyer!</p>
            </div>';
        }

        ob_start();
        ?>
        <div style="background:#FFFBEB;border:1.5px solid #FDE68A;border-radius:12px;padding:20px;">
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;">
                <div style="display:flex;align-items:center;gap:8px;">
                    <?php echo NMEB_Icons::get( $next['slug'], 28 ); ?>
                    <strong style="color:#0F2419;">Next: <?php echo esc_html( $next['name'] ); ?></strong>
                </div>
                <span style="font-size:0.85rem;color:#92400E;"><?php echo (int) $next['remaining']; ?> more order<?php echo $next['remaining'] === 1 ? '' : 's'; ?></span>
            </div>
            <div style="background:#FDE68A;border-radius:50px;height:10px;overflow:hidden;">
                <div style="background:linear-gradient(90deg,#10B981,#D4A843);width:<?php echo (int) $next['pct']; ?>%;height:100%;border-radius:50px;transition:width 0.5s;"></div>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
}
