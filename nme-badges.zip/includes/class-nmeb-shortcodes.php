<?php
/**
 * NMEB Shortcodes
 *
 * Public shortcodes for placing badges in theme/pages:
 * [nmeb_user_badges user_id="123"]
 * [nmeb_my_badges]                (current logged-in user)
 * [nmeb_buyer_progress]           (current logged-in user)
 * [nmeb_all_badges]               (showcase all available badges)
 *
 * @version 1.0.0
 */
if ( ! defined( 'ABSPATH' ) ) exit;

class NMEB_Shortcodes {

    public static function init() {
        add_shortcode( 'nmeb_user_badges',     array( __CLASS__, 'sc_user_badges' ) );
        add_shortcode( 'nmeb_my_badges',       array( __CLASS__, 'sc_my_badges' ) );
        add_shortcode( 'nmeb_buyer_progress',  array( __CLASS__, 'sc_buyer_progress' ) );
        add_shortcode( 'nmeb_all_badges',      array( __CLASS__, 'sc_all_badges' ) );
    }

    public static function sc_user_badges( $atts ) {
        $atts = shortcode_atts( array(
            'user_id'    => 0,
            'limit'      => 6,
            'size'       => 'md',
            'show_label' => 'true',
        ), $atts );

        $user_id = (int) $atts['user_id'];
        if ( $user_id <= 0 ) return '';

        return NMEB_Display::render_user_badges( $user_id, array(
            'limit'      => (int) $atts['limit'],
            'size'       => sanitize_key( $atts['size'] ),
            'show_label' => filter_var( $atts['show_label'], FILTER_VALIDATE_BOOLEAN ),
        ) );
    }

    public static function sc_my_badges( $atts ) {
        if ( ! is_user_logged_in() ) {
            return '<p style="color:#6B7280;">Log in to see your badges.</p>';
        }
        $atts = shortcode_atts( array(
            'limit'      => 10,
            'size'       => 'md',
            'show_label' => 'true',
        ), $atts );

        $badges_html = NMEB_Display::render_user_badges( get_current_user_id(), array(
            'limit'      => (int) $atts['limit'],
            'size'       => sanitize_key( $atts['size'] ),
            'show_label' => filter_var( $atts['show_label'], FILTER_VALIDATE_BOOLEAN ),
        ) );

        if ( ! $badges_html ) {
            return '<p style="color:#6B7280;">You haven\'t earned any badges yet. Complete an order to start earning recognition.</p>';
        }

        return '<div class="nmeb-my-badges-wrapper">' . $badges_html . '</div>';
    }

    public static function sc_buyer_progress( $atts ) {
        if ( ! is_user_logged_in() ) {
            return '<p style="color:#6B7280;">Log in to see your progress.</p>';
        }
        return NMEB_Display::render_buyer_progress( get_current_user_id() );
    }

    /**
     * Showcase all available badges (good for an /about-badges/ page)
     * v2.0: Uses custom SVG icons + premium card design
     */
    public static function sc_all_badges( $atts ) {
        $badges = NMEB_Badges::get_all();
        if ( empty( $badges ) ) return '<p>No badges defined yet.</p>';

        // Group by type
        $grouped = array(
            'expert_special'      => array( 'title' => 'Trust & Verification', 'badges' => array() ),
            'expert_level'        => array( 'title' => 'Expert Levels',        'badges' => array() ),
            'expert_achievement'  => array( 'title' => 'Expert Achievements',  'badges' => array() ),
            'buyer_level'         => array( 'title' => 'Buyer Levels',         'badges' => array() ),
            'buyer_achievement'   => array( 'title' => 'Buyer Recognitions',   'badges' => array() ),
        );
        foreach ( $badges as $b ) {
            if ( isset( $grouped[ $b->badge_type ] ) ) {
                $grouped[ $b->badge_type ]['badges'][] = $b;
            }
        }

        ob_start();
        ?>
        <div class="nmeb-all-badges-showcase">
            <?php foreach ( $grouped as $group ) : if ( empty( $group['badges'] ) ) continue; ?>
                <h3><?php echo esc_html( $group['title'] ); ?></h3>
                <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(260px, 1fr)); gap: 16px;">
                    <?php foreach ( $group['badges'] as $badge ) : ?>
                        <div class="nmeb-showcase-card" style="border-top: 4px solid <?php echo esc_attr( $badge->color ); ?>;">
                            <div style="margin-bottom: 14px;">
                                <?php echo NMEB_Icons::get( $badge->slug, 48, $badge->color ); ?>
                            </div>
                            <div style="font-weight: 700; font-size: 1.05rem; color: <?php echo esc_attr( $badge->color ); ?>; margin-bottom: 8px; line-height: 1.2;">
                                <?php echo esc_html( $badge->name ); ?>
                            </div>
                            <div style="font-size: 0.88rem; color: #4B5563; line-height: 1.55;">
                                <?php echo esc_html( $badge->description ); ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endforeach; ?>
        </div>
        <?php
        return ob_get_clean();
    }
}
