<?php
/**
 * NMEB Badges — definitions
 *
 * 20 badges total:
 * - 5 Expert Level   (mutually exclusive: New → Rising → Pro → Top Pro + Verified)
 * - 8 Expert Achievement (accumulative)
 * - 7 Buyer Badges   (mix of level + achievement)
 *
 * Badge types:
 *   expert_level         — Mutually exclusive level (one at a time)
 *   expert_achievement   — Accumulative (can have multiple)
 *   expert_special       — Trust/verification (Verified Expert)
 *   buyer_level          — Buyer level
 *   buyer_achievement    — Buyer achievement
 *
 * @version 1.0.0
 */
if ( ! defined( 'ABSPATH' ) ) exit;

class NMEB_Badges {

    public static function init() {
        // Run seed if no badges exist
        add_action( 'admin_init', array( __CLASS__, 'maybe_seed' ) );
    }

    /**
     * Seed default badges if table is empty (called on activation + admin_init safety check)
     */
    public static function maybe_seed() {
        global $wpdb;
        $table = NMEB_Database::table( 'badges' );
        $count = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $table" );
        if ( $count === 0 ) {
            self::seed_defaults();
        }
    }

    /**
     * Seed all 20 default badges
     */
    public static function seed_defaults() {
        global $wpdb;
        $table = NMEB_Database::table( 'badges' );

        $badges = self::get_default_badge_definitions();

        $inserted = 0;
        foreach ( $badges as $badge ) {
            // Check if already exists (idempotent)
            $exists = $wpdb->get_var( $wpdb->prepare(
                "SELECT id FROM $table WHERE slug = %s",
                $badge['slug']
            ) );
            if ( $exists ) continue;

            $result = $wpdb->insert( $table, array(
                'slug'          => $badge['slug'],
                'name'          => $badge['name'],
                'icon'          => $badge['icon'],
                'color'         => $badge['color'],
                'badge_type'    => $badge['badge_type'],
                'tier_rank'     => $badge['tier_rank'] ?? 0,
                'description'   => $badge['description'],
                'criteria_json' => isset( $badge['criteria'] ) ? wp_json_encode( $badge['criteria'] ) : null,
                'is_admin_only' => $badge['is_admin_only'] ?? 0,
                'is_visible'    => 1,
                'display_order' => $badge['display_order'] ?? 100,
            ) );
            if ( $result ) $inserted++;
        }

        if ( $inserted > 0 ) {
            NMEB_Logger::info( "Seeded {$inserted} default badges" );
        }
    }

    /**
     * Get full list of all badge definitions
     */
    public static function get_default_badge_definitions() {
        // Icon marks are rendered as inline SVG from the slug (see NMEB_Icons).
        // The `icon` column is kept as a short ASCII mnemonic purely for
        // backend identification (admin exports, legacy fallbacks). It is
        // NEVER rendered to users.
        return array(

            /* ============================================================
               EXPERT LEVELS — hex seals (mutually exclusive ladder)
               ============================================================ */
            array(
                'slug'          => 'new_expert',
                'name'          => 'New Expert',
                'icon'          => 'N',
                'color'         => '#10B981',
                'badge_type'    => 'expert_level',
                'tier_rank'     => 1,
                'description'   => 'Newly approved on Nagaland Me Experts. Welcome to the marketplace.',
                'criteria'      => array( 'auto' => true, 'on_approval' => true ),
                'display_order' => 10,
            ),
            array(
                'slug'          => 'rising_expert',
                'name'          => 'Rising Expert',
                'icon'          => 'R',
                'color'         => '#0A7558',
                'badge_type'    => 'expert_level',
                'tier_rank'     => 2,
                'description'   => 'Three or more completed orders, 4.5+ rating, and an 80% response rate. Momentum building.',
                'criteria'      => array(
                    'min_completed_orders' => 3,
                    'min_avg_rating'       => 4.5,
                    'min_response_rate'    => 80,
                ),
                'display_order' => 20,
            ),
            array(
                'slug'          => 'pro_expert',
                'name'          => 'Pro Expert',
                'icon'          => 'P',
                'color'         => '#D4A843',
                'badge_type'    => 'expert_level',
                'tier_rank'     => 3,
                'description'   => 'Fifteen or more completed orders, 4.7+ rating, 90% response rate, and three months of tenure.',
                'criteria'      => array(
                    'min_completed_orders' => 15,
                    'min_avg_rating'       => 4.7,
                    'min_response_rate'    => 90,
                    'min_days_active'      => 90,
                ),
                'display_order' => 30,
            ),
            array(
                'slug'          => 'top_pro',
                'name'          => 'Top Pro',
                'icon'          => 'TP',
                'color'         => '#1F2937',
                'badge_type'    => 'expert_level',
                'tier_rank'     => 4,
                'description'   => 'The marketplace\'s highest distinction — 40+ orders, 4.8+ rating, 95% response, and editorial review.',
                'criteria'      => array(
                    'min_completed_orders' => 40,
                    'min_avg_rating'       => 4.8,
                    'min_response_rate'    => 95,
                    'requires_admin_approval' => true,
                ),
                'is_admin_only' => 1,
                'display_order' => 40,
            ),

            /* ============================================================
               TRUST — crest shields
               ============================================================ */
            array(
                'slug'          => 'verified_expert',
                'name'          => 'Verified Expert',
                'icon'          => 'VE',
                'color'         => '#0A7558',
                'badge_type'    => 'expert_special',
                'tier_rank'     => 0,
                'description'   => 'KYC-verified identity with five or more completed orders. The trust mark buyers look for.',
                'criteria'      => array(
                    'min_completed_orders' => 5,
                    'requires_kyc'         => true,
                ),
                'display_order' => 5,
            ),

            /* ============================================================
               EXPERT ACHIEVEMENTS — medallions (accumulative)
               ============================================================ */
            array(
                'slug'          => 'first_sale',
                'name'          => 'First Sale',
                'icon'          => '1',
                'color'         => '#10B981',
                'badge_type'    => 'expert_achievement',
                'description'   => 'Completed a first order. The most meaningful milestone for any new expert.',
                'criteria'      => array( 'min_completed_orders' => 1 ),
                'display_order' => 100,
            ),
            array(
                'slug'          => 'quick_responder',
                'name'          => 'Quick Responder',
                'icon'          => 'QR',
                'color'         => '#0A7558',
                'badge_type'    => 'expert_achievement',
                'description'   => 'Sustained a 90% or higher response rate over the past thirty days.',
                'criteria'      => array( 'min_response_rate_30d' => 90 ),
                'display_order' => 110,
            ),
            array(
                'slug'          => 'five_star_streak',
                'name'          => 'Five-Star Streak',
                'icon'          => '5S',
                'color'         => '#D4A843',
                'badge_type'    => 'expert_achievement',
                'description'   => 'Ten consecutive five-star reviews without interruption.',
                'criteria'      => array( 'consecutive_5_star' => 10 ),
                'display_order' => 120,
            ),
            array(
                'slug'          => 'founding_expert',
                'name'          => 'Founding Expert',
                'icon'          => 'FE',
                'color'         => '#1F2937',
                'badge_type'    => 'expert_achievement',
                'description'   => 'One of the first fifty experts to join the marketplace. Permanent distinction.',
                'criteria'      => array( 'auto' => true, 'first_n_experts' => 50 ),
                'display_order' => 50,
            ),
            array(
                'slug'          => 'on_time_master',
                'name'          => 'On-Time Master',
                'icon'          => 'OT',
                'color'         => '#0A7558',
                'badge_type'    => 'expert_achievement',
                'description'   => 'One hundred percent on-time delivery across the past thirty days.',
                'criteria'      => array( 'on_time_rate_30d' => 100 ),
                'display_order' => 130,
            ),
            array(
                'slug'          => 'great_communicator',
                'name'          => 'Great Communicator',
                'icon'          => 'GC',
                'color'         => '#475569',
                'badge_type'    => 'expert_achievement',
                'description'   => 'A 95% response rate paired with a 4.9+ average rating. Clients feel heard.',
                'criteria'      => array(
                    'min_response_rate' => 95,
                    'min_avg_rating'    => 4.9,
                ),
                'display_order' => 140,
            ),
            array(
                'slug'          => 'niche_expert',
                'name'          => 'Niche Expert',
                'icon'          => 'NE',
                'color'         => '#0A7558',
                'badge_type'    => 'expert_achievement',
                'description'   => 'Twenty or more completed orders inside a single category. A recognised specialist.',
                'criteria'      => array( 'min_orders_in_category' => 20 ),
                'display_order' => 150,
            ),
            array(
                'slug'          => 'pan_india_reach',
                'name'          => 'Pan-India Reach',
                'icon'          => 'PI',
                'color'         => '#475569',
                'badge_type'    => 'expert_achievement',
                'description'   => 'Served clients from five or more Indian states. Reputation travels.',
                'criteria'      => array( 'min_unique_buyer_states' => 5 ),
                'display_order' => 160,
            ),

            /* ============================================================
               BUYER BADGES — medallions + shield
               ============================================================ */
            array(
                'slug'          => 'new_buyer',
                'name'          => 'New Buyer',
                'icon'          => 'N',
                'color'         => '#10B981',
                'badge_type'    => 'buyer_level',
                'tier_rank'     => 1,
                'description'   => 'Welcomed to Nagaland Me Experts after a first order.',
                'criteria'      => array( 'auto' => true, 'on_first_order' => true ),
                'display_order' => 200,
            ),
            array(
                'slug'          => 'active_buyer',
                'name'          => 'Active Buyer',
                'icon'          => 'A',
                'color'         => '#0A7558',
                'badge_type'    => 'buyer_level',
                'tier_rank'     => 2,
                'description'   => 'Three or more completed orders. A regular on the marketplace.',
                'criteria'      => array( 'min_completed_orders_as_buyer' => 3 ),
                'display_order' => 210,
            ),
            array(
                'slug'          => 'power_buyer',
                'name'          => 'Power Buyer',
                'icon'          => 'P',
                'color'         => '#D4A843',
                'badge_type'    => 'buyer_level',
                'tier_rank'     => 3,
                'description'   => 'Ten or more completed orders. Among the marketplace\'s most trusted patrons.',
                'criteria'      => array( 'min_completed_orders_as_buyer' => 10 ),
                'display_order' => 220,
            ),
            array(
                'slug'          => 'verified_buyer',
                'name'          => 'Verified Buyer',
                'icon'          => 'VB',
                'color'         => '#475569',
                'badge_type'    => 'buyer_level',
                'description'   => 'Email confirmed and at least one completed order on record.',
                'criteria'      => array( 'requires_verified_email' => true, 'min_completed_orders_as_buyer' => 1 ),
                'display_order' => 205,
            ),
            array(
                'slug'          => 'loyal_customer',
                'name'          => 'Loyal Customer',
                'icon'          => 'L',
                'color'         => '#D4A843',
                'badge_type'    => 'buyer_achievement',
                'description'   => 'Three or more orders with the same expert. A real working relationship.',
                'criteria'      => array( 'min_repeat_orders_same_expert' => 3 ),
                'display_order' => 230,
            ),
            array(
                'slug'          => 'early_supporter',
                'name'          => 'Early Supporter',
                'icon'          => 'ES',
                'color'         => '#1F2937',
                'badge_type'    => 'buyer_achievement',
                'description'   => 'Among the first two hundred buyers on the marketplace. Permanent mark of early trust.',
                'criteria'      => array( 'auto' => true, 'first_n_buyers' => 200 ),
                'display_order' => 215,
            ),
            array(
                'slug'          => 'quality_reviewer',
                'name'          => 'Quality Reviewer',
                'icon'          => 'QR',
                'color'         => '#475569',
                'badge_type'    => 'buyer_achievement',
                'description'   => 'Five or more detailed reviews of fifty characters or more. Strengthens the community.',
                'criteria'      => array( 'min_detailed_reviews' => 5, 'min_review_length' => 50 ),
                'display_order' => 240,
            ),
        );
    }

    /* ============================================================
       MIGRATION HELPERS
       ============================================================ */

    /**
     * Re-align existing rows to the v2.0 palette + icon mnemonics.
     * Idempotent — safe to run on every activation / upgrade.
     */
    public static function realign_to_v2() {
        global $wpdb;
        $table = NMEB_Database::table( 'badges' );
        foreach ( self::get_default_badge_definitions() as $def ) {
            $wpdb->update( $table, array(
                'icon'  => $def['icon'],
                'color' => $def['color'],
            ), array( 'slug' => $def['slug'] ) );
        }
    }

    /* ============================================================
       BADGE QUERIES
       ============================================================ */

    /**
     * Get all badges (admin / display)
     */
    public static function get_all() {
        global $wpdb;
        $table = NMEB_Database::table( 'badges' );
        return $wpdb->get_results( "SELECT * FROM $table WHERE is_visible = 1 ORDER BY display_order ASC, id ASC" );
    }

    /**
     * Get badges by type
     */
    public static function get_by_type( $type ) {
        global $wpdb;
        $table = NMEB_Database::table( 'badges' );
        return $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM $table WHERE badge_type = %s AND is_visible = 1 ORDER BY display_order ASC, tier_rank ASC",
            $type
        ) );
    }

    /**
     * Get a single badge by slug
     */
    public static function get_by_slug( $slug ) {
        global $wpdb;
        $table = NMEB_Database::table( 'badges' );
        return $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM $table WHERE slug = %s LIMIT 1",
            $slug
        ) );
    }

    /**
     * Get a single badge by ID
     */
    public static function get_by_id( $id ) {
        global $wpdb;
        $table = NMEB_Database::table( 'badges' );
        return $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM $table WHERE id = %d LIMIT 1",
            (int) $id
        ) );
    }

    /**
     * Get all expert level badges in order of rank (for promotion logic)
     */
    public static function get_expert_levels_by_rank() {
        global $wpdb;
        $table = NMEB_Database::table( 'badges' );
        return $wpdb->get_results( "SELECT * FROM $table WHERE badge_type = 'expert_level' AND is_visible = 1 ORDER BY tier_rank ASC" );
    }
}
