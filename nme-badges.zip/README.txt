================================================================================
NAGALAND ME EXPERTS — BADGES PLUGIN v2.0.0
Premium trust & recognition badges for the Nagaland Me Experts marketplace
================================================================================

WHAT THIS PLUGIN DOES
─────────────────────
Awards 20 engraved seals and medallions to experts and buyers based on their
activity. Purpose-built for a serious B2B marketplace aesthetic.

  - Trust signals for buyers (Verified Expert, Top Pro, Founding Expert)
  - Performance recognition (response rate, on-time delivery, review quality)
  - Four-tier expert ladder (New → Rising → Pro → Top Pro)
  - Buyer recognition (loyalty, volume, review quality, early supporter)
  - Admin override — grant or revoke any badge to any user
  - Zero pay-to-win: no badge is ever purchasable

This is a standalone plugin. It reads order and review data from the
nme-payments plugin but never modifies the payment flow.

================================================================================
THE 20 BADGES
================================================================================

TRUST & VERIFICATION (1)
  Verified Expert        — KYC verified + 5+ completed orders (auto)

EXPERT LEVELS (4 — mutually exclusive ladder, auto-promoted)
  New Expert             — Newly approved on the marketplace (default)
  Rising Expert          — 3+ orders, 4.5+ rating, 80%+ response rate
  Pro Expert             — 15+ orders, 4.7+ rating, 90%+ response, 90+ days
  Top Pro                — Admin-curated honour tier (manual award only)

EXPERT ACHIEVEMENTS (8 — cumulative, never revoked)
  First Sale             — Complete first paid order
  Quick Responder        — 90%+ response rate over a 30-day window
  5-Star Streak          — 10 consecutive 5-star reviews
  Founding Expert        — One of the first 50 approved experts
  On-Time Master         — 100% on-time delivery across a 30-day window
  Great Communicator     — 95%+ response + 4.9+ rating + 5+ orders
  Niche Expert           — 20+ orders in a single category
  Pan-India Reach        — Buyers from 5+ Indian states (admin grant)

BUYER RECOGNITIONS (7 — levels and achievements)
  New Buyer              — First order placed
  Active Buyer           — 3+ completed orders
  Power Buyer            — 10+ completed orders
  Verified Buyer         — Email verified + 1+ completed order
  Loyal Customer         — 3+ orders with the same expert
  Early Supporter        — One of the first 200 buyers
  Quality Reviewer       — 5+ detailed reviews (50+ characters each)

================================================================================
INSTALLATION
================================================================================

PREREQUISITES
  - Nagaland Me Experts — Payments plugin installed and active
    (This plugin reads from payment tables; it will not activate without it.)

INSTALLATION STEPS
  1. WP Admin → Plugins → Add New → Upload Plugin
  2. Upload nme-badges.zip
  3. Install Now → Activate
  4. (Optional) WP Admin → NME Badges → Run Auto-Award Now — scans all existing
     experts and buyers and awards every badge they already qualify for.

WHAT HAPPENS ON ACTIVATION
  - Creates 2 database tables (wp_nmeb_badges + wp_nmeb_user_badges)
  - Seeds 20 default badge definitions
  - Schedules the daily auto-award cron
  - Hooks into payment events for instant awards on order completion,
    auto-release, review submission, and expert approval.

================================================================================
ADMIN INTERFACE
================================================================================

Access at: WP Admin → NME Badges

DASHBOARD
  - Stat cards (total badges, total awards, awards in last 7 days)
  - Last cron run + next scheduled run
  - "Run Auto-Award Now" button
  - Most-awarded badges chart

AWARD BADGE
  - Pick a user
  - Pick a badge from a visual gallery
  - Add a reason (logged in the audit trail)
  - Award

ALL BADGES
  - Lists all 20 badge definitions
  - Shows award count and auto-vs-admin status

USER BADGES
  - Search by user ID or email
  - See all active badges, revoke individually
  - Grant additional badges to that user

================================================================================
FRONTEND DISPLAY
================================================================================

Badges automatically appear at these locations (via filter hooks):

  1. Expert profile — next to the expert's name.
  2. Service cards on browse pages — compact badge row.
  3. Single service page — in the expert mini-card.
  4. Reviews — buyer level badge next to reviewer name.
  5. Buyer "My orders" page — own badges plus progress bar.

================================================================================
SHORTCODES
================================================================================

[nmeb_user_badges user_id="123"]
  Render badges for any user.

[nmeb_my_badges]
  Render the current logged-in user's badges.

[nmeb_buyer_progress]
  Render "X more orders to unlock next badge" progress bar.

[nmeb_all_badges]
  Showcase every badge (ideal for a public /badges/ page).

================================================================================
HOW BADGES ARE AWARDED
================================================================================

AUTOMATIC
  - Daily cron scans every user.
  - Event-triggered on order completion, auto-release, expert approval,
    and review submission.

MANUAL
  - Admin can grant any badge to any user.
  - Badges with is_admin_only = 1 (Top Pro, Pan-India Reach) are admin-only.
  - Manual grants are logged with admin ID and reason.

PROMOTION LOGIC (Expert Levels)
  When an expert is promoted (New → Rising → Pro), the previous level badge
  is automatically revoked. An expert always holds exactly one level badge.
  Achievement badges are never revoked automatically — once earned, kept.

================================================================================
TECHNICAL DETAILS
================================================================================

DATABASE TABLES
  wp_nmeb_badges        — Badge definitions (20 rows, seeded on activation)
  wp_nmeb_user_badges   — Awarded badges (one row per user_id + badge_id)

DEPENDENCIES
  - nme-payments plugin (required for orders, reviews, ratings)
  - WordPress 6.0+
  - PHP 7.4+

ICON SYSTEM
  Every badge ships with an inline SVG mark — hex seals, crest shields,
  and medallions rendered in a restrained emerald / forest / gold / graphite
  palette. No emoji characters anywhere in the UI.

SECURITY
  - All admin actions gated by manage_options capability
  - WordPress nonces on every form
  - Inputs sanitized via WP helpers
  - Output escaped via esc_html / esc_attr / esc_url

================================================================================
CUSTOMIZATION HOOKS
================================================================================

ACTION HOOKS
  do_action( 'nmeb_badge_awarded', $user_id, $badge, $awarded_by );
  do_action( 'nmeb_badge_revoked', $user_id, $badge );

FILTER HOOKS
  apply_filters( 'nmep_expert_profile_after_name', $html, $expert );
  apply_filters( 'nmep_service_card_after_expert', $html, $user_id );
  apply_filters( 'nmep_review_after_buyer_name',   $html, $user_id );

PUBLIC HELPERS
  nmeb_get_user_badges( $user_id )         // array of badge objects
  nmeb_render_user_badges( $user_id )      // HTML
  nmeb_user_has_badge( $user_id, 'slug' )  // bool

================================================================================
RECOMMENDED ACTIONS AFTER INSTALL
================================================================================

  1. Run Auto-Award Now to retro-award every eligible user.
  2. Grant "Founding Expert" to your first 50 approved experts
     (the system auto-detects — nothing manual needed).
  3. Grant "Verified Expert" manually to your most trusted experts.
  4. Publish a /badges/ page with [nmeb_all_badges] as a marketing showcase.
  5. Announce the programme to experts and buyers.

================================================================================
PLUGIN INFO
================================================================================

Plugin Name:    Nagaland Me Experts — Badges
Version:        2.0.0
Author:         Nagaland Me
Requires:       nme-payments plugin
WordPress:      6.0+
PHP:            7.4+

================================================================================
SUPPORT
================================================================================

If badges are not being awarded automatically:
  1. Check NME Badges → Dashboard → "Last cron run" timestamp.
  2. If "Never run yet", click "Run Auto-Award Now".
  3. Confirm the nme-payments plugin is installed and active.
  4. Inspect wp-content/uploads/nmeb-logs/ when WP_DEBUG is enabled.

If a user should have a badge but does not:
  1. Go to NME Badges → User Badges.
  2. Search by email.
  3. Grant manually with a reason.

================================================================================

Built with care for Nagaland Me Experts.
Free, admin-controllable, no paid tiers.
