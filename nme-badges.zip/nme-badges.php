<?php
/**
 * Plugin Name:       Nagaland Me Experts — Badges
 * Plugin URI:        https://experts.nagaland.me
 * Description:       Premium trust & recognition badges for the Nagaland Me marketplace. Auto-awards expert level seals (New / Rising / Pro / Top Pro), achievement medallions, and buyer recognitions. Admin can manually grant or revoke any badge.
 * Version:           2.0.0
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            Nagaland Me
 * Author URI:        https://nagaland.me
 * License:           GPL v2 or later
 * Text Domain:       nme-badges
 *
 * @package NMEBadges
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'NMEB_VERSION',         '2.0.0' );
define( 'NMEB_DB_VERSION',      '2.0.0' );
define( 'NMEB_PLUGIN_FILE',     __FILE__ );
define( 'NMEB_PLUGIN_DIR',      plugin_dir_path( __FILE__ ) );
define( 'NMEB_PLUGIN_URL',      plugin_dir_url( __FILE__ ) );
define( 'NMEB_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );

/* ============================================================
   DEPENDENCY CHECK — must have nme-payments installed
   ============================================================ */
register_activation_hook( __FILE__, 'nmeb_check_dependencies' );

function nmeb_check_dependencies() {
    if ( ! class_exists( 'NMEP_Database' ) ) {
        deactivate_plugins( plugin_basename( __FILE__ ) );
        wp_die(
            '<h1>Cannot Activate Nagaland Me Experts — Badges</h1>' .
            '<p>This plugin requires <strong>Nagaland Me Experts — Payments</strong> to be installed and active first.</p>' .
            '<p>Please install/activate the payments plugin, then try again.</p>' .
            '<p><a href="' . esc_url( admin_url( 'plugins.php' ) ) . '">← Back to Plugins</a></p>',
            'Plugin Dependency Missing',
            array( 'response' => 200, 'back_link' => true )
        );
    }
}

/* ============================================================
   AUTOLOAD ALL CLASSES
   ============================================================ */
require_once NMEB_PLUGIN_DIR . 'includes/class-nmeb-logger.php';
require_once NMEB_PLUGIN_DIR . 'includes/class-nmeb-database.php';
require_once NMEB_PLUGIN_DIR . 'includes/class-nmeb-badges.php';
require_once NMEB_PLUGIN_DIR . 'includes/class-nmeb-icons.php';
require_once NMEB_PLUGIN_DIR . 'includes/class-nmeb-engine.php';
require_once NMEB_PLUGIN_DIR . 'includes/class-nmeb-display.php';
require_once NMEB_PLUGIN_DIR . 'includes/class-nmeb-cron.php';
require_once NMEB_PLUGIN_DIR . 'includes/class-nmeb-shortcodes.php';

if ( is_admin() ) {
    require_once NMEB_PLUGIN_DIR . 'admin/class-nmeb-admin.php';
}

/* ============================================================
   INIT — runs after all plugins loaded
   ============================================================ */
add_action( 'plugins_loaded', 'nmeb_init', 20 );

function nmeb_init() {
    // Don't initialize if dependency missing (post-activation safety)
    if ( ! class_exists( 'NMEP_Database' ) ) {
        add_action( 'admin_notices', 'nmeb_dependency_notice' );
        return;
    }

    NMEB_Database::init();
    NMEB_Badges::init();
    NMEB_Engine::init();
    NMEB_Display::init();
    NMEB_Cron::init();
    NMEB_Shortcodes::init();

    if ( is_admin() ) {
        NMEB_Admin::init();
    }

    // Frontend assets
    add_action( 'wp_enqueue_scripts', 'nmeb_enqueue_assets' );
}

function nmeb_dependency_notice() {
    echo '<div class="notice notice-error"><p><strong>Nagaland Me Experts — Badges</strong> requires the Payments plugin. <a href="' . esc_url( admin_url( 'plugins.php' ) ) . '">Manage plugins</a></p></div>';
}

function nmeb_enqueue_assets() {
    wp_enqueue_style(
        'nmeb-badges',
        NMEB_PLUGIN_URL . 'assets/css/badges.css',
        array(),
        NMEB_VERSION
    );
}

/* ============================================================
   ACTIVATION / DEACTIVATION HOOKS
   ============================================================ */
register_activation_hook( __FILE__, 'nmeb_activate' );

function nmeb_activate() {
    // Database tables
    if ( class_exists( 'NMEB_Database' ) ) {
        NMEB_Database::install();
    }
    // Seed default badges
    if ( class_exists( 'NMEB_Badges' ) ) {
        NMEB_Badges::seed_defaults();
    }
    // Schedule daily cron
    if ( ! wp_next_scheduled( 'nmeb_daily_auto_award' ) ) {
        wp_schedule_event( time() + 60, 'daily', 'nmeb_daily_auto_award' );
    }
    // Save version
    update_option( 'nmeb_version', NMEB_VERSION );
    update_option( 'nmeb_db_version', NMEB_DB_VERSION );
    // Flush rewrite rules so any future endpoints register cleanly
    flush_rewrite_rules();
}

register_deactivation_hook( __FILE__, 'nmeb_deactivate' );

function nmeb_deactivate() {
    // Cancel scheduled cron
    $timestamp = wp_next_scheduled( 'nmeb_daily_auto_award' );
    if ( $timestamp ) {
        wp_unschedule_event( $timestamp, 'nmeb_daily_auto_award' );
    }
}

/* ============================================================
   AUTO-MIGRATE ON VERSION CHANGE
   ============================================================ */
add_action( 'plugins_loaded', 'nmeb_maybe_migrate', 30 );

function nmeb_maybe_migrate() {
    if ( ! class_exists( 'NMEB_Database' ) ) return;

    $installed_db_version = get_option( 'nmeb_db_version', '0.0.0' );
    if ( version_compare( $installed_db_version, NMEB_DB_VERSION, '<' ) ) {
        NMEB_Database::install();
        // v2.0: realign icon mnemonics + restrained palette on existing rows.
        if ( class_exists( 'NMEB_Badges' ) && method_exists( 'NMEB_Badges', 'realign_to_v2' ) ) {
            NMEB_Badges::realign_to_v2();
        }
        update_option( 'nmeb_db_version', NMEB_DB_VERSION );
    }
}

/* ============================================================
   GLOBAL HELPERS
   ============================================================ */

/**
 * Get all badges a user has earned (returns array of badge objects with award metadata)
 */
function nmeb_get_user_badges( $user_id ) {
    return NMEB_Engine::get_user_badges( (int) $user_id );
}

/**
 * Render badges for a user (HTML chips)
 */
function nmeb_render_user_badges( $user_id, $args = array() ) {
    return NMEB_Display::render_user_badges( (int) $user_id, $args );
}

/**
 * Check if user has a specific badge slug
 */
function nmeb_user_has_badge( $user_id, $slug ) {
    return NMEB_Engine::user_has_badge( (int) $user_id, $slug );
}
