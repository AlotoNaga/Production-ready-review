<?php
/**
 * NMEB Admin
 *
 * Admin pages:
 * - Badges → All Badges       (list + manual award/revoke)
 * - Badges → Award Badge      (award form)
 * - Badges → Run Auto-Award   (manual cron trigger)
 *
 * Capability required: manage_options
 *
 * @version 1.0.0
 */
if ( ! defined( 'ABSPATH' ) ) exit;

class NMEB_Admin {

    public static function init() {
        add_action( 'admin_menu',           array( __CLASS__, 'register_menu' ) );
        add_action( 'admin_post_nmeb_award',  array( __CLASS__, 'handle_award' ) );
        add_action( 'admin_post_nmeb_revoke', array( __CLASS__, 'handle_revoke' ) );
        add_action( 'admin_post_nmeb_run_cron', array( __CLASS__, 'handle_run_cron' ) );
        add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_admin_assets' ) );
    }

    public static function enqueue_admin_assets( $hook ) {
        if ( strpos( $hook, 'nmeb' ) === false ) return;
        wp_enqueue_style( 'nmeb-admin', NMEB_PLUGIN_URL . 'assets/css/badges.css', array(), NMEB_VERSION );
    }

    public static function register_menu() {
        // Top-level menu
        add_menu_page(
            'NME Badges',
            'NME Badges',
            'manage_options',
            'nmeb-dashboard',
            array( __CLASS__, 'render_dashboard' ),
            'dashicons-awards',
            58
        );

        // Submenus
        add_submenu_page( 'nmeb-dashboard', 'Dashboard',     'Dashboard',     'manage_options', 'nmeb-dashboard',  array( __CLASS__, 'render_dashboard' ) );
        add_submenu_page( 'nmeb-dashboard', 'Award a Badge', 'Award Badge',   'manage_options', 'nmeb-award',      array( __CLASS__, 'render_award_form' ) );
        add_submenu_page( 'nmeb-dashboard', 'All Badges',    'All Badges',    'manage_options', 'nmeb-all',        array( __CLASS__, 'render_all_badges' ) );
        add_submenu_page( 'nmeb-dashboard', 'User Badges',   'User Badges',   'manage_options', 'nmeb-users',      array( __CLASS__, 'render_users_view' ) );
    }

    /* ============================================================
       DASHBOARD
       ============================================================ */
    public static function render_dashboard() {
        global $wpdb;
        $b_table  = NMEB_Database::table( 'badges' );
        $ub_table = NMEB_Database::table( 'user_badges' );

        $total_badges        = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $b_table" );
        $total_awards        = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $ub_table WHERE is_revoked = 0" );
        $unique_users        = (int) $wpdb->get_var( "SELECT COUNT(DISTINCT user_id) FROM $ub_table WHERE is_revoked = 0" );
        $awards_last_7d      = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $ub_table WHERE awarded_at >= DATE_SUB(NOW(), INTERVAL 7 DAY) AND is_revoked = 0" );

        $last_cron = get_option( 'nmeb_last_cron_run', null );
        $next_cron_ts = wp_next_scheduled( 'nmeb_daily_auto_award' );

        // Top badges by count
        $top_badges = $wpdb->get_results(
            "SELECT b.name, b.slug, b.icon, b.color, COUNT(ub.id) AS cnt
             FROM $ub_table ub
             INNER JOIN $b_table b ON b.id = ub.badge_id
             WHERE ub.is_revoked = 0
             GROUP BY b.id
             ORDER BY cnt DESC
             LIMIT 10"
        );

        ?>
        <div class="wrap">
            <h1 style="display:flex;align-items:center;gap:10px;">
                <?php echo NMEB_Icons::get( 'pro_expert', 32 ); ?>
                NME Badges Dashboard
            </h1>

            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 16px; margin: 24px 0;">
                <?php
                self::stat_card( 'Total Badges', $total_badges, '#0A7558' );
                self::stat_card( 'Awards Given', $total_awards, '#D4A843' );
                self::stat_card( 'Users with Badges', $unique_users, '#0F2419' );
                self::stat_card( 'Awards Last 7 Days', $awards_last_7d, '#10B981' );
                ?>
            </div>

            <div class="card" style="max-width: 100%; padding: 20px; margin-bottom: 24px;">
                <h2 style="margin-top: 0;">Auto-Award Engine</h2>
                <p>
                    <strong>Last run:</strong>
                    <?php if ( $last_cron && ! empty( $last_cron['time'] ) ) : ?>
                        <?php echo esc_html( $last_cron['time'] ); ?>
                        <?php if ( ! empty( $last_cron['stats'] ) ) :
                            $s = $last_cron['stats'];
                        ?>
                            — Scanned <?php echo (int) ( $s['experts_scanned'] ?? 0 ); ?> experts,
                            <?php echo (int) ( $s['buyers_scanned'] ?? 0 ); ?> buyers,
                            awarded <strong><?php echo (int) ( $s['badges_awarded'] ?? 0 ); ?></strong> badges
                        <?php endif; ?>
                    <?php else : ?>
                        <em>Never run yet</em>
                    <?php endif; ?>
                </p>
                <p>
                    <strong>Next scheduled:</strong>
                    <?php echo $next_cron_ts ? esc_html( date( 'Y-m-d H:i:s', $next_cron_ts ) ) : '<em>Not scheduled</em>'; ?>
                </p>
                <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display: inline;">
                    <input type="hidden" name="action" value="nmeb_run_cron">
                    <?php wp_nonce_field( 'nmeb_run_cron' ); ?>
                    <button type="submit" class="button button-primary">Run Auto-Award Now</button>
                </form>
                <a href="<?php echo esc_url( admin_url( 'admin.php?page=nmeb-award' ) ); ?>" class="button" style="margin-left: 8px;">+ Award Badge Manually</a>
            </div>

            <?php if ( ! empty( $top_badges ) ) : ?>
            <div class="card" style="max-width: 100%; padding: 20px;">
                <h2 style="margin-top: 0;">Most Awarded Badges</h2>
                <table class="widefat striped">
                    <thead>
                        <tr><th>Badge</th><th>Awards</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach ( $top_badges as $row ) : ?>
                            <tr>
                                <td style="display:flex;align-items:center;gap:10px;">
                                    <?php echo NMEB_Icons::get( $row->slug, 28, $row->color ); ?>
                                    <strong style="color:<?php echo esc_attr( $row->color ); ?>;"><?php echo esc_html( $row->name ); ?></strong>
                                </td>
                                <td><strong><?php echo (int) $row->cnt; ?></strong></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php endif; ?>
        </div>
        <?php
    }

    private static function stat_card( $label, $value, $color ) {
        ?>
        <div style="background:#fff;border-left:4px solid <?php echo esc_attr( $color ); ?>;padding:18px 20px;border-radius:6px;box-shadow:0 1px 3px rgba(0,0,0,0.05);">
            <div style="font-size:2rem;font-weight:700;color:<?php echo esc_attr( $color ); ?>;line-height:1;"><?php echo esc_html( $value ); ?></div>
            <div style="color:#6B7280;margin-top:6px;font-size:0.9rem;"><?php echo esc_html( $label ); ?></div>
        </div>
        <?php
    }

    /* ============================================================
       AWARD BADGE FORM
       ============================================================ */
    public static function render_award_form() {
        // Show success/error flash
        if ( isset( $_GET['nmeb_msg'] ) ) {
            $type = $_GET['nmeb_status'] ?? 'success';
            $color = $type === 'error' ? '#991B1B' : '#065F46';
            $bg    = $type === 'error' ? '#FEE2E2' : '#D1FAE5';
            echo '<div class="notice" style="background:' . esc_attr( $bg ) . ';color:' . esc_attr( $color ) . ';padding:12px;border-left:4px solid ' . esc_attr( $color ) . ';">' . esc_html( urldecode( $_GET['nmeb_msg'] ) ) . '</div>';
        }

        $badges = NMEB_Badges::get_all();

        $recent_users = get_users( array(
            'number'  => 200,
            'orderby' => 'registered',
            'order'   => 'DESC',
            'fields'  => array( 'ID', 'display_name', 'user_login', 'user_email' ),
        ) );

        // Group badges by type for visual gallery
        $grouped = array();
        foreach ( $badges as $b ) {
            $grouped[ $b->badge_type ][] = $b;
        }

        $type_labels = array(
            'expert_special'     => 'Trust & Verification',
            'expert_level'       => 'Expert Levels',
            'expert_achievement' => 'Expert Achievements',
            'buyer_level'        => 'Buyer Levels',
            'buyer_achievement'  => 'Buyer Recognitions',
        );

        ?>
        <div class="wrap">
            <h1 style="display:flex;align-items:center;gap:10px;">
                <?php echo NMEB_Icons::get( 'verified_expert', 32 ); ?>
                Award a Badge
            </h1>
            <p style="color:#6B7280;max-width:600px;">Manually award any badge to any user. They keep it permanently unless you revoke it.</p>

            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" id="nmeb-award-form">
                <input type="hidden" name="action" value="nmeb_award">
                <input type="hidden" name="badge_slug" id="nmeb-selected-badge" value="">
                <?php wp_nonce_field( 'nmeb_award' ); ?>

                <!-- Step 1: Select User -->
                <div class="card" style="max-width:100%;padding:24px;margin-bottom:20px;">
                    <h2 style="margin-top:0;font-size:1.1rem;color:#0F2419;">Step 1 — Select User</h2>
                    <select name="user_id" id="user_id" required style="width:100%;max-width:500px;padding:10px;font-size:0.95rem;border:1.5px solid #D1D5DB;border-radius:8px;">
                        <option value="">— Pick a user —</option>
                        <?php foreach ( $recent_users as $u ) : ?>
                            <option value="<?php echo (int) $u->ID; ?>">
                                <?php echo esc_html( $u->display_name . ' (' . $u->user_email . ')' ); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <!-- Step 2: Choose Badge (Visual Gallery) -->
                <div class="card" style="max-width:100%;padding:24px;margin-bottom:20px;">
                    <h2 style="margin-top:0;font-size:1.1rem;color:#0F2419;">Step 2 — Choose Badge</h2>
                    <p style="color:#6B7280;font-size:0.9rem;margin-bottom:16px;">Click a badge to select it. Selected badge will highlight.</p>

                    <?php foreach ( $type_labels as $type => $label ) :
                        if ( empty( $grouped[ $type ] ) ) continue;
                    ?>
                        <h3 style="font-size:0.85rem;text-transform:uppercase;letter-spacing:1px;color:#9CA3AF;margin:20px 0 10px;"><?php echo esc_html( $label ); ?></h3>
                        <div class="nmeb-admin-badge-grid">
                            <?php foreach ( $grouped[ $type ] as $badge ) : ?>
                                <div class="nmeb-admin-badge-item" data-slug="<?php echo esc_attr( $badge->slug ); ?>" onclick="nmebSelectBadge(this, '<?php echo esc_js( $badge->slug ); ?>')">
                                    <div style="margin-bottom:10px;">
                                        <?php echo NMEB_Icons::get( $badge->slug, 40, $badge->color ); ?>
                                    </div>
                                    <div style="font-weight:700;font-size:0.85rem;color:<?php echo esc_attr( $badge->color ); ?>;margin-bottom:4px;">
                                        <?php echo esc_html( $badge->name ); ?>
                                    </div>
                                    <div style="font-size:0.72rem;color:#9CA3AF;line-height:1.3;">
                                        <?php echo esc_html( substr( $badge->description, 0, 60 ) ); ?><?php echo strlen( $badge->description ) > 60 ? '…' : ''; ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endforeach; ?>
                </div>

                <!-- Step 3: Reason + Submit -->
                <div class="card" style="max-width:100%;padding:24px;">
                    <h2 style="margin-top:0;font-size:1.1rem;color:#0F2419;">Step 3 — Award It</h2>
                    <div id="nmeb-selected-preview" style="display:none;background:#F0FDF4;border:1.5px solid #BBF7D0;border-radius:12px;padding:16px;margin-bottom:16px;display:flex;align-items:center;gap:12px;">
                        <span id="nmeb-preview-text" style="font-weight:600;color:#065F46;"></span>
                    </div>
                    <p style="margin-bottom:12px;">
                        <label style="font-weight:600;color:#374151;">Reason / Note (optional)</label><br>
                        <textarea name="notes" rows="2" style="width:100%;max-width:500px;padding:10px;border:1.5px solid #D1D5DB;border-radius:8px;font-size:0.9rem;" placeholder="Why are you awarding this badge?"></textarea>
                    </p>
                    <button type="submit" class="button button-primary button-large" style="background:#0A7558;border-color:#0A7558;padding:8px 24px;">Award Badge</button>
                    <a href="<?php echo esc_url( admin_url( 'admin.php?page=nmeb-dashboard' ) ); ?>" class="button" style="margin-left:8px;">Cancel</a>
                </div>
            </form>
        </div>

        <script>
        function nmebSelectBadge(el, slug) {
            // Deselect all
            document.querySelectorAll('.nmeb-admin-badge-item').forEach(function(item) {
                item.style.borderColor = '#E5E7EB';
                item.style.background = '#fff';
                item.style.boxShadow = 'none';
            });
            // Select this one
            el.style.borderColor = '#10B981';
            el.style.background = '#F0FDF4';
            el.style.boxShadow = '0 0 0 3px rgba(16,185,129,0.2)';
            // Set hidden input
            document.getElementById('nmeb-selected-badge').value = slug;
            // Show preview
            var preview = document.getElementById('nmeb-selected-preview');
            var previewText = document.getElementById('nmeb-preview-text');
            preview.style.display = 'flex';
            previewText.textContent = 'Selected: ' + el.querySelector('div[style*="font-weight:700"]').textContent.trim();
        }
        document.getElementById('nmeb-award-form').addEventListener('submit', function(e) {
            if (!document.getElementById('nmeb-selected-badge').value) {
                e.preventDefault();
                alert('Please select a badge first.');
            }
        });
        </script>

        <style>
        .nmeb-admin-badge-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(160px, 1fr));
            gap: 10px;
        }
        .nmeb-admin-badge-item {
            background: #fff;
            border: 1.5px solid #E5E7EB;
            border-radius: 12px;
            padding: 16px 12px;
            text-align: center;
            cursor: pointer;
            transition: all 0.2s;
        }
        .nmeb-admin-badge-item:hover {
            border-color: #10B981;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0,0,0,0.06);
        }
        </style>
        <?php
    }

    /* ============================================================
       ALL BADGES LIST (definitions)
       ============================================================ */
    public static function render_all_badges() {
        $badges = NMEB_Badges::get_all();
        global $wpdb;
        $ub_table = NMEB_Database::table( 'user_badges' );

        ?>
        <div class="wrap">
            <h1 style="display:flex;align-items:center;gap:10px;">
                <?php echo NMEB_Icons::get( 'pro_expert', 32 ); ?>
                All Badges
            </h1>
            <p style="color:#6B7280;">All <?php echo count( $badges ); ?> badge definitions in the system.</p>

            <table class="wp-list-table widefat striped" style="margin-top:16px;">
                <thead>
                    <tr>
                        <th style="width:50px;">Icon</th>
                        <th>Badge</th>
                        <th>Type</th>
                        <th>Description</th>
                        <th style="width:80px;">Awards</th>
                        <th style="width:80px;">Auto?</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ( $badges as $badge ) :
                        $count = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $ub_table WHERE badge_id = %d AND is_revoked = 0", $badge->id ) );
                    ?>
                        <tr>
                            <td style="text-align:center;">
                                <?php echo NMEB_Icons::get( $badge->slug, 32, $badge->color ); ?>
                            </td>
                            <td>
                                <strong style="color:<?php echo esc_attr( $badge->color ); ?>;font-size:0.95rem;">
                                    <?php echo esc_html( $badge->name ); ?>
                                </strong>
                                <div style="font-size:0.75rem;color:#9CA3AF;font-family:monospace;"><?php echo esc_html( $badge->slug ); ?></div>
                            </td>
                            <td>
                                <span style="color:#6B7280;font-size:0.85rem;">
                                    <?php echo esc_html( str_replace( '_', ' ', $badge->badge_type ) ); ?>
                                </span>
                            </td>
                            <td style="font-size:0.88rem;color:#4B5563;max-width:300px;"><?php echo esc_html( $badge->description ); ?></td>
                            <td style="text-align:center;">
                                <strong style="font-size:1.1rem;color:#0F2419;"><?php echo $count; ?></strong>
                            </td>
                            <td style="text-align:center;">
                                <?php if ( $badge->is_admin_only ) : ?>
                                    <span style="color:#991B1B;font-size:0.8rem;font-weight:600;">Admin only</span>
                                <?php else : ?>
                                    <span style="color:#065F46;font-size:0.8rem;font-weight:600;">Auto</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php
    }

    /* ============================================================
       USER BADGES VIEW (search a user, see their badges, revoke)
       ============================================================ */
    public static function render_users_view() {
        // Show flash
        if ( isset( $_GET['nmeb_msg'] ) ) {
            $type = $_GET['nmeb_status'] ?? 'success';
            $color = $type === 'error' ? '#991B1B' : '#065F46';
            $bg    = $type === 'error' ? '#FEE2E2' : '#D1FAE5';
            echo '<div class="notice" style="background:' . esc_attr( $bg ) . ';color:' . esc_attr( $color ) . ';padding:12px;border-left:4px solid ' . esc_attr( $color ) . ';">' . esc_html( urldecode( $_GET['nmeb_msg'] ) ) . '</div>';
        }

        $search_user = isset( $_GET['user_id'] ) ? (int) $_GET['user_id'] : 0;

        ?>
        <div class="wrap">
            <h1 style="display:flex;align-items:center;gap:10px;">
                <?php echo NMEB_Icons::get( 'active_buyer', 32 ); ?>
                User Badges
            </h1>

            <form method="get" action="" style="margin: 20px 0; display: flex; gap: 8px; align-items: center;">
                <input type="hidden" name="page" value="nmeb-users">
                <label>Search user by ID or email:</label>
                <input type="text" name="user_id" placeholder="123 or user@example.com" value="<?php echo $search_user > 0 ? esc_attr( $search_user ) : ''; ?>" style="min-width: 240px;">
                <button class="button button-primary">View Badges</button>
            </form>

            <?php
            // Resolve search by email if not numeric
            if ( $search_user === 0 && isset( $_GET['user_id'] ) && is_email( $_GET['user_id'] ) ) {
                $u = get_user_by( 'email', sanitize_email( $_GET['user_id'] ) );
                if ( $u ) $search_user = (int) $u->ID;
            }

            if ( $search_user > 0 ) :
                $user = get_userdata( $search_user );
                if ( ! $user ) {
                    echo '<div class="notice notice-error"><p>User #' . $search_user . ' not found.</p></div>';
                } else {
                    self::render_user_detail( $user );
                }
            endif;
            ?>
        </div>
        <?php
    }

    private static function render_user_detail( $user ) {
        $user_id = (int) $user->ID;
        $current_badges = NMEB_Engine::get_user_badges( $user_id );
        $all_badges     = NMEB_Badges::get_all();

        // Build map of slugs the user already has (active) so we don't show "Award" for those
        $owned_slugs = array_map( function( $b ) { return $b->slug; }, $current_badges );

        ?>
        <div class="card" style="max-width:100%;padding:24px;">
            <h2 style="margin-top:0;"><?php echo esc_html( $user->display_name ); ?>
                <span style="color:#6B7280;font-weight:normal;font-size:0.9em;">
                    (#<?php echo $user_id; ?> · <?php echo esc_html( $user->user_email ); ?>)
                </span>
            </h2>

            <h3>Active Badges (<?php echo count( $current_badges ); ?>)</h3>
            <?php if ( empty( $current_badges ) ) : ?>
                <p><em>No badges awarded yet.</em></p>
            <?php else : ?>
                <table class="wp-list-table widefat striped">
                    <thead>
                        <tr>
                            <th>Badge</th>
                            <th>Awarded</th>
                            <th>By</th>
                            <th>Notes</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ( $current_badges as $b ) : ?>
                            <tr>
                                <td><?php echo NMEB_Display::render_badge_chip( $b, 'md', true ); // phpcs:ignore ?></td>
                                <td><?php echo esc_html( $b->awarded_at ); ?></td>
                                <td>
                                    <?php if ( $b->awarded_by === 'admin' ) : ?>
                                        <span style="color:#0A7558;font-weight:600;">Admin</span>
                                    <?php else : ?>
                                        <span style="color:#6B7280;">Auto</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo esc_html( $b->notes ?: '—' ); ?></td>
                                <td>
                                    <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline;" onsubmit="return confirm('Revoke this badge?');">
                                        <input type="hidden" name="action" value="nmeb_revoke">
                                        <input type="hidden" name="user_id" value="<?php echo $user_id; ?>">
                                        <input type="hidden" name="badge_slug" value="<?php echo esc_attr( $b->slug ); ?>">
                                        <?php wp_nonce_field( 'nmeb_revoke_' . $b->slug ); ?>
                                        <button type="submit" class="button button-link-delete">Revoke</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>

            <h3 style="margin-top: 32px;">Award a Badge to This User</h3>
            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:flex;gap:8px;align-items:flex-end;flex-wrap:wrap;">
                <input type="hidden" name="action" value="nmeb_award">
                <input type="hidden" name="user_id" value="<?php echo $user_id; ?>">
                <?php wp_nonce_field( 'nmeb_award' ); ?>
                <p style="margin:0;">
                    <label>Badge:</label><br>
                    <select name="badge_slug" required style="min-width:280px;">
                        <option value="">— Pick a badge to award —</option>
                        <?php foreach ( $all_badges as $b ) :
                            $is_owned = in_array( $b->slug, $owned_slugs, true );
                        ?>
                            <option value="<?php echo esc_attr( $b->slug ); ?>" <?php disabled( $is_owned ); ?>>
                                <?php echo esc_html( $b->name ); ?>
                                <?php echo $is_owned ? ' (already has)' : ''; ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </p>
                <p style="margin:0;flex:1;min-width:200px;">
                    <label>Reason (optional):</label><br>
                    <input type="text" name="notes" style="width:100%;" placeholder="Why awarding this badge?">
                </p>
                <p style="margin:0;">
                    <button class="button button-primary">Award Badge</button>
                </p>
            </form>
        </div>
        <?php
    }

    /* ============================================================
       FORM HANDLERS
       ============================================================ */

    public static function handle_award() {
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Permission denied' );
        check_admin_referer( 'nmeb_award' );

        $user_id    = isset( $_POST['user_id'] ) ? (int) $_POST['user_id'] : 0;
        $badge_slug = isset( $_POST['badge_slug'] ) ? sanitize_key( $_POST['badge_slug'] ) : '';
        $notes      = isset( $_POST['notes'] ) ? sanitize_textarea_field( wp_unslash( $_POST['notes'] ) ) : '';

        if ( $user_id <= 0 || ! $badge_slug ) {
            self::redirect_back( 'error', 'Missing user or badge.' );
        }

        $result = NMEB_Engine::award_badge( $user_id, $badge_slug, 'admin', get_current_user_id(), $notes );

        if ( $result ) {
            self::redirect_back( 'success', 'Badge awarded successfully!', $user_id );
        } else {
            self::redirect_back( 'error', 'Could not award badge. (Already exists or badge not found.)', $user_id );
        }
    }

    public static function handle_revoke() {
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Permission denied' );

        $user_id    = isset( $_POST['user_id'] ) ? (int) $_POST['user_id'] : 0;
        $badge_slug = isset( $_POST['badge_slug'] ) ? sanitize_key( $_POST['badge_slug'] ) : '';

        check_admin_referer( 'nmeb_revoke_' . $badge_slug );

        if ( $user_id <= 0 || ! $badge_slug ) {
            self::redirect_back( 'error', 'Missing user or badge.' );
        }

        $ok = NMEB_Engine::revoke_badge( $user_id, $badge_slug, get_current_user_id(), 'Revoked via admin UI' );
        self::redirect_back( $ok ? 'success' : 'error', $ok ? 'Badge revoked.' : 'Could not revoke.', $user_id );
    }

    public static function handle_run_cron() {
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Permission denied' );
        check_admin_referer( 'nmeb_run_cron' );

        $stats = NMEB_Engine::run_auto_awards();
        update_option( 'nmeb_last_cron_run', array(
            'time'  => current_time( 'mysql' ),
            'stats' => $stats,
        ) );

        $msg = sprintf(
            'Auto-award completed: %d experts scanned, %d buyers scanned, %d badges newly awarded.',
            (int) ( $stats['experts_scanned'] ?? 0 ),
            (int) ( $stats['buyers_scanned'] ?? 0 ),
            (int) ( $stats['badges_awarded'] ?? 0 )
        );

        wp_safe_redirect( add_query_arg( array(
            'page'        => 'nmeb-dashboard',
            'nmeb_status' => 'success',
            'nmeb_msg'    => urlencode( $msg ),
        ), admin_url( 'admin.php' ) ) );
        exit;
    }

    private static function redirect_back( $status, $msg, $user_id = 0 ) {
        $args = array(
            'nmeb_status' => $status,
            'nmeb_msg'    => urlencode( $msg ),
        );
        if ( $user_id ) {
            $args['page'] = 'nmeb-users';
            $args['user_id'] = $user_id;
        } else {
            $args['page'] = 'nmeb-award';
        }
        wp_safe_redirect( add_query_arg( $args, admin_url( 'admin.php' ) ) );
        exit;
    }
}
