================================================================================
NAGALAND ME EXPERTS - PAYMENTS PLUGIN v1.5.4
"Service Form 2.0" — Major UX overhaul of service creation
================================================================================

CHANGELOG
─────────
v1.5.4 (this release):
  ✅ Cover image now OPTIONAL (auto-generated forest-green placeholder)
  ✅ Photo upload widget (drag-drop, no more URL pasting)
  ✅ Tier 2 + Tier 3 fully optional (only ONE tier required)
  ✅ Friendly tier names: Starter / Standard / Pro
  ✅ Each tier has custom title field (e.g., "1 thumbnail")
  ✅ Inline error messages with form data preservation (no more 45-min losses!)
  ✅ Compare Packages table on public service page (when 2+ tiers)
  ✅ Auto-resize uploaded photos to 1280×720
  ✅ Removed diagnostic tool (no longer needed)
  ✅ DB migration: short_pitch column added, basic_price now nullable

v1.5.3 (previous): Sitemap diagnostic tool
v1.5.2 (previous): Rank Math sitemap registration fix
v1.5.0-1.5.1 (previous): Batch F SEO infrastructure

================================================================================
WHAT'S NEW — DETAILED
================================================================================

🎨 PHOTO UPLOAD (replaces URL pasting)
  Old:  Type/paste a URL into a text field
  New:  Tap to upload, drag & drop, or click "Replace"
        - Accepts JPG and PNG only
        - Max 5MB per photo
        - Auto-resized to 1280×720 server-side
        - Auto-stored in WordPress Media Library
        - Real-time progress bar
        - Inline error messages

🎁 OPTIONAL COVER IMAGE
  Old:  Cover Image URL was REQUIRED (*) — blocked many sellers
  New:  Cover photo is optional
        - If uploaded: shown as photo
        - If skipped: auto-generated forest-green card with service title
        - Looks beautiful either way

📦 OPTIONAL TIERS — Only ONE package required
  Old:  Basic was required; Standard/Premium "optional" but Basic price was *
        → If you wanted ONLY Premium, you couldn't!
  New:  Sellers can offer 1, 2, or 3 packages
        - "Add Standard package" / "Add Pro package" toggle buttons
        - Whichever tier(s) have a price = those are the offered packages
        - At least one package required

🏷️ FRIENDLIER TIER NAMES
  Old:  Basic / Standard / Premium (corporate jargon)
  New:  Starter / Standard / Pro (Upwork-style, friendlier)
        - Internal database keys unchanged for backward compatibility
        - All public displays use new friendly names
        - Each tier still gets a custom title (seller's choice)

✏️ PER-TIER CUSTOM TITLES
  Each package now has a title field where sellers can name their offering:
  Example:  Starter   → "1 thumbnail design"
            Standard  → "3 thumbnail designs + variations"
            Pro       → "10 thumbnails + Photoshop source files"
  These custom titles appear on the public service page.

🛡️ NO MORE SILENT FORM FAILURES
  Old:  Form failed → silent redirect to dashboard → all typing lost
  New:  Form failed → red error box at top → form repopulated from transient
        - Your typing is saved for 5 minutes
        - "Form data restored" notice appears so you know it worked
        - You see exactly what went wrong (e.g., "Description must be 100+ chars")

📊 COMPARE PACKAGES TABLE
  When a seller offers 2+ tiers, the public service page shows a
  beautiful side-by-side comparison table at the bottom:
  - All 3 columns side by side (Starter | Standard | Pro)
  - Highlights the currently selected tier
  - Shows seller's custom title for each tier
  - Lists "what's included" features as checkmarks
  - Delivery time and revisions per tier
  - "Select →" button to checkout that specific tier
  - Auto-shown only when 2+ tiers offered (no clutter for single-tier services)

================================================================================
DATABASE MIGRATION (AUTOMATIC ON ACTIVATION)
================================================================================

The plugin automatically migrates existing data on activation. NO DATA LOSS.

Changes applied:
  ALTER TABLE wp_nmep_services
    MODIFY COLUMN basic_price DECIMAL(10,2) DEFAULT NULL,
    ADD COLUMN short_pitch VARCHAR(160) DEFAULT NULL AFTER short_description;

Existing services continue to work — they just gain the ability to be
edited with the new optional-tier behavior.

================================================================================
INSTALLATION
================================================================================

Standard upgrade flow:

1. WP Admin → Plugins → "Nagaland Me Experts — Payments" → Deactivate
2. Delete (settings + all data preserved)
3. Plugins → Add New → Upload Plugin → choose nme-payments-v1.5.4.zip
4. Install Now → Activate
5. Settings → Permalinks → Save Changes

That's it. The DB migration runs automatically.

================================================================================
TEST PLAN — VERIFY IT WORKS
================================================================================

After installing, run these tests in order:

TEST 1 — Plugin activates clean
  ✓ Plugins page shows v1.5.4 active
  ✓ No fatal errors
  ✓ Database migration logged

TEST 2 — Sitemap still works (from v1.5.2)
  ✓ Visit /sitemap_index.xml — should show 5 sitemaps (or 6 with services)
  ✓ Cover placeholders work in expert sitemap (if any)

TEST 3 — Create a service WITHOUT cover image
  1. Visit /expert-dashboard/?action=new
  2. Fill in: Title (10+ chars), Category, Short desc (30+ chars), Description (100+ chars)
  3. SKIP the cover image
  4. Set ONLY Standard package price (skip Starter, skip Pro)
  5. Add features for Standard
  6. Submit
  ✓ Service should save successfully (NO red error)
  ✓ Should redirect with success message

TEST 4 — Verify auto-placeholder appears
  1. Approve the service from admin
  2. Visit /service/{slug}/
  ✓ Cover area shows beautiful forest-green card with your service title
  ✓ "★ NAGALAND ME EXPERTS" decorative text in corner

TEST 5 — Test photo upload
  1. Edit the service
  2. Click on the upload area
  3. Choose a JPG/PNG photo from your computer (under 5MB)
  ✓ Progress bar appears
  ✓ Photo preview shows after upload
  ✓ Save service
  ✓ Photo appears as cover on public page

TEST 6 — Test tier toggle
  1. Edit the service
  2. Click "✕ Remove this package" on Standard
  ✓ Standard package collapses
  ✓ "⭐ Add Standard package" button appears
  ✓ Click it — Standard reappears
  ✓ Save service

TEST 7 — Test form data preservation
  1. Edit a service
  2. Type something in description
  3. Clear the title (make it invalid)
  4. Save
  ✓ Should redirect back with red error: "Title must be at least 10 characters"
  ✓ Blue notice: "💾 Form data restored"
  ✓ Your description text is still in the textarea

TEST 8 — Test compare packages table
  1. Edit a service
  2. Set prices for ALL 3 tiers
  3. Save and view public page
  ✓ Bottom of page shows beautiful "Compare Packages" table
  ✓ All 3 columns side-by-side
  ✓ Current tier highlighted
  ✓ Each "Select →" button works

TEST 9 — Test single-tier service
  1. Create new service with ONLY Pro tier filled
  ✓ No "Compare Packages" table on public page (because only 1 tier)
  ✓ Single package displays correctly with seller's custom title

TEST 10 — Friendly tier names visible everywhere
  ✓ Form shows: 📦 Starter, ⭐ Standard, 💎 Pro
  ✓ Public page tabs show: Starter, Standard, Pro
  ✓ NEVER shows "Basic" or "Premium" anywhere user-facing
  ✓ Compare table shows: Starter, Standard, Pro

================================================================================
TECHNICAL CHANGES
================================================================================

Files added:
  - includes/class-nmep-uploads.php (NEW — photo upload AJAX handler)

Files removed:
  - includes/class-nmep-sitemap-debug.php (no longer needed in production)

Files modified:
  - nme-payments.php (version bump, register uploads class, add cover helper)
  - includes/class-nmep-database.php (add short_pitch + nullable basic_price)
  - includes/class-nmep-services.php (validation rewrite, sanitize_optional_price,
    friendly tier names, get_active_tiers helper, error handling with transients)
  - includes/class-nmep-shortcodes.php (form rebuild, photo upload widget,
    compare table, cover helper integration, friendly tier display)

Total: 26 PHP files, 10,494 lines of production code

================================================================================
WHAT'S COMING NEXT (v1.5.5+ / nme-badges v1.0.0)
================================================================================

Coming in the next release:
  - 🏅 Badge system (separate plugin: nme-badges)
    - 5 expert level badges (New, Rising, Pro, Top Pro, Verified)
    - 8 achievement badges (First Sale, Quick Responder, etc.)
    - 7 buyer badges (New Buyer, Power Buyer, Loyal Customer, etc.)
    - Admin badge management UI
    - Auto-award via daily cron
    - Badge display everywhere

Coming after that:
  - Live preview as user types in service form
  - Smart pricing presets per category

================================================================================
SUPPORT
================================================================================

If anything breaks: revert to v1.5.3 by uploading the previous ZIP.
All your data is safe — the migration is purely additive.

Built with care for Nagaland Me Experts.
