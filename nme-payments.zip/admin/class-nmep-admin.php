<?php
/**
 * NMEP_Admin
 * WordPress admin interface for the payments plugin.
 *
 * @version 1.1.0 (Batch B): adds Services management, Service Review queue
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class NMEP_Admin {

    public static function init() {
        add_action( 'admin_menu', array( __CLASS__, 'register_menu' ) );
        add_action( 'init', array( __CLASS__, 'hook_into_base_plugin' ), 30 );
    }

    public static function hook_into_base_plugin() {
        add_action( 'admin_post_nme_approve_expert', array( __CLASS__, 'after_base_plugin_approval' ), 9 );
    }

    public static function after_base_plugin_approval() {
        $expert_id = isset( $_POST['expert_id'] ) ? (int) $_POST['expert_id'] : 0;
        if ( $expert_id ) {
            wp_schedule_single_event( time() + 5, 'nmep_create_linked_async', array( $expert_id ) );
        }
    }

    public static function register_menu() {
        add_menu_page(
            'NME Payments', 'NME Payments', 'manage_options',
            'nmep-dashboard', array( __CLASS__, 'render_dashboard' ),
            'dashicons-money-alt', 31
        );

        add_submenu_page( 'nmep-dashboard', 'Dashboard', 'Dashboard', 'manage_options', 'nmep-dashboard', array( __CLASS__, 'render_dashboard' ) );
        add_submenu_page( 'nmep-dashboard', 'Settings', 'Settings', 'manage_options', 'nmep-settings', array( __CLASS__, 'render_settings' ) );
        add_submenu_page( 'nmep-dashboard', 'Services', 'Services', 'manage_options', 'nmep-services', array( __CLASS__, 'render_services_list' ) );

        // Service Review with badge for pending count
        $pending_count = NMEP_Services::count_by_status( NMEP_Services::STATUS_PENDING_REVIEW );
        $review_label = 'Service Review';
        if ( $pending_count > 0 ) {
            $review_label .= ' <span class="awaiting-mod">' . $pending_count . '</span>';
        }
        add_submenu_page( 'nmep-dashboard', 'Service Review', $review_label, 'manage_options', 'nmep-services-review', array( __CLASS__, 'render_services_review' ) );

        add_submenu_page( 'nmep-dashboard', 'Orders', 'Orders', 'manage_options', 'nmep-orders', array( __CLASS__, 'render_orders' ) );

        // Disputes with badge
        $open_disputes = class_exists( 'NMEP_Disputes' ) ? NMEP_Disputes::count_open() : 0;
        $disputes_label = 'Disputes';
        if ( $open_disputes > 0 ) {
            $disputes_label .= ' <span class="awaiting-mod">' . $open_disputes . '</span>';
        }
        add_submenu_page( 'nmep-dashboard', 'Disputes', $disputes_label, 'manage_options', 'nmep-disputes', array( __CLASS__, 'render_disputes' ) );

        add_submenu_page( 'nmep-dashboard', 'Linked Accounts', 'Linked Accounts', 'manage_options', 'nmep-linked-accounts', array( __CLASS__, 'render_linked_accounts' ) );
        add_submenu_page( 'nmep-dashboard', 'Logs', 'Logs', 'manage_options', 'nmep-logs', array( __CLASS__, 'render_logs' ) );
    }

    /* ============================================================
       DASHBOARD
       ============================================================ */
    public static function render_dashboard() {
        global $wpdb;
        $orders_table = NMEP_Database::table( 'orders' );
        $services_table = NMEP_Database::table( 'services' );
        $linked_table = NMEP_Database::table( 'linked_accounts' );

        $total_orders = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $orders_table" );
        $paid_orders  = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $orders_table WHERE payment_status = 'captured'" );
        $total_gmv    = (float) $wpdb->get_var( "SELECT SUM(gross_amount) FROM $orders_table WHERE payment_status = 'captured'" );
        $total_commission = (float) $wpdb->get_var( "SELECT SUM(commission_amount) FROM $orders_table WHERE payment_status = 'captured'" );
        $linked_accounts = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $linked_table" );
        $active_services = NMEP_Services::count_by_status( NMEP_Services::STATUS_ACTIVE );
        $pending_services = NMEP_Services::count_by_status( NMEP_Services::STATUS_PENDING_REVIEW );

        $mode = NMEP_Settings::get_mode();
        $api_configured = NMEP_Settings::is_api_configured();
        ?>
        <div class="wrap nmep-admin">
            <h1>NME Payments — Dashboard</h1>

            <?php if ( ! $api_configured ) : ?>
                <div class="notice notice-warning"><p><strong>⚠️ Razorpay not configured.</strong> Go to <a href="<?php echo esc_url( admin_url( 'admin.php?page=nmep-settings' ) ); ?>">Settings</a>.</p></div>
            <?php endif; ?>

            <div class="notice notice-info">
                <p><strong>Current Mode:</strong> <?php echo esc_html( strtoupper( $mode ) ); ?>
                   — <?php echo $mode === 'test' ? 'Sandbox / no real money' : 'LIVE production payments active'; ?>
                </p>
            </div>

            <?php if ( $pending_services > 0 ) : ?>
                <div class="notice notice-warning">
                    <p><strong><?php echo $pending_services; ?> service(s) awaiting your review.</strong> <a href="<?php echo esc_url( admin_url( 'admin.php?page=nmep-services-review' ) ); ?>">Review Now →</a></p>
                </div>
            <?php endif; ?>

            <div class="nmep-stats-grid">
                <div class="nmep-stat-card">
                    <div class="nmep-stat-label">Total Orders</div>
                    <div class="nmep-stat-value"><?php echo $total_orders; ?></div>
                </div>
                <div class="nmep-stat-card">
                    <div class="nmep-stat-label">Active Services</div>
                    <div class="nmep-stat-value"><?php echo $active_services; ?></div>
                </div>
                <div class="nmep-stat-card">
                    <div class="nmep-stat-label">Total GMV</div>
                    <div class="nmep-stat-value"><?php echo nmep_format_inr( $total_gmv ); ?></div>
                </div>
                <div class="nmep-stat-card">
                    <div class="nmep-stat-label">Commission Earned</div>
                    <div class="nmep-stat-value"><?php echo nmep_format_inr( $total_commission ); ?></div>
                </div>
                <div class="nmep-stat-card">
                    <div class="nmep-stat-label">Linked Accounts</div>
                    <div class="nmep-stat-value"><?php echo $linked_accounts; ?></div>
                </div>
            </div>

            <?php
            // v0.7.3 — Premium Membership KPI strip (Phase 2).
            // Only shown when the Premium Buyer module is loaded AND enabled in settings,
            // so a site running with premium disabled isn't cluttered with empty cards.
            if (
                class_exists( 'NMEP_Buyer_Premium' ) &&
                (bool) NMEP_Settings::get( 'premium_buyer_enabled', true )
            ) :
                $premium_subs        = NMEP_Buyer_Premium::stats_active_subscribers();
                $premium_revenue_mtd = NMEP_Buyer_Premium::stats_revenue_this_month();
                $premium_gmv_30d     = NMEP_Buyer_Premium::stats_premium_gmv_30d();
                $premium_expiring    = NMEP_Buyer_Premium::stats_expiring_30d();

                $delta      = (int) $premium_subs['delta'];
                $delta_html = '<span style="color:#6B7280;font-size:0.85rem;">—</span>';
                if ( $delta > 0 ) {
                    $delta_html = '<span style="color:#10B981;font-size:0.85rem;font-weight:600;">▲ +' . $delta . ' MoM</span>';
                } elseif ( $delta < 0 ) {
                    $delta_html = '<span style="color:#D63638;font-size:0.85rem;font-weight:600;">▼ ' . $delta . ' MoM</span>';
                } elseif ( (int) $premium_subs['last_month'] > 0 ) {
                    $delta_html = '<span style="color:#6B7280;font-size:0.85rem;">0 MoM</span>';
                }

                $csv_url = wp_nonce_url(
                    admin_url( 'admin-post.php?action=nmep_export_premium_expiring' ),
                    'nmep_export_premium_expiring'
                );
            ?>
            <div class="nmep-section" style="border-left:4px solid #D4A843;padding-left:16px;margin-top:24px;">
                <h2 style="margin-top:0;">⭐ Premium Membership</h2>
                <div class="nmep-stats-grid">
                    <div class="nmep-stat-card">
                        <div class="nmep-stat-label">Active Subscribers</div>
                        <div class="nmep-stat-value"><?php echo (int) $premium_subs['current']; ?></div>
                        <div style="margin-top:4px;"><?php echo $delta_html; ?></div>
                    </div>
                    <div class="nmep-stat-card">
                        <div class="nmep-stat-label">Revenue This Month</div>
                        <div class="nmep-stat-value"><?php echo nmep_format_inr( $premium_revenue_mtd ); ?></div>
                    </div>
                    <div class="nmep-stat-card">
                        <div class="nmep-stat-label">Premium GMV (30d)</div>
                        <div class="nmep-stat-value"><?php echo nmep_format_inr( $premium_gmv_30d ); ?></div>
                        <div style="color:#6B7280;font-size:0.8rem;margin-top:4px;">orders from premium buyers</div>
                    </div>
                    <div class="nmep-stat-card">
                        <div class="nmep-stat-label">Expiring in 30d</div>
                        <div class="nmep-stat-value"><?php echo (int) $premium_expiring; ?></div>
                        <?php if ( $premium_expiring > 0 ) : ?>
                            <div style="margin-top:6px;">
                                <a href="<?php echo esc_url( $csv_url ); ?>" class="button button-small">⬇ CSV</a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                <p style="margin-top:12px;">
                    <a href="<?php echo esc_url( admin_url( 'admin.php?page=nmep-premium-members' ) ); ?>" class="button">View all Premium Members</a>
                </p>
            </div>
            <?php endif; ?>

            <div class="nmep-section">
                <h2>Quick Actions</h2>
                <p>
                    <a href="<?php echo esc_url( admin_url( 'admin.php?page=nmep-services-review' ) ); ?>" class="button button-primary">📝 Service Review (<?php echo $pending_services; ?>)</a>
                    <a href="<?php echo esc_url( admin_url( 'admin.php?page=nmep-services' ) ); ?>" class="button">📦 All Services</a>
                    <a href="<?php echo esc_url( admin_url( 'admin.php?page=nmep-settings' ) ); ?>" class="button">⚙️ Settings</a>
                    <a href="<?php echo esc_url( admin_url( 'admin.php?page=nmep-linked-accounts' ) ); ?>" class="button">🏦 Linked Accounts</a>
                    <a href="<?php echo esc_url( admin_url( 'admin.php?page=nmep-logs' ) ); ?>" class="button">📜 Logs</a>
                </p>
            </div>

            <div class="nmep-section">
                <h2>Build Status — Plugin v1.0</h2>
                <ul>
                    <li>✅ <strong>Batch A:</strong> Database, settings, Razorpay client, Linked Accounts</li>
                    <li>✅ <strong>Batch B (current):</strong> Service creation, expert dashboard, browse, single service page, admin review queue</li>
                    <li>⏳ <strong>Batch C:</strong> Buyer checkout + Razorpay Route payment integration</li>
                    <li>⏳ <strong>Batch D:</strong> Escrow, auto-release, refunds, disputes</li>
                    <li>⏳ <strong>Batch E:</strong> Buyer & expert dashboards (orders, messages, reviews)</li>
                </ul>
            </div>

            <div class="nmep-section">
                <h2>Webhook Endpoint</h2>
                <code style="user-select:all; background: #f5f5f5; padding: 8px; display: inline-block;"><?php echo esc_html( rest_url( 'nmep/v1/webhook' ) ); ?></code>
            </div>
        </div>
        <?php
    }

    /* ============================================================
       SERVICE REVIEW QUEUE
       ============================================================ */
    public static function render_services_review() {
        if ( isset( $_GET['approved'] ) ) {
            echo '<div class="notice notice-success is-dismissible"><p>Service approved and now live.</p></div>';
        }
        if ( isset( $_GET['rejected'] ) ) {
            echo '<div class="notice notice-warning is-dismissible"><p>Service rejected. Expert has been notified.</p></div>';
        }

        $services = NMEP_Services::get_pending_review();
        ?>
        <div class="wrap nmep-admin">
            <h1>Service Review Queue</h1>
            <p>Services submitted by experts that need your approval before going live.</p>

            <?php if ( empty( $services ) ) : ?>
                <div class="nmep-section nmep-text-center">
                    <h3>🎉 All caught up!</h3>
                    <p>No services pending review.</p>
                </div>
            <?php else : ?>
                <?php foreach ( $services as $service ) : ?>
                    <div class="nmep-section" style="border-left: 4px solid #F59E0B;">
                        <div style="display: flex; gap: 24px; align-items: start;">
                            <?php if ( $service->cover_image ) : ?>
                                <img src="<?php echo esc_url( $service->cover_image ); ?>" style="width: 200px; height: 113px; object-fit: cover; border-radius: 8px;">
                            <?php endif; ?>
                            <div style="flex: 1;">
                                <h3 style="margin-top: 0;"><?php echo esc_html( $service->title ); ?></h3>
                                <p><strong>Expert:</strong> <?php echo esc_html( $service->expert_name ); ?> (<?php echo esc_html( $service->expert_email ); ?>)<br>
                                <strong>Submitted:</strong> <?php echo esc_html( date( 'd M Y H:i', strtotime( $service->updated_at ) ) ); ?><br>
                                <strong>Pricing:</strong> Basic <?php echo nmep_format_inr( $service->basic_price ); ?>
                                <?php if ( $service->standard_price > 0 ) echo ' | Standard ' . nmep_format_inr( $service->standard_price ); ?>
                                <?php if ( $service->premium_price > 0 ) echo ' | Premium ' . nmep_format_inr( $service->premium_price ); ?>
                                </p>
                                <p style="color: #6B7280;"><?php echo esc_html( $service->short_description ); ?></p>
                                <details>
                                    <summary style="cursor: pointer; color: var(--nme-emerald);">View full description</summary>
                                    <div style="background: #f9fafb; padding: 16px; margin-top: 8px; border-radius: 8px;">
                                        <?php echo wp_kses_post( wpautop( $service->description ) ); ?>
                                    </div>
                                </details>

                                <div style="margin-top: 16px; display: flex; gap: 12px; align-items: start;">
                                    <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline;">
                                        <input type="hidden" name="action" value="nmep_approve_service">
                                        <input type="hidden" name="service_id" value="<?php echo (int) $service->id; ?>">
                                        <?php wp_nonce_field( 'nmep_approve_service_' . $service->id ); ?>
                                        <button type="submit" class="button button-primary">✓ Approve</button>
                                    </form>

                                    <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:flex; gap: 8px;">
                                        <input type="hidden" name="action" value="nmep_reject_service">
                                        <input type="hidden" name="service_id" value="<?php echo (int) $service->id; ?>">
                                        <?php wp_nonce_field( 'nmep_reject_service_' . $service->id ); ?>
                                        <input type="text" name="rejection_reason" placeholder="Reason for rejection (sent to expert)" style="width: 320px;" required>
                                        <button type="submit" class="button">✗ Reject</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
        <?php
    }

    /* ============================================================
       SERVICES LIST
       ============================================================ */
    public static function render_services_list() {
        global $wpdb;
        $status_filter = isset( $_GET['status'] ) ? sanitize_key( $_GET['status'] ) : 'all';

        $where = $status_filter !== 'all' ? $wpdb->prepare( "WHERE s.status = %s", $status_filter ) : '';
        $services = $wpdb->get_results(
            "SELECT s.*, e.full_name AS expert_name
             FROM " . NMEP_Database::table( 'services' ) . " s
             LEFT JOIN " . NMEP_Compat::base_table( 'experts' ) . " e ON e.id = s.expert_id
             $where
             ORDER BY s.id DESC LIMIT 100"
        );

        $statuses = array(
            'all'            => 'All',
            'active'         => 'Active',
            'pending_review' => 'Pending',
            'draft'          => 'Drafts',
            'paused'         => 'Paused',
            'rejected'       => 'Rejected',
            'archived'       => 'Archived',
        );
        ?>
        <div class="wrap nmep-admin">
            <h1>All Services</h1>

            <ul class="subsubsub">
                <?php foreach ( $statuses as $key => $label ) :
                    $count = $key === 'all' ? '' : ' (' . NMEP_Services::count_by_status( $key ) . ')';
                ?>
                    <li><a href="?page=nmep-services&status=<?php echo esc_attr( $key ); ?>" <?php echo $status_filter === $key ? 'class="current"' : ''; ?>><?php echo esc_html( $label . $count ); ?></a> <?php echo $key !== 'archived' ? '|' : ''; ?></li>
                <?php endforeach; ?>
            </ul>

            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th>Title</th>
                        <th>Expert</th>
                        <th>Status</th>
                        <th>Basic Price</th>
                        <th>Orders</th>
                        <th>Views</th>
                        <th>Created</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ( empty( $services ) ) : ?>
                        <tr><td colspan="7" style="text-align: center; padding: 40px;">No services found.</td></tr>
                    <?php else : ?>
                        <?php foreach ( $services as $s ) : ?>
                            <tr>
                                <td>
                                    <strong><?php echo esc_html( $s->title ); ?></strong>
                                    <?php if ( $s->status === 'active' ) : ?>
                                        <br><small><a href="<?php echo esc_url( home_url( '/service/' . $s->slug ) ); ?>" target="_blank">View</a></small>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo esc_html( $s->expert_name ); ?></td>
                                <td><?php echo NMEP_Services::get_status_badge( $s->status ); ?></td>
                                <td><?php echo nmep_format_inr( $s->basic_price ); ?></td>
                                <td><?php echo (int) $s->orders_count; ?></td>
                                <td><?php echo (int) $s->views; ?></td>
                                <td><?php echo esc_html( date( 'd M Y', strtotime( $s->created_at ) ) ); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php
    }

    /* ============================================================
       SETTINGS
       ============================================================ */
    public static function render_settings() {
        if ( isset( $_GET['settings-updated'] ) ) {
            echo '<div class="notice notice-success is-dismissible"><p>Settings saved.</p></div>';
        }
        $s = NMEP_Settings::all();
        ?>
        <div class="wrap nmep-admin">
            <h1>NME Payments — Settings</h1>
            <form method="post" action="options.php">
                <?php settings_fields( 'nmep_settings_group' ); ?>

                <h2 class="title">Mode</h2>
                <table class="form-table">
                    <tr><th>Active Mode</th><td>
                        <select name="nmep_settings[mode]">
                            <option value="test" <?php selected( $s['mode'], 'test' ); ?>>Test Mode (Sandbox)</option>
                            <option value="live" <?php selected( $s['mode'], 'live' ); ?>>Live Mode (Production)</option>
                        </select>
                    </td></tr>
                </table>

                <h2 class="title">Test Mode Credentials</h2>
                <table class="form-table">
                    <tr><th>Test Key ID</th><td><input type="text" name="nmep_settings[test_key_id]" value="<?php echo esc_attr( $s['test_key_id'] ); ?>" style="width:480px;" placeholder="rzp_test_..."></td></tr>
                    <tr><th>Test Key Secret</th><td><input type="password" name="nmep_settings[test_key_secret]" value="<?php echo esc_attr( $s['test_key_secret'] ); ?>" style="width:480px;"></td></tr>
                    <tr><th>Test Webhook Secret</th><td><input type="password" name="nmep_settings[test_webhook_secret]" value="<?php echo esc_attr( $s['test_webhook_secret'] ); ?>" style="width:480px;"></td></tr>
                </table>

                <h2 class="title">Live Mode Credentials</h2>
                <p style="color: #b00; font-weight: 600;">⚠️ Only fill these after Razorpay Route is approved.</p>
                <table class="form-table">
                    <tr><th>Live Key ID</th><td><input type="text" name="nmep_settings[live_key_id]" value="<?php echo esc_attr( $s['live_key_id'] ); ?>" style="width:480px;" placeholder="rzp_live_..."></td></tr>
                    <tr><th>Live Key Secret</th><td><input type="password" name="nmep_settings[live_key_secret]" value="<?php echo esc_attr( $s['live_key_secret'] ); ?>" style="width:480px;"></td></tr>
                    <tr><th>Live Webhook Secret</th><td><input type="password" name="nmep_settings[live_webhook_secret]" value="<?php echo esc_attr( $s['live_webhook_secret'] ); ?>" style="width:480px;"></td></tr>
                </table>

                <h2 class="title">Marketplace</h2>
                <table class="form-table">
                    <tr><th>Default Commission Rate (%)</th><td><input type="number" step="0.01" min="0" max="50" name="nmep_settings[default_commission_rate]" value="<?php echo esc_attr( $s['default_commission_rate'] ); ?>" style="width:120px;"></td></tr>
                    <tr><th>Founding Expert Commission (%)</th><td><input type="number" step="0.01" min="0" max="50" name="nmep_settings[founding_expert_commission_rate]" value="<?php echo esc_attr( $s['founding_expert_commission_rate'] ); ?>" style="width:120px;"></td></tr>
                    <tr><th>Auto-Release After (days)</th><td><input type="number" min="1" max="30" name="nmep_settings[auto_release_days]" value="<?php echo esc_attr( $s['auto_release_days'] ); ?>" style="width:120px;"></td></tr>
                    <tr><th>Min Order (₹)</th><td><input type="number" name="nmep_settings[min_order_amount]" value="<?php echo esc_attr( $s['min_order_amount'] ); ?>" style="width:120px;"></td></tr>
                    <tr><th>Max Order (₹)</th><td><input type="number" name="nmep_settings[max_order_amount]" value="<?php echo esc_attr( $s['max_order_amount'] ); ?>" style="width:120px;"></td></tr>
                </table>

                <h2 class="title">Branding</h2>
                <table class="form-table">
                    <tr><th>Merchant Name</th><td><input type="text" name="nmep_settings[merchant_name]" value="<?php echo esc_attr( $s['merchant_name'] ); ?>" style="width:380px;"></td></tr>
                    <tr><th>Theme Color</th><td><input type="text" name="nmep_settings[theme_color]" value="<?php echo esc_attr( $s['theme_color'] ); ?>" style="width:120px;"></td></tr>
                    <tr><th>Logo URL</th><td><input type="url" name="nmep_settings[logo_url]" value="<?php echo esc_attr( $s['logo_url'] ); ?>" style="width:480px;"></td></tr>
                    <tr><th>Support Email</th><td><input type="email" name="nmep_settings[support_email]" value="<?php echo esc_attr( $s['support_email'] ); ?>" style="width:380px;"></td></tr>
                </table>

                <h2 class="title">Behavior</h2>
                <table class="form-table">
                    <tr><th>Guest Checkout</th><td><label><input type="checkbox" name="nmep_settings[enable_guest_checkout]" value="1" <?php checked( $s['enable_guest_checkout'], true ); ?>> Allow buyers to checkout without account</label></td></tr>
                    <tr><th>Debug Logs</th><td><label><input type="checkbox" name="nmep_settings[enable_debug_logs]" value="1" <?php checked( $s['enable_debug_logs'], true ); ?>> Verbose debug logging</label></td></tr>
                </table>

                <h2 class="title">Premium Membership</h2>
                <p style="color:#555;max-width:780px;">
                    Sets the price and perks of the <strong>Premium Buyer</strong> program. Changes apply only to <em>new</em>
                    purchases and renewals — existing Premium members keep the terms they paid for. Leave the module
                    disabled to hide the Premium pages from buyers without uninstalling.
                </p>
                <table class="form-table">
                    <tr>
                        <th>Enable Premium Buyer</th>
                        <td>
                            <label><input type="checkbox" name="nmep_settings[premium_buyer_enabled]" value="1" <?php checked( ! empty( $s['premium_buyer_enabled'] ), true ); ?>> Offer the Premium Buyer program to site visitors</label>
                            <p class="description">Unchecked = the landing page, checkout, and discounts are all disabled. Existing memberships are preserved but stop applying discounts.</p>
                        </td>
                    </tr>
                    <tr>
                        <th>Price (₹)</th>
                        <td>
                            <input type="number" step="1" min="1" max="99999" name="nmep_settings[premium_buyer_price]" value="<?php echo esc_attr( $s['premium_buyer_price'] ); ?>" style="width:160px;">
                            <p class="description">One-time payment in INR. Default <code>499</code>. Never charged again until the buyer manually renews.</p>
                        </td>
                    </tr>
                    <tr>
                        <th>Duration (days)</th>
                        <td>
                            <input type="number" step="1" min="1" max="3650" name="nmep_settings[premium_buyer_duration_days]" value="<?php echo esc_attr( $s['premium_buyer_duration_days'] ); ?>" style="width:160px;">
                            <p class="description">How long each purchase lasts. Default <code>365</code> (one year).</p>
                        </td>
                    </tr>
                    <tr>
                        <th>Premium Discount (%)</th>
                        <td>
                            <input type="number" step="0.01" min="0" max="50" name="nmep_settings[premium_buyer_discount_percent]" value="<?php echo esc_attr( $s['premium_buyer_discount_percent'] ); ?>" style="width:120px;">
                            <p class="description">Auto-applied off every order a Premium Buyer places. Stacks with coupons. Default <code>5</code>. Discounts come out of the expert's share — commission is always computed on the original price.</p>
                        </td>
                    </tr>
                    <tr>
                        <th>Trusted Buyer Discount (%)</th>
                        <td>
                            <input type="number" step="0.01" min="0" max="50" name="nmep_settings[premium_buyer_trusted_discount_percent]" value="<?php echo esc_attr( $s['premium_buyer_trusted_discount_percent'] ); ?>" style="width:120px;">
                            <p class="description">Lifetime reward for approved whistleblower reports. Stacks additively with Premium. Default <code>3</code>.</p>
                        </td>
                    </tr>
                </table>

                <h2 class="title">SMS &amp; WhatsApp (MSG91)</h2>
                <p style="color:#555;max-width:780px;">
                    Sends OTPs and transactional alerts over SMS (and optionally WhatsApp) via
                    <a href="https://msg91.com/" target="_blank" rel="noopener">MSG91</a>. Indian SMS requires
                    DLT registration (sender ID + message template approval by TRAI) — MSG91 walks you through
                    it on signup. Leave disabled to keep delivery on email only.
                </p>
                <table class="form-table">
                    <tr>
                        <th>Enable SMS</th>
                        <td>
                            <label><input type="checkbox" name="nmep_settings[msg91_enabled]" value="1" <?php checked( $s['msg91_enabled'], true ); ?>> Send OTPs and alerts over MSG91 SMS</label>
                            <p class="description">Unchecked = SMS code path is disabled; emails still go out as usual.</p>
                        </td>
                    </tr>
                    <tr>
                        <th>MSG91 Auth Key</th>
                        <td>
                            <input type="password" name="nmep_settings[msg91_auth_key]" value="<?php echo esc_attr( $s['msg91_auth_key'] ); ?>" style="width:480px;" placeholder="Your MSG91 Auth Key" autocomplete="off">
                            <p class="description">Find in MSG91 Dashboard → Settings → API Keys. Stored in <code>wp_options</code>.</p>
                        </td>
                    </tr>
                    <tr>
                        <th>Sender ID (SMS)</th>
                        <td>
                            <input type="text" name="nmep_settings[msg91_sender_id]" value="<?php echo esc_attr( $s['msg91_sender_id'] ); ?>" style="width:200px;" maxlength="6" placeholder="NMEXPT">
                            <p class="description">Exactly 6 characters, DLT-approved. Default: <code>NMEXPT</code>.</p>
                        </td>
                    </tr>
                    <tr>
                        <th>SMS Route</th>
                        <td>
                            <select name="nmep_settings[msg91_route]">
                                <option value="4" <?php selected( $s['msg91_route'], '4' ); ?>>4 — Transactional (OTPs, order alerts)</option>
                                <option value="1" <?php selected( $s['msg91_route'], '1' ); ?>>1 — Promotional</option>
                            </select>
                            <p class="description">Keep on <strong>4 (Transactional)</strong> for OTPs.</p>
                        </td>
                    </tr>
                    <tr>
                        <th>Country Code</th>
                        <td>
                            <input type="text" name="nmep_settings[msg91_country_code]" value="<?php echo esc_attr( $s['msg91_country_code'] ); ?>" style="width:100px;" maxlength="3" placeholder="91">
                            <p class="description">Dialing code without <code>+</code>. India = <code>91</code>.</p>
                        </td>
                    </tr>
                    <tr>
                        <th>Enable WhatsApp</th>
                        <td>
                            <label><input type="checkbox" name="nmep_settings[whatsapp_enabled]" value="1" <?php checked( $s['whatsapp_enabled'], true ); ?>> Send order notifications over MSG91 WhatsApp</label>
                            <p class="description">Requires a separate MSG91 WhatsApp Business number — enable only after it's approved.</p>
                        </td>
                    </tr>
                    <tr>
                        <th>WhatsApp Integrated Number</th>
                        <td>
                            <input type="text" name="nmep_settings[whatsapp_integrated_number]" value="<?php echo esc_attr( $s['whatsapp_integrated_number'] ); ?>" style="width:260px;" placeholder="+919876543210">
                            <p class="description">E.164 format (e.g. <code>+919876543210</code>). Required only if WhatsApp is enabled.</p>
                        </td>
                    </tr>
                </table>

                <?php submit_button( 'Save Settings' ); ?>
            </form>
        </div>
        <?php
    }

    /* ============================================================
       ORDERS (with refund button)
       ============================================================ */
    public static function render_orders() {
        global $wpdb;
        $orders = $wpdb->get_results( "SELECT * FROM " . NMEP_Database::table( 'orders' ) . " ORDER BY id DESC LIMIT 100" );

        if ( isset( $_GET['nmep_refunded'] ) ) {
            echo '<div class="notice notice-success is-dismissible"><p>Refund initiated successfully.</p></div>';
        }
        if ( isset( $_GET['nmep_error'] ) ) {
            echo '<div class="notice notice-error is-dismissible"><p>' . esc_html( urldecode( $_GET['nmep_error'] ) ) . '</p></div>';
        }
        ?>
        <div class="wrap nmep-admin">
            <h1>Orders</h1>
            <table class="wp-list-table widefat fixed striped">
                <thead><tr><th>Order #</th><th>Buyer</th><th>Service</th><th>Amount</th><th>Status</th><th>Escrow</th><th>Created</th><th>Actions</th></tr></thead>
                <tbody>
                    <?php if ( empty( $orders ) ) : ?>
                        <tr><td colspan="8" style="text-align:center;padding:40px;">No orders yet.</td></tr>
                    <?php else : ?>
                        <?php foreach ( $orders as $o ) : ?>
                            <tr>
                                <td><code><?php echo esc_html( $o->order_number ); ?></code></td>
                                <td><?php echo esc_html( $o->buyer_name ); ?><br><small><?php echo esc_html( $o->buyer_email ); ?></small></td>
                                <td><?php echo esc_html( $o->service_title ); ?><br><small><?php echo esc_html( ucfirst( $o->package_tier ) ); ?></small></td>
                                <td><?php echo nmep_format_inr( $o->gross_amount ); ?></td>
                                <td><?php echo esc_html( str_replace( '_', ' ', $o->status ) ); ?></td>
                                <td><?php echo esc_html( $o->escrow_status ); ?></td>
                                <td><?php echo esc_html( date( 'd M Y H:i', strtotime( $o->created_at ) ) ); ?></td>
                                <td>
                                    <?php if ( $o->payment_status === 'captured' && $o->status !== 'refunded' ) : ?>
                                        <details>
                                            <summary style="cursor:pointer;color:#d63638;">Refund</summary>
                                            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin-top:8px;background:#FEF2F2;padding:10px;border-radius:6px;">
                                                <input type="hidden" name="action" value="nmep_admin_create_refund">
                                                <input type="hidden" name="order_id" value="<?php echo (int) $o->id; ?>">
                                                <?php wp_nonce_field( 'nmep_refund_' . $o->id ); ?>
                                                <p style="margin:4px 0;">
                                                    <select name="refund_type" style="width:100%;">
                                                        <option value="full">Full Refund (<?php echo nmep_format_inr( $o->gross_amount ); ?>)</option>
                                                        <option value="partial">Partial Refund</option>
                                                    </select>
                                                </p>
                                                <p style="margin:4px 0;">
                                                    <input type="number" name="amount" placeholder="Amount (₹)" step="0.01" min="0.01" max="<?php echo esc_attr( $o->gross_amount ); ?>" style="width:100%;">
                                                </p>
                                                <p style="margin:4px 0;">
                                                    <input type="text" name="reason" placeholder="Reason (required)" required style="width:100%;">
                                                </p>
                                                <button type="submit" class="button button-small" style="background:#d63638;color:#fff;border-color:#d63638;" onclick="return confirm('Issue this refund? This action cannot be undone.');">Process</button>
                                            </form>
                                        </details>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php
    }

    /* ============================================================
       DISPUTES PAGE
       ============================================================ */
    public static function render_disputes() {
        if ( isset( $_GET['resolved'] ) ) {
            echo '<div class="notice notice-success is-dismissible"><p>Dispute resolved.</p></div>';
        }

        $disputes = NMEP_Disputes::get_open();
        ?>
        <div class="wrap nmep-admin">
            <h1>Open Disputes</h1>
            <p>Disputes raised by buyers or experts that need your mediation.</p>

            <?php if ( empty( $disputes ) ) : ?>
                <div class="nmep-section nmep-text-center">
                    <h3>🎉 No open disputes</h3>
                    <p>Great! There are no disputes requiring attention.</p>
                </div>
            <?php else : ?>
                <?php foreach ( $disputes as $dispute ) : ?>
                    <div class="nmep-section" style="border-left: 4px solid #EF4444;">
                        <div style="display: flex; justify-content: space-between; align-items: start; gap: 24px; flex-wrap: wrap;">
                            <div style="flex: 1; min-width: 300px;">
                                <h3 style="margin-top: 0;">
                                    <?php echo esc_html( $dispute->order_number ); ?>
                                    <span style="background: <?php echo $dispute->opened_role === 'buyer' ? '#EF4444' : '#3B82F6'; ?>; color: #fff; padding: 3px 10px; border-radius: 50px; font-size: 0.7rem; text-transform: uppercase; margin-left: 8px;">
                                        Opened by <?php echo esc_html( $dispute->opened_role ); ?>
                                    </span>
                                </h3>
                                <p>
                                    <strong>Service:</strong> <?php echo esc_html( $dispute->service_title ); ?><br>
                                    <strong>Buyer:</strong> <?php echo esc_html( $dispute->buyer_name ); ?> (<?php echo esc_html( $dispute->buyer_email ); ?>)<br>
                                    <strong>Amount:</strong> <?php echo nmep_format_inr( $dispute->gross_amount ); ?><br>
                                    <strong>Reason:</strong> <?php echo esc_html( $dispute->reason ); ?><br>
                                    <strong>Opened:</strong> <?php echo esc_html( date( 'd M Y H:i', strtotime( $dispute->created_at ) ) ); ?>
                                </p>
                                <h4>Description:</h4>
                                <div style="background: #F9FAFB; padding: 16px; border-radius: 8px; white-space: pre-line;"><?php echo esc_html( $dispute->description ); ?></div>
                            </div>

                            <div style="width: 320px; min-width: 280px;">
                                <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="background: #F9FAFB; padding: 16px; border-radius: 8px;">
                                    <input type="hidden" name="action" value="nmep_admin_resolve_dispute">
                                    <input type="hidden" name="dispute_id" value="<?php echo (int) $dispute->id; ?>">
                                    <?php wp_nonce_field( 'nmep_resolve_dispute_' . $dispute->id ); ?>

                                    <h4 style="margin-top: 0;">Resolve</h4>

                                    <p>
                                        <label><strong>Resolution</strong></label>
                                        <select name="resolution" required onchange="document.getElementById('partial_<?php echo (int) $dispute->id; ?>').style.display = this.value === 'partial_refund' ? 'block' : 'none';" style="width: 100%; padding: 6px;">
                                            <option value="">— Select —</option>
                                            <option value="refund_buyer">Refund buyer (full)</option>
                                            <option value="release_to_expert">Release to expert</option>
                                            <option value="partial_refund">Partial refund</option>
                                        </select>
                                    </p>

                                    <p id="partial_<?php echo (int) $dispute->id; ?>" style="display: none;">
                                        <label>Refund amount (₹)</label>
                                        <input type="number" name="partial_amount" min="1" max="<?php echo esc_attr( $dispute->gross_amount ); ?>" step="0.01" style="width: 100%; padding: 6px;">
                                    </p>

                                    <p>
                                        <label>Resolution Notes</label>
                                        <textarea name="notes" rows="3" required placeholder="Explain your decision..." style="width: 100%; padding: 6px;"></textarea>
                                    </p>

                                    <button type="submit" class="button button-primary" onclick="return confirm('Apply this resolution? This action is final.');">Resolve Dispute</button>
                                </form>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
        <?php
    }

    /* ============================================================
       LINKED ACCOUNTS
       ============================================================ */
    public static function render_linked_accounts() {
        global $wpdb;
        $accounts = $wpdb->get_results(
            "SELECT la.*, e.full_name, e.email
             FROM " . NMEP_Database::table( 'linked_accounts' ) . " la
             LEFT JOIN " . NMEP_Compat::base_table( 'experts' ) . " e ON e.id = la.expert_id
             ORDER BY la.id DESC LIMIT 100"
        );

        // Approved experts with no linked account row in the current mode yet.
        // Powers the "Create Linked Account" UI below so admins don't need SQL to bootstrap.
        $mode          = NMEP_Settings::get_mode();
        $experts_table = NMEP_Compat::base_table( 'experts' );
        $linked_table  = NMEP_Database::table( 'linked_accounts' );
        $missing = $wpdb->get_results( $wpdb->prepare(
            "SELECT e.id, e.full_name, e.email, e.bank_account_number, e.bank_ifsc, e.pan_number,
                    e.street_address, e.village_locality, e.postal_code
             FROM {$experts_table} e
             WHERE e.status = %s
             AND NOT EXISTS (
                 SELECT 1 FROM {$linked_table} la
                 WHERE la.expert_id = e.id AND la.mode = %s
             )
             ORDER BY e.id DESC LIMIT 100",
            'approved', $mode
        ) );
        ?>
        <div class="wrap nmep-admin">
            <h1>Linked Accounts (Razorpay Route)</h1>
            <p>Each expert needs a Razorpay Linked Account to receive payments.</p>

            <?php if ( isset( $_GET['nmep_error'] ) ) : ?>
                <div class="notice notice-error"><p><?php echo esc_html( urldecode( $_GET['nmep_error'] ) ); ?></p></div>
            <?php endif; ?>
            <?php if ( isset( $_GET['nmep_success'] ) ) : ?>
                <div class="notice notice-success"><p>Linked Account created successfully.</p></div>
            <?php endif; ?>

            <?php if ( ! empty( $missing ) ) : ?>
                <h2 style="margin-top:24px;">Approved experts without a Linked Account (<?php echo esc_html( strtoupper( $mode ) ); ?> mode)</h2>
                <table class="wp-list-table widefat fixed striped" style="margin-bottom:32px;">
                    <thead><tr><th>Expert</th><th>Bank</th><th>PAN</th><th>Address</th><th>Action</th></tr></thead>
                    <tbody>
                        <?php foreach ( $missing as $m ) :
                            $has_bank    = ! empty( $m->bank_account_number ) && ! empty( $m->bank_ifsc );
                            $has_pan     = ! empty( $m->pan_number );
                            $has_address = ! empty( $m->street_address )
                                && ! empty( $m->village_locality )
                                && preg_match( '/^\d{6}$/', (string) $m->postal_code );
                            $ready = $has_bank && $has_pan && $has_address;
                            $edit_url = admin_url( 'admin.php?page=nme-experts&action=view&id=' . (int) $m->id );
                        ?>
                            <tr>
                                <td><strong><?php echo esc_html( $m->full_name ); ?></strong><br><small>#<?php echo (int) $m->id; ?> · <?php echo esc_html( $m->email ); ?></small></td>
                                <td><?php echo $has_bank ? '&#10003;' : '<span style="color:#c00;">missing</span>'; ?></td>
                                <td><?php echo $has_pan ? '&#10003;' : '<span style="color:#c00;">missing</span>'; ?></td>
                                <td>
                                    <?php if ( $has_address ) : ?>
                                        &#10003;
                                    <?php else : ?>
                                        <a href="<?php echo esc_url( $edit_url ); ?>" style="color:#c00;">missing — fill it</a>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if ( $ready ) : ?>
                                        <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline;">
                                            <input type="hidden" name="action" value="nmep_create_linked_account">
                                            <input type="hidden" name="expert_id" value="<?php echo (int) $m->id; ?>">
                                            <?php wp_nonce_field( 'nmep_create_linked_' . $m->id ); ?>
                                            <button type="submit" class="button button-primary button-small">Create Linked Account</button>
                                        </form>
                                    <?php else : ?>
                                        <em style="color:#999;">Complete all fields first</em>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>

            <table class="wp-list-table widefat fixed striped">
                <thead><tr><th>Expert</th><th>Razorpay ID</th><th>Mode</th><th>Status</th><th>Activation</th><th>Created</th><th>Actions</th></tr></thead>
                <tbody>
                    <?php if ( empty( $accounts ) ) : ?>
                        <tr><td colspan="7" style="text-align:center;padding:40px;">No Linked Accounts yet.</td></tr>
                    <?php else : ?>
                        <?php foreach ( $accounts as $a ) : ?>
                            <tr>
                                <td><strong><?php echo esc_html( $a->full_name ); ?></strong><br><small><?php echo esc_html( $a->email ); ?></small></td>
                                <td><?php echo $a->razorpay_account_id ? '<code>' . esc_html( $a->razorpay_account_id ) . '</code>' : '—'; ?></td>
                                <td><?php echo esc_html( strtoupper( $a->mode ) ); ?></td>
                                <td><?php echo esc_html( $a->status ); ?></td>
                                <td><?php echo esc_html( $a->activation_status ); ?></td>
                                <td><?php echo esc_html( date( 'd M Y', strtotime( $a->created_at ) ) ); ?></td>
                                <td>
                                    <?php if ( ! $a->razorpay_account_id ) : ?>
                                        <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline;">
                                            <input type="hidden" name="action" value="nmep_create_linked_account">
                                            <input type="hidden" name="expert_id" value="<?php echo (int) $a->expert_id; ?>">
                                            <?php wp_nonce_field( 'nmep_create_linked_' . $a->expert_id ); ?>
                                            <button type="submit" class="button button-small">Retry</button>
                                        </form>
                                    <?php else : ?>—<?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php
    }

    /* ============================================================
       LOGS
       ============================================================ */
    public static function render_logs() {
        $logs = NMEP_Logger::get_recent( 200 );
        ?>
        <div class="wrap nmep-admin">
            <h1>Logs</h1>
            <p>Last 200 entries. Logs kept 30 days.</p>
            <div style="background:#1e1e1e;color:#e0e0e0;padding:16px;font-family:monospace;font-size:12px;max-height:600px;overflow:auto;border-radius:4px;">
                <?php if ( empty( $logs ) ) : ?>
                    <p>No log entries yet.</p>
                <?php else : ?>
                    <?php foreach ( array_reverse( $logs ) as $line ) :
                        $color = '#e0e0e0';
                        if ( strpos( $line, '[ERROR]' ) !== false || strpos( $line, '[CRITICAL]' ) !== false ) $color = '#ff6b6b';
                        elseif ( strpos( $line, '[WARNING]' ) !== false ) $color = '#feca57';
                        elseif ( strpos( $line, '[INFO]' ) !== false ) $color = '#48dbfb';
                    ?>
                        <div style="color:<?php echo $color; ?>;margin-bottom:4px;word-break:break-all;"><?php echo esc_html( $line ); ?></div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
        <?php
    }
}

add_action( 'nmep_create_linked_async', function( $expert_id ) {
    NMEP_Linked_Accounts::create_for_expert( (int) $expert_id );
}, 10, 1 );