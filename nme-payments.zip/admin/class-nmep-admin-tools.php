<?php
/**
 * NMEP_Admin_Tools
 *
 * Phase 5A — ops console for the NME Payments admin:
 *
 *   1. Bulk CSV export for orders, services, experts, payouts, sms_log.
 *      Streams rows directly to the browser (no temp file, no memory
 *      blow-up) via fputcsv against php://output.
 *
 *   2. User impersonation ("View as buyer / expert"). An admin can
 *      assume another user's identity; the original admin id is stored
 *      so a "Switch back" link restores the session. Every switch is
 *      written to nmep_audit_log.
 *
 *   3. Unified moderation queue that aggregates: services pending
 *      review, open disputes (with SLA remaining), flagged / reported
 *      reviews, and messages flagged by the blocked-word filter. One
 *      page to clear everything.
 *
 * @package NagalandMeExpertsPayments
 * @since   2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class NMEP_Admin_Tools {

    const IMPERSONATION_COOKIE = 'nmep_impersonate_original';
    const IMPERSONATION_META   = '_nmep_impersonating_as';

    public static function init() {
        add_action( 'admin_menu',                      array( __CLASS__, 'register_menu' ), 25 );
        add_action( 'admin_post_nmep_csv_export',      array( __CLASS__, 'handle_csv_export' ) );
        add_action( 'admin_post_nmep_impersonate',     array( __CLASS__, 'handle_impersonate' ) );
        add_action( 'admin_post_nmep_stop_impersonate',array( __CLASS__, 'handle_stop_impersonate' ) );
        add_action( 'admin_bar_menu',                  array( __CLASS__, 'admin_bar_switch_back' ), 999 );
    }

    /* ============================================================
       MENU
       ============================================================ */

    public static function register_menu() {
        add_submenu_page(
            'nmep-dashboard',
            'Exports',
            'Exports',
            'manage_options',
            'nmep-exports',
            array( __CLASS__, 'render_exports' )
        );

        $pending = self::moderation_totals();
        $label = 'Moderation';
        if ( $pending['total'] > 0 ) {
            $label .= ' <span class="awaiting-mod">' . (int) $pending['total'] . '</span>';
        }
        add_submenu_page(
            'nmep-dashboard',
            'Moderation Queue',
            $label,
            'manage_options',
            'nmep-moderation',
            array( __CLASS__, 'render_moderation' )
        );

        add_submenu_page(
            'nmep-dashboard',
            'Impersonate User',
            'Impersonate',
            'manage_options',
            'nmep-impersonate',
            array( __CLASS__, 'render_impersonate' )
        );
    }

    /* ============================================================
       CSV EXPORT
       ============================================================ */

    public static function render_exports() {
        if ( ! current_user_can( 'manage_options' ) ) return;
        $nonce = wp_create_nonce( 'nmep_csv_export' );
        ?>
        <div class="wrap nmep-admin">
            <h1>Exports</h1>
            <p>Streamed CSV of every row in the requested dataset. Large datasets are safe — rows are written directly to the HTTP response.</p>

            <table class="widefat striped" style="max-width:880px;">
                <thead><tr><th>Dataset</th><th>Description</th><th style="width:160px;">Action</th></tr></thead>
                <tbody>
                <?php
                $datasets = array(
                    'orders'   => 'All orders with amounts, parties, payment status, payout status.',
                    'services' => 'All services (catalog) with pricing, category, expert, status.',
                    'experts'  => 'All WP users with the expert role, including payout UPI if set.',
                    'payouts'  => 'All payout ledger rows (escrow splits, UPI payouts, refunds).',
                    'sms_log'  => 'All outbound SMS / WhatsApp dispatch attempts with provider response.',
                    'coupons'  => 'All coupons with redemption counts.',
                );
                foreach ( $datasets as $slug => $desc ) :
                    $url = admin_url( 'admin-post.php' );
                    ?>
                    <tr>
                        <td><strong><?php echo esc_html( $slug ); ?>.csv</strong></td>
                        <td><?php echo esc_html( $desc ); ?></td>
                        <td>
                            <form method="post" action="<?php echo esc_url( $url ); ?>" style="margin:0;">
                                <input type="hidden" name="action" value="nmep_csv_export" />
                                <input type="hidden" name="dataset" value="<?php echo esc_attr( $slug ); ?>" />
                                <input type="hidden" name="_wpnonce" value="<?php echo esc_attr( $nonce ); ?>" />
                                <button class="button button-primary">Download CSV</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php
    }

    public static function handle_csv_export() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( 'Forbidden' );
        }
        check_admin_referer( 'nmep_csv_export' );

        $dataset = isset( $_POST['dataset'] ) ? sanitize_key( $_POST['dataset'] ) : '';
        $allowed = array( 'orders', 'services', 'experts', 'payouts', 'sms_log', 'coupons' );
        if ( ! in_array( $dataset, $allowed, true ) ) {
            wp_die( 'Unknown dataset' );
        }

        if ( class_exists( 'NMEP_Audit_Log' ) ) {
            NMEP_Audit_Log::record( 'admin.csv_export', 'dataset', null, array( 'dataset' => $dataset ) );
        }

        nocache_headers();
        header( 'Content-Type: text/csv; charset=utf-8' );
        header( 'Content-Disposition: attachment; filename="nmep-' . $dataset . '-' . gmdate( 'Ymd-His' ) . '.csv"' );

        $out = fopen( 'php://output', 'w' );
        switch ( $dataset ) {
            case 'orders':   self::stream_orders( $out );   break;
            case 'services': self::stream_services( $out ); break;
            case 'experts':  self::stream_experts( $out );  break;
            case 'payouts':  self::stream_payouts( $out );  break;
            case 'sms_log':  self::stream_sms_log( $out );  break;
            case 'coupons':  self::stream_coupons( $out );  break;
        }
        fclose( $out );
        exit;
    }

    private static function stream_orders( $out ) {
        global $wpdb;
        fputcsv( $out, array(
            'id','order_number','status','payment_status','buyer_email','buyer_phone',
            'expert_id','service_title','gross_amount','commission_amount','expert_amount',
            'tax_amount','discount_amount','coupon_code','razorpay_order_id','razorpay_payment_id',
            'created_at','paid_at','delivered_at','completed_at'
        ) );
        $table = NMEP_Database::table( 'orders' );
        $batch = 500;
        $offset = 0;
        while ( true ) {
            $rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM $table ORDER BY id ASC LIMIT %d OFFSET %d", $batch, $offset ), ARRAY_A );
            if ( empty( $rows ) ) break;
            foreach ( $rows as $r ) {
                fputcsv( $out, array(
                    $r['id'], $r['order_number'], $r['status'], $r['payment_status'],
                    $r['buyer_email'] ?? '', $r['buyer_phone'] ?? '',
                    $r['expert_id'] ?? '', $r['service_title'] ?? '',
                    $r['gross_amount'] ?? '', $r['commission_amount'] ?? '', $r['expert_amount'] ?? '',
                    $r['tax_amount'] ?? '', $r['discount_amount'] ?? '', $r['coupon_code'] ?? '',
                    $r['razorpay_order_id'] ?? '', $r['razorpay_payment_id'] ?? '',
                    $r['created_at'] ?? '', $r['paid_at'] ?? '', $r['delivered_at'] ?? '', $r['completed_at'] ?? '',
                ) );
            }
            $offset += $batch;
            if ( count( $rows ) < $batch ) break;
        }
    }

    private static function stream_services( $out ) {
        global $wpdb;
        fputcsv( $out, array( 'id','expert_id','title','category','price','status','created_at','updated_at' ) );
        $table = NMEP_Database::table( 'services' );
        $batch = 500; $offset = 0;
        while ( true ) {
            $rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM $table ORDER BY id ASC LIMIT %d OFFSET %d", $batch, $offset ), ARRAY_A );
            if ( empty( $rows ) ) break;
            foreach ( $rows as $r ) {
                fputcsv( $out, array(
                    $r['id'], $r['expert_id'] ?? '', $r['title'] ?? '', $r['category'] ?? '',
                    $r['price'] ?? '', $r['status'] ?? '', $r['created_at'] ?? '', $r['updated_at'] ?? '',
                ) );
            }
            $offset += $batch;
            if ( count( $rows ) < $batch ) break;
        }
    }

    private static function stream_experts( $out ) {
        fputcsv( $out, array( 'user_id','email','display_name','registered','upi_vpa','tier','total_orders','avg_rating' ) );
        $users = get_users( array( 'role' => 'expert', 'number' => -1, 'fields' => array( 'ID','user_email','display_name','user_registered' ) ) );
        foreach ( $users as $u ) {
            $upi = get_user_meta( $u->ID, 'nmep_upi_vpa', true );
            $tier = get_user_meta( $u->ID, 'nmep_tier', true );
            $stats = class_exists( 'NMEP_Tiers' ) ? NMEP_Tiers::get_stats( (int) $u->ID ) : null;
            fputcsv( $out, array(
                $u->ID, $u->user_email, $u->display_name, $u->user_registered,
                $upi ?: '', $tier ?: '',
                $stats['total_orders'] ?? '', $stats['avg_rating'] ?? '',
            ) );
        }
    }

    private static function stream_payouts( $out ) {
        global $wpdb;
        fputcsv( $out, array( 'id','order_id','expert_id','type','amount','currency','status','reference','created_at','completed_at' ) );
        $table = NMEP_Database::table( 'payouts' );
        $batch = 500; $offset = 0;
        while ( true ) {
            $rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM $table ORDER BY id ASC LIMIT %d OFFSET %d", $batch, $offset ), ARRAY_A );
            if ( empty( $rows ) ) break;
            foreach ( $rows as $r ) {
                fputcsv( $out, array(
                    $r['id'], $r['order_id'] ?? '', $r['expert_id'] ?? '',
                    $r['type'] ?? '', $r['amount'] ?? '', $r['currency'] ?? '',
                    $r['status'] ?? '', $r['reference'] ?? $r['razorpayx_payout_id'] ?? '',
                    $r['created_at'] ?? '', $r['completed_at'] ?? '',
                ) );
            }
            $offset += $batch;
            if ( count( $rows ) < $batch ) break;
        }
    }

    private static function stream_sms_log( $out ) {
        global $wpdb;
        fputcsv( $out, array( 'id','channel','recipient','template','status','provider_id','created_at' ) );
        $table = NMEP_Database::table( 'sms_log' );
        $batch = 500; $offset = 0;
        while ( true ) {
            $rows = $wpdb->get_results( $wpdb->prepare( "SELECT id,channel,recipient,template,status,provider_id,created_at FROM $table ORDER BY id ASC LIMIT %d OFFSET %d", $batch, $offset ), ARRAY_A );
            if ( empty( $rows ) ) break;
            foreach ( $rows as $r ) {
                fputcsv( $out, array(
                    $r['id'], $r['channel'], $r['recipient'], $r['template'],
                    $r['status'], $r['provider_id'] ?? '', $r['created_at'] ?? '',
                ) );
            }
            $offset += $batch;
            if ( count( $rows ) < $batch ) break;
        }
    }

    private static function stream_coupons( $out ) {
        global $wpdb;
        fputcsv( $out, array( 'id','code','type','discount_value','max_uses','times_used','active','expires_at','created_at' ) );
        if ( ! class_exists( 'NMEP_Coupons' ) ) return;
        $table = method_exists( 'NMEP_Coupons', 'table' ) ? NMEP_Coupons::table() : NMEP_Database::table( 'coupons' );
        $rows = $wpdb->get_results( "SELECT * FROM $table ORDER BY id ASC", ARRAY_A );
        foreach ( $rows as $r ) {
            fputcsv( $out, array(
                $r['id'], $r['code'] ?? '', $r['type'] ?? '',
                $r['discount_value'] ?? '', $r['max_uses'] ?? '', $r['times_used'] ?? '',
                $r['active'] ?? '', $r['expires_at'] ?? '', $r['created_at'] ?? '',
            ) );
        }
    }

    /* ============================================================
       IMPERSONATION
       ============================================================ */

    public static function render_impersonate() {
        if ( ! current_user_can( 'manage_options' ) ) return;
        $nonce = wp_create_nonce( 'nmep_impersonate' );
        ?>
        <div class="wrap nmep-admin">
            <h1>Impersonate User</h1>
            <p class="description">Switch into a user's session to reproduce issues, verify checkout flow, or inspect a dashboard. Every switch is recorded to the audit log. A floating "Switch back" bar appears in the admin toolbar.</p>

            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                <input type="hidden" name="action" value="nmep_impersonate" />
                <input type="hidden" name="_wpnonce" value="<?php echo esc_attr( $nonce ); ?>" />
                <table class="form-table">
                    <tr>
                        <th><label for="target">Target user</label></th>
                        <td>
                            <input type="text" id="target" name="target" class="regular-text" placeholder="email, username, or user ID" required />
                            <p class="description">Admins and super admins cannot be impersonated.</p>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="reason">Reason (logged)</label></th>
                        <td><input type="text" id="reason" name="reason" class="regular-text" maxlength="200" required /></td>
                    </tr>
                </table>
                <?php submit_button( 'Start impersonating', 'primary' ); ?>
            </form>
        </div>
        <?php
    }

    public static function handle_impersonate() {
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Forbidden' );
        check_admin_referer( 'nmep_impersonate' );

        $target_raw = isset( $_POST['target'] ) ? trim( (string) $_POST['target'] ) : '';
        $reason     = isset( $_POST['reason'] ) ? sanitize_text_field( (string) $_POST['reason'] ) : '';
        if ( $target_raw === '' || $reason === '' ) wp_die( 'Missing target or reason' );

        $target = self::resolve_user( $target_raw );
        if ( ! $target ) wp_die( 'User not found' );

        if ( user_can( $target->ID, 'manage_options' ) || is_super_admin( $target->ID ) ) {
            wp_die( 'Cannot impersonate another admin.' );
        }

        $original_id = get_current_user_id();

        if ( class_exists( 'NMEP_Audit_Log' ) ) {
            NMEP_Audit_Log::record( 'admin.impersonate.start', 'user', $target->ID, array(
                'admin_id' => $original_id,
                'target_email' => $target->user_email,
                'reason' => $reason,
            ) );
        }

        update_user_meta( $target->ID, self::IMPERSONATION_META, $original_id );

        $secure = is_ssl();
        setcookie(
            self::IMPERSONATION_COOKIE,
            (string) $original_id . '|' . wp_create_nonce( 'nmep_impersonate_back_' . $original_id ),
            time() + HOUR_IN_SECONDS,
            COOKIEPATH,
            COOKIE_DOMAIN,
            $secure,
            true
        );

        wp_clear_auth_cookie();
        wp_set_current_user( $target->ID );
        wp_set_auth_cookie( $target->ID, false, $secure );

        wp_safe_redirect( home_url( '/' ) );
        exit;
    }

    public static function handle_stop_impersonate() {
        check_admin_referer( 'nmep_stop_impersonate' );

        if ( empty( $_COOKIE[ self::IMPERSONATION_COOKIE ] ) ) {
            wp_safe_redirect( home_url( '/' ) );
            exit;
        }

        $parts = explode( '|', (string) $_COOKIE[ self::IMPERSONATION_COOKIE ], 2 );
        $original_id = (int) ( $parts[0] ?? 0 );
        $nonce       = $parts[1] ?? '';

        if ( ! $original_id || ! wp_verify_nonce( $nonce, 'nmep_impersonate_back_' . $original_id ) ) {
            wp_die( 'Invalid impersonation token' );
        }

        $current_id = get_current_user_id();
        if ( $current_id ) {
            delete_user_meta( $current_id, self::IMPERSONATION_META );
        }

        if ( class_exists( 'NMEP_Audit_Log' ) ) {
            NMEP_Audit_Log::record( 'admin.impersonate.stop', 'user', $current_id, array(
                'admin_id' => $original_id,
            ) );
        }

        setcookie( self::IMPERSONATION_COOKIE, '', time() - 3600, COOKIEPATH, COOKIE_DOMAIN, is_ssl(), true );

        wp_clear_auth_cookie();
        wp_set_current_user( $original_id );
        wp_set_auth_cookie( $original_id, false, is_ssl() );

        wp_safe_redirect( admin_url( 'admin.php?page=nmep-impersonate' ) );
        exit;
    }

    public static function admin_bar_switch_back( $wp_admin_bar ) {
        if ( empty( $_COOKIE[ self::IMPERSONATION_COOKIE ] ) ) return;
        $parts = explode( '|', (string) $_COOKIE[ self::IMPERSONATION_COOKIE ], 2 );
        $original_id = (int) ( $parts[0] ?? 0 );
        if ( ! $original_id ) return;

        $url = wp_nonce_url( admin_url( 'admin-post.php?action=nmep_stop_impersonate' ), 'nmep_stop_impersonate' );
        $wp_admin_bar->add_node( array(
            'id'    => 'nmep-switch-back',
            'title' => '↩ Switch back to admin',
            'href'  => $url,
            'meta'  => array( 'class' => 'nmep-switch-back' ),
        ) );
    }

    private static function resolve_user( $raw ) {
        if ( ctype_digit( (string) $raw ) ) {
            $u = get_user_by( 'id', (int) $raw );
            if ( $u ) return $u;
        }
        if ( strpos( $raw, '@' ) !== false ) {
            $u = get_user_by( 'email', $raw );
            if ( $u ) return $u;
        }
        return get_user_by( 'login', $raw );
    }

    /* ============================================================
       MODERATION QUEUE
       ============================================================ */

    public static function render_moderation() {
        if ( ! current_user_can( 'manage_options' ) ) return;
        $totals = self::moderation_totals();
        $services  = self::pending_services( 20 );
        $disputes  = self::open_disputes( 20 );
        $reviews   = self::flagged_reviews( 20 );
        $messages  = self::blocked_messages( 20 );
        ?>
        <div class="wrap nmep-admin">
            <h1>Moderation Queue</h1>
            <p><strong><?php echo (int) $totals['total']; ?></strong> item(s) need attention
                — <?php echo (int) $totals['services']; ?> services,
                <?php echo (int) $totals['disputes']; ?> disputes,
                <?php echo (int) $totals['reviews']; ?> reviews,
                <?php echo (int) $totals['messages']; ?> messages.</p>

            <h2>Services awaiting review</h2>
            <?php if ( empty( $services ) ) : ?>
                <p><em>No services pending.</em></p>
            <?php else : ?>
                <table class="widefat striped"><thead><tr>
                    <th>ID</th><th>Title</th><th>Expert</th><th>Price</th><th>Created</th><th></th>
                </tr></thead><tbody>
                <?php foreach ( $services as $s ) : ?>
                    <tr>
                        <td>#<?php echo (int) $s->id; ?></td>
                        <td><?php echo esc_html( $s->title ?? '' ); ?></td>
                        <td>#<?php echo (int) ( $s->expert_id ?? 0 ); ?></td>
                        <td><?php echo esc_html( $s->price ?? '' ); ?></td>
                        <td><?php echo esc_html( $s->created_at ?? '' ); ?></td>
                        <td><a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=nmep-services-review' ) ); ?>">Review</a></td>
                    </tr>
                <?php endforeach; ?>
                </tbody></table>
            <?php endif; ?>

            <h2>Open disputes</h2>
            <?php if ( empty( $disputes ) ) : ?>
                <p><em>No open disputes.</em></p>
            <?php else : ?>
                <table class="widefat striped"><thead><tr>
                    <th>ID</th><th>Order</th><th>Role</th><th>Status</th><th>SLA</th><th></th>
                </tr></thead><tbody>
                <?php foreach ( $disputes as $d ) : ?>
                    <tr>
                        <td>#<?php echo (int) $d->id; ?></td>
                        <td><?php echo esc_html( $d->order_number ?? $d->order_id ); ?></td>
                        <td><?php echo esc_html( $d->opened_by_role ?? '—' ); ?></td>
                        <td><?php echo esc_html( $d->status ); ?></td>
                        <td><?php
                            if ( class_exists( 'NMEP_Dispute_SLA' ) && ! empty( $d->sla_due_at ) ) {
                                echo esc_html( NMEP_Dispute_SLA::time_remaining_label( $d ) );
                            } else { echo '—'; }
                        ?></td>
                        <td><a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=nmep-disputes' ) ); ?>">Resolve</a></td>
                    </tr>
                <?php endforeach; ?>
                </tbody></table>
            <?php endif; ?>

            <h2>Reported / flagged reviews</h2>
            <?php if ( empty( $reviews ) ) : ?>
                <p><em>No reported reviews.</em></p>
            <?php else : ?>
                <table class="widefat striped"><thead><tr>
                    <th>ID</th><th>Rating</th><th>Excerpt</th><th>Reports</th><th></th>
                </tr></thead><tbody>
                <?php foreach ( $reviews as $rv ) : ?>
                    <tr>
                        <td>#<?php echo (int) $rv->id; ?></td>
                        <td><?php echo esc_html( $rv->rating ?? '' ); ?></td>
                        <td><?php echo esc_html( wp_trim_words( $rv->comment ?? '', 16 ) ); ?></td>
                        <td><?php echo (int) ( $rv->report_count ?? 0 ); ?></td>
                        <td><a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=nmep-review-reports' ) ); ?>">Moderate</a></td>
                    </tr>
                <?php endforeach; ?>
                </tbody></table>
            <?php endif; ?>

            <h2>Blocked messages</h2>
            <?php if ( empty( $messages ) ) : ?>
                <p><em>No blocked messages.</em></p>
            <?php else : ?>
                <table class="widefat striped"><thead><tr>
                    <th>ID</th><th>Order</th><th>Reason</th><th>Excerpt</th><th>Created</th>
                </tr></thead><tbody>
                <?php foreach ( $messages as $m ) : ?>
                    <tr>
                        <td>#<?php echo (int) $m->id; ?></td>
                        <td>#<?php echo (int) ( $m->order_id ?? 0 ); ?></td>
                        <td><code><?php echo esc_html( $m->blocked_reason ?? '' ); ?></code></td>
                        <td><?php echo esc_html( wp_trim_words( $m->message ?? '', 12 ) ); ?></td>
                        <td><?php echo esc_html( $m->created_at ?? '' ); ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody></table>
            <?php endif; ?>
        </div>
        <?php
    }

    public static function moderation_totals() {
        global $wpdb;
        $services_t = NMEP_Database::table( 'services' );
        $disputes_t = NMEP_Database::table( 'disputes' );
        $reviews_t  = NMEP_Database::table( 'reviews' );
        $messages_t = NMEP_Database::table( 'order_messages' );

        $services = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $services_t WHERE status = %s", 'pending_review' ) );
        $disputes = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $disputes_t WHERE status IN ('open','investigating','escalated')" );
        $reviews  = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $reviews_t WHERE is_flagged = 1 AND status != 'removed'" );
        $messages = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $messages_t WHERE blocked_reason IS NOT NULL" );

        return array(
            'services' => $services,
            'disputes' => $disputes,
            'reviews'  => $reviews,
            'messages' => $messages,
            'total'    => $services + $disputes + $reviews + $messages,
        );
    }

    private static function pending_services( $limit ) {
        global $wpdb;
        $t = NMEP_Database::table( 'services' );
        return $wpdb->get_results( $wpdb->prepare(
            "SELECT id,title,expert_id,price,created_at FROM $t WHERE status = %s ORDER BY created_at ASC LIMIT %d",
            'pending_review', (int) $limit
        ) );
    }

    private static function open_disputes( $limit ) {
        global $wpdb;
        $d = NMEP_Database::table( 'disputes' );
        $o = NMEP_Database::table( 'orders' );
        return $wpdb->get_results( $wpdb->prepare(
            "SELECT d.*, o.order_number
             FROM $d d LEFT JOIN $o o ON o.id = d.order_id
             WHERE d.status IN ('open','investigating','escalated')
             ORDER BY d.sla_due_at ASC
             LIMIT %d",
            (int) $limit
        ) );
    }

    private static function flagged_reviews( $limit ) {
        global $wpdb;
        $r  = NMEP_Database::table( 'reviews' );
        $rr = NMEP_Database::table( 'review_reports' );
        return $wpdb->get_results( $wpdb->prepare(
            "SELECT r.id, r.rating, r.comment,
                    ( SELECT COUNT(*) FROM $rr WHERE review_id = r.id AND status = 'open' ) AS report_count
             FROM $r r
             WHERE r.is_flagged = 1 AND r.status != 'removed'
             ORDER BY r.id DESC
             LIMIT %d",
            (int) $limit
        ) );
    }

    private static function blocked_messages( $limit ) {
        global $wpdb;
        $t = NMEP_Database::table( 'order_messages' );
        return $wpdb->get_results( $wpdb->prepare(
            "SELECT id, order_id, blocked_reason, message, created_at
             FROM $t
             WHERE blocked_reason IS NOT NULL
             ORDER BY id DESC
             LIMIT %d",
            (int) $limit
        ) );
    }
}
