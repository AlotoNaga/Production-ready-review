(function($) {
    'use strict';
    $(document).ready(function() {
        // Admin interactions
    });
})(jQuery);
