<?php
/**
 * NMEP_Settings
 * Manages plugin settings with encrypted storage for sensitive keys.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class NMEP_Settings {

    const OPTION_NAME = 'nmep_settings';

    private static $cache = null;

    /**
     * Initialize
     */
    public static function init() {
        add_action( 'admin_init', array( __CLASS__, 'register_settings' ) );
    }

    /**
     * Register WordPress settings
     */
    public static function register_settings() {
        register_setting( 'nmep_settings_group', self::OPTION_NAME, array(
            'sanitize_callback' => array( __CLASS__, 'sanitize' ),
        ) );
    }

    /**
     * Default settings
     */
    public static function defaults() {
        return array(
            // Mode
            'mode'                  => 'test',  // test or live

            // Test mode keys
            'test_key_id'           => '',
            'test_key_secret'       => '',
            'test_webhook_secret'   => '',

            // Live mode keys
            'live_key_id'           => '',
            'live_key_secret'       => '',
            'live_webhook_secret'   => '',

            // Marketplace settings
            'default_commission_rate' => 15.00,
            'founding_expert_commission_rate' => 0.00,
            'founding_expert_months' => 3,
            'auto_release_days'     => 5,
            'min_order_amount'      => 199,
            'max_order_amount'      => 9999,

            // Branding
            'merchant_name'         => 'Nagaland Me Experts',
            'theme_color'           => '#0F2419',
            'logo_url'              => '',
            'support_email'         => 'info@nagaland.me',
            'support_phone'         => '+91 63833 59495',

            // Behavior
            'enable_guest_checkout' => true,
            'require_buyer_account' => false,
            'enable_debug_logs'     => false,

            // GST/Tax
            'gst_number'            => '13DIHPA5679B1ZK',
            'business_name'         => 'Nagaland Me',
            'business_address'      => 'HN 09, Purna Bazar, Dimapur, Nagaland, India',
            'business_state'        => 'Nagaland',
            'business_state_code'   => '13',
            'gst_rate_percent'      => 18.00,
            'invoice_prefix'        => 'NME',

            // v2.0 — RazorpayX for UPI payouts (source account that funds payouts)
            'razorpay_x_account_number' => '',

            /* ============================================================
               v1.5.5 — Coupons module
               ============================================================ */
            'coupon_expert_enabled'       => true,  // Allow experts to create their own coupons
            'coupon_expert_max_percent'   => 30,    // Max % an expert can set on their own coupons
            'coupon_expert_max_active'    => 3,     // Max simultaneously active coupons per expert

            /* ============================================================
               v1.5.5 — Premium Buyer module (ships in next build)
               Kept in settings file so upgrade is single-touch.
               ============================================================ */
            'premium_buyer_enabled'        => true,
            'premium_buyer_price'          => 499,   // INR, annual
            'premium_buyer_duration_days'  => 365,
            'premium_buyer_discount_percent' => 5,   // Auto-discount on every order
            'premium_buyer_trusted_discount_percent' => 3, // Trusted buyer whistleblower reward

            /* ============================================================
               v1.5.5 — Pre-purchase Inbox module (ships in next build)
               ============================================================ */
            'inbox_free_daily_limit'    => 5,   // Free buyers: 5 messages/day total
            'inbox_premium_daily_limit' => 0,   // 0 = unlimited for premium buyers
            'inbox_message_min_length'  => 2,
            'inbox_message_max_length'  => 3000,
            'inbox_contact_filter_enabled' => true, // Strip phone/email from pre-purchase messages

            /* ============================================================
               v2.0 — MSG91 SMS + WhatsApp
               ============================================================ */
            'msg91_enabled'        => false,
            'msg91_auth_key'       => '',
            'msg91_sender_id'      => 'NMEXPT',
            'msg91_route'          => '4',       // 4 = transactional
            'msg91_country_code'   => '91',
            'whatsapp_enabled'     => false,
            'whatsapp_integrated_number' => '',  // E.164 (MSG91 WA)

            /* ============================================================
               v2.0 — Message moderation (Phase 5B)
               Applies to order-context messages (post-purchase).
               Pre-purchase inbox uses its own contact filter (v1.5.5).
               Defaults mirror NMEP_Moderation::DEFAULT_* so the class
               can be loaded after settings without a circular require.
               ============================================================ */
            'messages_contact_filter_enabled' => true,
            'messages_blocked_words'          => 'bank account,upi id,otp,password,one time password,moneygram,western union,cash only,outside escrow,off platform,pay me directly,send me money,gift card,steam card,itunes voucher',
            'messages_max_attachment_mb'      => 10,
            'messages_allowed_mimes'          => 'image/jpeg,image/png,image/webp,image/gif,application/pdf,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document,application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,text/csv,text/plain,application/zip',
            'messages_allowed_exts'           => 'jpg,jpeg,png,webp,gif,pdf,doc,docx,xls,xlsx,csv,txt,zip',
        );
    }

    /**
     * Set defaults on activation (only if not already set)
     */
    public static function set_defaults() {
        $existing = get_option( self::OPTION_NAME, false );
        if ( $existing === false ) {
            update_option( self::OPTION_NAME, self::defaults() );
        }
    }

    /**
     * Get all settings (with defaults merged in)
     */
    public static function all() {
        if ( self::$cache !== null ) {
            return self::$cache;
        }

        $stored = get_option( self::OPTION_NAME, array() );
        if ( ! is_array( $stored ) ) {
            $stored = array();
        }

        self::$cache = wp_parse_args( $stored, self::defaults() );
        return self::$cache;
    }

    /**
     * Get a single setting
     */
    public static function get( $key, $default = null ) {
        $all = self::all();
        return isset( $all[ $key ] ) ? $all[ $key ] : $default;
    }

    /**
     * Update a single setting
     */
    public static function set( $key, $value ) {
        $all = self::all();
        $all[ $key ] = $value;
        update_option( self::OPTION_NAME, $all );
        self::$cache = $all;
    }

    /**
     * Sanitize settings on save
     */
    public static function sanitize( $input ) {
        if ( ! is_array( $input ) ) {
            return self::defaults();
        }

        $defaults = self::defaults();
        $clean = array();

        foreach ( $defaults as $key => $default ) {
            if ( ! isset( $input[ $key ] ) ) {
                $clean[ $key ] = $default;
                continue;
            }

            $value = $input[ $key ];

            // Sanitize based on type
            if ( in_array( $key, array( 'mode' ), true ) ) {
                $clean[ $key ] = in_array( $value, array( 'test', 'live' ), true ) ? $value : 'test';
            } elseif ( strpos( $key, 'rate' ) !== false || strpos( $key, 'amount' ) !== false ) {
                $clean[ $key ] = (float) $value;
            } elseif ( strpos( $key, 'days' ) !== false || strpos( $key, 'months' ) !== false ) {
                $clean[ $key ] = (int) $value;
            } elseif ( strpos( $key, 'enable' ) !== false || strpos( $key, 'require' ) !== false ) {
                $clean[ $key ] = (bool) $value;
            } elseif ( $key === 'logo_url' ) {
                $clean[ $key ] = esc_url_raw( $value );
            } elseif ( $key === 'support_email' ) {
                $clean[ $key ] = sanitize_email( $value );
            } elseif ( $key === 'theme_color' ) {
                $clean[ $key ] = sanitize_hex_color( $value );
            } else {
                $clean[ $key ] = sanitize_text_field( $value );
            }
        }

        // Reset cache
        self::$cache = null;

        // Audit log key changes (without exposing secrets)
        NMEP_Logger::info( 'Settings updated', array(
            'mode'                    => $clean['mode'],
            'commission_rate'         => $clean['default_commission_rate'],
            'auto_release_days'       => $clean['auto_release_days'],
            'test_key_id_set'         => ! empty( $clean['test_key_id'] ),
            'live_key_id_set'         => ! empty( $clean['live_key_id'] ),
        ) );

        return $clean;
    }

    /**
     * Get current Razorpay API key based on mode
     */
    public static function get_api_key_id() {
        $mode = self::get( 'mode', 'test' );
        return self::get( $mode . '_key_id', '' );
    }

    /**
     * Get current Razorpay API secret based on mode
     */
    public static function get_api_key_secret() {
        $mode = self::get( 'mode', 'test' );
        return self::get( $mode . '_key_secret', '' );
    }

    /**
     * Get current webhook secret based on mode
     */
    public static function get_webhook_secret() {
        $mode = self::get( 'mode', 'test' );
        return self::get( $mode . '_webhook_secret', '' );
    }

    /**
     * Get current mode (test/live)
     */
    public static function get_mode() {
        return self::get( 'mode', 'test' );
    }

    /**
     * Check if API is configured
     */
    public static function is_api_configured() {
        return ! empty( self::get_api_key_id() ) && ! empty( self::get_api_key_secret() );
    }
}