<?php
/**
 * NMEP_Inbox
 *
 * Pre-purchase buyer ↔ expert messaging for Nagaland Me Experts.
 *
 * WHY SEPARATE FROM NMEP_Messages?
 * NMEP_Messages operates in the context of an existing order
 * (wp_nmep_order_messages.order_id is NOT NULL). This class
 * handles the DIFFERENT case where a buyer wants to ask an
 * expert a question BEFORE they commit to a purchase — no order
 * yet, no escrow, no obligation on either side.
 *
 * RATE LIMITS (configurable in settings):
 *   Free buyers    : 5 messages per 24h (inbox_free_daily_limit)
 *   Premium buyers : unlimited (inbox_premium_daily_limit = 0)
 *   Experts        : unlimited replies to incoming threads
 *
 * SAFETY: contact-info filter strips phone numbers and email
 * addresses from buyer messages (and expert messages too, as
 * a mirror defence against off-platform migration attempts).
 * This applies ONLY to pre-purchase inbox — once an order
 * exists, the existing NMEP_Messages flow takes over and the
 * filter isn't applied there.
 *
 * DB TABLE
 *   wp_nmep_inbox_messages
 *
 * SHORTCODES
 *   [nmep_inbox]           — buyer inbox (list of threads + reply view)
 *   [nmep_expert_inbox]    — expert-side inbox (pending pre-purchase threads)
 *
 * @package NagalandMeExpertsPayments
 * @version 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class NMEP_Inbox {

    const DB_VERSION_OPTION = 'nmep_inbox_db_version';
    const DB_VERSION        = '1.0.0';

    const ROLE_BUYER  = 'buyer';
    const ROLE_EXPERT = 'expert';

    // Page bootstrap — auto-creates /inbox/ and /expert-inbox/ the
    // first time this plugin boots on a site that's missing them.
    // Earlier builds never created these pages, so NMEP_Inbox::
    // buyer_inbox_url() fell back to home_url('/inbox/') which 404'd
    // and every "Message Expert" CTA dead-ended.
    const PAGES_OPTION = 'nmep_inbox_pages_v1';
    const PAGES_LOCK   = 'nmep_inbox_pages_creating';

    /* ============================================================
       INIT
       ============================================================ */

    public static function init() {
        add_action( 'admin_init',     array( __CLASS__, 'maybe_migrate' ), 5 );
        add_action( 'plugins_loaded', array( __CLASS__, 'maybe_migrate' ), 30 );

        // Page bootstrap — create /inbox/ + /expert-inbox/ if missing.
        // Guarded to admin/cron/CLI inside the method itself, so this
        // never touches wp_posts during a buyer's page render.
        add_action( 'init', array( __CLASS__, 'maybe_create_pages' ), 40 );

        // Send handler — both buyers and experts post here
        add_action( 'admin_post_nopriv_nmep_inbox_send', array( __CLASS__, 'handle_send_denied' ) );
        add_action( 'admin_post_nmep_inbox_send',        array( __CLASS__, 'handle_send' ) );

        // Shortcodes
        add_shortcode( 'nmep_inbox',         array( __CLASS__, 'render_buyer_inbox' ) );
        add_shortcode( 'nmep_expert_inbox',  array( __CLASS__, 'render_expert_inbox' ) );

        // When a "Message Expert" CTA calls wp_login_url() with a
        // redirect target of /inbox/, bypass wp-login.php entirely
        // and send the user straight to /inbox/, where our shortcode
        // renders a friendly gate explaining how to get an account.
        // Bare wp-login.php with no explainer and no sign-up link is
        // a dead end.
        add_filter( 'login_url', array( __CLASS__, 'filter_login_url' ), 10, 3 );
    }

    public static function table( $name ) {
        global $wpdb;
        return $wpdb->prefix . 'nmep_' . $name;
    }

    /* ============================================================
       MIGRATION
       ============================================================ */

    public static function maybe_migrate() {
        $installed = get_option( self::DB_VERSION_OPTION, '0.0.0' );
        if ( version_compare( $installed, self::DB_VERSION, '>=' ) ) {
            return;
        }
        self::create_tables();
        update_option( self::DB_VERSION_OPTION, self::DB_VERSION, false );
    }

    public static function create_tables() {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        $tbl = self::table( 'inbox_messages' );
        $sql = "CREATE TABLE $tbl (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            buyer_user_id BIGINT(20) UNSIGNED NOT NULL,
            buyer_email VARCHAR(190) NOT NULL,
            buyer_name VARCHAR(120) NOT NULL,
            expert_id BIGINT(20) UNSIGNED NOT NULL,
            sender_role VARCHAR(20) NOT NULL,
            message LONGTEXT NOT NULL,
            message_raw LONGTEXT DEFAULT NULL,
            was_filtered TINYINT(1) DEFAULT 0,
            is_read TINYINT(1) DEFAULT 0,
            ip_address VARCHAR(45) DEFAULT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY thread_key (buyer_user_id, expert_id, created_at),
            KEY expert_id (expert_id),
            KEY buyer_user_id (buyer_user_id),
            KEY is_read (is_read)
        ) $charset_collate;";

        dbDelta( $sql );

        if ( class_exists( 'NMEP_Logger' ) ) {
            NMEP_Logger::info( 'Inbox tables migrated', array( 'version' => self::DB_VERSION ) );
        }
    }

    /* ============================================================
       CONTACT-INFO FILTER
       Strips phone numbers and email addresses from message body
       so pre-purchase conversations can't be hijacked off-platform.
       ============================================================ */

    /**
     * @return array { filtered: string, was_filtered: bool }
     */
    public static function filter_contact_info( $text ) {
        if ( ! (bool) NMEP_Settings::get( 'inbox_contact_filter_enabled', true ) ) {
            return array( 'filtered' => $text, 'was_filtered' => false );
        }

        $original = $text;

        // Email — standard-enough RFC 5322 simplification
        $text = preg_replace( '/[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}/i', '[contact hidden]', $text );

        // Phone — handles: +91 98765 43210, +919876543210, 98765 43210, 98765-43210, (987) 654-3210, etc.
        // Core: 10+ digits that may be interrupted by spaces, dashes, dots, parens, or a +country-code.
        $text = preg_replace( '/(?<![A-Za-z0-9])\+?\d[\d\s\-\.\(\)]{8,}\d(?![A-Za-z0-9])/', '[contact hidden]', $text );

        // Obfuscation attempts: "nine eight seven..." → skip (too lossy to try)
        // "at" and "dot" spelled out: basic catch
        $text = preg_replace( '/\b([A-Z0-9._%+\-]+)\s*(?:\[at\]|\(at\)| at )\s*([A-Z0-9.\-]+)\s*(?:\[dot\]|\(dot\)| dot )\s*([A-Z]{2,})\b/i', '[contact hidden]', $text );

        // Very common messaging apps — these are offers to go off-platform, so block them too (configurable via filter)
        $text = preg_replace( '/\b(whatsapp|telegram|signal)\s*(number|no\.?|me)?\b/i', '[contact hidden]', $text );

        $was_filtered = ( $text !== $original );
        return array( 'filtered' => $text, 'was_filtered' => $was_filtered );
    }

    /* ============================================================
       SEND HANDLER
       ============================================================ */

    public static function handle_send_denied() {
        wp_die( 'Please log in to send messages.' );
    }

    public static function handle_send() {
        if ( ! is_user_logged_in() ) {
            wp_die( 'Please log in to send messages.' );
        }
        if ( ! isset( $_POST['_wpnonce'] ) || ! wp_verify_nonce( $_POST['_wpnonce'], 'nmep_inbox_send' ) ) {
            wp_die( 'Security check failed.' );
        }

        $expert_id = isset( $_POST['expert_id'] ) ? (int) $_POST['expert_id'] : 0;
        $role      = sanitize_key( $_POST['role'] ?? '' );
        $raw       = (string) ( $_POST['message'] ?? '' );

        $expert = NMEP_Compat::get_expert( $expert_id );
        if ( ! $expert ) {
            wp_die( 'Expert not found.' );
        }

        $min_len = (int) NMEP_Settings::get( 'inbox_message_min_length', 2 );
        $max_len = (int) NMEP_Settings::get( 'inbox_message_max_length', 3000 );

        $trimmed = trim( $raw );
        if ( mb_strlen( $trimmed ) < $min_len ) {
            self::redirect_error( 'Message is too short.', $expert_id, $role );
        }
        if ( mb_strlen( $trimmed ) > $max_len ) {
            self::redirect_error( sprintf( 'Message is too long (max %d chars).', $max_len ), $expert_id, $role );
        }

        $user = wp_get_current_user();

        // Determine the (buyer_user_id, expert_id) thread coordinates for either role
        $buyer_user_id = 0;
        $buyer_email   = '';
        $buyer_name    = '';

        if ( $role === self::ROLE_BUYER ) {
            // The current user IS the buyer
            $buyer_user_id = (int) $user->ID;
            $buyer_email   = (string) $user->user_email;
            $buyer_name    = (string) $user->display_name;

            // Rate limit (per 24h rolling window)
            if ( ! self::can_buyer_send_now( $buyer_user_id ) ) {
                $limit = self::effective_buyer_daily_limit( $buyer_user_id );
                self::redirect_error(
                    sprintf( 'Daily message limit reached (%d). Upgrade to Premium for unlimited messaging.', $limit ),
                    $expert_id,
                    self::ROLE_BUYER
                );
            }
        } elseif ( $role === self::ROLE_EXPERT ) {
            // Current user must be the expert whose inbox we're replying from
            $me = NMEP_Compat::get_expert_by_user( get_current_user_id() );
            if ( ! $me || (int) $me->id !== (int) $expert->id ) {
                wp_die( 'Permission denied.' );
            }
            // The thread is identified by the buyer_user_id passed via POST
            $buyer_user_id = isset( $_POST['buyer_user_id'] ) ? (int) $_POST['buyer_user_id'] : 0;
            if ( $buyer_user_id <= 0 ) {
                wp_die( 'Invalid buyer thread.' );
            }
            $buyer_user = get_userdata( $buyer_user_id );
            if ( ! $buyer_user ) {
                wp_die( 'Buyer not found.' );
            }

            // Experts may only REPLY to pre-existing threads — never initiate.
            // Without this, a logged-in expert could forge a POST and send
            // unsolicited messages to arbitrary user IDs.
            global $wpdb;
            $tbl           = self::table( 'inbox_messages' );
            $thread_exists = (int) $wpdb->get_var( $wpdb->prepare(
                "SELECT 1 FROM $tbl WHERE expert_id = %d AND buyer_user_id = %d LIMIT 1",
                (int) $expert->id,
                $buyer_user_id
            ) );
            if ( ! $thread_exists ) {
                wp_die( 'No existing thread with this buyer.' );
            }

            $buyer_email = (string) $buyer_user->user_email;
            $buyer_name  = (string) $buyer_user->display_name;
        } else {
            wp_die( 'Invalid role.' );
        }

        // Run the contact-info filter
        $filtered = self::filter_contact_info( $raw );
        $final_message = $filtered['filtered'];
        $was_filtered  = $filtered['was_filtered'] ? 1 : 0;

        global $wpdb;
        $inserted = $wpdb->insert( self::table( 'inbox_messages' ), array(
            'buyer_user_id' => $buyer_user_id,
            'buyer_email'   => $buyer_email,
            'buyer_name'    => $buyer_name,
            'expert_id'     => (int) $expert->id,
            'sender_role'   => $role,
            'message'       => $final_message,
            'message_raw'   => $was_filtered ? $raw : null,
            'was_filtered'  => $was_filtered,
            'is_read'       => 0,
            'ip_address'    => isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( $_SERVER['REMOTE_ADDR'] ) : null,
        ) );

        // If the DB write failed we must NOT log success, fire the notification
        // email, or redirect the user to a success page — that would cause the
        // recipient to receive a mail for a message that doesn't exist in the
        // thread. Bail out with a user-facing error instead.
        if ( false === $inserted ) {
            NMEP_Logger::error( 'Inbox message insert failed', array(
                'role'          => $role,
                'expert_id'     => (int) $expert->id,
                'buyer_user_id' => $buyer_user_id,
                'db_error'      => $wpdb->last_error,
            ) );
            self::redirect_error( 'Sorry, your message could not be sent. Please try again.', $expert_id, $role );
        }

        $message_id = (int) $wpdb->insert_id;

        NMEP_Logger::info( 'Inbox message sent', array(
            'message_id'   => $message_id,
            'role'         => $role,
            'expert_id'    => $expert->id,
            'buyer_user_id'=> $buyer_user_id,
            'was_filtered' => $was_filtered,
        ) );

        self::notify_recipient( $expert, $role, $buyer_name, $buyer_email, $buyer_user_id, $final_message );

        // Redirect back to the thread view
        if ( $role === self::ROLE_BUYER ) {
            $url = add_query_arg( array( 'expert_id' => $expert->id, 'nmep_sent' => 1 ), self::buyer_inbox_url() );
            if ( $was_filtered ) {
                $url = add_query_arg( 'nmep_filtered', 1, $url );
            }
        } else {
            $url = add_query_arg( array(
                'thread_buyer' => $buyer_user_id,
                'nmep_sent'    => 1,
            ), self::expert_inbox_url() );
        }

        wp_safe_redirect( $url . '#thread-bottom' );
        exit;
    }

    private static function redirect_error( $msg, $expert_id, $role ) {
        $base = ( $role === self::ROLE_EXPERT ) ? self::expert_inbox_url() : self::buyer_inbox_url();
        $url = add_query_arg( array(
            'expert_id'   => $expert_id,
            'nmep_status' => 'error',
            'nmep_msg'    => urlencode( $msg ),
        ), $base );
        wp_safe_redirect( $url );
        exit;
    }

    /* ============================================================
       RATE LIMITS
       ============================================================ */

    public static function effective_buyer_daily_limit( $user_id ) {
        if ( class_exists( 'NMEP_Buyer_Premium' ) && NMEP_Buyer_Premium::is_premium( $user_id ) ) {
            return (int) NMEP_Settings::get( 'inbox_premium_daily_limit', 0 ); // 0 = unlimited
        }
        return (int) NMEP_Settings::get( 'inbox_free_daily_limit', 5 );
    }

    public static function messages_sent_last_24h( $user_id ) {
        global $wpdb;
        return (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM " . self::table( 'inbox_messages' ) . "
             WHERE buyer_user_id = %d AND sender_role = %s
               AND created_at > DATE_SUB(UTC_TIMESTAMP(), INTERVAL 24 HOUR)",
            (int) $user_id, self::ROLE_BUYER
        ) );
    }

    public static function can_buyer_send_now( $user_id ) {
        $limit = self::effective_buyer_daily_limit( $user_id );
        if ( $limit <= 0 ) return true; // 0 = unlimited
        return self::messages_sent_last_24h( $user_id ) < $limit;
    }

    /* ============================================================
       QUERIES
       ============================================================ */

    public static function get_thread( $buyer_user_id, $expert_id ) {
        global $wpdb;
        return $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM " . self::table( 'inbox_messages' ) . "
             WHERE buyer_user_id = %d AND expert_id = %d
             ORDER BY created_at ASC",
            (int) $buyer_user_id, (int) $expert_id
        ) );
    }

    public static function get_buyer_threads( $buyer_user_id ) {
        global $wpdb;
        $tbl = self::table( 'inbox_messages' );
        $experts_tbl = NMEP_Compat::base_table( 'experts' );

        return $wpdb->get_results( $wpdb->prepare(
            "SELECT m.expert_id,
                    e.full_name AS expert_name,
                    e.profile_photo AS expert_photo,
                    MAX(m.created_at) AS last_msg_at,
                    SUM(CASE WHEN m.sender_role = 'expert' AND m.is_read = 0 THEN 1 ELSE 0 END) AS unread_count,
                    COUNT(*) AS total_messages,
                    (SELECT m2.message FROM $tbl m2 WHERE m2.buyer_user_id = m.buyer_user_id AND m2.expert_id = m.expert_id ORDER BY m2.created_at DESC LIMIT 1) AS last_message,
                    (SELECT m2.sender_role FROM $tbl m2 WHERE m2.buyer_user_id = m.buyer_user_id AND m2.expert_id = m.expert_id ORDER BY m2.created_at DESC LIMIT 1) AS last_sender_role
             FROM $tbl m
             LEFT JOIN $experts_tbl e ON e.id = m.expert_id
             WHERE m.buyer_user_id = %d
             GROUP BY m.expert_id
             ORDER BY last_msg_at DESC",
            (int) $buyer_user_id
        ) );
    }

    /**
     * Fetch expert's pre-purchase threads, optionally filtered to premium buyers only.
     *
     * @param int    $expert_id
     * @param string $filter 'all' (default) or 'premium'. The premium filter INNER-JOINs
     *                       against an active buyer_premium row; if the premium table
     *                       doesn't exist (module disabled), premium filter returns empty.
     * @return array
     */
    public static function get_expert_threads( $expert_id, $filter = 'all' ) {
        global $wpdb;
        $tbl = self::table( 'inbox_messages' );

        if ( $filter === 'premium' ) {
            // Only include threads whose buyer currently has an active premium subscription.
            // Gate on the premium table existing so we fail gracefully if the module hasn't
            // been migrated yet on this install.
            $ptbl = class_exists( 'NMEP_Buyer_Premium' ) ? NMEP_Buyer_Premium::table( 'buyer_premium' ) : '';
            if ( ! $ptbl ) {
                return array();
            }
            $exists = (string) $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $ptbl ) );
            if ( $exists !== $ptbl ) {
                return array();
            }

            return $wpdb->get_results( $wpdb->prepare(
                "SELECT m.buyer_user_id,
                        MAX(m.buyer_name) AS buyer_name,
                        MAX(m.buyer_email) AS buyer_email,
                        MAX(m.created_at) AS last_msg_at,
                        SUM(CASE WHEN m.sender_role = 'buyer' AND m.is_read = 0 THEN 1 ELSE 0 END) AS unread_count,
                        COUNT(*) AS total_messages,
                        (SELECT m2.message FROM $tbl m2 WHERE m2.buyer_user_id = m.buyer_user_id AND m2.expert_id = m.expert_id ORDER BY m2.created_at DESC LIMIT 1) AS last_message,
                        (SELECT m2.sender_role FROM $tbl m2 WHERE m2.buyer_user_id = m.buyer_user_id AND m2.expert_id = m.expert_id ORDER BY m2.created_at DESC LIMIT 1) AS last_sender_role
                 FROM $tbl m
                 INNER JOIN $ptbl p
                    ON p.user_id = m.buyer_user_id
                   AND p.is_active = 1
                   AND p.expires_at > UTC_TIMESTAMP()
                 WHERE m.expert_id = %d
                 GROUP BY m.buyer_user_id
                 ORDER BY last_msg_at DESC",
                (int) $expert_id
            ) );
        }

        return $wpdb->get_results( $wpdb->prepare(
            "SELECT m.buyer_user_id,
                    MAX(m.buyer_name) AS buyer_name,
                    MAX(m.buyer_email) AS buyer_email,
                    MAX(m.created_at) AS last_msg_at,
                    SUM(CASE WHEN m.sender_role = 'buyer' AND m.is_read = 0 THEN 1 ELSE 0 END) AS unread_count,
                    COUNT(*) AS total_messages,
                    (SELECT m2.message FROM $tbl m2 WHERE m2.buyer_user_id = m.buyer_user_id AND m2.expert_id = m.expert_id ORDER BY m2.created_at DESC LIMIT 1) AS last_message,
                    (SELECT m2.sender_role FROM $tbl m2 WHERE m2.buyer_user_id = m.buyer_user_id AND m2.expert_id = m.expert_id ORDER BY m2.created_at DESC LIMIT 1) AS last_sender_role
             FROM $tbl m
             WHERE m.expert_id = %d
             GROUP BY m.buyer_user_id
             ORDER BY last_msg_at DESC",
            (int) $expert_id
        ) );
    }

    public static function mark_thread_read( $buyer_user_id, $expert_id, $reader_role ) {
        global $wpdb;
        // Mark messages from the OTHER party as read
        $other = $reader_role === self::ROLE_BUYER ? self::ROLE_EXPERT : self::ROLE_BUYER;
        $wpdb->query( $wpdb->prepare(
            "UPDATE " . self::table( 'inbox_messages' ) . "
             SET is_read = 1
             WHERE buyer_user_id = %d AND expert_id = %d AND sender_role = %s AND is_read = 0",
            (int) $buyer_user_id, (int) $expert_id, $other
        ) );
    }

    public static function unread_count_for_expert( $expert_id ) {
        global $wpdb;
        return (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM " . self::table( 'inbox_messages' ) . "
             WHERE expert_id = %d AND sender_role = 'buyer' AND is_read = 0",
            (int) $expert_id
        ) );
    }

    public static function unread_count_for_buyer( $buyer_user_id ) {
        global $wpdb;
        return (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM " . self::table( 'inbox_messages' ) . "
             WHERE buyer_user_id = %d AND sender_role = 'expert' AND is_read = 0",
            (int) $buyer_user_id
        ) );
    }

    /* ============================================================
       SHORTCODES
       ============================================================ */

    public static function render_buyer_inbox( $atts ) {
        $expert_id = isset( $_GET['expert_id'] ) ? (int) $_GET['expert_id'] : 0;

        if ( ! is_user_logged_in() ) {
            return self::render_login_gate( $expert_id );
        }

        $user = wp_get_current_user();

        ob_start();

        if ( $expert_id ) {
            echo self::render_buyer_thread_view( $user, $expert_id );
        } else {
            echo self::render_buyer_thread_list( $user );
        }

        return ob_get_clean();
    }

    private static function render_buyer_thread_list( $user ) {
        $threads = self::get_buyer_threads( $user->ID );
        ob_start();
        ?>
        <section class="nme-section">
            <div class="nme-container" style="max-width:900px;">
                <h1>Your Inbox</h1>
                <p style="color:var(--nme-text-light,#6B7280);">Pre-purchase conversations with experts. Once you place an order, order-specific messages are in <a href="<?php echo esc_url( nmep_get_page_url( 'my-orders' ) ); ?>">My Orders</a>.</p>

                <?php if ( empty( $threads ) ) : ?>
                    <div class="nme-card nme-text-center" style="padding:60px 20px;">
                        <div style="font-size:4rem;">💬</div>
                        <h3>No conversations yet</h3>
                        <p>Browse experts and click "Message" on any service to start a conversation.</p>
                        <p><a href="<?php echo esc_url( home_url( '/services/' ) ); ?>" class="nme-btn nme-btn-gold">Browse Services</a></p>
                    </div>
                <?php else : ?>
                    <div class="nme-card" style="padding:0;">
                        <?php foreach ( $threads as $t ) :
                            $url = add_query_arg( 'expert_id', (int) $t->expert_id, self::buyer_inbox_url() );
                            $preview = self::truncate( $t->last_message, 110 );
                            $unread = (int) $t->unread_count > 0;
                        ?>
                            <a href="<?php echo esc_url( $url ); ?>" style="display:flex;gap:14px;padding:16px;border-bottom:1px solid var(--nme-border,#E5E7EB);text-decoration:none;color:inherit;<?php echo $unread ? 'background:#ECFDF5;' : ''; ?>">
                                <div style="flex:0 0 48px;">
                                    <?php if ( ! empty( $t->expert_photo ) ) : ?>
                                        <img src="<?php echo esc_url( $t->expert_photo ); ?>" style="width:48px;height:48px;border-radius:50%;object-fit:cover;">
                                    <?php else : ?>
                                        <div style="width:48px;height:48px;border-radius:50%;background:var(--nme-forest,#0F2419);color:var(--nme-gold,#D4A843);display:flex;align-items:center;justify-content:center;font-weight:700;"><?php echo esc_html( strtoupper( substr( (string) $t->expert_name, 0, 1 ) ) ); ?></div>
                                    <?php endif; ?>
                                </div>
                                <div style="flex:1;min-width:0;">
                                    <div style="display:flex;justify-content:space-between;align-items:baseline;gap:8px;">
                                        <strong style="color:var(--nme-forest,#0F2419);"><?php echo esc_html( $t->expert_name ?: 'Expert' ); ?></strong>
                                        <small style="color:var(--nme-text-light,#6B7280);white-space:nowrap;"><?php echo esc_html( human_time_diff( strtotime( $t->last_msg_at ), current_time( 'timestamp', true ) ) ); ?> ago</small>
                                    </div>
                                    <div style="color:var(--nme-text-light,#6B7280);font-size:0.9rem;margin-top:4px;">
                                        <?php echo $t->last_sender_role === 'buyer' ? '<span style="color:var(--nme-emerald,#10B981);">You:</span> ' : ''; ?>
                                        <?php echo esc_html( $preview ); ?>
                                    </div>
                                </div>
                                <?php if ( $unread ) : ?>
                                    <div style="flex:0 0 auto;align-self:center;background:var(--nme-emerald,#10B981);color:#fff;border-radius:50px;padding:2px 10px;font-size:0.75rem;font-weight:700;"><?php echo (int) $t->unread_count; ?></div>
                                <?php endif; ?>
                            </a>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </section>
        <?php
        return ob_get_clean();
    }

    private static function render_buyer_thread_view( $user, $expert_id ) {
        $expert = NMEP_Compat::get_expert( $expert_id );
        if ( ! $expert ) {
            return '<div class="nme-card"><h2>Expert not found</h2><p><a href="' . esc_url( self::buyer_inbox_url() ) . '">← Back to inbox</a></p></div>';
        }

        $messages = self::get_thread( $user->ID, $expert_id );
        self::mark_thread_read( $user->ID, $expert_id, self::ROLE_BUYER );

        $limit = self::effective_buyer_daily_limit( $user->ID );
        $sent_24h = self::messages_sent_last_24h( $user->ID );
        $remaining = $limit > 0 ? max( 0, $limit - $sent_24h ) : -1; // -1 = unlimited
        $can_send  = $limit <= 0 || $remaining > 0;

        $expert_profile_url = class_exists( 'NMEP_Expert_Profiles' ) ? NMEP_Expert_Profiles::get_expert_url( $expert ) : '';

        ob_start();
        ?>
        <section class="nme-section">
            <div class="nme-container" style="max-width:820px;">
                <p><a href="<?php echo esc_url( self::buyer_inbox_url() ); ?>" style="color:var(--nme-emerald,#10B981);">← All conversations</a></p>

                <?php if ( isset( $_GET['nmep_filtered'] ) ) : ?>
                    <div class="nme-card" style="border-left:4px solid #F59E0B;background:#FEF3C7;margin-bottom:12px;">
                        <p style="margin:0;color:#78350F;font-size:0.9rem;">⚠️ Your last message contained contact info (phone or email), which was hidden for your protection. All transactions must happen on Nagaland Me so you keep escrow protection.</p>
                    </div>
                <?php endif; ?>
                <?php if ( isset( $_GET['nmep_status'] ) && $_GET['nmep_status'] === 'error' && isset( $_GET['nmep_msg'] ) ) : ?>
                    <div class="nme-card" style="border-left:4px solid #EF4444;background:#FEF2F2;margin-bottom:12px;">
                        <p style="margin:0;color:#991B1B;">❌ <?php echo esc_html( urldecode( $_GET['nmep_msg'] ) ); ?></p>
                    </div>
                <?php endif; ?>
                <?php if ( isset( $_GET['nmep_sent'] ) ) : ?>
                    <div class="nme-card" style="border-left:4px solid var(--nme-emerald,#10B981);background:#ECFDF5;margin-bottom:12px;">
                        <p style="margin:0;color:#065F46;">✅ Message sent.</p>
                    </div>
                <?php endif; ?>

                <div class="nme-card">
                    <div style="display:flex;gap:12px;align-items:center;margin-bottom:12px;border-bottom:1px solid var(--nme-border,#E5E7EB);padding-bottom:12px;">
                        <?php if ( ! empty( $expert->profile_photo ) ) : ?>
                            <img src="<?php echo esc_url( $expert->profile_photo ); ?>" style="width:48px;height:48px;border-radius:50%;object-fit:cover;">
                        <?php endif; ?>
                        <div style="flex:1;">
                            <strong style="color:var(--nme-forest,#0F2419);">
                                <?php if ( $expert_profile_url ) : ?>
                                    <a href="<?php echo esc_url( $expert_profile_url ); ?>" style="color:var(--nme-forest,#0F2419);text-decoration:none;"><?php echo esc_html( $expert->full_name ); ?></a>
                                <?php else : ?>
                                    <?php echo esc_html( $expert->full_name ); ?>
                                <?php endif; ?>
                            </strong>
                            <?php if ( ! empty( $expert->tagline ) ) : ?>
                                <div style="font-size:0.85rem;color:var(--nme-text-light,#6B7280);"><?php echo esc_html( $expert->tagline ); ?></div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div style="max-height:500px;overflow-y:auto;padding:8px;background:var(--nme-bg-soft,#F9FAFB);border-radius:8px;margin-bottom:16px;">
                        <?php if ( empty( $messages ) ) : ?>
                            <p style="text-align:center;color:var(--nme-text-light,#6B7280);padding:20px;">No messages yet. Send the first one below.</p>
                        <?php else : foreach ( $messages as $m ) :
                            $is_mine = ( $m->sender_role === self::ROLE_BUYER );
                        ?>
                            <div style="display:flex;<?php echo $is_mine ? 'justify-content:flex-end;' : ''; ?>margin-bottom:12px;">
                                <div style="max-width:75%;<?php echo $is_mine ? 'background:var(--nme-emerald,#10B981);color:white;' : 'background:white;color:var(--nme-text,#374151);'; ?>padding:10px 14px;border-radius:14px;">
                                    <div style="white-space:pre-line;word-break:break-word;"><?php echo esc_html( $m->message ); ?></div>
                                    <div style="font-size:0.7rem;opacity:0.7;margin-top:4px;text-align:right;"><?php echo esc_html( human_time_diff( strtotime( $m->created_at ), current_time( 'timestamp', true ) ) ); ?> ago</div>
                                </div>
                            </div>
                        <?php endforeach; endif; ?>
                        <div id="thread-bottom"></div>
                    </div>

                    <?php if ( $can_send ) : ?>
                        <?php if ( $remaining !== -1 ) : ?>
                            <p style="font-size:0.85rem;color:var(--nme-text-light,#6B7280);margin:0 0 8px;">
                                📨 <?php echo (int) $remaining; ?> of <?php echo (int) $limit; ?> daily messages remaining.
                                <?php if ( $remaining <= 1 ) : ?>
                                    <a href="<?php echo esc_url( class_exists( 'NMEP_Buyer_Premium' ) ? NMEP_Buyer_Premium::landing_url() : home_url( '/buyer-premium/' ) ); ?>" style="color:var(--nme-emerald,#10B981);font-weight:600;">Upgrade to Premium</a> for unlimited messaging.
                                <?php endif; ?>
                            </p>
                        <?php endif; ?>

                        <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                            <input type="hidden" name="action" value="nmep_inbox_send">
                            <input type="hidden" name="expert_id" value="<?php echo (int) $expert->id; ?>">
                            <input type="hidden" name="role" value="<?php echo esc_attr( self::ROLE_BUYER ); ?>">
                            <?php wp_nonce_field( 'nmep_inbox_send' ); ?>
                            <p>
                                <textarea name="message" rows="3" required minlength="<?php echo (int) NMEP_Settings::get( 'inbox_message_min_length', 2 ); ?>" maxlength="<?php echo (int) NMEP_Settings::get( 'inbox_message_max_length', 3000 ); ?>" placeholder="Type your message..." style="width:100%;padding:10px;border:1px solid var(--nme-border,#E5E7EB);border-radius:8px;"></textarea>
                            </p>
                            <p style="font-size:0.8rem;color:var(--nme-text-light,#6B7280);">
                                🔒 For your safety, phone numbers and emails in messages will be hidden. All work and payment must happen on Nagaland Me to keep your escrow protection.
                            </p>
                            <p>
                                <button type="submit" class="nme-btn nme-btn-gold">Send Message</button>
                            </p>
                        </form>
                    <?php else : ?>
                        <div class="nme-card" style="background:#FEF3C7;border-left:4px solid #F59E0B;">
                            <p style="margin:0;"><strong>Daily message limit reached.</strong> You've used all <?php echo (int) $limit; ?> messages in the last 24 hours. <a href="<?php echo esc_url( class_exists( 'NMEP_Buyer_Premium' ) ? NMEP_Buyer_Premium::landing_url() : home_url( '/buyer-premium/' ) ); ?>" style="color:var(--nme-emerald,#10B981);font-weight:600;">Upgrade to Premium</a> for unlimited messaging.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </section>
        <script>
        (function(){
            var el = document.getElementById('thread-bottom');
            if (el) { el.scrollIntoView({block:'end'}); }
        })();
        </script>
        <?php
        return ob_get_clean();
    }

    public static function render_expert_inbox( $atts ) {
        if ( ! is_user_logged_in() ) {
            return '<div class="nme-card"><p>Please log in.</p></div>';
        }
        $expert = NMEP_Compat::get_expert_by_user( get_current_user_id() );
        if ( ! $expert || $expert->status !== 'approved' ) {
            return '<div class="nme-card"><p>This page is for approved experts only.</p></div>';
        }

        $thread_buyer = isset( $_GET['thread_buyer'] ) ? (int) $_GET['thread_buyer'] : 0;
        $filter       = isset( $_GET['filter'] ) && $_GET['filter'] === 'premium' ? 'premium' : 'all';

        ob_start();
        if ( $thread_buyer ) {
            echo self::render_expert_thread_view( $expert, $thread_buyer );
        } else {
            echo self::render_expert_thread_list( $expert, $filter );
        }
        return ob_get_clean();
    }

    private static function render_expert_thread_list( $expert, $filter = 'all' ) {
        // v0.7.4 — Premium signal for experts. We load two counts regardless of the
        // active filter so the tab labels always show the right totals.
        $premium_module_on = class_exists( 'NMEP_Buyer_Premium' ) && (bool) NMEP_Settings::get( 'premium_buyer_enabled', true );
        $all_threads       = self::get_expert_threads( $expert->id, 'all' );
        $premium_threads   = $premium_module_on ? self::get_expert_threads( $expert->id, 'premium' ) : array();
        $threads           = ( $filter === 'premium' ) ? $premium_threads : $all_threads;

        $tab_all_url     = remove_query_arg( 'filter', self::expert_inbox_url() );
        $tab_premium_url = add_query_arg( 'filter', 'premium', self::expert_inbox_url() );

        ob_start();
        ?>
        <section class="nme-section">
            <div class="nme-container" style="max-width:900px;">
                <h1>Pre-Purchase Inbox</h1>
                <p style="color:var(--nme-text-light,#6B7280);">Questions from buyers who haven't placed an order yet. Once they purchase, the conversation moves to that order's Messages tab.</p>

                <?php if ( $premium_module_on ) : ?>
                    <div class="nme-inbox-tabs" style="display:flex;gap:6px;margin:16px 0;border-bottom:1px solid var(--nme-border,#E5E7EB);padding-bottom:0;">
                        <a href="<?php echo esc_url( $tab_all_url ); ?>" style="padding:10px 16px;border-bottom:3px solid <?php echo $filter === 'all' ? 'var(--nme-gold,#D4A843)' : 'transparent'; ?>;color:<?php echo $filter === 'all' ? 'var(--nme-forest,#0F2419)' : 'var(--nme-text-light,#6B7280)'; ?>;text-decoration:none;font-weight:<?php echo $filter === 'all' ? '700' : '500'; ?>;margin-bottom:-1px;">
                            All <span style="color:var(--nme-text-light,#6B7280);font-weight:500;">(<?php echo count( $all_threads ); ?>)</span>
                        </a>
                        <a href="<?php echo esc_url( $tab_premium_url ); ?>" style="padding:10px 16px;border-bottom:3px solid <?php echo $filter === 'premium' ? 'var(--nme-gold,#D4A843)' : 'transparent'; ?>;color:<?php echo $filter === 'premium' ? 'var(--nme-forest,#0F2419)' : 'var(--nme-text-light,#6B7280)'; ?>;text-decoration:none;font-weight:<?php echo $filter === 'premium' ? '700' : '500'; ?>;margin-bottom:-1px;">
                            ⭐ Premium <span style="color:var(--nme-text-light,#6B7280);font-weight:500;">(<?php echo count( $premium_threads ); ?>)</span>
                        </a>
                    </div>
                <?php endif; ?>

                <?php if ( empty( $threads ) ) : ?>
                    <div class="nme-card nme-text-center" style="padding:60px 20px;">
                        <div style="font-size:4rem;">📥</div>
                        <?php if ( $filter === 'premium' ) : ?>
                            <h3>No Premium Buyer messages yet</h3>
                            <p>When a Premium Buyer messages you, they'll show up here.</p>
                            <p><a href="<?php echo esc_url( $tab_all_url ); ?>" class="nme-btn nme-btn-gold">← View all conversations</a></p>
                        <?php else : ?>
                            <h3>No pre-purchase messages yet</h3>
                            <p>When buyers message you from a service page, their messages will show up here.</p>
                        <?php endif; ?>
                    </div>
                <?php else : ?>
                    <div class="nme-card" style="padding:0;">
                        <?php foreach ( $threads as $t ) :
                            $url = add_query_arg( 'thread_buyer', (int) $t->buyer_user_id, self::expert_inbox_url() );
                            $unread = (int) $t->unread_count > 0;
                            $is_premium_buyer = $premium_module_on && NMEP_Buyer_Premium::is_premium( (int) $t->buyer_user_id );
                            $is_trusted_buyer = class_exists( 'NMEP_Buyer_Premium' ) && NMEP_Buyer_Premium::is_trusted_buyer( (int) $t->buyer_user_id );
                        ?>
                            <a href="<?php echo esc_url( $url ); ?>" style="display:flex;gap:14px;padding:16px;border-bottom:1px solid var(--nme-border,#E5E7EB);text-decoration:none;color:inherit;<?php echo $unread ? 'background:#ECFDF5;' : ''; ?>">
                                <div style="flex:0 0 48px;">
                                    <div style="width:48px;height:48px;border-radius:50%;background:var(--nme-forest,#0F2419);color:var(--nme-gold,#D4A843);display:flex;align-items:center;justify-content:center;font-weight:700;"><?php echo esc_html( strtoupper( substr( (string) $t->buyer_name, 0, 1 ) ) ); ?></div>
                                </div>
                                <div style="flex:1;min-width:0;">
                                    <div style="display:flex;justify-content:space-between;align-items:baseline;gap:8px;">
                                        <div style="min-width:0;">
                                            <strong style="color:var(--nme-forest,#0F2419);"><?php echo esc_html( $t->buyer_name ); ?></strong>
                                            <?php if ( $is_premium_buyer ) : ?>
                                                <span title="Premium Buyer" style="display:inline-block;padding:2px 8px;margin-left:6px;border-radius:50px;font-size:0.65rem;font-weight:700;background:#D4A843;color:#fff;text-transform:uppercase;letter-spacing:0.05em;vertical-align:middle;">★ Premium</span>
                                            <?php endif; ?>
                                            <?php if ( $is_trusted_buyer ) : ?>
                                                <span title="Trusted Buyer — verified" style="display:inline-block;padding:2px 8px;margin-left:4px;border-radius:50px;font-size:0.65rem;font-weight:700;background:#10B981;color:#fff;text-transform:uppercase;letter-spacing:0.05em;vertical-align:middle;">✓ Trusted</span>
                                            <?php endif; ?>
                                        </div>
                                        <small style="color:var(--nme-text-light,#6B7280);white-space:nowrap;"><?php echo esc_html( human_time_diff( strtotime( $t->last_msg_at ), current_time( 'timestamp', true ) ) ); ?> ago</small>
                                    </div>
                                    <div style="color:var(--nme-text-light,#6B7280);font-size:0.9rem;margin-top:4px;">
                                        <?php echo $t->last_sender_role === 'expert' ? '<span style="color:var(--nme-emerald,#10B981);">You:</span> ' : ''; ?>
                                        <?php echo esc_html( self::truncate( $t->last_message, 110 ) ); ?>
                                    </div>
                                </div>
                                <?php if ( $unread ) : ?>
                                    <div style="flex:0 0 auto;align-self:center;background:var(--nme-emerald,#10B981);color:#fff;border-radius:50px;padding:2px 10px;font-size:0.75rem;font-weight:700;"><?php echo (int) $t->unread_count; ?></div>
                                <?php endif; ?>
                            </a>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </section>
        <?php
        return ob_get_clean();
    }

    private static function render_expert_thread_view( $expert, $buyer_user_id ) {
        $buyer = get_userdata( $buyer_user_id );
        if ( ! $buyer ) {
            return '<div class="nme-card"><p>Buyer not found.</p></div>';
        }

        $messages = self::get_thread( $buyer_user_id, $expert->id );
        self::mark_thread_read( $buyer_user_id, $expert->id, self::ROLE_EXPERT );

        $is_premium = class_exists( 'NMEP_Buyer_Premium' ) && NMEP_Buyer_Premium::is_premium( $buyer_user_id );
        $is_trusted = class_exists( 'NMEP_Buyer_Premium' ) && NMEP_Buyer_Premium::is_trusted_buyer( $buyer_user_id );

        ob_start();
        ?>
        <section class="nme-section">
            <div class="nme-container" style="max-width:820px;">
                <p><a href="<?php echo esc_url( self::expert_inbox_url() ); ?>" style="color:var(--nme-emerald,#10B981);">← All conversations</a></p>

                <?php if ( isset( $_GET['nmep_sent'] ) ) : ?>
                    <div class="nme-card" style="border-left:4px solid var(--nme-emerald,#10B981);background:#ECFDF5;margin-bottom:12px;">
                        <p style="margin:0;color:#065F46;">✅ Reply sent.</p>
                    </div>
                <?php endif; ?>

                <div class="nme-card">
                    <div style="display:flex;gap:12px;align-items:center;margin-bottom:12px;border-bottom:1px solid var(--nme-border,#E5E7EB);padding-bottom:12px;">
                        <div style="width:48px;height:48px;border-radius:50%;background:var(--nme-forest,#0F2419);color:var(--nme-gold,#D4A843);display:flex;align-items:center;justify-content:center;font-weight:700;"><?php echo esc_html( strtoupper( substr( $buyer->display_name, 0, 1 ) ) ); ?></div>
                        <div style="flex:1;">
                            <strong style="color:var(--nme-forest,#0F2419);"><?php echo esc_html( $buyer->display_name ); ?></strong>
                            <?php if ( $is_premium ) : ?><span style="display:inline-block;padding:2px 8px;margin-left:6px;border-radius:50px;font-size:0.65rem;font-weight:700;background:#D4A843;color:#fff;text-transform:uppercase;letter-spacing:0.05em;">★ Premium</span><?php endif; ?>
                            <?php if ( $is_trusted ) : ?><span style="display:inline-block;padding:2px 8px;margin-left:4px;border-radius:50px;font-size:0.65rem;font-weight:700;background:#10B981;color:#fff;text-transform:uppercase;letter-spacing:0.05em;">✓ Trusted</span><?php endif; ?>
                        </div>
                    </div>

                    <div style="max-height:500px;overflow-y:auto;padding:8px;background:var(--nme-bg-soft,#F9FAFB);border-radius:8px;margin-bottom:16px;">
                        <?php if ( empty( $messages ) ) : ?>
                            <p style="text-align:center;color:var(--nme-text-light,#6B7280);padding:20px;">No messages in this thread.</p>
                        <?php else : foreach ( $messages as $m ) :
                            $is_mine = ( $m->sender_role === self::ROLE_EXPERT );
                        ?>
                            <div style="display:flex;<?php echo $is_mine ? 'justify-content:flex-end;' : ''; ?>margin-bottom:12px;">
                                <div style="max-width:75%;<?php echo $is_mine ? 'background:var(--nme-emerald,#10B981);color:white;' : 'background:white;color:var(--nme-text,#374151);'; ?>padding:10px 14px;border-radius:14px;">
                                    <div style="white-space:pre-line;word-break:break-word;"><?php echo esc_html( $m->message ); ?></div>
                                    <div style="font-size:0.7rem;opacity:0.7;margin-top:4px;text-align:right;"><?php echo esc_html( human_time_diff( strtotime( $m->created_at ), current_time( 'timestamp', true ) ) ); ?> ago</div>
                                </div>
                            </div>
                        <?php endforeach; endif; ?>
                        <div id="thread-bottom"></div>
                    </div>

                    <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                        <input type="hidden" name="action" value="nmep_inbox_send">
                        <input type="hidden" name="expert_id" value="<?php echo (int) $expert->id; ?>">
                        <input type="hidden" name="buyer_user_id" value="<?php echo (int) $buyer_user_id; ?>">
                        <input type="hidden" name="role" value="<?php echo esc_attr( self::ROLE_EXPERT ); ?>">
                        <?php wp_nonce_field( 'nmep_inbox_send' ); ?>
                        <p>
                            <textarea name="message" rows="3" required minlength="<?php echo (int) NMEP_Settings::get( 'inbox_message_min_length', 2 ); ?>" maxlength="<?php echo (int) NMEP_Settings::get( 'inbox_message_max_length', 3000 ); ?>" placeholder="Reply to <?php echo esc_attr( $buyer->display_name ); ?>..." style="width:100%;padding:10px;border:1px solid var(--nme-border,#E5E7EB);border-radius:8px;"></textarea>
                        </p>
                        <p style="font-size:0.8rem;color:var(--nme-text-light,#6B7280);">
                            🔒 Contact info in your reply will be hidden. Keep all communication and payment on Nagaland Me.
                        </p>
                        <p>
                            <button type="submit" class="nme-btn nme-btn-gold">Send Reply</button>
                        </p>
                    </form>
                </div>
            </div>
        </section>
        <script>(function(){var el=document.getElementById('thread-bottom');if(el)el.scrollIntoView({block:'end'});})();</script>
        <?php
        return ob_get_clean();
    }

    /* ============================================================
       EMAIL NOTIFICATIONS
       ============================================================ */

    private static function notify_recipient( $expert, $sender_role, $buyer_name, $buyer_email, $buyer_user_id, $message ) {
        $preview = self::truncate( $message, 160 );
        $subject = '';
        $to      = '';
        $body    = '';
        $cta_text = '';
        $cta_url  = '';

        if ( $sender_role === self::ROLE_BUYER ) {
            // Notify expert
            $to = (string) $expert->email;
            if ( ! $to ) return;
            $subject = 'New message from ' . $buyer_name . ' — Nagaland Me Experts';
            $body = '<p>Hi <strong>' . esc_html( $expert->full_name ) . '</strong>,</p>
            <p>You have a new pre-purchase message from <strong>' . esc_html( $buyer_name ) . '</strong>:</p>
            <div style="background:#F9FAFB;padding:12px;border-radius:6px;white-space:pre-line;font-style:italic;">' . esc_html( $preview ) . '</div>
            <p>Reply from your expert dashboard to keep the conversation going.</p>';
            $cta_text = 'Open Inbox';
            $cta_url  = self::expert_inbox_url();
        } else {
            // Notify buyer
            $buyer = get_userdata( $buyer_user_id );
            if ( ! $buyer ) return;
            $to = (string) $buyer->user_email;
            if ( ! $to ) return;
            $subject = esc_html( $expert->full_name ) . ' replied to your message — Nagaland Me Experts';
            $body = '<p>Hi <strong>' . esc_html( $buyer->display_name ) . '</strong>,</p>
            <p><strong>' . esc_html( $expert->full_name ) . '</strong> has replied to your pre-purchase question:</p>
            <div style="background:#F9FAFB;padding:12px;border-radius:6px;white-space:pre-line;font-style:italic;">' . esc_html( $preview ) . '</div>';
            $cta_text = 'View Reply';
            $cta_url  = add_query_arg( 'expert_id', (int) $expert->id, self::buyer_inbox_url() );
        }

        $html = self::email_wrap( 'New Message', $body, $cta_text, $cta_url );
        $sent = wp_mail( $to, $subject, $html, self::email_headers() );
        NMEP_Logger::info( 'Inbox notification email sent', array(
            'to'   => $to,
            'role' => $sender_role,
            'sent' => $sent,
        ) );
    }

    private static function email_wrap( $title, $body_html, $cta_text = '', $cta_url = '' ) {
        $merchant = NMEP_Settings::get( 'merchant_name', 'Nagaland Me Experts' );
        $support  = NMEP_Settings::get( 'support_email', 'info@nagaland.me' );
        $color    = NMEP_Settings::get( 'theme_color', '#0F2419' );
        $year     = date( 'Y' );

        $cta_html = '';
        if ( $cta_text && $cta_url ) {
            $cta_html = '<table cellpadding="0" cellspacing="0" border="0" style="margin:24px auto;"><tr><td style="background:#D4A843;border-radius:50px;"><a href="' . esc_url( $cta_url ) . '" style="display:inline-block;padding:14px 32px;color:' . esc_attr( $color ) . ';text-decoration:none;font-weight:700;font-family:Arial,sans-serif;">' . esc_html( $cta_text ) . '</a></td></tr></table>';
        }

        return '<!DOCTYPE html><html><head><meta charset="UTF-8"></head>
<body style="margin:0;padding:0;background:#F5F2E8;font-family:Arial,Helvetica,sans-serif;color:#1F2937;">
<table width="100%" cellpadding="0" cellspacing="0" style="background:#F5F2E8;padding:30px 20px;">
<tr><td align="center">
<table width="600" cellpadding="0" cellspacing="0" style="max-width:600px;background:#FFFFFF;border-radius:12px;overflow:hidden;">
<tr><td style="background:' . esc_attr( $color ) . ';padding:24px;text-align:center;color:#fff;font-size:1.2rem;font-family:Georgia,serif;">' . esc_html( $merchant ) . '</td></tr>
<tr><td style="padding:28px;">
<h1 style="color:' . esc_attr( $color ) . ';font-family:Georgia,serif;font-size:22px;margin:0 0 14px;">' . esc_html( $title ) . '</h1>
<div style="font-size:15px;line-height:1.6;color:#374151;">' . $body_html . '</div>' . $cta_html . '
</td></tr>
<tr><td style="background:#F9FAFB;padding:18px 28px;border-top:1px solid #E5E7EB;text-align:center;font-size:12px;color:#6B7280;">
<p style="margin:0;">© ' . $year . ' ' . esc_html( $merchant ) . ' · Help: <a href="mailto:' . esc_attr( $support ) . '" style="color:#6B7280;">' . esc_html( $support ) . '</a></p>
</td></tr>
</table></td></tr></table></body></html>';
    }

    private static function email_headers() {
        $support = NMEP_Settings::get( 'support_email', 'info@nagaland.me' );
        $name    = NMEP_Settings::get( 'merchant_name', 'Nagaland Me Experts' );
        return array(
            'From: ' . $name . ' <' . $support . '>',
            'Content-Type: text/html; charset=UTF-8',
            'Reply-To: ' . $support,
        );
    }

    /* ============================================================
       PAGE BOOTSTRAP
       ============================================================
       Creates /inbox/ and /expert-inbox/ once, on first run. Earlier
       plugin builds skipped these pages entirely, so buyer_inbox_url()
       dead-ended at 404 and every "Message Expert" CTA broke.

       Race-safe: transient lock + direct wpdb check against wp_posts
       (not get_page_by_path, which is permalink-cache-backed and can
       lag enough to produce auto-suffixed duplicates under concurrent
       init-hook fires). Option flag prevents re-runs on the same site.
       Guarded to admin/cron/CLI so the LIKE on wp_posts can't land in
       a buyer's page-render path. */

    public static function maybe_create_pages() {
        if ( get_option( self::PAGES_OPTION ) ) {
            return;
        }
        if ( ! is_admin() && ! wp_doing_cron() && ! ( defined( 'WP_CLI' ) && WP_CLI ) ) {
            return;
        }
        if ( get_transient( self::PAGES_LOCK ) ) {
            return;
        }
        set_transient( self::PAGES_LOCK, 1, MINUTE_IN_SECONDS );

        $wanted = array(
            'inbox'        => array( 'title' => 'My Messages',  'content' => '[nmep_inbox]' ),
            'expert-inbox' => array( 'title' => 'Expert Inbox', 'content' => '[nmep_expert_inbox]' ),
        );
        foreach ( $wanted as $slug => $data ) {
            if ( self::page_slug_exists( $slug ) ) {
                continue;
            }
            $pid = wp_insert_post( array(
                'post_title'   => $data['title'],
                'post_name'    => $slug,
                'post_content' => $data['content'],
                'post_status'  => 'publish',
                'post_type'    => 'page',
                'post_author'  => 1,
            ) );
            if ( ! is_wp_error( $pid ) && $pid && class_exists( 'NMEP_Logger' ) ) {
                NMEP_Logger::info( 'Inbox page created', array(
                    'slug'    => $slug,
                    'post_id' => (int) $pid,
                ) );
            }
        }

        update_option( self::PAGES_OPTION, time(), false );
        delete_transient( self::PAGES_LOCK );
    }

    private static function page_slug_exists( $slug ) {
        global $wpdb;
        $slug = sanitize_title( (string) $slug );
        if ( $slug === '' ) {
            return true;
        }
        $id = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT ID FROM {$wpdb->posts}
              WHERE post_type   = 'page'
                AND post_name   = %s
                AND post_status <> 'auto-draft'
              LIMIT 1",
            $slug
        ) );
        return $id > 0;
    }

    /* ============================================================
       LOGIN GATE
       ============================================================
       Friendly stand-in for the bare wp-login.php redirect. Shown
       by render_buyer_inbox() when an anonymous visitor lands on
       /inbox/ (typically from clicking "Message Expert" on a
       service or profile page). Explains WHY they need an account
       and HOW to get one (buy a service — account is auto-created
       by NMEP_Buyer_Account_Auto at the payment-captured step). */

    private static function render_login_gate( $expert_id = 0 ) {
        $expert      = $expert_id > 0 ? NMEP_Compat::get_expert( $expert_id ) : null;
        $expert_name = ( $expert && ! empty( $expert->full_name ) ) ? (string) $expert->full_name : '';

        // Preserve expert_id through login so the buyer lands directly
        // on the right thread after authenticating.
        $target_url = $expert_id > 0
            ? add_query_arg( 'expert_id', (int) $expert_id, self::buyer_inbox_url() )
            : self::buyer_inbox_url();

        // Build the login URL via site_url() rather than wp_login_url()
        // so our own filter_login_url() callback doesn't turn this
        // button back into a link to the gate (infinite loop).
        $login_url = site_url( 'wp-login.php?redirect_to=' . rawurlencode( $target_url ), 'login' );

        $services_url = home_url( '/services/' );

        $heading = $expert_name !== ''
            ? sprintf( 'Log in to message %s', esc_html( $expert_name ) )
            : 'Log in to message an expert';

        ob_start();
        ?>
        <section class="nme-section">
            <div class="nme-container" style="max-width:640px;">
                <div class="nme-card" style="text-align:center; padding:40px 28px;">
                    <div style="font-size:3rem; margin-bottom:16px;">🔒</div>
                    <h1 style="margin:0 0 16px; color:var(--nme-forest,#0F2419);"><?php echo $heading; // already escaped above ?></h1>

                    <p style="color:var(--nme-text-light,#6B7280); margin:0 auto 24px; max-width:520px; line-height:1.7;">
                        Messaging is available to buyers with an account on Nagaland Me Experts. We create your account <strong>automatically</strong> when you purchase a service &mdash; no separate sign-up form needed. This keeps the platform safe for both buyers and experts.
                    </p>

                    <div style="text-align:left; background:#F9FAFB; border-radius:8px; padding:18px 20px; margin:0 auto 24px; max-width:520px;">
                        <p style="margin:0 0 12px;">
                            <strong style="color:var(--nme-forest,#0F2419);">Already purchased a service here?</strong><br>
                            <span style="color:var(--nme-text-light,#6B7280);">Your account is ready &mdash; just log in below to start chatting.</span>
                        </p>
                        <p style="margin:0;">
                            <strong style="color:var(--nme-forest,#0F2419);">New to Nagaland Me Experts?</strong><br>
                            <span style="color:var(--nme-text-light,#6B7280);">Pick a service and complete your first order. We'll set up your account automatically &mdash; then you can message any expert.</span>
                        </p>
                    </div>

                    <div style="display:flex; gap:12px; justify-content:center; flex-wrap:wrap;">
                        <a href="<?php echo esc_url( $login_url ); ?>" class="nme-btn nme-btn-gold" style="padding:12px 28px;">Log In &rarr;</a>
                        <a href="<?php echo esc_url( $services_url ); ?>" class="nme-btn" style="padding:12px 28px; background:transparent; color:var(--nme-forest,#0F2419); border:2px solid var(--nme-forest,#0F2419);">Browse Services &rarr;</a>
                    </div>

                    <p style="color:var(--nme-text-light,#9CA3AF); font-size:0.85rem; margin:24px 0 0;">
                        Lost your password? <a href="<?php echo esc_url( wp_lostpassword_url( $target_url ) ); ?>" style="color:var(--nme-emerald,#10B981);">Reset it here</a>.
                    </p>
                </div>
            </div>
        </section>
        <?php
        return ob_get_clean();
    }

    /**
     * login_url filter. When a caller passes a redirect target that
     * lives on our buyer-inbox page, skip wp-login.php entirely and
     * send the user straight there, where render_buyer_inbox() will
     * render the login gate. We deliberately do NOT touch any other
     * login URL (wp-admin, expert-dashboard, my-account, etc.).
     *
     * Signature matches apply_filters( 'login_url', $url, $redirect,
     * $force_reauth ).
     */
    public static function filter_login_url( $login_url, $redirect, $force_reauth ) {
        if ( $force_reauth ) {
            return $login_url;
        }
        if ( empty( $redirect ) ) {
            return $login_url;
        }
        $inbox_path = wp_parse_url( self::buyer_inbox_url(), PHP_URL_PATH );
        if ( empty( $inbox_path ) ) {
            return $login_url;
        }
        $redirect_path = wp_parse_url( (string) $redirect, PHP_URL_PATH );
        if ( $redirect_path !== $inbox_path ) {
            return $login_url;
        }
        return $redirect;
    }

    /* ============================================================
       URL + TEXT HELPERS
       ============================================================ */

    public static function buyer_inbox_url() {
        $page = get_page_by_path( 'inbox' );
        if ( $page ) return get_permalink( $page );
        return home_url( '/inbox/' );
    }

    public static function expert_inbox_url() {
        $page = get_page_by_path( 'expert-inbox' );
        if ( $page ) return get_permalink( $page );
        return home_url( '/expert-inbox/' );
    }

    private static function truncate( $text, $len ) {
        $text = (string) $text;
        if ( mb_strlen( $text ) <= $len ) return $text;
        return rtrim( mb_substr( $text, 0, $len ) ) . '…';
    }
}