<?php
/**
 * NMEP_Refunds
 * Production-grade refund management.
 *
 * Refund types:
 * - full: 100% of order amount (uses reverse_all=1 to also reverse Route transfers)
 * - partial: specified amount (transfers reversed proportionally if needed)
 *
 * @version 1.3.0 (Batch D)
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class NMEP_Refunds {

    public static function init() {
        add_action( 'admin_post_nmep_admin_create_refund', array( __CLASS__, 'handle_admin_refund' ) );
    }

    /* ============================================================
       CREATE REFUND
       ============================================================ */

    /**
     * Create a refund for an order.
     *
     * @param int    $order_id   Local order ID
     * @param float|null $amount Amount in INR (null = full refund)
     * @param string $reason     Reason for refund
     * @param int    $initiated_by_user WordPress user ID who initiated
     * @param string $initiated_role admin|buyer|system
     * @return int|WP_Error Refund local ID on success
     */
    public static function create( $order_id, $amount = null, $reason = '', $initiated_by_user = 0, $initiated_role = 'admin' ) {
        global $wpdb;

        $order = NMEP_Orders::get( $order_id );
        if ( ! $order ) {
            return new WP_Error( 'nmep_order_not_found', 'Order not found' );
        }

        // Must be paid to refund
        if ( $order->payment_status !== NMEP_Orders::PAYMENT_CAPTURED ) {
            return new WP_Error( 'nmep_not_refundable', 'Order is not in a refundable state' );
        }

        // Already fully refunded?
        if ( $order->status === NMEP_Orders::STATUS_REFUNDED ) {
            return new WP_Error( 'nmep_already_refunded', 'Order is already refunded' );
        }

        // Determine amount + type
        $is_full = ( $amount === null || $amount >= $order->gross_amount );
        if ( $is_full ) {
            $refund_amount = (float) $order->gross_amount;
            $refund_type = 'full';
        } else {
            $refund_amount = (float) $amount;
            $refund_type = 'partial';

            if ( $refund_amount <= 0 ) {
                return new WP_Error( 'nmep_invalid_amount', 'Refund amount must be greater than zero' );
            }
            if ( $refund_amount > $order->gross_amount ) {
                return new WP_Error( 'nmep_invalid_amount', 'Refund amount cannot exceed order total' );
            }
        }

        // Insert local refund record (status: pending)
        $refunds_table = NMEP_Database::table( 'refunds' );

        $insert_result = $wpdb->insert( $refunds_table, array(
            'order_id'       => (int) $order_id,
            'mode'           => $order->mode,
            'refund_amount'  => $refund_amount,
            'refund_type'    => $refund_type,
            'reason'         => sanitize_text_field( $reason ),
            'initiated_by'   => (int) $initiated_by_user,
            'initiated_role' => sanitize_key( $initiated_role ),
            'status'         => 'pending',
        ) );

        if ( ! $insert_result ) {
            return new WP_Error( 'nmep_db_error', 'Could not create refund record' );
        }

        $refund_local_id = (int) $wpdb->insert_id;

        NMEP_Logger::info( 'Refund initiated', array(
            'order_id'      => $order_id,
            'refund_id'     => $refund_local_id,
            'amount'        => $refund_amount,
            'type'          => $refund_type,
            'initiated_by'  => $initiated_role,
        ) );

        // Call Razorpay refund API (passes reverse_all=1 to also reverse Route transfers)
        $amount_paise = $is_full ? null : nmep_to_paise( $refund_amount );

        $notes = array(
            'order_number' => $order->order_number,
            'reason'       => $reason,
            'refund_id'    => (string) $refund_local_id,
        );

        $response = NMEP_Razorpay_Client::create_refund(
            $order->razorpay_payment_id,
            $amount_paise,
            $notes
        );

        if ( is_wp_error( $response ) ) {
            $wpdb->update( $refunds_table, array(
                'status'         => 'failed',
                'failure_reason' => $response->get_error_message(),
                'api_response'   => wp_json_encode( $response->get_error_data() ),
            ), array( 'id' => $refund_local_id ) );

            NMEP_Logger::error( 'Razorpay refund creation failed', array(
                'order_id'  => $order_id,
                'refund_id' => $refund_local_id,
                'error'     => $response->get_error_message(),
            ) );

            return $response;
        }

        // Save Razorpay refund ID + initial status
        $wpdb->update( $refunds_table, array(
            'razorpay_refund_id' => sanitize_text_field( $response['id'] ?? '' ),
            'status'             => sanitize_text_field( $response['status'] ?? 'pending' ),
            'api_response'       => wp_json_encode( $response ),
        ), array( 'id' => $refund_local_id ) );

        NMEP_Logger::info( 'Razorpay refund created', array(
            'order_id'           => $order_id,
            'refund_id'          => $refund_local_id,
            'razorpay_refund_id' => $response['id'] ?? '',
            'status'             => $response['status'] ?? '',
        ) );

        // Update order status
        $update_data = array();
        if ( $is_full ) {
            $update_data['status']         = NMEP_Orders::STATUS_REFUNDED;
            $update_data['payment_status'] = NMEP_Orders::PAYMENT_REFUNDED;
            $update_data['escrow_status']  = NMEP_Orders::ESCROW_REVERSED;
        }
        if ( ! empty( $update_data ) ) {
            NMEP_Orders::update( $order_id, $update_data );
        }

        NMEP_Compat::audit_log( 'refund_created', 'order', $order_id, array(
            'amount'       => $refund_amount,
            'type'         => $refund_type,
            'initiated_by' => $initiated_role,
        ) );

        // Send email
        if ( class_exists( 'NMEP_Emails' ) ) {
            $order = NMEP_Orders::get( $order_id );
            $refund = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $refunds_table WHERE id = %d", $refund_local_id ) );
            NMEP_Emails::send_refund_confirmation( $order, $refund );
        }

        do_action( 'nmep_refund_created', $order_id, $refund_local_id );

        if ( class_exists( 'NMEP_Events' ) ) {
            if ( $is_full ) {
                NMEP_Events::emit( NMEP_Events::ORDER_REFUNDED, $order_id, $refund_local_id, $refund_amount );
            }
            NMEP_Events::emit( NMEP_Events::REFUND_PROCESSED, $order_id, $refund_local_id, $refund_amount, $refund_type );
        }

        return $refund_local_id;
    }

    /* ============================================================
       ADMIN HANDLER
       ============================================================ */

    /**
     * Admin form: create a refund
     */
    public static function handle_admin_refund() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( 'Permission denied.' );
        }

        $order_id = isset( $_POST['order_id'] ) ? (int) $_POST['order_id'] : 0;
        if ( ! wp_verify_nonce( $_POST['_wpnonce'] ?? '', 'nmep_refund_' . $order_id ) ) {
            wp_die( 'Invalid request.' );
        }

        $refund_type = sanitize_key( $_POST['refund_type'] ?? 'full' );
        $reason      = sanitize_text_field( $_POST['reason'] ?? '' );
        $amount      = $refund_type === 'partial' ? (float) ( $_POST['amount'] ?? 0 ) : null;

        if ( empty( $reason ) ) {
            wp_die( 'Please provide a refund reason.' );
        }

        $result = self::create( $order_id, $amount, $reason, get_current_user_id(), 'admin' );

        $redirect = admin_url( 'admin.php?page=nmep-orders' );
        if ( is_wp_error( $result ) ) {
            $redirect = add_query_arg( 'nmep_error', urlencode( $result->get_error_message() ), $redirect );
        } else {
            $redirect = add_query_arg( 'nmep_refunded', '1', $redirect );
        }

        wp_safe_redirect( $redirect );
        exit;
    }

    /* ============================================================
       QUERIES
       ============================================================ */

    public static function get_for_order( $order_id ) {
        global $wpdb;
        return $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM " . NMEP_Database::table( 'refunds' ) . " WHERE order_id = %d ORDER BY created_at DESC",
            (int) $order_id
        ) );
    }

    public static function total_refunded_for_order( $order_id ) {
        global $wpdb;
        return (float) $wpdb->get_var( $wpdb->prepare(
            "SELECT COALESCE(SUM(refund_amount), 0) FROM " . NMEP_Database::table( 'refunds' ) . "
             WHERE order_id = %d AND status IN ('processed', 'pending')",
            (int) $order_id
        ) );
    }
}
