<?php
/**
 * NMEP_Moderation
 *
 * Phase 5B — defensive content + attachment screening for order messages.
 *
 * screen_message( $text )
 *   Runs the text through:
 *     - contact-info redaction (phone, email, "at/dot" obfuscation)
 *     - explicit blocked-word list (from settings)
 *     - URL cap (> N links triggers flag but is NOT rewritten)
 *   Returns array {
 *     'allowed'        => bool      // always true — we flag, never outright reject
 *     'text'           => string    // redacted copy safe to persist
 *     'blocked_reason' => string|null ('contact_info' | 'blocked_word' | 'url_flood')
 *     'matched'        => string[]  // for audit
 *   }
 *
 * handle_upload( $file )
 *   Validates an uploaded attachment:
 *     - size <= messages_max_attachment_mb
 *     - real MIME (via finfo) in allow-list
 *     - extension in allow-list (defence-in-depth)
 *   Moves the file into uploads/nmep-message-attachments/<y>/<m>/, returns
 *   array { 'url','path','mime','size','original_name' } or WP_Error.
 *
 * @package NagalandMeExpertsPayments
 * @since   2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class NMEP_Moderation {

    const UPLOAD_SUBDIR = 'nmep-message-attachments';

    const DEFAULT_BLOCKED_WORDS = 'bank account,upi id,otp,password,one time password,moneygram,western union,cash only,outside escrow,off platform,pay me directly,send me money,gift card,steam card,itunes voucher';

    const DEFAULT_ALLOWED_MIMES = 'image/jpeg,image/png,image/webp,image/gif,application/pdf,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document,application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,text/csv,text/plain,application/zip';

    const DEFAULT_ALLOWED_EXTS = 'jpg,jpeg,png,webp,gif,pdf,doc,docx,xls,xlsx,csv,txt,zip';

    const URL_LIMIT = 3;

    /* ============================================================
       TEXT SCREENING
       ============================================================ */

    public static function screen_message( $text ) {
        $original = (string) $text;
        $redacted = $original;
        $matched  = array();
        $reason   = null;

        // 1. Contact-info redaction — reuse pre-purchase inbox filter if present.
        if ( class_exists( 'NMEP_Inbox' ) && method_exists( 'NMEP_Inbox', 'filter_contact_info' ) ) {
            $r = NMEP_Inbox::filter_contact_info( $redacted );
            if ( ! empty( $r['was_filtered'] ) ) {
                $redacted = $r['filtered'];
                $reason   = 'contact_info';
                $matched[] = 'contact_info';
            }
        } else {
            $pre = $redacted;
            $redacted = preg_replace( '/[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}/i', '[contact hidden]', $redacted );
            $redacted = preg_replace( '/(?<![A-Za-z0-9])\+?\d[\d\s\-\.\(\)]{8,}\d(?![A-Za-z0-9])/', '[contact hidden]', $redacted );
            if ( $redacted !== $pre ) {
                $reason   = 'contact_info';
                $matched[] = 'contact_info';
            }
        }

        // 2. Explicit blocked-word list (settings-driven).
        $words = self::blocked_words();
        foreach ( $words as $w ) {
            if ( $w === '' ) continue;
            if ( stripos( $redacted, $w ) !== false ) {
                $matched[] = $w;
                if ( ! $reason ) $reason = 'blocked_word';
                // Replace matched phrase with [removed] but preserve length-ish
                $redacted = preg_replace( '/' . preg_quote( $w, '/' ) . '/i', '[removed]', $redacted );
            }
        }

        // 3. URL flood — > N links is suspicious in a message context.
        if ( preg_match_all( '#https?://[^\s<]+#i', $redacted, $m ) && count( $m[0] ) > self::URL_LIMIT ) {
            $matched[] = 'url_flood';
            if ( ! $reason ) $reason = 'url_flood';
        }

        return array(
            'allowed'        => true,
            'text'           => $redacted,
            'blocked_reason' => $reason,
            'matched'        => $matched,
        );
    }

    public static function blocked_words() {
        $raw = (string) NMEP_Settings::get( 'messages_blocked_words', self::DEFAULT_BLOCKED_WORDS );
        $parts = array_map( 'trim', explode( ',', $raw ) );
        return array_filter( $parts, function ( $p ) { return $p !== ''; } );
    }

    /* ============================================================
       ATTACHMENT UPLOAD
       ============================================================ */

    public static function handle_upload( $file ) {
        if ( ! is_array( $file ) || empty( $file['tmp_name'] ) || ! is_uploaded_file( $file['tmp_name'] ) ) {
            return new WP_Error( 'no_file', 'No file uploaded.' );
        }
        if ( ! empty( $file['error'] ) && (int) $file['error'] !== UPLOAD_ERR_OK ) {
            return new WP_Error( 'upload_error', 'Upload failed with error code ' . (int) $file['error'] );
        }

        $size     = (int) $file['size'];
        $max_mb   = (int) NMEP_Settings::get( 'messages_max_attachment_mb', 10 );
        $max_size = max( 1, $max_mb ) * 1024 * 1024;
        if ( $size <= 0 || $size > $max_size ) {
            return new WP_Error( 'bad_size', sprintf( 'File too large (max %d MB).', $max_mb ) );
        }

        $original = isset( $file['name'] ) ? (string) $file['name'] : 'attachment';
        $ext = strtolower( pathinfo( $original, PATHINFO_EXTENSION ) );
        if ( $ext === '' ) return new WP_Error( 'bad_ext', 'File has no extension.' );

        $allowed_exts = self::allowed_extensions();
        if ( ! in_array( $ext, $allowed_exts, true ) ) {
            return new WP_Error( 'bad_ext', 'Extension .' . $ext . ' is not permitted.' );
        }

        $mime = self::detect_mime( $file['tmp_name'], $original );
        $allowed_mimes = self::allowed_mimes();
        if ( ! in_array( $mime, $allowed_mimes, true ) ) {
            return new WP_Error( 'bad_mime', 'MIME type ' . $mime . ' is not permitted.' );
        }

        // Destination: uploads/nmep-message-attachments/YYYY/MM/
        $uploads = wp_upload_dir();
        if ( ! empty( $uploads['error'] ) ) {
            return new WP_Error( 'uploads_dir', $uploads['error'] );
        }
        $sub  = self::UPLOAD_SUBDIR . '/' . gmdate( 'Y/m' );
        $dir  = trailingslashit( $uploads['basedir'] ) . $sub;
        $url  = trailingslashit( $uploads['baseurl'] ) . $sub;
        if ( ! wp_mkdir_p( $dir ) ) {
            return new WP_Error( 'mkdir', 'Could not create upload directory.' );
        }

        $safe_base = sanitize_file_name( pathinfo( $original, PATHINFO_FILENAME ) );
        if ( $safe_base === '' ) $safe_base = 'file';
        $filename = $safe_base . '-' . wp_generate_password( 8, false, false ) . '.' . $ext;
        $dest_path = $dir . '/' . $filename;
        $dest_url  = $url . '/' . $filename;

        if ( ! @move_uploaded_file( $file['tmp_name'], $dest_path ) ) {
            return new WP_Error( 'move', 'Failed to move uploaded file.' );
        }
        @chmod( $dest_path, 0644 );

        return array(
            'url'           => $dest_url,
            'path'          => $dest_path,
            'mime'          => $mime,
            'size'          => $size,
            'original_name' => substr( $original, 0, 200 ),
        );
    }

    public static function persist_attachment( $message_id, $uploaded ) {
        global $wpdb;
        $wpdb->insert( NMEP_Database::table( 'message_attachments' ), array(
            'message_id'    => (int) $message_id,
            'file_url'      => $uploaded['url'],
            'file_mime'     => $uploaded['mime'],
            'file_size'     => (int) $uploaded['size'],
            'original_name' => $uploaded['original_name'],
        ) );
        return (int) $wpdb->insert_id;
    }

    private static function detect_mime( $path, $original_name ) {
        if ( function_exists( 'finfo_open' ) ) {
            $f = finfo_open( FILEINFO_MIME_TYPE );
            if ( $f ) {
                $m = finfo_file( $f, $path );
                finfo_close( $f );
                if ( $m ) return $m;
            }
        }
        $ft = wp_check_filetype( $original_name );
        return $ft['type'] ?: 'application/octet-stream';
    }

    public static function allowed_mimes() {
        $raw = (string) NMEP_Settings::get( 'messages_allowed_mimes', self::DEFAULT_ALLOWED_MIMES );
        return array_filter( array_map( 'trim', explode( ',', $raw ) ) );
    }

    public static function allowed_extensions() {
        $raw = (string) NMEP_Settings::get( 'messages_allowed_exts', self::DEFAULT_ALLOWED_EXTS );
        return array_filter( array_map( 'trim', array_map( 'strtolower', explode( ',', $raw ) ) ) );
    }
}
