<?php
/**
 * NMEP_Expert_Profile_V2
 *
 * Rich expert-profile data introduced in v2.0:
 *   - Subcategories under existing categories (nmep_subcategories)
 *   - Portfolio items (nmep_portfolio)
 *   - Languages + proficiency (nmep_expert_languages)
 *   - Certifications (nmep_expert_certifications)
 *   - Availability mode (reuses nmep_expert_metrics: availability_mode +
 *     away_message maintained by NMEP_Metrics)
 *
 * CRUD endpoints + admin submenu for subcategories + expert-dashboard
 * shortcodes that render edit forms for portfolio / languages /
 * certifications. Availability is handled via NMEP_Metrics::ajax_set_mode
 * so this class exposes only a render helper.
 *
 * @package NagalandMeExpertsPayments
 * @since   2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class NMEP_Expert_Profile_V2 {

    const LANG_PROFICIENCIES = array( 'basic', 'conversational', 'fluent', 'native' );

    public static function init() {
        // Subcategories — admin
        if ( is_admin() ) {
            add_action( 'admin_menu', array( __CLASS__, 'register_admin_menu' ), 27 );
            add_action( 'admin_post_nmep_save_subcategory',   array( __CLASS__, 'handle_admin_save_subcategory' ) );
            add_action( 'admin_post_nmep_delete_subcategory', array( __CLASS__, 'handle_admin_delete_subcategory' ) );
        }

        // Expert-facing admin-post handlers
        add_action( 'admin_post_nmep_save_portfolio',        array( __CLASS__, 'handle_save_portfolio' ) );
        add_action( 'admin_post_nmep_delete_portfolio',      array( __CLASS__, 'handle_delete_portfolio' ) );
        add_action( 'admin_post_nmep_save_language',         array( __CLASS__, 'handle_save_language' ) );
        add_action( 'admin_post_nmep_delete_language',       array( __CLASS__, 'handle_delete_language' ) );
        add_action( 'admin_post_nmep_save_certification',    array( __CLASS__, 'handle_save_certification' ) );
        add_action( 'admin_post_nmep_delete_certification',  array( __CLASS__, 'handle_delete_certification' ) );

        // Dashboard shortcode (can be dropped into expert dashboard)
        add_shortcode( 'nmep_expert_profile_editor', array( __CLASS__, 'render_profile_editor_shortcode' ) );

        // REST-style public read (used by profile page + Expo app)
        add_filter( 'nmep_public_expert_profile', array( __CLASS__, 'attach_profile_data' ), 10, 2 );
    }

    /* ============================================================
       SUBCATEGORIES
       ============================================================ */

    public static function list_subcategories( $category_id = 0, $active_only = true ) {
        global $wpdb;
        $sql = "SELECT * FROM " . NMEP_Database::table( 'subcategories' );
        $args = array();
        $where = array();
        if ( $category_id ) {
            $where[] = "category_id = %d";
            $args[]  = (int) $category_id;
        }
        if ( $active_only ) {
            $where[] = "is_active = 1";
        }
        if ( $where ) $sql .= ' WHERE ' . implode( ' AND ', $where );
        $sql .= ' ORDER BY sort_order ASC, name ASC';
        return $args
            ? $wpdb->get_results( $wpdb->prepare( $sql, $args ) )
            : $wpdb->get_results( $sql );
    }

    public static function register_admin_menu() {
        add_submenu_page(
            'nmep-dashboard',
            'Subcategories',
            'Subcategories',
            'manage_options',
            'nmep-subcategories',
            array( __CLASS__, 'render_subcategories_admin_page' )
        );
    }

    public static function render_subcategories_admin_page() {
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Permission denied.' );

        $subs = self::list_subcategories( 0, false );

        if ( isset( $_GET['saved'] ) )   echo '<div class="notice notice-success"><p>Subcategory saved.</p></div>';
        if ( isset( $_GET['deleted'] ) ) echo '<div class="notice notice-success"><p>Subcategory deleted.</p></div>';
        ?>
        <div class="wrap">
            <h1>Subcategories</h1>
            <p>Nest finer-grained service types inside the existing top-level categories.</p>

            <div style="background:#fff;padding:20px;border:1px solid #E5E7EB;border-radius:8px;">
                <h2 style="margin-top:0;">Add New</h2>
                <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                    <input type="hidden" name="action" value="nmep_save_subcategory">
                    <?php wp_nonce_field( 'nmep_save_subcategory' ); ?>
                    <table class="form-table">
                        <tr>
                            <th><label>Category ID</label></th>
                            <td><input type="number" name="category_id" required min="1" style="width:120px;"></td>
                        </tr>
                        <tr>
                            <th><label>Name</label></th>
                            <td><input type="text" name="name" required maxlength="120" style="width:320px;"></td>
                        </tr>
                        <tr>
                            <th><label>Slug (optional)</label></th>
                            <td><input type="text" name="slug" maxlength="120" style="width:320px;" placeholder="auto-generated from name"></td>
                        </tr>
                        <tr>
                            <th><label>Sort order</label></th>
                            <td><input type="number" name="sort_order" value="0" style="width:120px;"></td>
                        </tr>
                    </table>
                    <p><button type="submit" class="button button-primary">Create Subcategory</button></p>
                </form>
            </div>

            <h2 style="margin-top:32px;">All Subcategories (<?php echo count( $subs ); ?>)</h2>
            <table class="wp-list-table widefat fixed striped">
                <thead><tr>
                    <th>ID</th><th>Category</th><th>Name</th><th>Slug</th><th>Sort</th><th>Active</th><th>Actions</th>
                </tr></thead>
                <tbody>
                    <?php if ( empty( $subs ) ) : ?>
                        <tr><td colspan="7" style="text-align:center;padding:30px;">No subcategories yet.</td></tr>
                    <?php else : foreach ( $subs as $s ) : ?>
                    <tr>
                        <td><?php echo (int) $s->id; ?></td>
                        <td><?php echo (int) $s->category_id; ?></td>
                        <td><?php echo esc_html( $s->name ); ?></td>
                        <td><code><?php echo esc_html( $s->slug ); ?></code></td>
                        <td><?php echo (int) $s->sort_order; ?></td>
                        <td><?php echo $s->is_active ? 'Yes' : '<span style="color:#6B7280;">No</span>'; ?></td>
                        <td>
                            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline;" onsubmit="return confirm('Delete subcategory?');">
                                <input type="hidden" name="action" value="nmep_delete_subcategory">
                                <input type="hidden" name="id" value="<?php echo (int) $s->id; ?>">
                                <?php wp_nonce_field( 'nmep_delete_subcategory_' . $s->id ); ?>
                                <button type="submit" class="button button-small" style="color:#D63638;">Delete</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
        <?php
    }

    public static function handle_admin_save_subcategory() {
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Permission denied.' );
        check_admin_referer( 'nmep_save_subcategory' );

        $category_id = (int) ( $_POST['category_id'] ?? 0 );
        $name        = sanitize_text_field( $_POST['name'] ?? '' );
        $slug        = sanitize_title( $_POST['slug'] ?? $name );
        $sort        = (int) ( $_POST['sort_order'] ?? 0 );

        if ( ! $category_id || ! $name || ! $slug ) {
            wp_die( 'Missing required fields.' );
        }

        global $wpdb;
        $wpdb->insert( NMEP_Database::table( 'subcategories' ), array(
            'category_id' => $category_id,
            'slug'        => $slug,
            'name'        => substr( $name, 0, 120 ),
            'sort_order'  => $sort,
            'is_active'   => 1,
        ) );

        wp_safe_redirect( admin_url( 'admin.php?page=nmep-subcategories&saved=1' ) );
        exit;
    }

    public static function handle_admin_delete_subcategory() {
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Permission denied.' );
        $id = (int) ( $_POST['id'] ?? 0 );
        check_admin_referer( 'nmep_delete_subcategory_' . $id );

        global $wpdb;
        $wpdb->delete( NMEP_Database::table( 'subcategories' ), array( 'id' => $id ) );

        wp_safe_redirect( admin_url( 'admin.php?page=nmep-subcategories&deleted=1' ) );
        exit;
    }

    /* ============================================================
       PORTFOLIO
       ============================================================ */

    public static function list_portfolio( $expert_id, $public_only = false ) {
        global $wpdb;
        $sql = "SELECT * FROM " . NMEP_Database::table( 'portfolio' ) . " WHERE expert_id = %d";
        if ( $public_only ) $sql .= " AND is_public = 1";
        $sql .= " ORDER BY sort_order ASC, id DESC";
        return $wpdb->get_results( $wpdb->prepare( $sql, (int) $expert_id ) );
    }

    public static function handle_save_portfolio() {
        $expert = self::require_expert();
        check_admin_referer( 'nmep_save_portfolio' );

        $id    = (int) ( $_POST['id'] ?? 0 );
        $title = sanitize_text_field( $_POST['title'] ?? '' );
        if ( strlen( $title ) < 2 ) {
            self::redirect_dashboard_error( 'Portfolio title is required.' );
        }

        $data = array(
            'expert_id'    => (int) $expert->id,
            'title'        => substr( $title, 0, 200 ),
            'description'  => sanitize_textarea_field( $_POST['description'] ?? '' ),
            'image_url'    => esc_url_raw( $_POST['image_url'] ?? '' ),
            'external_url' => esc_url_raw( $_POST['external_url'] ?? '' ),
            'sort_order'   => (int) ( $_POST['sort_order'] ?? 0 ),
            'is_public'    => ! empty( $_POST['is_public'] ) ? 1 : 0,
        );

        global $wpdb;
        if ( $id ) {
            // Ownership check
            $owned = (int) $wpdb->get_var( $wpdb->prepare(
                "SELECT expert_id FROM " . NMEP_Database::table( 'portfolio' ) . " WHERE id = %d",
                $id
            ) );
            if ( $owned !== (int) $expert->id ) wp_die( 'Permission denied.' );
            $wpdb->update( NMEP_Database::table( 'portfolio' ), $data, array( 'id' => $id ) );
        } else {
            $wpdb->insert( NMEP_Database::table( 'portfolio' ), $data );
        }

        self::redirect_dashboard_success( 'Portfolio item saved.', '#portfolio' );
    }

    public static function handle_delete_portfolio() {
        $expert = self::require_expert();
        $id = (int) ( $_POST['id'] ?? 0 );
        check_admin_referer( 'nmep_delete_portfolio_' . $id );

        global $wpdb;
        $wpdb->delete(
            NMEP_Database::table( 'portfolio' ),
            array( 'id' => $id, 'expert_id' => (int) $expert->id )
        );

        self::redirect_dashboard_success( 'Portfolio item deleted.', '#portfolio' );
    }

    /* ============================================================
       LANGUAGES
       ============================================================ */

    public static function list_languages( $expert_id ) {
        global $wpdb;
        return $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM " . NMEP_Database::table( 'expert_languages' ) . "
             WHERE expert_id = %d ORDER BY language ASC",
            (int) $expert_id
        ) );
    }

    public static function handle_save_language() {
        $expert = self::require_expert();
        check_admin_referer( 'nmep_save_language' );

        $language    = substr( sanitize_text_field( $_POST['language'] ?? '' ), 0, 60 );
        $proficiency = sanitize_key( $_POST['proficiency'] ?? 'conversational' );
        if ( ! in_array( $proficiency, self::LANG_PROFICIENCIES, true ) ) {
            $proficiency = 'conversational';
        }
        if ( $language === '' ) {
            self::redirect_dashboard_error( 'Language is required.' );
        }

        global $wpdb;
        $table = NMEP_Database::table( 'expert_languages' );

        // Unique key is (expert_id, language) — upsert
        $wpdb->query( $wpdb->prepare(
            "INSERT INTO $table (expert_id, language, proficiency) VALUES (%d, %s, %s)
             ON DUPLICATE KEY UPDATE proficiency = VALUES(proficiency)",
            (int) $expert->id, $language, $proficiency
        ) );

        self::redirect_dashboard_success( 'Language saved.', '#languages' );
    }

    public static function handle_delete_language() {
        $expert = self::require_expert();
        $id = (int) ( $_POST['id'] ?? 0 );
        check_admin_referer( 'nmep_delete_language_' . $id );

        global $wpdb;
        $wpdb->delete(
            NMEP_Database::table( 'expert_languages' ),
            array( 'id' => $id, 'expert_id' => (int) $expert->id )
        );

        self::redirect_dashboard_success( 'Language removed.', '#languages' );
    }

    /* ============================================================
       CERTIFICATIONS
       ============================================================ */

    public static function list_certifications( $expert_id ) {
        global $wpdb;
        return $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM " . NMEP_Database::table( 'expert_certifications' ) . "
             WHERE expert_id = %d ORDER BY sort_order ASC, issued_year DESC",
            (int) $expert_id
        ) );
    }

    public static function handle_save_certification() {
        $expert = self::require_expert();
        check_admin_referer( 'nmep_save_certification' );

        $id     = (int) ( $_POST['id'] ?? 0 );
        $title  = substr( sanitize_text_field( $_POST['title'] ?? '' ), 0, 200 );
        $issuer = substr( sanitize_text_field( $_POST['issuer'] ?? '' ), 0, 200 );
        $year   = (int) ( $_POST['issued_year'] ?? 0 );
        $url    = esc_url_raw( $_POST['credential_url'] ?? '' );
        $sort   = (int) ( $_POST['sort_order'] ?? 0 );

        if ( $title === '' ) {
            self::redirect_dashboard_error( 'Certification title is required.' );
        }
        if ( $year && ( $year < 1950 || $year > (int) date( 'Y' ) + 1 ) ) {
            self::redirect_dashboard_error( 'Invalid certification year.' );
        }

        $data = array(
            'expert_id'      => (int) $expert->id,
            'title'          => $title,
            'issuer'         => $issuer ?: null,
            'issued_year'    => $year ?: null,
            'credential_url' => $url  ?: null,
            'sort_order'     => $sort,
        );

        global $wpdb;
        if ( $id ) {
            $owned = (int) $wpdb->get_var( $wpdb->prepare(
                "SELECT expert_id FROM " . NMEP_Database::table( 'expert_certifications' ) . " WHERE id = %d",
                $id
            ) );
            if ( $owned !== (int) $expert->id ) wp_die( 'Permission denied.' );
            $wpdb->update( NMEP_Database::table( 'expert_certifications' ), $data, array( 'id' => $id ) );
        } else {
            $wpdb->insert( NMEP_Database::table( 'expert_certifications' ), $data );
        }

        self::redirect_dashboard_success( 'Certification saved.', '#certifications' );
    }

    public static function handle_delete_certification() {
        $expert = self::require_expert();
        $id = (int) ( $_POST['id'] ?? 0 );
        check_admin_referer( 'nmep_delete_certification_' . $id );

        global $wpdb;
        $wpdb->delete(
            NMEP_Database::table( 'expert_certifications' ),
            array( 'id' => $id, 'expert_id' => (int) $expert->id )
        );

        self::redirect_dashboard_success( 'Certification removed.', '#certifications' );
    }

    /* ============================================================
       DASHBOARD SHORTCODE
       ============================================================ */

    public static function render_profile_editor_shortcode( $atts ) {
        if ( ! is_user_logged_in() ) {
            return '<div class="nme-card"><p>Please log in to edit your profile.</p></div>';
        }
        $expert = NMEP_Compat::get_expert_by_user( get_current_user_id() );
        if ( ! $expert ) {
            return '<div class="nme-card"><p>Expert profile not found.</p></div>';
        }

        $portfolio     = self::list_portfolio( (int) $expert->id );
        $languages     = self::list_languages( (int) $expert->id );
        $certifications = self::list_certifications( (int) $expert->id );
        $metrics       = class_exists( 'NMEP_Metrics' ) ? NMEP_Metrics::get( (int) $expert->id ) : null;
        $action_url    = esc_url( admin_url( 'admin-post.php' ) );

        ob_start();
        ?>
        <div class="nme-card" id="availability">
            <h2 style="margin-top:0;">Availability</h2>
            <?php if ( $metrics ) : ?>
                <p>Current status: <strong><?php echo esc_html( ucfirst( $metrics->availability_mode ) ); ?></strong>
                    <?php if ( ! empty( $metrics->away_message ) ) : ?>
                        — <em><?php echo esc_html( $metrics->away_message ); ?></em>
                    <?php endif; ?>
                </p>
            <?php endif; ?>
            <p>
                <button type="button" class="nme-btn nme-btn-gold" data-nmep-mode="online">Go Online</button>
                <button type="button" class="nme-btn" data-nmep-mode="away">Set Away</button>
                <button type="button" class="nme-btn" data-nmep-mode="offline">Go Offline</button>
            </p>
            <p>
                <input type="text" id="nmep_away_message" maxlength="200" placeholder="Optional away message" style="width:100%;max-width:480px;padding:8px;border:1px solid #E5E7EB;border-radius:6px;">
            </p>
            <script>
            (function(){
                document.querySelectorAll('[data-nmep-mode]').forEach(function(btn){
                    btn.addEventListener('click', function(){
                        var mode = btn.getAttribute('data-nmep-mode');
                        var msg  = document.getElementById('nmep_away_message').value || '';
                        var data = new FormData();
                        data.append('action', 'nmep_metrics_set_mode');
                        data.append('nonce', '<?php echo esc_js( wp_create_nonce( 'nmep_ajax' ) ); ?>');
                        data.append('mode', mode);
                        data.append('away_message', msg);
                        fetch('<?php echo esc_js( admin_url( 'admin-ajax.php' ) ); ?>', { method:'POST', body:data, credentials:'same-origin' })
                            .then(function(r){ return r.json(); })
                            .then(function(){ window.location.reload(); });
                    });
                });
            })();
            </script>
        </div>

        <div class="nme-card nme-mt-3" id="portfolio">
            <h2 style="margin-top:0;">Portfolio</h2>
            <form method="post" action="<?php echo $action_url; ?>" style="margin-bottom:20px;">
                <input type="hidden" name="action" value="nmep_save_portfolio">
                <?php wp_nonce_field( 'nmep_save_portfolio' ); ?>
                <p><input type="text" name="title" required maxlength="200" placeholder="Title" style="width:100%;padding:8px;"></p>
                <p><textarea name="description" rows="2" placeholder="Short description" style="width:100%;padding:8px;"></textarea></p>
                <p><input type="url" name="image_url" placeholder="Image URL (optional)" style="width:100%;padding:8px;"></p>
                <p><input type="url" name="external_url" placeholder="External case-study link (optional)" style="width:100%;padding:8px;"></p>
                <p><label><input type="checkbox" name="is_public" value="1" checked> Show on my public profile</label></p>
                <p><button class="nme-btn nme-btn-gold" type="submit">Add portfolio item</button></p>
            </form>

            <?php if ( empty( $portfolio ) ) : ?>
                <p>No portfolio items yet.</p>
            <?php else : ?>
                <ul style="list-style:none;padding:0;">
                <?php foreach ( $portfolio as $p ) : ?>
                    <li style="padding:12px;border:1px solid #E5E7EB;border-radius:8px;margin-bottom:10px;">
                        <strong><?php echo esc_html( $p->title ); ?></strong>
                        <?php if ( ! empty( $p->description ) ) : ?>
                            <div style="color:#6B7280;font-size:0.9rem;"><?php echo esc_html( $p->description ); ?></div>
                        <?php endif; ?>
                        <form method="post" action="<?php echo $action_url; ?>" style="display:inline;" onsubmit="return confirm('Delete this portfolio item?');">
                            <input type="hidden" name="action" value="nmep_delete_portfolio">
                            <input type="hidden" name="id" value="<?php echo (int) $p->id; ?>">
                            <?php wp_nonce_field( 'nmep_delete_portfolio_' . $p->id ); ?>
                            <button class="nme-btn" type="submit" style="padding:2px 8px;font-size:0.8rem;color:#D63638;">Remove</button>
                        </form>
                    </li>
                <?php endforeach; ?>
                </ul>
            <?php endif; ?>
        </div>

        <div class="nme-card nme-mt-3" id="languages">
            <h2 style="margin-top:0;">Languages</h2>
            <form method="post" action="<?php echo $action_url; ?>" style="margin-bottom:20px;display:flex;gap:8px;flex-wrap:wrap;">
                <input type="hidden" name="action" value="nmep_save_language">
                <?php wp_nonce_field( 'nmep_save_language' ); ?>
                <input type="text" name="language" required maxlength="60" placeholder="Language" style="padding:8px;">
                <select name="proficiency" style="padding:8px;">
                    <?php foreach ( self::LANG_PROFICIENCIES as $lvl ) : ?>
                        <option value="<?php echo esc_attr( $lvl ); ?>"><?php echo esc_html( ucfirst( $lvl ) ); ?></option>
                    <?php endforeach; ?>
                </select>
                <button class="nme-btn nme-btn-gold" type="submit">Add / update</button>
            </form>

            <?php if ( empty( $languages ) ) : ?>
                <p>No languages added yet.</p>
            <?php else : ?>
                <ul style="list-style:none;padding:0;">
                <?php foreach ( $languages as $l ) : ?>
                    <li style="display:flex;justify-content:space-between;align-items:center;padding:6px 0;border-bottom:1px solid #F3F4F6;">
                        <span><strong><?php echo esc_html( $l->language ); ?></strong> — <?php echo esc_html( ucfirst( $l->proficiency ) ); ?></span>
                        <form method="post" action="<?php echo $action_url; ?>" style="display:inline;">
                            <input type="hidden" name="action" value="nmep_delete_language">
                            <input type="hidden" name="id" value="<?php echo (int) $l->id; ?>">
                            <?php wp_nonce_field( 'nmep_delete_language_' . $l->id ); ?>
                            <button class="nme-btn" type="submit" style="padding:2px 8px;font-size:0.8rem;color:#D63638;">Remove</button>
                        </form>
                    </li>
                <?php endforeach; ?>
                </ul>
            <?php endif; ?>
        </div>

        <div class="nme-card nme-mt-3" id="certifications">
            <h2 style="margin-top:0;">Certifications</h2>
            <form method="post" action="<?php echo $action_url; ?>" style="margin-bottom:20px;">
                <input type="hidden" name="action" value="nmep_save_certification">
                <?php wp_nonce_field( 'nmep_save_certification' ); ?>
                <p><input type="text" name="title" required maxlength="200" placeholder="Certification title" style="width:100%;padding:8px;"></p>
                <p><input type="text" name="issuer" maxlength="200" placeholder="Issuer (optional)" style="width:100%;padding:8px;"></p>
                <p><input type="number" name="issued_year" min="1950" max="<?php echo (int) date( 'Y' ) + 1; ?>" placeholder="Year (optional)" style="width:180px;padding:8px;"></p>
                <p><input type="url" name="credential_url" placeholder="Credential URL (optional)" style="width:100%;padding:8px;"></p>
                <p><button class="nme-btn nme-btn-gold" type="submit">Add certification</button></p>
            </form>

            <?php if ( empty( $certifications ) ) : ?>
                <p>No certifications added yet.</p>
            <?php else : ?>
                <ul style="list-style:none;padding:0;">
                <?php foreach ( $certifications as $c ) : ?>
                    <li style="padding:10px 0;border-bottom:1px solid #F3F4F6;">
                        <strong><?php echo esc_html( $c->title ); ?></strong>
                        <?php if ( ! empty( $c->issuer ) ) echo ' — ' . esc_html( $c->issuer ); ?>
                        <?php if ( ! empty( $c->issued_year ) ) echo ' (' . (int) $c->issued_year . ')'; ?>
                        <form method="post" action="<?php echo $action_url; ?>" style="display:inline;float:right;">
                            <input type="hidden" name="action" value="nmep_delete_certification">
                            <input type="hidden" name="id" value="<?php echo (int) $c->id; ?>">
                            <?php wp_nonce_field( 'nmep_delete_certification_' . $c->id ); ?>
                            <button class="nme-btn" type="submit" style="padding:2px 8px;font-size:0.8rem;color:#D63638;">Remove</button>
                        </form>
                    </li>
                <?php endforeach; ?>
                </ul>
            <?php endif; ?>
        </div>
        <?php
        return ob_get_clean();
    }

    /* ============================================================
       PUBLIC PROFILE DATA
       ============================================================ */

    /**
     * Filter `nmep_public_expert_profile`: attach rich profile data for
     * the public expert profile view and REST responses.
     *
     * Expected usage:
     *   $profile = apply_filters( 'nmep_public_expert_profile', $base_profile, $expert );
     */
    public static function attach_profile_data( $profile, $expert ) {
        if ( ! $expert || empty( $expert->id ) ) return $profile;
        $profile = is_array( $profile ) ? $profile : array();

        $profile['portfolio']      = self::list_portfolio( (int) $expert->id, true );
        $profile['languages']      = self::list_languages( (int) $expert->id );
        $profile['certifications'] = self::list_certifications( (int) $expert->id );

        if ( class_exists( 'NMEP_Metrics' ) ) {
            $metrics = NMEP_Metrics::get( (int) $expert->id );
            $profile['availability'] = array(
                'mode'         => $metrics->availability_mode ?? 'offline',
                'away_message' => $metrics->away_message      ?? null,
                'is_online'    => NMEP_Metrics::is_online( (int) $expert->id ),
                'last_seen_at' => $metrics->last_seen_at      ?? null,
            );
        }

        return $profile;
    }

    /* ============================================================
       HELPERS
       ============================================================ */

    private static function require_expert() {
        if ( ! is_user_logged_in() ) wp_die( 'Please log in.' );
        $expert = NMEP_Compat::get_expert_by_user( get_current_user_id() );
        if ( ! $expert ) wp_die( 'Expert profile not found.' );
        return $expert;
    }

    private static function redirect_dashboard_success( $msg, $fragment = '' ) {
        $url = add_query_arg(
            array( 'nmep_status' => 'success', 'nmep_msg' => urlencode( $msg ) ),
            nmep_get_page_url( 'expert-dashboard' )
        );
        wp_safe_redirect( $url . $fragment );
        exit;
    }

    private static function redirect_dashboard_error( $msg ) {
        $url = add_query_arg(
            array( 'nmep_status' => 'error', 'nmep_msg' => urlencode( $msg ) ),
            nmep_get_page_url( 'expert-dashboard' )
        );
        wp_safe_redirect( $url );
        exit;
    }
}
