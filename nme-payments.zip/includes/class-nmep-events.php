<?php
/**
 * NMEP_Events
 *
 * Single source of truth for every lifecycle event the marketplace emits.
 * Other modules (badges, CRM, analytics, SMS, WhatsApp, webhooks) subscribe
 * via add_action() on the constants below.
 *
 * Rule: NEVER call do_action( 'nmep_order_xxx', ... ) directly outside this
 * class. Go through NMEP_Events::emit() so behaviour stays observable and
 * loggable in one place.
 *
 * @package NagalandMeExpertsPayments
 * @since   2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class NMEP_Events {

    /* ============================================================
       ORDER LIFECYCLE EVENTS
       ============================================================ */
    const ORDER_CREATED       = 'nmep_order_created';
    const ORDER_PAID          = 'nmep_order_paid';
    const ORDER_ACCEPTED      = 'nmep_order_accepted';       // auto-accepted on payment
    const ORDER_IN_PROGRESS   = 'nmep_order_in_progress';
    const ORDER_DELIVERED     = 'nmep_order_delivered';
    const ORDER_IN_REVISION   = 'nmep_order_in_revision';
    const ORDER_COMPLETED     = 'nmep_order_completed';      // buyer approved
    const ORDER_AUTO_RELEASED = 'nmep_order_auto_released';  // escrow auto-released by cron
    const ORDER_CANCELLED     = 'nmep_order_cancelled';
    const ORDER_DISPUTED      = 'nmep_order_disputed';
    const ORDER_REFUNDED      = 'nmep_order_refunded';
    const ORDER_REOPENED      = 'nmep_order_reopened';

    /* ============================================================
       PAYMENT / PAYOUT EVENTS
       ============================================================ */
    const PAYMENT_FAILED    = 'nmep_payment_failed';
    const PAYMENT_RETRY     = 'nmep_payment_retry';
    const PAYOUT_SCHEDULED  = 'nmep_payout_scheduled';
    const PAYOUT_COMPLETED  = 'nmep_payout_completed';
    const PAYOUT_FAILED     = 'nmep_payout_failed';
    const REFUND_PROCESSED  = 'nmep_refund_processed';

    /* ============================================================
       DISPUTE EVENTS
       ============================================================ */
    const DISPUTE_OPENED       = 'nmep_dispute_opened';
    const DISPUTE_RESPONDED    = 'nmep_dispute_responded';
    const DISPUTE_ESCALATED    = 'nmep_dispute_escalated';
    const DISPUTE_RESOLVED     = 'nmep_dispute_resolved';

    /* ============================================================
       EXPERT / SERVICE EVENTS
       ============================================================ */
    const EXPERT_TIER_CHANGED   = 'nmep_expert_tier_changed';
    const EXPERT_WENT_ONLINE    = 'nmep_expert_went_online';
    const EXPERT_WENT_OFFLINE   = 'nmep_expert_went_offline';
    const SERVICE_ACTIVATED     = 'nmep_service_activated';
    const SERVICE_PAUSED        = 'nmep_service_paused';

    /* ============================================================
       MESSAGING / REVIEW EVENTS
       ============================================================ */
    const MESSAGE_SENT         = 'nmep_message_sent';
    const REVIEW_SUBMITTED     = 'nmep_review_submitted';
    const REVIEW_RESPONDED     = 'nmep_review_responded';
    const REVIEW_REPORTED      = 'nmep_review_reported';

    /**
     * Emit an event. Wraps do_action() and records to the audit log.
     *
     * @param string $event   One of the constants above.
     * @param mixed  ...$args Event payload — first arg is typically order_id / expert_id.
     */
    public static function emit( $event, ...$args ) {
        // Log to structured log for observability
        if ( class_exists( 'NMEP_Logger' ) ) {
            NMEP_Logger::info( 'Event: ' . $event, array( 'args' => self::summarize_args( $args ) ) );
        }

        do_action( $event, ...$args );
        do_action( 'nmep_event', $event, $args );
    }

    /**
     * All event constants as a flat list — used by admin tooling + tests.
     *
     * @return string[]
     */
    public static function all() {
        return array(
            self::ORDER_CREATED, self::ORDER_PAID, self::ORDER_ACCEPTED,
            self::ORDER_IN_PROGRESS, self::ORDER_DELIVERED, self::ORDER_IN_REVISION,
            self::ORDER_COMPLETED, self::ORDER_AUTO_RELEASED, self::ORDER_CANCELLED,
            self::ORDER_DISPUTED, self::ORDER_REFUNDED, self::ORDER_REOPENED,
            self::PAYMENT_FAILED, self::PAYMENT_RETRY,
            self::PAYOUT_SCHEDULED, self::PAYOUT_COMPLETED, self::PAYOUT_FAILED,
            self::REFUND_PROCESSED,
            self::DISPUTE_OPENED, self::DISPUTE_RESPONDED,
            self::DISPUTE_ESCALATED, self::DISPUTE_RESOLVED,
            self::EXPERT_TIER_CHANGED, self::EXPERT_WENT_ONLINE, self::EXPERT_WENT_OFFLINE,
            self::SERVICE_ACTIVATED, self::SERVICE_PAUSED,
            self::MESSAGE_SENT, self::REVIEW_SUBMITTED,
            self::REVIEW_RESPONDED, self::REVIEW_REPORTED,
        );
    }

    /**
     * Compact args for logging (avoid dumping full order objects).
     */
    private static function summarize_args( array $args ) {
        $out = array();
        foreach ( $args as $i => $a ) {
            if ( is_scalar( $a ) ) {
                $out[ $i ] = $a;
            } elseif ( is_object( $a ) && isset( $a->id ) ) {
                $out[ $i ] = get_class( $a ) . '#' . $a->id;
            } elseif ( is_array( $a ) ) {
                $out[ $i ] = 'array(' . count( $a ) . ')';
            } else {
                $out[ $i ] = gettype( $a );
            }
        }
        return $out;
    }
}
