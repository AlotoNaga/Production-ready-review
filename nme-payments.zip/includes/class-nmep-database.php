<?php
/**
 * NMEP_Database
 * Manages all database tables for the payments plugin.
 * 8 tables: services, orders, transfers, refunds, disputes, linked_accounts, webhook_events, payouts
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class NMEP_Database {

    /**
     * Get prefixed table name
     */
    public static function table( $name ) {
        global $wpdb;
        return $wpdb->prefix . 'nmep_' . $name;
    }

    /**
     * Create all plugin tables
     */
    public static function create_tables() {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        // === SERVICES TABLE (gigs created by experts) ===
        $sql_services = "CREATE TABLE " . self::table( 'services' ) . " (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            expert_id BIGINT(20) UNSIGNED NOT NULL,
            category_id BIGINT(20) UNSIGNED NOT NULL,
            slug VARCHAR(160) NOT NULL,
            title VARCHAR(200) NOT NULL,
            short_description VARCHAR(300) DEFAULT NULL,
            short_pitch VARCHAR(160) DEFAULT NULL,
            description LONGTEXT DEFAULT NULL,
            cover_image VARCHAR(500) DEFAULT NULL,
            gallery_images TEXT DEFAULT NULL,
            video_url VARCHAR(500) DEFAULT NULL,

            basic_title VARCHAR(80) DEFAULT 'Basic',
            basic_price DECIMAL(10,2) DEFAULT NULL,
            basic_delivery_days INT(11) DEFAULT 3,
            basic_revisions INT(11) DEFAULT 1,
            basic_features TEXT DEFAULT NULL,

            standard_title VARCHAR(80) DEFAULT 'Standard',
            standard_price DECIMAL(10,2) DEFAULT NULL,
            standard_delivery_days INT(11) DEFAULT 5,
            standard_revisions INT(11) DEFAULT 2,
            standard_features TEXT DEFAULT NULL,

            premium_title VARCHAR(80) DEFAULT 'Premium',
            premium_price DECIMAL(10,2) DEFAULT NULL,
            premium_delivery_days INT(11) DEFAULT 7,
            premium_revisions INT(11) DEFAULT 3,
            premium_features TEXT DEFAULT NULL,

            requirements TEXT DEFAULT NULL,
            faqs LONGTEXT DEFAULT NULL,
            tags VARCHAR(500) DEFAULT NULL,

            views INT(11) DEFAULT 0,
            orders_count INT(11) DEFAULT 0,
            avg_rating DECIMAL(3,2) DEFAULT 0.00,
            reviews_count INT(11) DEFAULT 0,

            status VARCHAR(20) DEFAULT 'draft',
            rejection_reason TEXT DEFAULT NULL,
            approved_at DATETIME DEFAULT NULL,
            approved_by BIGINT(20) UNSIGNED DEFAULT NULL,

            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            UNIQUE KEY slug (slug),
            KEY expert_id (expert_id),
            KEY category_id (category_id),
            KEY status (status)
        ) $charset_collate;";

        // === LINKED ACCOUNTS TABLE (Razorpay Route accounts for experts) ===
        $sql_linked_accounts = "CREATE TABLE " . self::table( 'linked_accounts' ) . " (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            expert_id BIGINT(20) UNSIGNED NOT NULL,
            user_id BIGINT(20) UNSIGNED NOT NULL,

            mode VARCHAR(10) NOT NULL DEFAULT 'test',
            razorpay_account_id VARCHAR(50) DEFAULT NULL,
            razorpay_stakeholder_id VARCHAR(50) DEFAULT NULL,
            razorpay_product_config_id VARCHAR(50) DEFAULT NULL,

            account_email VARCHAR(190) NOT NULL,
            account_phone VARCHAR(20) DEFAULT NULL,
            account_holder_name VARCHAR(120) NOT NULL,
            business_type VARCHAR(40) DEFAULT 'individual',
            business_category VARCHAR(40) DEFAULT 'others',
            business_subcategory VARCHAR(60) DEFAULT 'professional_services',

            bank_account_number VARCHAR(40) DEFAULT NULL,
            bank_ifsc VARCHAR(20) DEFAULT NULL,
            beneficiary_name VARCHAR(120) DEFAULT NULL,

            address_street1 VARCHAR(200) DEFAULT NULL,
            address_street2 VARCHAR(200) DEFAULT NULL,
            address_city VARCHAR(80) DEFAULT NULL,
            address_state VARCHAR(80) DEFAULT NULL,
            address_postal_code VARCHAR(20) DEFAULT NULL,
            address_country VARCHAR(10) DEFAULT 'IN',

            pan_number VARCHAR(15) DEFAULT NULL,
            gst_number VARCHAR(20) DEFAULT NULL,

            status VARCHAR(30) DEFAULT 'pending',
            verification_status VARCHAR(30) DEFAULT 'pending',
            activation_status VARCHAR(30) DEFAULT 'pending',
            failure_reason TEXT DEFAULT NULL,

            api_response LONGTEXT DEFAULT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            UNIQUE KEY expert_mode (expert_id, mode),
            KEY user_id (user_id),
            KEY razorpay_account_id (razorpay_account_id),
            KEY status (status)
        ) $charset_collate;";

        // === ORDERS TABLE (the central marketplace orders) ===
        $sql_orders = "CREATE TABLE " . self::table( 'orders' ) . " (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            order_number VARCHAR(40) NOT NULL,

            buyer_user_id BIGINT(20) UNSIGNED DEFAULT NULL,
            buyer_name VARCHAR(120) NOT NULL,
            buyer_email VARCHAR(190) NOT NULL,
            buyer_phone VARCHAR(20) DEFAULT NULL,

            expert_id BIGINT(20) UNSIGNED NOT NULL,
            service_id BIGINT(20) UNSIGNED NOT NULL,
            package_tier VARCHAR(20) NOT NULL,

            service_title VARCHAR(200) NOT NULL,
            package_title VARCHAR(80) NOT NULL,
            delivery_days INT(11) NOT NULL DEFAULT 3,
            revisions_allowed INT(11) NOT NULL DEFAULT 1,

            gross_amount DECIMAL(10,2) NOT NULL DEFAULT 0.00,
            commission_rate DECIMAL(5,2) NOT NULL DEFAULT 15.00,
            commission_amount DECIMAL(10,2) NOT NULL DEFAULT 0.00,
            expert_amount DECIMAL(10,2) NOT NULL DEFAULT 0.00,
            currency VARCHAR(10) NOT NULL DEFAULT 'INR',

            buyer_requirements LONGTEXT DEFAULT NULL,
            view_token VARCHAR(64) DEFAULT NULL,

            mode VARCHAR(10) NOT NULL DEFAULT 'test',
            razorpay_order_id VARCHAR(50) DEFAULT NULL,
            razorpay_payment_id VARCHAR(50) DEFAULT NULL,
            razorpay_signature VARCHAR(255) DEFAULT NULL,
            razorpay_transfer_id VARCHAR(50) DEFAULT NULL,

            status VARCHAR(30) NOT NULL DEFAULT 'initiated',
            payment_status VARCHAR(30) NOT NULL DEFAULT 'pending',
            escrow_status VARCHAR(30) NOT NULL DEFAULT 'pending',
            delivery_status VARCHAR(30) NOT NULL DEFAULT 'pending',

            paid_at DATETIME DEFAULT NULL,
            delivery_due_at DATETIME DEFAULT NULL,
            delivered_at DATETIME DEFAULT NULL,
            approved_at DATETIME DEFAULT NULL,
            auto_release_at DATETIME DEFAULT NULL,
            released_at DATETIME DEFAULT NULL,
            cancelled_at DATETIME DEFAULT NULL,
            disputed_at DATETIME DEFAULT NULL,

            revisions_used INT(11) DEFAULT 0,
            api_response LONGTEXT DEFAULT NULL,

            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            UNIQUE KEY order_number (order_number),
            KEY buyer_email (buyer_email),
            KEY buyer_user_id (buyer_user_id),
            KEY expert_id (expert_id),
            KEY service_id (service_id),
            KEY status (status),
            KEY payment_status (payment_status),
            KEY auto_release_at (auto_release_at),
            KEY razorpay_order_id (razorpay_order_id),
            KEY razorpay_payment_id (razorpay_payment_id)
        ) $charset_collate;";

        // === TRANSFERS TABLE (Razorpay transfer records) ===
        $sql_transfers = "CREATE TABLE " . self::table( 'transfers' ) . " (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            order_id BIGINT(20) UNSIGNED NOT NULL,
            linked_account_id BIGINT(20) UNSIGNED NOT NULL,

            mode VARCHAR(10) NOT NULL DEFAULT 'test',
            razorpay_transfer_id VARCHAR(50) DEFAULT NULL,
            razorpay_recipient VARCHAR(50) DEFAULT NULL,

            amount DECIMAL(10,2) NOT NULL DEFAULT 0.00,
            currency VARCHAR(10) NOT NULL DEFAULT 'INR',
            status VARCHAR(30) NOT NULL DEFAULT 'pending',
            on_hold TINYINT(1) DEFAULT 1,
            on_hold_until DATETIME DEFAULT NULL,
            settled_at DATETIME DEFAULT NULL,
            failure_reason TEXT DEFAULT NULL,
            api_response LONGTEXT DEFAULT NULL,

            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY order_id (order_id),
            KEY linked_account_id (linked_account_id),
            KEY razorpay_transfer_id (razorpay_transfer_id),
            KEY status (status)
        ) $charset_collate;";

        // === REFUNDS TABLE ===
        $sql_refunds = "CREATE TABLE " . self::table( 'refunds' ) . " (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            order_id BIGINT(20) UNSIGNED NOT NULL,

            mode VARCHAR(10) NOT NULL DEFAULT 'test',
            razorpay_refund_id VARCHAR(50) DEFAULT NULL,
            razorpay_reversal_id VARCHAR(50) DEFAULT NULL,

            refund_amount DECIMAL(10,2) NOT NULL DEFAULT 0.00,
            refund_type VARCHAR(20) NOT NULL DEFAULT 'full',
            reason VARCHAR(500) DEFAULT NULL,
            initiated_by BIGINT(20) UNSIGNED DEFAULT NULL,
            initiated_role VARCHAR(20) DEFAULT NULL,
            status VARCHAR(30) NOT NULL DEFAULT 'pending',
            processed_at DATETIME DEFAULT NULL,
            failure_reason TEXT DEFAULT NULL,
            api_response LONGTEXT DEFAULT NULL,

            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY order_id (order_id),
            KEY razorpay_refund_id (razorpay_refund_id),
            KEY status (status)
        ) $charset_collate;";

        // === DISPUTES TABLE ===
        $sql_disputes = "CREATE TABLE " . self::table( 'disputes' ) . " (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            order_id BIGINT(20) UNSIGNED NOT NULL,

            opened_by BIGINT(20) UNSIGNED DEFAULT NULL,
            opened_role VARCHAR(20) NOT NULL,
            reason VARCHAR(100) NOT NULL,
            description LONGTEXT NOT NULL,
            evidence_urls TEXT DEFAULT NULL,

            status VARCHAR(30) NOT NULL DEFAULT 'open',
            resolution VARCHAR(40) DEFAULT NULL,
            resolution_notes LONGTEXT DEFAULT NULL,
            resolved_by BIGINT(20) UNSIGNED DEFAULT NULL,
            resolved_at DATETIME DEFAULT NULL,

            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY order_id (order_id),
            KEY status (status)
        ) $charset_collate;";

        // === ORDER MESSAGES TABLE (buyer-expert chat) ===
        $sql_messages = "CREATE TABLE " . self::table( 'order_messages' ) . " (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            order_id BIGINT(20) UNSIGNED NOT NULL,
            sender_user_id BIGINT(20) UNSIGNED DEFAULT NULL,
            sender_role VARCHAR(20) NOT NULL,
            sender_name VARCHAR(120) NOT NULL,
            message LONGTEXT NOT NULL,
            attachment_urls TEXT DEFAULT NULL,
            is_delivery TINYINT(1) DEFAULT 0,
            is_revision_request TINYINT(1) DEFAULT 0,
            is_read TINYINT(1) DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY order_id (order_id),
            KEY created_at (created_at)
        ) $charset_collate;";

        // === WEBHOOK EVENTS TABLE (idempotency tracking) ===
        $sql_webhooks = "CREATE TABLE " . self::table( 'webhook_events' ) . " (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            event_id VARCHAR(80) NOT NULL,
            event_type VARCHAR(80) NOT NULL,
            mode VARCHAR(10) NOT NULL DEFAULT 'test',
            payload LONGTEXT DEFAULT NULL,
            processing_status VARCHAR(20) DEFAULT 'pending',
            processed_at DATETIME DEFAULT NULL,
            error_message TEXT DEFAULT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            UNIQUE KEY event_id (event_id),
            KEY event_type (event_type),
            KEY processing_status (processing_status)
        ) $charset_collate;";

        // === REVIEWS TABLE (Batch E) ===
        $sql_reviews = "CREATE TABLE " . self::table( 'reviews' ) . " (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            order_id BIGINT(20) UNSIGNED NOT NULL,
            service_id BIGINT(20) UNSIGNED NOT NULL,
            expert_id BIGINT(20) UNSIGNED NOT NULL,
            buyer_user_id BIGINT(20) UNSIGNED DEFAULT NULL,
            buyer_name VARCHAR(120) NOT NULL,
            buyer_email VARCHAR(190) NOT NULL,
            rating TINYINT(1) NOT NULL DEFAULT 5,
            comment LONGTEXT NOT NULL,
            would_recommend TINYINT(1) DEFAULT 1,
            expert_response LONGTEXT DEFAULT NULL,
            expert_responded_at DATETIME DEFAULT NULL,
            status VARCHAR(20) DEFAULT 'published',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            UNIQUE KEY order_id (order_id),
            KEY service_id (service_id),
            KEY expert_id (expert_id),
            KEY rating (rating),
            KEY status (status)
        ) $charset_collate;";

        dbDelta( $sql_services );
        dbDelta( $sql_linked_accounts );
        dbDelta( $sql_orders );
        dbDelta( $sql_transfers );
        dbDelta( $sql_refunds );
        dbDelta( $sql_disputes );
        dbDelta( $sql_messages );
        dbDelta( $sql_webhooks );
        dbDelta( $sql_reviews );

        // === v1.5.4 explicit migration: make basic_price nullable + add short_pitch ===
        // dbDelta cannot reliably change NOT NULL → NULL, so we do it manually
        $services_table = self::table( 'services' );
        $current_version = get_option( 'nmep_db_version', '0.0.0' );
        if ( version_compare( $current_version, '1.5.4', '<' ) ) {
            // Add short_pitch column if missing
            $col_exists = $wpdb->get_var( "SHOW COLUMNS FROM $services_table LIKE 'short_pitch'" );
            if ( ! $col_exists ) {
                $wpdb->query( "ALTER TABLE $services_table ADD COLUMN short_pitch VARCHAR(160) DEFAULT NULL AFTER short_description" );
            }
            // Make basic_price nullable (so single-tier services work)
            $wpdb->query( "ALTER TABLE $services_table MODIFY COLUMN basic_price DECIMAL(10,2) DEFAULT NULL" );
            NMEP_Logger::info( 'v1.5.4 migration applied: short_pitch added, basic_price nullable' );
        }

        NMEP_Logger::info( 'Database tables created/updated', array( 'version' => NMEP_DB_VERSION ) );
    }

    /**
     * Generate unique order number
     */
    public static function generate_order_number() {
        return 'NMEX' . date( 'ymd' ) . wp_rand( 1000, 9999 );
    }

    /**
     * Generate view token for guest order tracking
     */
    public static function generate_view_token() {
        try {
            return bin2hex( random_bytes( 16 ) );
        } catch ( Exception $e ) {
            return wp_hash( wp_rand() . microtime( true ) );
        }
    }

    /**
     * Generate service slug
     */
    public static function generate_service_slug( $title, $expert_id ) {
        global $wpdb;
        $base = sanitize_title( $title );
        $slug = $base;
        $i = 1;

        while ( $wpdb->get_var( $wpdb->prepare(
            "SELECT id FROM " . self::table( 'services' ) . " WHERE slug = %s",
            $slug
        ) ) ) {
            $slug = $base . '-' . $i;
            $i++;
            if ( $i > 100 ) {
                $slug = $base . '-' . $expert_id . '-' . wp_rand( 100, 999 );
                break;
            }
        }

        return $slug;
    }
}
