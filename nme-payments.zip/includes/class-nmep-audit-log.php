<?php
/**
 * NMEP_Audit_Log
 *
 * Structured audit log writer + admin viewer on top of nmep_audit_log.
 *
 * Subscribes to every canonical event via nmep_event (wildcard emitted by
 * NMEP_Events::emit) and records actor/ip/ua + event payload. Adds an admin
 * page that paginates through the log with filters.
 *
 * @package NagalandMeExpertsPayments
 * @since   2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class NMEP_Audit_Log {

    const PER_PAGE = 50;

    public static function init() {
        add_action( 'nmep_event', array( __CLASS__, 'on_event' ), 10, 2 );
        add_action( 'admin_menu', array( __CLASS__, 'register_menu' ), 20 );
    }

    public static function on_event( $event, $args ) {
        self::record( $event, null, null, $args );
    }

    public static function record( $event, $subject_type = null, $subject_id = null, $meta = array() ) {
        global $wpdb;
        $wpdb->insert( NMEP_Database::table( 'audit_log' ), array(
            'actor_user_id' => get_current_user_id() ?: null,
            'actor_role'    => self::current_role(),
            'event'         => substr( (string) $event, 0, 80 ),
            'subject_type'  => $subject_type ? substr( $subject_type, 0, 40 ) : null,
            'subject_id'    => $subject_id ? (int) $subject_id : null,
            'ip'            => self::client_ip(),
            'user_agent'    => substr( (string) ( $_SERVER['HTTP_USER_AGENT'] ?? '' ), 0, 255 ),
            'meta'          => $meta ? wp_json_encode( $meta ) : null,
        ) );
    }

    private static function current_role() {
        if ( ! is_user_logged_in() ) return 'guest';
        $u = wp_get_current_user();
        if ( in_array( 'administrator', (array) $u->roles, true ) ) return 'admin';
        return (string) ( $u->roles[0] ?? 'user' );
    }

    private static function client_ip() {
        foreach ( array( 'HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR' ) as $k ) {
            if ( ! empty( $_SERVER[ $k ] ) ) {
                $ip = trim( explode( ',', $_SERVER[ $k ] )[0] );
                return substr( $ip, 0, 64 );
            }
        }
        return '';
    }

    /* ============================================================
       ADMIN PAGE
       ============================================================ */

    public static function register_menu() {
        add_submenu_page(
            'nmep-dashboard', 'Audit Log', 'Audit Log',
            'manage_options', 'nmep-audit-log', array( __CLASS__, 'render_page' )
        );
    }

    public static function render_page() {
        if ( ! current_user_can( 'manage_options' ) ) return;
        global $wpdb;
        $table = NMEP_Database::table( 'audit_log' );

        $event_filter = sanitize_text_field( $_GET['event'] ?? '' );
        $page         = max( 1, (int) ( $_GET['paged'] ?? 1 ) );
        $offset       = ( $page - 1 ) * self::PER_PAGE;

        $where = '1=1';
        $params = array();
        if ( $event_filter ) {
            $where    = 'event LIKE %s';
            $params[] = '%' . $wpdb->esc_like( $event_filter ) . '%';
        }

        $params_list = array_merge( $params, array( self::PER_PAGE, $offset ) );
        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM $table WHERE $where ORDER BY id DESC LIMIT %d OFFSET %d",
            $params_list
        ) );

        $total = (int) $wpdb->get_var( $params
            ? $wpdb->prepare( "SELECT COUNT(*) FROM $table WHERE $where", $params )
            : "SELECT COUNT(*) FROM $table" );

        echo '<div class="wrap"><h1>Audit Log</h1>';
        echo '<form method="get" style="margin:16px 0;">';
        echo '<input type="hidden" name="page" value="nmep-audit-log">';
        echo 'Event: <input type="text" name="event" value="' . esc_attr( $event_filter ) . '" placeholder="e.g. nmep_order_paid"> ';
        echo '<button class="button">Filter</button></form>';

        echo '<table class="widefat striped"><thead><tr>';
        echo '<th>When</th><th>Event</th><th>Actor</th><th>Role</th><th>IP</th><th>Subject</th><th>Meta</th>';
        echo '</tr></thead><tbody>';
        foreach ( $rows as $r ) {
            echo '<tr>';
            echo '<td>' . esc_html( $r->created_at ) . '</td>';
            echo '<td><code>' . esc_html( $r->event ) . '</code></td>';
            echo '<td>' . ( $r->actor_user_id ? esc_html( '#' . $r->actor_user_id ) : '—' ) . '</td>';
            echo '<td>' . esc_html( $r->actor_role ) . '</td>';
            echo '<td>' . esc_html( $r->ip ) . '</td>';
            echo '<td>' . ( $r->subject_type ? esc_html( $r->subject_type . '#' . $r->subject_id ) : '—' ) . '</td>';
            echo '<td><pre style="max-width:360px; white-space:pre-wrap; margin:0; font-size:11px;">'
                . esc_html( wp_trim_words( (string) $r->meta, 30 ) ) . '</pre></td>';
            echo '</tr>';
        }
        echo '</tbody></table>';

        $pages = (int) ceil( $total / self::PER_PAGE );
        if ( $pages > 1 ) {
            echo '<p style="margin-top:12px;">';
            for ( $p = 1; $p <= min( $pages, 20 ); $p++ ) {
                $url = add_query_arg( array( 'paged' => $p ) );
                $cls = $p === $page ? 'button button-primary' : 'button';
                echo '<a class="' . esc_attr( $cls ) . '" href="' . esc_url( $url ) . '">' . $p . '</a> ';
            }
            echo '</p>';
        }
        echo '</div>';
    }
}
