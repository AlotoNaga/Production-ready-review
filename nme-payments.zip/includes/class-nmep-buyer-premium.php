<?php
/**
 * NMEP_Buyer_Premium
 *
 * Premium Buyer program for the Nagaland Me Experts marketplace.
 *
 * === PATH B (confirmed with Aloto, 17 Apr 2026) ===
 * Annual one-time payment of ₹499 (configurable). No auto-renewal.
 * Uses existing NMEP_Razorpay_Client::create_order() — the same
 * tested code path that powers service checkout. Does NOT use
 * Razorpay Subscriptions API, keeping the integration simple and
 * the cost predictable for buyers (no surprise annual debits).
 *
 * === WHAT A PREMIUM BUYER GETS ===
 *   • 5% automatic discount on every order (stacks with coupons)
 *   • Reveals expert phone + email on profile / service pages
 *     (every reveal is logged for abuse investigation)
 *   • Unlimited pre-purchase messages (handled by NMEP_Inbox)
 *   • "Premium Buyer" badge next to name in reviews
 *
 * === TRUSTED BUYER (whistleblower reward) ===
 * Any buyer can report suspected off-platform transactions by an
 * expert, with evidence. After admin review + approval, the reporter
 * earns a permanent "Trusted Buyer" badge plus 3% lifetime discount
 * that STACKS with the premium 5% (additive, off the original price).
 * Commission is always calculated on the ORIGINAL price — discounts
 * come out of the expert's cut, not the platform's.
 *
 * === DATABASE ===
 *   wp_nmep_buyer_premium      — subscription records
 *   wp_nmep_phone_view_log     — audit log of contact reveals
 *   wp_nmep_whistleblower      — off-platform-activity reports
 *   (plus user_meta 'nmep_is_trusted_buyer' = 1 for approved reporters)
 *
 * === HOOKS ===
 *   filter nmep_checkout_pricing @ priority 20 — premium 5% discount
 *   filter nmep_checkout_pricing @ priority 30 — trusted 3% discount
 *   action nmep_after_payment_captured         — not used here
 *                                                (premium purchase has
 *                                                 its own verify handler)
 *
 * === SHORTCODES ===
 *   [nmep_buyer_premium]         — landing/purchase page
 *   [nmep_whistleblower_form]    — off-platform report form
 *
 * @package NagalandMeExpertsPayments
 * @version 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class NMEP_Buyer_Premium {

    const DB_VERSION_OPTION = 'nmep_premium_db_version';
    const DB_VERSION        = '1.0.0';

    const TRUSTED_USER_META = 'nmep_is_trusted_buyer';

    const WB_STATUS_PENDING  = 'pending';
    const WB_STATUS_APPROVED = 'approved';
    const WB_STATUS_REJECTED = 'rejected';

    /* ============================================================
       INIT
       ============================================================ */

    public static function init() {
        add_action( 'admin_init',     array( __CLASS__, 'maybe_migrate' ), 5 );
        add_action( 'plugins_loaded', array( __CLASS__, 'maybe_migrate' ), 30 );

        // Discount filters — priority 20 (premium) and 30 (trusted) run AFTER coupons (10)
        add_filter( 'nmep_checkout_pricing', array( __CLASS__, 'apply_premium_discount' ), 20, 5 );
        add_filter( 'nmep_checkout_pricing', array( __CLASS__, 'apply_trusted_discount' ), 30, 5 );

        // Premium purchase flow (mirrors NMEP_Checkout pattern)
        add_action( 'admin_post_nopriv_nmep_premium_start_checkout', array( __CLASS__, 'handle_purchase_start' ) );
        add_action( 'admin_post_nmep_premium_start_checkout',        array( __CLASS__, 'handle_purchase_start' ) );
        add_action( 'admin_post_nopriv_nmep_premium_verify_payment', array( __CLASS__, 'handle_payment_verification' ) );
        add_action( 'admin_post_nmep_premium_verify_payment',        array( __CLASS__, 'handle_payment_verification' ) );

        // AJAX contact reveal (logged, rate-limited, premium-gated)
        add_action( 'wp_ajax_nmep_reveal_contact',        array( __CLASS__, 'ajax_reveal_contact' ) );
        add_action( 'wp_ajax_nopriv_nmep_reveal_contact', array( __CLASS__, 'ajax_reveal_contact_denied' ) );

        // Whistleblower submission
        add_action( 'admin_post_nopriv_nmep_submit_whistleblower', array( __CLASS__, 'handle_whistleblower_submit' ) );
        add_action( 'admin_post_nmep_submit_whistleblower',        array( __CLASS__, 'handle_whistleblower_submit' ) );

        // Admin
        if ( is_admin() ) {
            add_action( 'admin_menu', array( __CLASS__, 'register_admin_menu' ), 26 );
        }
        add_action( 'admin_post_nmep_admin_approve_whistleblower', array( __CLASS__, 'handle_admin_approve_whistleblower' ) );
        add_action( 'admin_post_nmep_admin_reject_whistleblower',  array( __CLASS__, 'handle_admin_reject_whistleblower' ) );

        // Phase 2 — CEO CSV export for expiring-soon subscriptions
        add_action( 'admin_post_nmep_export_premium_expiring', array( __CLASS__, 'handle_export_expiring_csv' ) );

        // Shortcodes
        add_shortcode( 'nmep_buyer_premium',       array( __CLASS__, 'render_premium_landing' ) );
        add_shortcode( 'nmep_whistleblower_form',  array( __CLASS__, 'render_whistleblower_form' ) );
        add_shortcode( 'nmep_my_premium',          array( __CLASS__, 'render_my_premium' ) );

        // Badge hook on reviews (reads existing nmep_review_after_buyer_name filter in expert-profiles)
        add_filter( 'nmep_review_after_buyer_name',        array( __CLASS__, 'filter_review_badge' ), 10, 2 );
        add_filter( 'nmep_expert_profile_after_name',      array( __CLASS__, 'filter_expert_profile_noop' ), 10, 2 );

        // Daily cron hook — caller (NMEP_Cron) may schedule this
        add_action( 'nmep_cron_premium_daily', array( __CLASS__, 'cron_daily' ) );
    }

    /* ============================================================
       TABLES / MIGRATION
       ============================================================ */

    public static function table( $name ) {
        global $wpdb;
        return $wpdb->prefix . 'nmep_' . $name;
    }

    public static function maybe_migrate() {
        $installed = get_option( self::DB_VERSION_OPTION, '0.0.0' );
        if ( version_compare( $installed, self::DB_VERSION, '>=' ) ) {
            return;
        }
        self::create_tables();
        update_option( self::DB_VERSION_OPTION, self::DB_VERSION, false );
    }

    public static function create_tables() {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        $premium = self::table( 'buyer_premium' );
        $phone   = self::table( 'phone_view_log' );
        $wb      = self::table( 'whistleblower' );

        $sql_premium = "CREATE TABLE $premium (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id BIGINT(20) UNSIGNED NOT NULL,
            email VARCHAR(190) NOT NULL,
            full_name VARCHAR(120) DEFAULT NULL,

            started_at DATETIME NOT NULL,
            expires_at DATETIME NOT NULL,
            is_active TINYINT(1) NOT NULL DEFAULT 1,

            mode VARCHAR(10) NOT NULL DEFAULT 'test',
            razorpay_order_id VARCHAR(50) DEFAULT NULL,
            razorpay_payment_id VARCHAR(50) DEFAULT NULL,
            razorpay_signature VARCHAR(255) DEFAULT NULL,
            amount_paid DECIMAL(10,2) NOT NULL DEFAULT 0.00,
            currency VARCHAR(10) NOT NULL DEFAULT 'INR',

            view_token VARCHAR(64) DEFAULT NULL,
            api_response LONGTEXT DEFAULT NULL,

            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY user_id (user_id),
            KEY email (email),
            KEY is_active (is_active),
            KEY expires_at (expires_at),
            KEY razorpay_order_id (razorpay_order_id)
        ) $charset_collate;";

        $sql_phone = "CREATE TABLE $phone (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            expert_id BIGINT(20) UNSIGNED NOT NULL,
            buyer_user_id BIGINT(20) UNSIGNED DEFAULT NULL,
            buyer_email VARCHAR(190) DEFAULT NULL,
            reveal_source VARCHAR(20) NOT NULL DEFAULT 'profile',
            contact_type VARCHAR(10) NOT NULL DEFAULT 'phone',
            ip_address VARCHAR(45) DEFAULT NULL,
            user_agent VARCHAR(255) DEFAULT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY expert_id (expert_id),
            KEY buyer_user_id (buyer_user_id),
            KEY created_at (created_at)
        ) $charset_collate;";

        $sql_wb = "CREATE TABLE $wb (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            reporter_user_id BIGINT(20) UNSIGNED NOT NULL,
            reporter_email VARCHAR(190) NOT NULL,
            reporter_name VARCHAR(120) DEFAULT NULL,
            expert_id BIGINT(20) UNSIGNED DEFAULT NULL,
            expert_name_snapshot VARCHAR(120) DEFAULT NULL,
            incident_date DATE DEFAULT NULL,
            amount_involved DECIMAL(10,2) DEFAULT NULL,
            description LONGTEXT NOT NULL,
            evidence_urls TEXT DEFAULT NULL,
            status VARCHAR(20) NOT NULL DEFAULT 'pending',
            reviewed_by BIGINT(20) UNSIGNED DEFAULT NULL,
            reviewed_at DATETIME DEFAULT NULL,
            admin_notes TEXT DEFAULT NULL,
            ip_address VARCHAR(45) DEFAULT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY reporter_user_id (reporter_user_id),
            KEY expert_id (expert_id),
            KEY status (status)
        ) $charset_collate;";

        dbDelta( $sql_premium );
        dbDelta( $sql_phone );
        dbDelta( $sql_wb );

        if ( class_exists( 'NMEP_Logger' ) ) {
            NMEP_Logger::info( 'Buyer Premium tables migrated', array( 'version' => self::DB_VERSION ) );
        }
    }

    /* ============================================================
       PREMIUM STATUS HELPERS
       ============================================================ */

    /**
     * @return object|null active premium record (or null)
     */
    public static function get_active_record( $user_id ) {
        $user_id = (int) $user_id;
        if ( $user_id <= 0 ) return null;

        global $wpdb;
        return $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM " . self::table( 'buyer_premium' ) . "
             WHERE user_id = %d AND is_active = 1 AND expires_at > UTC_TIMESTAMP()
             ORDER BY expires_at DESC LIMIT 1",
            $user_id
        ) );
    }

    public static function is_premium( $user_id = null ) {
        if ( $user_id === null ) {
            $user_id = get_current_user_id();
        }
        return (bool) self::get_active_record( (int) $user_id );
    }

    public static function is_trusted_buyer( $user_id = null ) {
        if ( $user_id === null ) {
            $user_id = get_current_user_id();
        }
        if ( ! $user_id ) return false;
        return (bool) get_user_meta( (int) $user_id, self::TRUSTED_USER_META, true );
    }

    public static function mark_trusted_buyer( $user_id ) {
        update_user_meta( (int) $user_id, self::TRUSTED_USER_META, 1 );
    }

    /* ============================================================
       DISCOUNT FILTERS (stack additively off ORIGINAL price)
       ============================================================ */

    /**
     * Shared math helper: adds an extra discount (as % of original)
     * onto an existing pricing array while keeping commission fixed
     * on the ORIGINAL price.
     */
    private static function stack_discount( $pricing, $additional_pct, $source_tag, $commission_rate ) {
        $additional_pct = max( 0.0, (float) $additional_pct );
        if ( $additional_pct <= 0 ) return $pricing;

        $original = (float) ( $pricing['original_amount'] ?? $pricing['gross_amount'] );
        if ( $original <= 0 ) return $pricing;

        $extra_discount = round( $original * $additional_pct / 100, 2 );
        $new_discount   = round( (float) ( $pricing['discount_amount'] ?? 0 ) + $extra_discount, 2 );

        // Cap total discount at the original (never over 100%)
        if ( $new_discount > $original ) {
            $new_discount = $original;
        }

        $new_gross = max( 0.0, round( $original - $new_discount, 2 ) );
        $commission = round( $original * (float) $commission_rate / 100, 2 );
        $expert     = max( 0.0, round( $new_gross - $commission, 2 ) );

        $pricing['original_amount']   = $original;
        $pricing['discount_amount']   = $new_discount;
        $pricing['gross_amount']      = $new_gross;
        $pricing['commission_amount'] = $commission;
        $pricing['expert_amount']     = $expert;

        $existing_src = (string) ( $pricing['discount_source'] ?? '' );
        $pricing['discount_source'] = $existing_src !== '' ? ( $existing_src . '+' . $source_tag ) : $source_tag;

        return $pricing;
    }

    public static function apply_premium_discount( $pricing, $post_data, $service, $expert, $commission_rate ) {
        if ( ! (bool) NMEP_Settings::get( 'premium_buyer_enabled', true ) ) {
            return $pricing;
        }
        // Only logged-in buyers can be premium (Path B requires a WP account at purchase time)
        if ( ! is_user_logged_in() ) {
            return $pricing;
        }
        if ( ! self::is_premium( get_current_user_id() ) ) {
            return $pricing;
        }

        $pct = (float) NMEP_Settings::get( 'premium_buyer_discount_percent', 5 );
        return self::stack_discount( $pricing, $pct, 'premium', $commission_rate );
    }

    public static function apply_trusted_discount( $pricing, $post_data, $service, $expert, $commission_rate ) {
        if ( ! is_user_logged_in() ) {
            return $pricing;
        }
        if ( ! self::is_trusted_buyer( get_current_user_id() ) ) {
            return $pricing;
        }

        $pct = (float) NMEP_Settings::get( 'premium_buyer_trusted_discount_percent', 3 );
        return self::stack_discount( $pricing, $pct, 'trusted', $commission_rate );
    }

    /* ============================================================
       PREMIUM PURCHASE FLOW (mirrors NMEP_Checkout pattern)
       ============================================================ */

    /**
     * Stage 1 — Create Razorpay order, create local premium record (pending),
     * redirect to the Razorpay popup page (same /buyer-premium/?action=pay pattern
     * used by the service checkout).
     */
    public static function handle_purchase_start() {
        if ( ! is_user_logged_in() ) {
            self::redirect_error( 'Please log in or register before purchasing Premium Buyer.', self::landing_url() );
        }
        if ( ! isset( $_POST['nmep_premium_nonce'] ) || ! wp_verify_nonce( $_POST['nmep_premium_nonce'], 'nmep_premium_purchase' ) ) {
            self::redirect_error( 'Security check failed. Please try again.', self::landing_url() );
        }

        if ( ! (bool) NMEP_Settings::get( 'premium_buyer_enabled', true ) ) {
            self::redirect_error( 'Premium Buyer is currently unavailable.', self::landing_url() );
        }

        // Already active? Extend from current expiry rather than overwrite.
        $user = wp_get_current_user();

        $price = (float) NMEP_Settings::get( 'premium_buyer_price', 499 );
        if ( $price <= 0 ) {
            self::redirect_error( 'Premium Buyer pricing is not configured.', self::landing_url() );
        }

        if ( class_exists( 'NMEP_Guard' ) ) {
            NMEP_Guard::rate_enforce( 'premium_checkout', 5, 300, 'user' );
        }

        // Compute dates: if already has active premium, extend; else start now.
        $existing  = self::get_active_record( $user->ID );
        $duration  = max( 1, (int) NMEP_Settings::get( 'premium_buyer_duration_days', 365 ) );
        $now       = current_time( 'mysql' );
        $start_ts  = time();
        if ( $existing && ! empty( $existing->expires_at ) ) {
            $start_ts = max( $start_ts, strtotime( $existing->expires_at ) );
        }
        $expires_ts = strtotime( "+{$duration} days", $start_ts );

        // Create local record in pending state (is_active=0 until payment captured)
        global $wpdb;
        $token = class_exists( 'NMEP_Database' ) ? NMEP_Database::generate_view_token() : bin2hex( random_bytes( 16 ) );

        $row = array(
            'user_id'     => (int) $user->ID,
            'email'       => (string) $user->user_email,
            'full_name'   => (string) $user->display_name,
            'started_at'  => date( 'Y-m-d H:i:s', $start_ts ),
            'expires_at'  => date( 'Y-m-d H:i:s', $expires_ts ),
            'is_active'   => 0,
            'mode'        => NMEP_Settings::get_mode(),
            'amount_paid' => $price,
            'currency'    => 'INR',
            'view_token'  => $token,
            'created_at'  => $now,
        );

        $wpdb->insert( self::table( 'buyer_premium' ), $row );
        $premium_id = (int) $wpdb->insert_id;
        if ( ! $premium_id ) {
            NMEP_Logger::error( 'Failed to insert premium pending row', array( 'error' => $wpdb->last_error ) );
            self::redirect_error( 'Could not start your Premium purchase. Please try again.', self::landing_url() );
        }

        // Create Razorpay order
        $receipt = 'NMEPREM' . $premium_id;
        $rzp = NMEP_Razorpay_Client::create_order(
            nmep_to_paise( $price ),
            'INR',
            $receipt,
            array(
                'product'    => 'buyer_premium',
                'premium_id' => (string) $premium_id,
                'user_id'    => (string) $user->ID,
                'email'      => (string) $user->user_email,
                'platform'   => 'experts.nagaland.me',
            ),
            null // no transfers — this is platform income, not a marketplace order
        );

        if ( is_wp_error( $rzp ) ) {
            NMEP_Logger::error( 'Razorpay order creation failed for premium', array(
                'premium_id' => $premium_id,
                'error'      => $rzp->get_error_message(),
            ) );
            // Cleanup: delete the orphan pending row
            $wpdb->delete( self::table( 'buyer_premium' ), array( 'id' => $premium_id ) );
            self::redirect_error( 'Payment gateway error: ' . $rzp->get_error_message(), self::landing_url() );
        }

        $wpdb->update(
            self::table( 'buyer_premium' ),
            array(
                'razorpay_order_id' => sanitize_text_field( $rzp['id'] ),
                'api_response'      => wp_json_encode( $rzp ),
            ),
            array( 'id' => $premium_id )
        );

        NMEP_Logger::info( 'Premium Razorpay order created', array(
            'premium_id'        => $premium_id,
            'razorpay_order_id' => $rzp['id'],
            'amount'            => $price,
        ) );

        // Redirect to the payment popup page
        $pay_url = add_query_arg( array(
            'action'     => 'pay',
            'premium_id' => $premium_id,
            'token'      => $token,
        ), self::landing_url() );
        wp_safe_redirect( $pay_url );
        exit;
    }

    /**
     * Stage 2 — Verify Razorpay payment signature + activate the premium record.
     */
    public static function handle_payment_verification() {
        $payment_id = sanitize_text_field( $_POST['razorpay_payment_id']  ?? '' );
        $order_id   = sanitize_text_field( $_POST['razorpay_order_id']    ?? '' );
        $signature  = sanitize_text_field( $_POST['razorpay_signature']   ?? '' );
        $premium_id = isset( $_POST['local_premium_id'] ) ? (int) $_POST['local_premium_id'] : 0;

        if ( empty( $payment_id ) || empty( $order_id ) || empty( $signature ) || empty( $premium_id ) ) {
            NMEP_Logger::error( 'Premium payment verification: missing fields' );
            self::redirect_error( 'Payment verification failed — missing data.', self::landing_url() );
        }

        global $wpdb;
        $record = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM " . self::table( 'buyer_premium' ) . " WHERE id = %d LIMIT 1",
            $premium_id
        ) );
        if ( ! $record ) {
            NMEP_Logger::error( 'Premium payment verification: record not found', array( 'premium_id' => $premium_id ) );
            self::redirect_error( 'Subscription record not found.', self::landing_url() );
        }
        if ( $record->razorpay_order_id !== $order_id ) {
            NMEP_Logger::critical( 'Premium payment verification: order_id mismatch (possible tampering)', array(
                'expected'   => $record->razorpay_order_id,
                'received'   => $order_id,
                'premium_id' => $premium_id,
            ) );
            self::redirect_error( 'Order verification failed.', self::landing_url() );
        }

        $valid = NMEP_Razorpay_Client::verify_payment_signature( $order_id, $payment_id, $signature );
        if ( ! $valid ) {
            NMEP_Logger::critical( 'Premium payment signature verification FAILED', array(
                'premium_id' => $premium_id,
                'payment_id' => $payment_id,
            ) );
            self::redirect_error( 'Payment signature verification failed. Your card was not charged. Please contact support if you were billed.', self::landing_url() );
        }

        // Activate
        $wpdb->update(
            self::table( 'buyer_premium' ),
            array(
                'razorpay_payment_id' => $payment_id,
                'razorpay_signature'  => $signature,
                'is_active'           => 1,
            ),
            array( 'id' => $premium_id )
        );

        $record = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM " . self::table( 'buyer_premium' ) . " WHERE id = %d LIMIT 1",
            $premium_id
        ) );

        NMEP_Logger::info( 'Premium activated', array(
            'premium_id' => $premium_id,
            'user_id'    => $record->user_id,
            'expires_at' => $record->expires_at,
        ) );

        if ( class_exists( 'NMEP_Compat' ) ) {
            NMEP_Compat::audit_log( 'premium_activated', 'buyer_premium', $premium_id, array(
                'user_id'    => $record->user_id,
                'amount'     => $record->amount_paid,
                'expires_at' => $record->expires_at,
            ) );
        }

        // Fire an extensible event so other plugins can react to premium
        // activation (e.g., the nme-badges plugin can award a "Premium Buyer"
        // badge in the same request without waiting for the daily cron).
        // Passes the buyer's user_id first and the full record second so
        // subscribers don't have to re-query the DB.
        do_action( 'nmep_premium_activated', (int) $record->user_id, $record );

        self::send_welcome_email( $record );

        $thanks_url = add_query_arg( array(
            'action'     => 'welcome',
            'premium_id' => $premium_id,
            'token'      => $record->view_token,
        ), self::landing_url() );
        wp_safe_redirect( $thanks_url );
        exit;
    }

    /* ============================================================
       CONTACT REVEAL (AJAX) — premium-only, logged, rate-limited
       ============================================================ */

    public static function ajax_reveal_contact_denied() {
        wp_send_json_error( array(
            'message' => 'Please log in and upgrade to Premium Buyer to view expert contact details.',
            'code'    => 'nmep_not_logged_in',
        ), 401 );
    }

    public static function ajax_reveal_contact() {
        if ( ! isset( $_POST['nonce'] ) || ! wp_verify_nonce( $_POST['nonce'], 'nmep_ajax' ) ) {
            wp_send_json_error( array( 'message' => 'Security check failed.', 'code' => 'nmep_bad_nonce' ), 403 );
        }

        $user_id = get_current_user_id();
        if ( ! $user_id ) {
            wp_send_json_error( array(
                'message' => 'Please log in to view expert contact details.',
                'code'    => 'nmep_not_logged_in',
            ), 401 );
        }

        if ( ! self::is_premium( $user_id ) ) {
            wp_send_json_error( array(
                'message'      => 'Premium Buyer required to view expert contact details.',
                'code'         => 'nmep_not_premium',
                'upgrade_url'  => self::landing_url(),
            ), 403 );
        }

        // Rate limit: 30 reveals per hour per user
        if ( class_exists( 'NMEP_Guard' ) ) {
            if ( ! NMEP_Guard::rate_check( 'reveal_contact', 30, 3600, 'user' ) ) {
                wp_send_json_error( array(
                    'message' => 'You have revealed too many contact details in the last hour. Please try again later.',
                    'code'    => 'nmep_rate_limited',
                ), 429 );
            }
        }

        $expert_id    = isset( $_POST['expert_id'] ) ? (int) $_POST['expert_id'] : 0;
        $contact_type = isset( $_POST['contact_type'] ) ? sanitize_key( $_POST['contact_type'] ) : 'phone';
        $source       = isset( $_POST['source'] ) ? sanitize_key( $_POST['source'] ) : 'profile';
        if ( ! in_array( $contact_type, array( 'phone', 'email' ), true ) ) $contact_type = 'phone';
        if ( ! in_array( $source, array( 'profile', 'service' ), true ) )   $source = 'profile';

        $expert = NMEP_Compat::get_expert( $expert_id );
        if ( ! $expert ) {
            wp_send_json_error( array( 'message' => 'Expert not found.', 'code' => 'nmep_no_expert' ), 404 );
        }

        $value = $contact_type === 'phone' ? (string) ( $expert->phone ?? '' ) : (string) ( $expert->email ?? '' );
        if ( $value === '' ) {
            wp_send_json_error( array(
                'message' => 'This expert has not provided a ' . $contact_type . '.',
                'code'    => 'nmep_no_value',
            ), 404 );
        }

        // Log the reveal (always — required for abuse investigations)
        self::log_contact_view( $expert_id, $user_id, wp_get_current_user()->user_email ?? '', $source, $contact_type );

        wp_send_json_success( array(
            'contact_type' => $contact_type,
            'value'        => $value,
            'display'      => $contact_type === 'phone' ? self::format_phone_display( $value ) : $value,
        ) );
    }

    private static function log_contact_view( $expert_id, $buyer_user_id, $buyer_email, $source, $contact_type ) {
        global $wpdb;
        $wpdb->insert( self::table( 'phone_view_log' ), array(
            'expert_id'      => (int) $expert_id,
            'buyer_user_id'  => (int) $buyer_user_id,
            'buyer_email'    => sanitize_email( $buyer_email ),
            'reveal_source'  => sanitize_key( $source ),
            'contact_type'   => sanitize_key( $contact_type ),
            'ip_address'     => isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( $_SERVER['REMOTE_ADDR'] ) : null,
            'user_agent'     => isset( $_SERVER['HTTP_USER_AGENT'] ) ? substr( sanitize_text_field( $_SERVER['HTTP_USER_AGENT'] ), 0, 255 ) : null,
        ) );
    }

    private static function format_phone_display( $phone ) {
        $digits = preg_replace( '/\D/', '', $phone );
        if ( strlen( $digits ) === 10 ) {
            return '+91 ' . substr( $digits, 0, 5 ) . ' ' . substr( $digits, 5 );
        }
        if ( strlen( $digits ) === 12 && substr( $digits, 0, 2 ) === '91' ) {
            return '+91 ' . substr( $digits, 2, 5 ) . ' ' . substr( $digits, 7 );
        }
        return $phone;
    }

    /* ============================================================
       WHISTLEBLOWER — submission + admin review
       ============================================================ */

    public static function handle_whistleblower_submit() {
        if ( ! is_user_logged_in() ) {
            self::redirect_error( 'Please log in to submit a report.', home_url( '/' ) );
        }
        if ( ! isset( $_POST['nmep_wb_nonce'] ) || ! wp_verify_nonce( $_POST['nmep_wb_nonce'], 'nmep_submit_whistleblower' ) ) {
            self::redirect_error( 'Security check failed.', home_url( '/' ) );
        }

        // Rate limit — max 3 submissions per day per user
        if ( class_exists( 'NMEP_Guard' ) ) {
            NMEP_Guard::rate_enforce( 'whistleblower_submit', 3, 86400, 'user' );
        }

        $user        = wp_get_current_user();
        $expert_id   = isset( $_POST['expert_id'] ) ? (int) $_POST['expert_id'] : 0;
        $description = sanitize_textarea_field( $_POST['description'] ?? '' );
        $incident    = isset( $_POST['incident_date'] ) && $_POST['incident_date'] ? date( 'Y-m-d', strtotime( $_POST['incident_date'] ) ) : null;
        $amount      = isset( $_POST['amount_involved'] ) && $_POST['amount_involved'] !== '' ? (float) $_POST['amount_involved'] : null;

        // Evidence URLs — one per line, up to 5
        $raw_urls = (string) ( $_POST['evidence_urls'] ?? '' );
        $urls = array_filter( array_map( 'trim', preg_split( '/\r?\n/', $raw_urls ) ) );
        $urls = array_slice( array_map( 'esc_url_raw', $urls ), 0, 5 );

        if ( strlen( $description ) < 30 ) {
            self::redirect_error( 'Please provide a detailed description (at least 30 characters).', self::whistleblower_url() );
        }
        if ( empty( $urls ) ) {
            self::redirect_error( 'Please provide at least one URL with evidence (screenshot, WhatsApp chat link, receipt, etc.).', self::whistleblower_url() );
        }

        $expert_name = '';
        if ( $expert_id ) {
            $expert = NMEP_Compat::get_expert( $expert_id );
            if ( $expert ) {
                $expert_name = $expert->full_name;
            }
        }

        global $wpdb;
        $wpdb->insert( self::table( 'whistleblower' ), array(
            'reporter_user_id'     => (int) $user->ID,
            'reporter_email'       => (string) $user->user_email,
            'reporter_name'        => (string) $user->display_name,
            'expert_id'            => $expert_id ?: null,
            'expert_name_snapshot' => $expert_name,
            'incident_date'        => $incident,
            'amount_involved'      => $amount,
            'description'          => $description,
            'evidence_urls'        => wp_json_encode( $urls ),
            'status'               => self::WB_STATUS_PENDING,
            'ip_address'           => isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( $_SERVER['REMOTE_ADDR'] ) : null,
        ) );

        $report_id = (int) $wpdb->insert_id;

        NMEP_Logger::info( 'Whistleblower report submitted', array(
            'report_id'        => $report_id,
            'reporter_user_id' => $user->ID,
            'expert_id'        => $expert_id,
        ) );

        self::notify_admin_of_whistleblower( $report_id, $user, $expert_name, $description, $urls );

        $url = add_query_arg( 'nmep_wb_submitted', 1, wp_get_referer() ?: home_url( '/' ) );
        wp_safe_redirect( $url );
        exit;
    }

    /* ============================================================
       SHORTCODES — landing page + whistleblower form
       ============================================================ */

    public static function render_premium_landing( $atts ) {
        $action = isset( $_GET['action'] ) ? sanitize_key( $_GET['action'] ) : '';

        if ( $action === 'pay' ) {
            return self::render_premium_payment_page();
        }
        if ( $action === 'welcome' ) {
            return self::render_premium_welcome();
        }

        return self::render_premium_hero();
    }

    private static function render_premium_hero() {
        $price    = (float) NMEP_Settings::get( 'premium_buyer_price', 499 );
        $duration = (int) NMEP_Settings::get( 'premium_buyer_duration_days', 365 );
        $disc_pct = rtrim( rtrim( number_format( (float) NMEP_Settings::get( 'premium_buyer_discount_percent', 5 ), 2 ), '0' ), '.' );

        $user   = is_user_logged_in() ? wp_get_current_user() : null;
        $active = $user ? self::get_active_record( $user->ID ) : null;

        ob_start();
        ?>
        <section class="nme-section">
            <div class="nme-container" style="max-width: 900px;">

                <?php if ( isset( $_GET['nmep_status'] ) && $_GET['nmep_status'] === 'error' && isset( $_GET['nmep_msg'] ) ) : ?>
                    <div class="nme-card" style="border-left: 4px solid #EF4444; background: #FEF2F2; margin-bottom: 16px;">
                        <p style="margin: 0; color: #991B1B;">❌ <?php echo esc_html( urldecode( $_GET['nmep_msg'] ) ); ?></p>
                    </div>
                <?php endif; ?>

                <div class="nme-card" style="text-align: center; padding: 48px 32px; background: linear-gradient(135deg, #0F2419 0%, #0A7558 100%); color: #fff; border-top: 6px solid #D4A843;">
                    <div style="font-size: 3rem; margin-bottom: 12px;">⭐</div>
                    <h1 style="color: #fff; margin: 0 0 12px; font-family: 'DM Serif Display', Georgia, serif;">Nagaland Me Premium Buyer</h1>
                    <p style="color: #D4A843; font-size: 1.1rem; margin: 0 0 24px;">Get more from every hire. Save on every order.</p>
                    <div style="font-size: 2.8rem; font-weight: 700; margin-bottom: 4px;"><?php echo nmep_format_inr( $price ); ?></div>
                    <div style="font-size: 0.95rem; color: #D4A843; margin-bottom: 24px;">One-time payment · <?php echo (int) $duration; ?> days access · No auto-renewal</div>
                </div>

                <div class="nme-card nme-mt-3">
                    <h2 style="margin-top: 0;">What you get</h2>
                    <ul style="list-style: none; padding: 0; margin: 0;">
                        <li style="padding: 12px 0; border-bottom: 1px solid var(--nme-border, #E5E7EB);"><strong style="color: var(--nme-emerald, #10B981);">✓ <?php echo esc_html( $disc_pct ); ?>% off every order you place</strong> — applied automatically at checkout, stacks with coupons.</li>
                        <li style="padding: 12px 0; border-bottom: 1px solid var(--nme-border, #E5E7EB);"><strong style="color: var(--nme-emerald, #10B981);">✓ Expert phone + email visible</strong> on every expert's profile — skip the back-and-forth for urgent work.</li>
                        <li style="padding: 12px 0; border-bottom: 1px solid var(--nme-border, #E5E7EB);"><strong style="color: var(--nme-emerald, #10B981);">✓ Unlimited pre-purchase messages</strong> — free buyers are limited to 5 per day.</li>
                        <li style="padding: 12px 0; border-bottom: 1px solid var(--nme-border, #E5E7EB);"><strong style="color: var(--nme-emerald, #10B981);">✓ Premium Buyer badge</strong> — shows experts you're a serious client.</li>
                        <li style="padding: 12px 0;"><strong style="color: var(--nme-emerald, #10B981);">✓ Priority support</strong> from the Nagaland Me team.</li>
                    </ul>
                </div>

                <?php if ( $active ) : ?>
                    <div class="nme-card nme-mt-3" style="background: #ECFDF5; border-left: 4px solid var(--nme-emerald, #10B981);">
                        <h3 style="margin-top: 0; color: #065F46;">You're already a Premium Buyer ✓</h3>
                        <p style="margin: 0; color: #065F46;">
                            Your current plan expires on <strong><?php echo esc_html( date( 'd M Y', strtotime( $active->expires_at ) ) ); ?></strong>.
                            You can extend anytime — we'll add <?php echo (int) $duration; ?> more days starting from your current expiry.
                        </p>
                    </div>
                <?php endif; ?>

                <div class="nme-card nme-mt-3 nme-text-center">
                    <?php if ( ! $user ) : ?>
                        <p style="color: var(--nme-text-light, #6B7280); margin-bottom: 16px;">You need a Nagaland Me account to buy Premium.</p>
                        <a href="<?php echo esc_url( wp_login_url( get_permalink() ) ); ?>" class="nme-btn nme-btn-gold" style="font-size: 1.05rem;">Log In / Register</a>
                    <?php else : ?>
                        <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                            <input type="hidden" name="action" value="nmep_premium_start_checkout">
                            <?php wp_nonce_field( 'nmep_premium_purchase', 'nmep_premium_nonce' ); ?>
                            <button type="submit" class="nme-btn nme-btn-gold" style="font-size: 1.1rem; padding: 16px 40px;">
                                <?php echo $active ? 'Extend Premium' : 'Get Premium'; ?> — <?php echo nmep_format_inr( $price ); ?>
                            </button>
                        </form>
                        <p style="font-size: 0.85rem; color: var(--nme-text-light, #6B7280); margin-top: 16px;">
                            🔒 Secure payment via Razorpay · No auto-renewal — you'll only ever be charged once per purchase.
                        </p>
                    <?php endif; ?>
                </div>

            </div>
        </section>
        <?php
        return ob_get_clean();
    }

    private static function render_premium_payment_page() {
        $premium_id = isset( $_GET['premium_id'] ) ? (int) $_GET['premium_id'] : 0;
        $token      = isset( $_GET['token'] ) ? sanitize_text_field( $_GET['token'] ) : '';

        if ( ! $premium_id || ! $token ) {
            return '<section class="nme-section"><div class="nme-container"><div class="nme-card nme-text-center"><h2>Invalid payment link</h2><p><a href="' . esc_url( self::landing_url() ) . '" class="nme-btn nme-btn-gold">Back to Premium</a></p></div></div></section>';
        }

        global $wpdb;
        $record = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM " . self::table( 'buyer_premium' ) . " WHERE id = %d AND view_token = %s LIMIT 1",
            $premium_id, $token
        ) );
        if ( ! $record ) {
            return '<section class="nme-section"><div class="nme-container"><div class="nme-card nme-text-center"><h2>Subscription not found</h2><p><a href="' . esc_url( self::landing_url() ) . '" class="nme-btn nme-btn-gold">Back to Premium</a></p></div></div></section>';
        }
        if ( $record->is_active ) {
            wp_safe_redirect( add_query_arg( array( 'action' => 'welcome', 'premium_id' => $record->id, 'token' => $record->view_token ), self::landing_url() ) );
            exit;
        }
        if ( empty( $record->razorpay_order_id ) ) {
            return '<section class="nme-section"><div class="nme-container"><div class="nme-card nme-text-center"><h2>Payment not ready</h2><p>Please contact support.</p></div></div></section>';
        }

        $config = array(
            'key'         => NMEP_Settings::get_api_key_id(),
            'amount'      => nmep_to_paise( $record->amount_paid ),
            'currency'    => $record->currency,
            'name'        => NMEP_Settings::get( 'merchant_name', 'Nagaland Me Experts' ),
            'description' => 'Premium Buyer — ' . (int) NMEP_Settings::get( 'premium_buyer_duration_days', 365 ) . ' days',
            'image'       => NMEP_Settings::get( 'logo_url', '' ),
            'order_id'    => $record->razorpay_order_id,
            'prefill'     => array(
                'name'    => $record->full_name,
                'email'   => $record->email,
            ),
            'notes'       => array(
                'product'    => 'buyer_premium',
                'premium_id' => (string) $record->id,
            ),
            'theme'       => array( 'color' => NMEP_Settings::get( 'theme_color', '#0F2419' ) ),
            'local_premium_id' => (int) $record->id,
        );

        ob_start();
        ?>
        <section class="nme-section">
            <div class="nme-container" style="max-width: 720px;">
                <div class="nme-card nme-text-center" style="padding: 48px 32px;">
                    <h2 style="margin-top: 0;">Ready for Payment</h2>
                    <p style="color: var(--nme-text-light, #6B7280); font-size: 1.05rem;">
                        Premium Buyer · <strong><?php echo nmep_format_inr( $record->amount_paid ); ?></strong>
                    </p>
                    <button id="nmep-premium-pay-btn" class="nme-btn nme-btn-gold" style="font-size: 1.1rem; padding: 16px 48px; margin: 24px 0;">
                        💳 Pay <?php echo nmep_format_inr( $record->amount_paid ); ?>
                    </button>
                    <p style="font-size: 0.85rem; color: var(--nme-text-light, #6B7280); margin: 16px 0 0;">
                        🔒 You will be securely redirected to Razorpay to complete payment.
                    </p>
                </div>
            </div>
        </section>
        <script src="https://checkout.razorpay.com/v1/checkout.js"></script>
        <script>
        (function(){
            var cfg = <?php echo wp_json_encode( $config ); ?>;
            var ajaxUrl = '<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>';

            var options = {
                key: cfg.key, amount: cfg.amount, currency: cfg.currency,
                name: cfg.name, description: cfg.description, image: cfg.image,
                order_id: cfg.order_id, prefill: cfg.prefill, notes: cfg.notes, theme: cfg.theme,
                handler: function(response) {
                    var form = document.createElement('form');
                    form.method = 'POST';
                    form.action = ajaxUrl;
                    var fields = {
                        'action': 'nmep_premium_verify_payment',
                        'razorpay_payment_id': response.razorpay_payment_id,
                        'razorpay_order_id': response.razorpay_order_id,
                        'razorpay_signature': response.razorpay_signature,
                        'local_premium_id': cfg.local_premium_id
                    };
                    for (var k in fields) {
                        var i = document.createElement('input');
                        i.type = 'hidden'; i.name = k; i.value = fields[k];
                        form.appendChild(i);
                    }
                    document.body.appendChild(form);
                    form.submit();
                },
                modal: { ondismiss: function(){ console.log('dismissed'); } }
            };
            var rzp = new Razorpay(options);
            rzp.on('payment.failed', function(response){
                alert('Payment failed: ' + (response.error.description || 'Unknown error'));
            });
            document.getElementById('nmep-premium-pay-btn').addEventListener('click', function(){ rzp.open(); });
            setTimeout(function(){ rzp.open(); }, 800);
        })();
        </script>
        <?php
        return ob_get_clean();
    }

    private static function render_premium_welcome() {
        $premium_id = isset( $_GET['premium_id'] ) ? (int) $_GET['premium_id'] : 0;
        $token      = isset( $_GET['token'] ) ? sanitize_text_field( $_GET['token'] ) : '';

        global $wpdb;
        $record = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM " . self::table( 'buyer_premium' ) . " WHERE id = %d AND view_token = %s LIMIT 1",
            $premium_id, $token
        ) );
        if ( ! $record || ! $record->is_active ) {
            wp_safe_redirect( self::landing_url() );
            exit;
        }

        ob_start();
        ?>
        <section class="nme-section">
            <div class="nme-container" style="max-width: 720px;">
                <div class="nme-card nme-text-center" style="padding: 48px 32px; border-top: 6px solid var(--nme-emerald, #10B981);">
                    <div style="font-size: 4rem; margin-bottom: 16px;">⭐</div>
                    <h1 style="margin: 0;">Welcome to Premium!</h1>
                    <p style="font-size: 1.1rem; color: var(--nme-text-light, #6B7280); margin: 16px 0;">
                        Thanks, <strong><?php echo esc_html( $record->full_name ); ?></strong>! Your Premium Buyer plan is active until <strong><?php echo esc_html( date( 'd M Y', strtotime( $record->expires_at ) ) ); ?></strong>.
                    </p>
                    <div style="background: var(--nme-bg-soft, #F9FAFB); padding: 20px; border-radius: 12px; text-align: left; margin: 24px 0;">
                        <strong>What's active now:</strong>
                        <ul style="margin: 8px 0 0; padding-left: 20px; color: var(--nme-text, #374151);">
                            <li><?php echo esc_html( rtrim( rtrim( number_format( (float) NMEP_Settings::get( 'premium_buyer_discount_percent', 5 ), 2 ), '0' ), '.' ) ); ?>% off every order — auto-applied</li>
                            <li>Contact info visible on all expert profiles</li>
                            <li>Unlimited pre-purchase messages</li>
                            <li>Premium Buyer badge on your reviews</li>
                        </ul>
                    </div>
                    <p><a href="<?php echo esc_url( home_url( '/services/' ) ); ?>" class="nme-btn nme-btn-gold">Browse Services →</a></p>
                </div>
            </div>
        </section>
        <?php
        return ob_get_clean();
    }

    /**
     * [nmep_my_premium] — buyer-facing "My Premium" account panel.
     * Shows current subscription status, expiry countdown, renewal CTA,
     * and a collapsible log of past contact reveals. Used on the
     * /my-account/premium/ page.
     */
    public static function render_my_premium( $atts ) {
        if ( ! is_user_logged_in() ) {
            $login = esc_url( wp_login_url( get_permalink() ) );
            return '<section class="nme-section"><div class="nme-container" style="max-width:720px;">
                <div class="nme-card">
                    <h2 style="margin-top:0;">My Premium</h2>
                    <p>Please <a href="' . $login . '">log in</a> to view your Premium Buyer status.</p>
                </div></div></section>';
        }

        $user     = wp_get_current_user();
        $active   = self::get_active_record( $user->ID );
        $duration = max( 1, (int) NMEP_Settings::get( 'premium_buyer_duration_days', 365 ) );
        $price    = (float) NMEP_Settings::get( 'premium_buyer_price', 499 );
        $disc_pct = rtrim( rtrim( number_format( (float) NMEP_Settings::get( 'premium_buyer_discount_percent', 5 ), 2 ), '0' ), '.' );

        // Most-recent record (active OR expired) — for showing "last paid" / renew context
        global $wpdb;
        $latest = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM " . self::table( 'buyer_premium' ) . "
             WHERE user_id = %d AND is_active = 1
             ORDER BY expires_at DESC LIMIT 1",
            (int) $user->ID
        ) );

        if ( $active ) {
            $state = 'active';
        } elseif ( $latest ) {
            $state = 'expired';
        } else {
            $state = 'none';
        }

        ob_start();
        ?>
        <section class="nme-section">
            <div class="nme-container" style="max-width: 820px;">

                <div class="nme-card" style="background: linear-gradient(135deg, #0F2419 0%, #0A7558 100%); color: #fff; padding: 32px; border-top: 6px solid #D4A843;">
                    <div style="font-size: 2.2rem; margin-bottom: 4px;">⭐</div>
                    <h1 style="color: #fff; margin: 0 0 4px; font-family: 'DM Serif Display', Georgia, serif;">My Premium</h1>
                    <p style="color: #D4A843; margin: 0;">Your Nagaland Me Premium Buyer account.</p>
                </div>

                <?php if ( $state === 'active' ) :
                    $days_left = max( 0, (int) floor( ( strtotime( $active->expires_at ) - time() ) / DAY_IN_SECONDS ) );
                ?>
                    <div class="nme-card nme-mt-3" style="border-left: 4px solid var(--nme-emerald, #10B981); background: #ECFDF5;">
                        <h3 style="margin-top:0;color:#065F46;">✓ Premium — Active</h3>
                        <p style="color:#065F46;margin:0;">
                            Your plan is active and expires on
                            <strong><?php echo esc_html( date( 'd M Y', strtotime( $active->expires_at ) ) ); ?></strong>
                            (<?php echo (int) $days_left; ?> day<?php echo $days_left === 1 ? '' : 's'; ?> left).
                        </p>
                    </div>

                    <div class="nme-card nme-mt-3">
                        <h3 style="margin-top:0;">Plan details</h3>
                        <table style="width:100%;border-collapse:collapse;">
                            <tr>
                                <td style="padding:10px 0;border-bottom:1px solid var(--nme-border,#E5E7EB);color:var(--nme-text-light,#6B7280);width:45%;">Started on</td>
                                <td style="padding:10px 0;border-bottom:1px solid var(--nme-border,#E5E7EB);"><strong><?php echo esc_html( date( 'd M Y', strtotime( $active->started_at ) ) ); ?></strong></td>
                            </tr>
                            <tr>
                                <td style="padding:10px 0;border-bottom:1px solid var(--nme-border,#E5E7EB);color:var(--nme-text-light,#6B7280);">Expires on</td>
                                <td style="padding:10px 0;border-bottom:1px solid var(--nme-border,#E5E7EB);"><strong><?php echo esc_html( date( 'd M Y', strtotime( $active->expires_at ) ) ); ?></strong></td>
                            </tr>
                            <tr>
                                <td style="padding:10px 0;border-bottom:1px solid var(--nme-border,#E5E7EB);color:var(--nme-text-light,#6B7280);">Last payment</td>
                                <td style="padding:10px 0;border-bottom:1px solid var(--nme-border,#E5E7EB);"><strong><?php echo nmep_format_inr( $active->amount_paid ); ?></strong></td>
                            </tr>
                            <tr>
                                <td style="padding:10px 0;color:var(--nme-text-light,#6B7280);">Auto-renewal</td>
                                <td style="padding:10px 0;">No — one-time payment only.</td>
                            </tr>
                        </table>
                    </div>

                    <div class="nme-card nme-mt-3">
                        <h3 style="margin-top:0;">Extend early</h3>
                        <p>Extend now and we'll add <?php echo (int) $duration; ?> more days starting from your current expiry.</p>
                        <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin-top:12px;">
                            <input type="hidden" name="action" value="nmep_premium_start_checkout">
                            <?php wp_nonce_field( 'nmep_premium_purchase', 'nmep_premium_nonce' ); ?>
                            <button type="submit" class="nme-btn nme-btn-gold">Extend Premium — <?php echo nmep_format_inr( $price ); ?></button>
                        </form>
                    </div>

                <?php elseif ( $state === 'expired' ) : ?>
                    <div class="nme-card nme-mt-3" style="border-left:4px solid #F59E0B;background:#FFFBEB;">
                        <h3 style="margin-top:0;color:#92400E;">Your Premium has expired</h3>
                        <p style="color:#92400E;margin:0;">
                            Your last plan expired on
                            <strong><?php echo esc_html( date( 'd M Y', strtotime( $latest->expires_at ) ) ); ?></strong>.
                            Renew below to restore your <?php echo esc_html( $disc_pct ); ?>% discount and contact-reveal access.
                        </p>
                    </div>

                    <div class="nme-card nme-mt-3 nme-text-center">
                        <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                            <input type="hidden" name="action" value="nmep_premium_start_checkout">
                            <?php wp_nonce_field( 'nmep_premium_purchase', 'nmep_premium_nonce' ); ?>
                            <button type="submit" class="nme-btn nme-btn-gold" style="font-size:1.05rem;padding:14px 36px;">
                                Renew Premium — <?php echo nmep_format_inr( $price ); ?>
                            </button>
                        </form>
                        <p style="font-size:0.85rem;color:var(--nme-text-light,#6B7280);margin-top:12px;">
                            🔒 Secure payment via Razorpay · No auto-renewal.
                        </p>
                    </div>

                <?php else : ?>
                    <div class="nme-card nme-mt-3">
                        <h3 style="margin-top:0;">You're not a Premium Buyer yet</h3>
                        <p>Get <strong><?php echo esc_html( $disc_pct ); ?>% off every order</strong>, see experts' phone and email, and message unlimited experts before hiring.</p>
                        <p style="margin-top:16px;">
                            <a href="<?php echo esc_url( self::landing_url() ); ?>" class="nme-btn nme-btn-gold">⭐ Learn more &amp; go Premium</a>
                        </p>
                    </div>
                <?php endif; ?>

                <?php
                // Reveal history (shown for anyone who has ever revealed a contact)
                $reveals = $wpdb->get_results( $wpdb->prepare(
                    "SELECT l.*, e.full_name AS expert_name
                     FROM " . self::table( 'phone_view_log' ) . " l
                     LEFT JOIN " . NMEP_Compat::base_table( 'experts' ) . " e ON e.id = l.expert_id
                     WHERE l.buyer_user_id = %d
                     ORDER BY l.id DESC
                     LIMIT 50",
                    (int) $user->ID
                ) );
                ?>
                <?php if ( ! empty( $reveals ) ) : ?>
                    <div class="nme-card nme-mt-3">
                        <details>
                            <summary style="cursor:pointer;font-weight:600;">
                                Recent contact reveals (<?php echo count( $reveals ); ?>)
                            </summary>
                            <p style="color:var(--nme-text-light,#6B7280);font-size:0.9rem;margin-top:12px;">
                                Every time you reveal an expert's phone or email, it's logged here. Useful if you want to find an expert you contacted earlier.
                            </p>
                            <table class="nme-table" style="width:100%;border-collapse:collapse;margin-top:12px;">
                                <thead>
                                    <tr style="text-align:left;border-bottom:1px solid var(--nme-border,#E5E7EB);">
                                        <th style="padding:8px 4px;">When</th>
                                        <th style="padding:8px 4px;">Expert</th>
                                        <th style="padding:8px 4px;">Type</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ( $reveals as $r ) : ?>
                                        <tr style="border-bottom:1px solid var(--nme-border,#E5E7EB);">
                                            <td style="padding:8px 4px;font-size:0.9rem;"><?php echo esc_html( date( 'd M Y H:i', strtotime( $r->created_at ) ) ); ?></td>
                                            <td style="padding:8px 4px;"><?php echo esc_html( $r->expert_name ?: ( '#' . (int) $r->expert_id ) ); ?></td>
                                            <td style="padding:8px 4px;"><code style="font-size:0.8rem;"><?php echo esc_html( $r->contact_type ); ?></code></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </details>
                    </div>
                <?php endif; ?>

            </div>
        </section>
        <?php
        return ob_get_clean();
    }

    public static function render_whistleblower_form( $atts ) {
        if ( ! is_user_logged_in() ) {
            return '<div class="nme-card"><p>Please <a href="' . esc_url( wp_login_url( get_permalink() ) ) . '">log in</a> to submit an off-platform activity report.</p></div>';
        }

        ob_start();
        if ( isset( $_GET['nmep_wb_submitted'] ) ) : ?>
            <div class="nme-card" style="border-left:4px solid var(--nme-emerald,#10B981);background:#ECFDF5;">
                <h3 style="margin-top:0;color:#065F46;">✓ Report received</h3>
                <p style="color:#065F46;">Thank you. Our team will review your report within 3 business days. If we approve it, you'll receive a <strong>Trusted Buyer</strong> badge and a permanent 3% discount on all future orders.</p>
            </div>
        <?php endif;

        if ( isset( $_GET['nmep_status'] ) && $_GET['nmep_status'] === 'error' && isset( $_GET['nmep_msg'] ) ) : ?>
            <div class="nme-card" style="border-left:4px solid #EF4444;background:#FEF2F2;">
                <p style="margin:0;color:#991B1B;">❌ <?php echo esc_html( urldecode( $_GET['nmep_msg'] ) ); ?></p>
            </div>
        <?php endif; ?>

        <div class="nme-card">
            <h2 style="margin-top:0;">Report Off-Platform Activity</h2>
            <p>If an expert tried to take payment or deliver work outside Nagaland Me Experts (WhatsApp, direct UPI, etc.), please tell us. Verified reports earn you a <strong>Trusted Buyer</strong> badge and a <strong>3% lifetime discount</strong> on all future orders.</p>
            <p style="background:#FEF3C7;border-left:3px solid #F59E0B;padding:10px 12px;border-radius:6px;font-size:0.9rem;">⚠️ False or malicious reports will result in your account being suspended. Please only submit if you have real evidence.</p>

            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                <input type="hidden" name="action" value="nmep_submit_whistleblower">
                <?php wp_nonce_field( 'nmep_submit_whistleblower', 'nmep_wb_nonce' ); ?>

                <p>
                    <label>Expert (optional — enter their Nagaland Me Expert ID or name)</label>
                    <input type="text" name="expert_name_or_id" maxlength="120" placeholder="e.g. 12 or Aloto Naga">
                    <small>If you know their expert ID (number), enter it; otherwise the name works.</small>
                </p>
                <p>
                    <label>Incident date</label>
                    <input type="date" name="incident_date" required>
                </p>
                <p>
                    <label>Amount involved (₹)</label>
                    <input type="number" name="amount_involved" min="1" step="1" placeholder="Optional">
                </p>
                <p>
                    <label>What happened? *</label>
                    <textarea name="description" rows="6" required minlength="30" maxlength="3000" placeholder="Describe the attempted/completed off-platform transaction in detail..."></textarea>
                    <small>Minimum 30 characters.</small>
                </p>
                <p>
                    <label>Evidence URLs * (one per line, up to 5)</label>
                    <textarea name="evidence_urls" rows="4" required placeholder="https://example.com/screenshot1.png&#10;https://drive.google.com/file/..."></textarea>
                    <small>Upload screenshots to Google Drive, Dropbox, or Imgur and paste the shareable links here. WhatsApp chat exports are also accepted.</small>
                </p>
                <p class="nme-mt-3">
                    <button type="submit" class="nme-btn nme-btn-gold">Submit Report</button>
                </p>
            </form>
        </div>
        <?php
        return ob_get_clean();
    }

    /* ============================================================
       BADGE RENDERERS (hook into existing filters)
       ============================================================ */

    public static function filter_review_badge( $html, $buyer_user_id ) {
        $buyer_user_id = (int) $buyer_user_id;
        if ( ! $buyer_user_id ) return $html;

        if ( self::is_premium( $buyer_user_id ) ) {
            $html .= ' <span title="Premium Buyer" style="display:inline-block;padding:2px 8px;margin-left:4px;border-radius:50px;font-size:0.65rem;font-weight:700;background:#D4A843;color:#fff;text-transform:uppercase;letter-spacing:0.05em;vertical-align:middle;">★ Premium</span>';
        }
        if ( self::is_trusted_buyer( $buyer_user_id ) ) {
            $html .= ' <span title="Trusted Buyer — verified" style="display:inline-block;padding:2px 8px;margin-left:4px;border-radius:50px;font-size:0.65rem;font-weight:700;background:#10B981;color:#fff;text-transform:uppercase;letter-spacing:0.05em;vertical-align:middle;">✓ Trusted</span>';
        }
        return $html;
    }

    public static function filter_expert_profile_noop( $html, $expert ) {
        // Reserved for future expert-side badges — no-op for now
        return $html;
    }

    /* ============================================================
       ADMIN UI
       ============================================================ */

    public static function register_admin_menu() {
        $pending_wb = self::count_pending_whistleblower();
        $wb_label   = 'Whistleblower';
        if ( $pending_wb > 0 ) {
            $wb_label .= ' <span class="awaiting-mod">' . $pending_wb . '</span>';
        }

        add_submenu_page(
            'nmep-dashboard', 'Premium Members', 'Premium Members',
            'manage_options', 'nmep-premium-members',
            array( __CLASS__, 'render_admin_premium_members' )
        );
        add_submenu_page(
            'nmep-dashboard', 'Whistleblower Reports', $wb_label,
            'manage_options', 'nmep-whistleblower',
            array( __CLASS__, 'render_admin_whistleblower' )
        );
        add_submenu_page(
            'nmep-dashboard', 'Contact Reveal Log', 'Contact Reveal Log',
            'manage_options', 'nmep-contact-log',
            array( __CLASS__, 'render_admin_contact_log' )
        );
    }

    private static function count_pending_whistleblower() {
        global $wpdb;
        $tbl = self::table( 'whistleblower' );
        // Table may not exist yet on first install — soft check
        $exists = $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $tbl ) );
        if ( ! $exists ) return 0;
        return (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM $tbl WHERE status = %s", self::WB_STATUS_PENDING
        ) );
    }

    public static function render_admin_premium_members() {
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Permission denied.' );
        global $wpdb;
        $records = $wpdb->get_results(
            "SELECT * FROM " . self::table( 'buyer_premium' ) . "
             ORDER BY id DESC LIMIT 200"
        );
        $expiring_count = self::stats_expiring_30d();

        $csv_url = wp_nonce_url(
            admin_url( 'admin-post.php?action=nmep_export_premium_expiring' ),
            'nmep_export_premium_expiring'
        );
        ?>
        <div class="wrap nmep-admin">
            <h1 class="wp-heading-inline">Premium Members</h1>
            <a href="<?php echo esc_url( $csv_url ); ?>" class="page-title-action">
                ⬇ Export Expiring (<?php echo (int) $expiring_count; ?>) CSV
            </a>
            <hr class="wp-header-end">
            <p>All buyer premium purchases. Showing latest 200. The CSV export covers everyone whose subscription expires in the next 30 days.</p>
            <table class="wp-list-table widefat fixed striped">
                <thead><tr>
                    <th>Name</th><th>Email</th><th>Amount</th><th>Started</th><th>Expires</th><th>Status</th><th>Razorpay ID</th>
                </tr></thead>
                <tbody>
                    <?php if ( empty( $records ) ) : ?>
                        <tr><td colspan="7" style="text-align:center;padding:40px;">No premium members yet.</td></tr>
                    <?php else : foreach ( $records as $r ) :
                        $is_current_active = $r->is_active && strtotime( $r->expires_at ) > time();
                        $status_html = $is_current_active
                            ? '<span style="color:#10B981;font-weight:600;">Active</span>'
                            : ( $r->is_active ? '<span style="color:#D63638;">Expired</span>' : '<span style="color:#6B7280;">Pending/Failed</span>' );
                    ?>
                        <tr>
                            <td><strong><?php echo esc_html( $r->full_name ); ?></strong></td>
                            <td><?php echo esc_html( $r->email ); ?></td>
                            <td><?php echo nmep_format_inr( $r->amount_paid ); ?></td>
                            <td><?php echo esc_html( date( 'd M Y', strtotime( $r->started_at ) ) ); ?></td>
                            <td><?php echo esc_html( date( 'd M Y', strtotime( $r->expires_at ) ) ); ?></td>
                            <td><?php echo $status_html; ?></td>
                            <td><code style="font-size:0.8rem;"><?php echo esc_html( $r->razorpay_payment_id ?: $r->razorpay_order_id ?: '—' ); ?></code></td>
                        </tr>
                    <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
        <?php
    }

    public static function render_admin_whistleblower() {
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Permission denied.' );

        if ( isset( $_GET['approved'] ) ) {
            echo '<div class="notice notice-success is-dismissible"><p>Report approved — reporter granted Trusted Buyer badge.</p></div>';
        }
        if ( isset( $_GET['rejected'] ) ) {
            echo '<div class="notice notice-success is-dismissible"><p>Report rejected.</p></div>';
        }

        $status = isset( $_GET['wb_status'] ) ? sanitize_key( $_GET['wb_status'] ) : self::WB_STATUS_PENDING;
        global $wpdb;
        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM " . self::table( 'whistleblower' ) . "
             WHERE status = %s ORDER BY id DESC LIMIT 100",
            $status
        ) );

        ?>
        <div class="wrap nmep-admin">
            <h1>Whistleblower Reports</h1>
            <ul class="subsubsub">
                <?php foreach ( array( 'pending' => 'Pending', 'approved' => 'Approved', 'rejected' => 'Rejected' ) as $k => $lbl ) : ?>
                    <li><a href="?page=nmep-whistleblower&wb_status=<?php echo esc_attr( $k ); ?>" <?php echo $status === $k ? 'class="current"' : ''; ?>><?php echo esc_html( $lbl ); ?></a> <?php echo $k !== 'rejected' ? '|' : ''; ?></li>
                <?php endforeach; ?>
            </ul>

            <?php if ( empty( $rows ) ) : ?>
                <div class="nmep-section nmep-text-center"><h3>No reports in this category.</h3></div>
            <?php else : foreach ( $rows as $r ) :
                $urls = ! empty( $r->evidence_urls ) ? json_decode( $r->evidence_urls, true ) : array();
            ?>
                <div class="nmep-section" style="border-left:4px solid #F59E0B;">
                    <div style="display:flex;justify-content:space-between;flex-wrap:wrap;gap:16px;">
                        <div style="flex:1;min-width:300px;">
                            <h3 style="margin-top:0;">Report #<?php echo (int) $r->id; ?> — against <?php echo esc_html( $r->expert_name_snapshot ?: 'unnamed expert' ); ?></h3>
                            <p>
                                <strong>Reporter:</strong> <?php echo esc_html( $r->reporter_name ); ?> (<?php echo esc_html( $r->reporter_email ); ?>)<br>
                                <strong>Submitted:</strong> <?php echo esc_html( date( 'd M Y H:i', strtotime( $r->created_at ) ) ); ?><br>
                                <?php if ( $r->incident_date ) : ?><strong>Incident date:</strong> <?php echo esc_html( $r->incident_date ); ?><br><?php endif; ?>
                                <?php if ( $r->amount_involved ) : ?><strong>Amount involved:</strong> <?php echo nmep_format_inr( $r->amount_involved ); ?><br><?php endif; ?>
                            </p>
                            <h4>Description:</h4>
                            <div style="background:#F9FAFB;padding:12px;border-radius:8px;white-space:pre-line;"><?php echo esc_html( $r->description ); ?></div>
                            <h4>Evidence:</h4>
                            <?php if ( empty( $urls ) ) : ?><p>No URLs provided.</p><?php else : ?>
                                <ul>
                                    <?php foreach ( $urls as $u ) : ?>
                                        <li><a href="<?php echo esc_url( $u ); ?>" target="_blank" rel="noopener"><?php echo esc_html( $u ); ?></a></li>
                                    <?php endforeach; ?>
                                </ul>
                            <?php endif; ?>
                            <?php if ( ! empty( $r->admin_notes ) ) : ?>
                                <h4>Admin notes:</h4>
                                <div style="background:#FFFBEB;padding:10px;border-radius:8px;white-space:pre-line;"><?php echo esc_html( $r->admin_notes ); ?></div>
                            <?php endif; ?>
                        </div>

                        <?php if ( $r->status === self::WB_STATUS_PENDING ) : ?>
                        <div style="width:320px;min-width:280px;">
                            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="background:#F9FAFB;padding:16px;border-radius:8px;">
                                <input type="hidden" name="action" value="nmep_admin_approve_whistleblower">
                                <input type="hidden" name="report_id" value="<?php echo (int) $r->id; ?>">
                                <?php wp_nonce_field( 'nmep_admin_wb_' . $r->id ); ?>
                                <h4 style="margin-top:0;">Approve</h4>
                                <p style="font-size:0.9rem;">Grants Trusted Buyer badge + 3% lifetime discount to the reporter.</p>
                                <p><textarea name="admin_notes" rows="3" placeholder="Internal notes (optional)" style="width:100%;"></textarea></p>
                                <button type="submit" class="button button-primary" onclick="return confirm('Approve this report and grant Trusted Buyer status?');">✓ Approve</button>
                            </form>
                            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="background:#FEF2F2;padding:16px;border-radius:8px;margin-top:8px;">
                                <input type="hidden" name="action" value="nmep_admin_reject_whistleblower">
                                <input type="hidden" name="report_id" value="<?php echo (int) $r->id; ?>">
                                <?php wp_nonce_field( 'nmep_admin_wb_' . $r->id ); ?>
                                <h4 style="margin-top:0;">Reject</h4>
                                <p><textarea name="admin_notes" rows="3" placeholder="Reason (internal)" style="width:100%;" required></textarea></p>
                                <button type="submit" class="button" style="color:#D63638;" onclick="return confirm('Reject this report?');">✗ Reject</button>
                            </form>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; endif; ?>
        </div>
        <?php
    }

    public static function render_admin_contact_log() {
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Permission denied.' );
        global $wpdb;
        $rows = $wpdb->get_results(
            "SELECT l.*, e.full_name AS expert_name, e.phone AS expert_phone
             FROM " . self::table( 'phone_view_log' ) . " l
             LEFT JOIN " . NMEP_Compat::base_table( 'experts' ) . " e ON e.id = l.expert_id
             ORDER BY l.id DESC LIMIT 200"
        );
        ?>
        <div class="wrap nmep-admin">
            <h1>Contact Reveal Log</h1>
            <p>Every time a premium buyer reveals an expert's phone or email, it's logged here. Use this for abuse investigations.</p>
            <table class="wp-list-table widefat fixed striped">
                <thead><tr>
                    <th>When</th><th>Buyer</th><th>Expert</th><th>Type</th><th>Source</th><th>IP</th>
                </tr></thead>
                <tbody>
                    <?php if ( empty( $rows ) ) : ?>
                        <tr><td colspan="6" style="text-align:center;padding:40px;">No reveals logged yet.</td></tr>
                    <?php else : foreach ( $rows as $r ) : ?>
                        <tr>
                            <td><?php echo esc_html( date( 'd M Y H:i', strtotime( $r->created_at ) ) ); ?></td>
                            <td><?php echo esc_html( $r->buyer_email ?: '#' . (int) $r->buyer_user_id ); ?></td>
                            <td><?php echo esc_html( $r->expert_name ?: '#' . (int) $r->expert_id ); ?></td>
                            <td><code><?php echo esc_html( $r->contact_type ); ?></code></td>
                            <td><?php echo esc_html( $r->reveal_source ); ?></td>
                            <td><code style="font-size:0.8rem;"><?php echo esc_html( $r->ip_address ?: '—' ); ?></code></td>
                        </tr>
                    <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
        <?php
    }

    public static function handle_admin_approve_whistleblower() {
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Permission denied.' );
        $id = isset( $_POST['report_id'] ) ? (int) $_POST['report_id'] : 0;
        check_admin_referer( 'nmep_admin_wb_' . $id );

        global $wpdb;
        $r = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM " . self::table( 'whistleblower' ) . " WHERE id = %d", $id ) );
        if ( ! $r || $r->status !== self::WB_STATUS_PENDING ) {
            wp_safe_redirect( admin_url( 'admin.php?page=nmep-whistleblower' ) );
            exit;
        }

        $wpdb->update(
            self::table( 'whistleblower' ),
            array(
                'status'       => self::WB_STATUS_APPROVED,
                'reviewed_by'  => get_current_user_id(),
                'reviewed_at'  => current_time( 'mysql' ),
                'admin_notes'  => sanitize_textarea_field( $_POST['admin_notes'] ?? '' ),
            ),
            array( 'id' => $id )
        );

        // Grant trusted buyer status
        self::mark_trusted_buyer( (int) $r->reporter_user_id );

        NMEP_Logger::info( 'Whistleblower approved, Trusted Buyer granted', array(
            'report_id'        => $id,
            'reporter_user_id' => $r->reporter_user_id,
        ) );

        if ( class_exists( 'NMEP_Compat' ) ) {
            NMEP_Compat::audit_log( 'whistleblower_approved', 'whistleblower', $id, array(
                'reporter_user_id' => $r->reporter_user_id,
            ) );
        }

        self::send_trusted_buyer_email( $r );

        wp_safe_redirect( admin_url( 'admin.php?page=nmep-whistleblower&approved=1' ) );
        exit;
    }

    public static function handle_admin_reject_whistleblower() {
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Permission denied.' );
        $id = isset( $_POST['report_id'] ) ? (int) $_POST['report_id'] : 0;
        check_admin_referer( 'nmep_admin_wb_' . $id );

        global $wpdb;
        $wpdb->update(
            self::table( 'whistleblower' ),
            array(
                'status'       => self::WB_STATUS_REJECTED,
                'reviewed_by'  => get_current_user_id(),
                'reviewed_at'  => current_time( 'mysql' ),
                'admin_notes'  => sanitize_textarea_field( $_POST['admin_notes'] ?? '' ),
            ),
            array( 'id' => $id )
        );

        if ( class_exists( 'NMEP_Compat' ) ) {
            NMEP_Compat::audit_log( 'whistleblower_rejected', 'whistleblower', $id, array() );
        }

        wp_safe_redirect( admin_url( 'admin.php?page=nmep-whistleblower&rejected=1' ) );
        exit;
    }

    /* ============================================================
       CRON — daily expiry + pre-expiry reminders
       ============================================================ */

    public static function cron_daily() {
        global $wpdb;

        // 1. Soft-expire records that have passed expiry (is_active stays 1 for history,
        //    but get_active_record() also checks expires_at > NOW, so they naturally stop
        //    applying discounts). We don't flip is_active so the purchase record is preserved.

        // 2. Send "expiring soon" email to anyone whose subscription expires in 7 days (±12h window)
        $rows = $wpdb->get_results(
            "SELECT * FROM " . self::table( 'buyer_premium' ) . "
             WHERE is_active = 1
               AND expires_at BETWEEN DATE_ADD(UTC_TIMESTAMP(), INTERVAL 6 DAY 12 HOUR)
                                  AND DATE_ADD(UTC_TIMESTAMP(), INTERVAL 7 DAY 12 HOUR)"
        );
        foreach ( $rows as $r ) {
            self::send_expiring_email( $r );
        }

        // 3. v0.7.4 — Purge contact-reveal log entries older than 90 days.
        //    The log exists for abuse investigations; keeping older rows indefinitely is
        //    both a GDPR exposure and a noisy table for no operational value. 90 days is
        //    wide enough to investigate any reported off-platform activity while still
        //    honouring data-minimisation. Soft-guarded by table_exists() because the log
        //    table may not be created yet on a fresh install.
        $log_tbl = self::table( 'phone_view_log' );
        if ( self::table_exists( $log_tbl ) ) {
            $deleted = (int) $wpdb->query(
                "DELETE FROM $log_tbl
                 WHERE created_at < DATE_SUB(UTC_TIMESTAMP(), INTERVAL 90 DAY)"
            );
            if ( $deleted > 0 && class_exists( 'NMEP_Logger' ) ) {
                NMEP_Logger::info( 'Premium reveal log purged', array( 'deleted_rows' => $deleted ) );
            }
        }
    }

    /* ============================================================
       CEO DASHBOARD STATS (Phase 2)
       ------------------------------------------------------------
       All methods are defensive about missing tables on fresh
       installs — the premium table may not exist until after the
       first maybe_migrate() run, and the orders table may not be
       populated on a brand-new site. Every accessor returns a
       safe zero on missing tables so the dashboard never fatals.
       ============================================================ */

    /**
     * Returns true if a named table exists. Cached per-request so
     * four stats queries don't fire four SHOW TABLES.
     */
    private static function table_exists( $table ) {
        static $cache = array();
        if ( isset( $cache[ $table ] ) ) {
            return $cache[ $table ];
        }
        global $wpdb;
        $found = (string) $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $table ) );
        return $cache[ $table ] = ( $found === $table );
    }

    /**
     * Active subscribers now and at start of the current month,
     * plus month-over-month delta.
     *
     * @return array{current:int,last_month:int,delta:int}
     */
    public static function stats_active_subscribers() {
        $out = array( 'current' => 0, 'last_month' => 0, 'delta' => 0 );
        $tbl = self::table( 'buyer_premium' );
        if ( ! self::table_exists( $tbl ) ) {
            return $out;
        }

        global $wpdb;
        $current = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM $tbl WHERE is_active = 1 AND expires_at > UTC_TIMESTAMP()"
        );

        // "Last month" = how many subs were active one month ago, i.e. records that had
        // already started and hadn't yet expired as of (UTC_TIMESTAMP() - 1 month). Compared
        // against today's count this gives MoM change. This is an approximation — we don't
        // snapshot historical counts, but it's cheap and directionally accurate.
        $last_month = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM $tbl
             WHERE is_active = 1
               AND started_at <= DATE_SUB(UTC_TIMESTAMP(), INTERVAL 1 MONTH)
               AND expires_at >  DATE_SUB(UTC_TIMESTAMP(), INTERVAL 1 MONTH)"
        );

        $out['current']    = $current;
        $out['last_month'] = $last_month;
        $out['delta']      = $current - $last_month;
        return $out;
    }

    /**
     * Revenue captured this calendar month (INR). Only counts activated (paid)
     * subscriptions — pending rows left behind by dropped checkouts are excluded.
     */
    public static function stats_revenue_this_month() {
        $tbl = self::table( 'buyer_premium' );
        if ( ! self::table_exists( $tbl ) ) {
            return 0.0;
        }
        global $wpdb;
        return (float) $wpdb->get_var(
            "SELECT COALESCE(SUM(amount_paid), 0) FROM $tbl
             WHERE is_active = 1
               AND YEAR(created_at)  = YEAR(UTC_TIMESTAMP())
               AND MONTH(created_at) = MONTH(UTC_TIMESTAMP())"
        );
    }

    /**
     * Gross merchandise value from orders placed by active Premium Buyers
     * within the last 30 days. Guest-checkout orders (no buyer_user_id)
     * are necessarily excluded.
     */
    public static function stats_premium_gmv_30d() {
        $pt = self::table( 'buyer_premium' );
        $ot = NMEP_Database::table( 'orders' );
        if ( ! self::table_exists( $pt ) || ! self::table_exists( $ot ) ) {
            return 0.0;
        }
        global $wpdb;
        // Join against a DISTINCT user_id subquery rather than the raw
        // buyer_premium table. A buyer with more than one is_active=1 row
        // (renewals, or stale rows never flipped off) would otherwise cause
        // each of their orders to be summed once per matching premium row —
        // inflating GMV by an unpredictable multiple.
        return (float) $wpdb->get_var(
            "SELECT COALESCE(SUM(o.gross_amount), 0)
             FROM $ot o
             INNER JOIN (
                SELECT DISTINCT user_id FROM $pt WHERE is_active = 1
             ) p ON p.user_id = o.buyer_user_id
             WHERE o.payment_status = 'captured'
               AND o.paid_at >= DATE_SUB(UTC_TIMESTAMP(), INTERVAL 30 DAY)"
        );
    }

    /**
     * Number of active subscriptions expiring within the next 30 days.
     * Drives the CSV export link on the dashboard.
     */
    public static function stats_expiring_30d() {
        $tbl = self::table( 'buyer_premium' );
        if ( ! self::table_exists( $tbl ) ) {
            return 0;
        }
        global $wpdb;
        return (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM $tbl
             WHERE is_active = 1
               AND expires_at BETWEEN UTC_TIMESTAMP()
                                  AND DATE_ADD(UTC_TIMESTAMP(), INTERVAL 30 DAY)"
        );
    }

    /**
     * Records of subscriptions expiring within the next 30 days, newest-expiry first.
     * Used by the CSV export handler.
     */
    public static function get_expiring_rows_30d() {
        $tbl = self::table( 'buyer_premium' );
        if ( ! self::table_exists( $tbl ) ) {
            return array();
        }
        global $wpdb;
        return $wpdb->get_results(
            "SELECT id, user_id, email, full_name, started_at, expires_at,
                    amount_paid, currency, razorpay_payment_id
             FROM $tbl
             WHERE is_active = 1
               AND expires_at BETWEEN UTC_TIMESTAMP()
                                  AND DATE_ADD(UTC_TIMESTAMP(), INTERVAL 30 DAY)
             ORDER BY expires_at ASC"
        );
    }

    /* ============================================================
       CSV EXPORT — expiring-soon subscriptions
       ============================================================ */

    /**
     * Neutralises CSV injection: Excel/Calc treat cells starting with =, +, -, @
     * as formulas. Prefix a single quote so they render as literal text.
     */
    private static function csv_safe( $value ) {
        $value = (string) $value;
        if ( $value === '' ) return '';
        $first = $value[0];
        if ( $first === '=' || $first === '+' || $first === '-' || $first === '@' ) {
            return "'" . $value;
        }
        return $value;
    }

    public static function handle_export_expiring_csv() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( 'Permission denied.', 403 );
        }
        check_admin_referer( 'nmep_export_premium_expiring' );

        $rows = self::get_expiring_rows_30d();

        // Close any buffered output before streaming CSV.
        while ( ob_get_level() > 0 ) {
            ob_end_clean();
        }
        nocache_headers();
        $filename = 'premium-expiring-' . date( 'Y-m-d' ) . '.csv';
        header( 'Content-Type: text/csv; charset=UTF-8' );
        header( 'Content-Disposition: attachment; filename="' . $filename . '"' );

        $out = fopen( 'php://output', 'w' );
        // UTF-8 BOM so Excel on Windows renders ₹ and diacritics correctly.
        fwrite( $out, "\xEF\xBB\xBF" );

        fputcsv( $out, array(
            'id', 'user_id', 'email', 'full_name',
            'started_at_utc', 'expires_at_utc', 'days_left',
            'amount_paid', 'currency', 'razorpay_payment_id',
        ) );

        $now = time();
        foreach ( $rows as $r ) {
            $days_left = (int) floor( ( strtotime( $r->expires_at ) - $now ) / DAY_IN_SECONDS );
            fputcsv( $out, array(
                self::csv_safe( $r->id ),
                self::csv_safe( $r->user_id ),
                self::csv_safe( $r->email ),
                self::csv_safe( $r->full_name ),
                self::csv_safe( $r->started_at ),
                self::csv_safe( $r->expires_at ),
                self::csv_safe( $days_left ),
                self::csv_safe( $r->amount_paid ),
                self::csv_safe( $r->currency ),
                self::csv_safe( $r->razorpay_payment_id ),
            ) );
        }
        fclose( $out );

        NMEP_Logger::info( 'Premium expiring CSV exported', array(
            'rows'    => count( $rows ),
            'user_id' => get_current_user_id(),
        ) );
        exit;
    }

    /* ============================================================
       EMAILS (self-contained; do not require NMEP_Emails class changes)
       ============================================================ */

    private static function email_wrap( $title, $body_html, $cta_text = '', $cta_url = '' ) {
        $merchant = NMEP_Settings::get( 'merchant_name', 'Nagaland Me Experts' );
        $support  = NMEP_Settings::get( 'support_email', 'info@nagaland.me' );
        $color    = NMEP_Settings::get( 'theme_color', '#0F2419' );
        $year     = date( 'Y' );
        $home     = esc_url( home_url( '/' ) );

        $cta_html = '';
        if ( $cta_text && $cta_url ) {
            $cta_html = '<table cellpadding="0" cellspacing="0" border="0" style="margin:24px auto;"><tr><td style="background:#D4A843;border-radius:50px;"><a href="' . esc_url( $cta_url ) . '" style="display:inline-block;padding:14px 32px;color:' . esc_attr( $color ) . ';text-decoration:none;font-weight:700;font-family:Arial,sans-serif;">' . esc_html( $cta_text ) . '</a></td></tr></table>';
        }

        return '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>' . esc_html( $title ) . '</title></head>
<body style="margin:0;padding:0;background:#F5F2E8;font-family:Arial,Helvetica,sans-serif;color:#1F2937;">
<table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:#F5F2E8;padding:30px 20px;">
<tr><td align="center">
<table width="600" cellpadding="0" cellspacing="0" border="0" style="max-width:600px;background:#FFFFFF;border-radius:12px;overflow:hidden;">
<tr><td style="background:' . esc_attr( $color ) . ';padding:24px;text-align:center;color:#fff;font-size:1.3rem;font-family:Georgia,serif;">' . esc_html( $merchant ) . '</td></tr>
<tr><td style="padding:32px 28px;">
<h1 style="color:' . esc_attr( $color ) . ';font-family:Georgia,serif;font-size:24px;margin:0 0 16px;">' . esc_html( $title ) . '</h1>
<div style="font-size:15px;line-height:1.6;color:#374151;">' . $body_html . '</div>' . $cta_html . '
</td></tr>
<tr><td style="background:#F9FAFB;padding:20px 28px;border-top:1px solid #E5E7EB;text-align:center;font-size:13px;color:#6B7280;">
<p style="margin:0 0 6px;">Need help? Email <a href="mailto:' . esc_attr( $support ) . '" style="color:' . esc_attr( $color ) . ';">' . esc_html( $support ) . '</a></p>
<p style="margin:0;">© ' . $year . ' ' . esc_html( $merchant ) . ' — <a href="' . $home . '" style="color:#6B7280;">' . esc_html( preg_replace( '#^https?://(www\.)?#', '', $home ) ) . '</a></p>
</td></tr>
</table></td></tr></table></body></html>';
    }

    private static function email_headers() {
        $support = NMEP_Settings::get( 'support_email', 'info@nagaland.me' );
        $name    = NMEP_Settings::get( 'merchant_name', 'Nagaland Me Experts' );
        return array(
            'From: ' . $name . ' <' . $support . '>',
            'Content-Type: text/html; charset=UTF-8',
            'Reply-To: ' . $support,
        );
    }

    public static function send_welcome_email( $record ) {
        if ( ! $record || empty( $record->email ) ) return false;
        $expires = date( 'd M Y', strtotime( $record->expires_at ) );
        $pct     = (float) NMEP_Settings::get( 'premium_buyer_discount_percent', 5 );
        $body = '<p>Hi <strong>' . esc_html( $record->full_name ) . '</strong>,</p>
        <p>Thank you for joining <strong>Nagaland Me Premium</strong>! Your plan is active immediately and valid until <strong>' . esc_html( $expires ) . '</strong>.</p>
        <h3 style="color:#0F2419;margin-top:24px;">What\'s active now:</h3>
        <ul style="color:#374151;line-height:1.8;">
            <li><strong>' . esc_html( rtrim( rtrim( number_format( $pct, 2 ), '0' ), '.' ) ) . '% off every order</strong>, automatically applied at checkout.</li>
            <li><strong>Expert contact details visible</strong> on every expert profile.</li>
            <li><strong>Unlimited pre-purchase messages</strong> (free buyers get 5/day).</li>
            <li><strong>Premium Buyer badge</strong> on your reviews.</li>
        </ul>
        <p>Ready to start saving?</p>';
        $html = self::email_wrap( 'Welcome to Premium!', $body, 'Browse Services', home_url( '/services/' ) );
        $sent = wp_mail( $record->email, 'Welcome to Nagaland Me Premium!', $html, self::email_headers() );
        NMEP_Logger::info( 'Premium welcome email sent', array( 'user_id' => $record->user_id, 'sent' => $sent ) );
        return $sent;
    }

    public static function send_expiring_email( $record ) {
        if ( ! $record || empty( $record->email ) ) return false;
        $expires = date( 'd M Y', strtotime( $record->expires_at ) );
        $body = '<p>Hi <strong>' . esc_html( $record->full_name ) . '</strong>,</p>
        <p>Your <strong>Nagaland Me Premium</strong> plan expires on <strong>' . esc_html( $expires ) . '</strong> (in about a week).</p>
        <p>Renew now to keep your automatic discount, unlimited messaging, and contact reveal privileges without interruption. No auto-renewal — renewal is always a one-time payment.</p>';
        $html = self::email_wrap( 'Your Premium plan expires soon', $body, 'Renew Now', self::landing_url() );
        $sent = wp_mail( $record->email, 'Your Nagaland Me Premium plan expires in 7 days', $html, self::email_headers() );
        NMEP_Logger::info( 'Premium expiring email sent', array( 'user_id' => $record->user_id, 'sent' => $sent ) );
        return $sent;
    }

    public static function send_trusted_buyer_email( $report ) {
        if ( ! $report || empty( $report->reporter_email ) ) return false;
        $pct = (float) NMEP_Settings::get( 'premium_buyer_trusted_discount_percent', 3 );
        $body = '<p>Hi <strong>' . esc_html( $report->reporter_name ) . '</strong>,</p>
        <p>Thank you for reporting suspected off-platform activity. After careful review, we\'ve approved your report.</p>
        <p>As a thank-you for helping keep Nagaland Me Experts trustworthy, you\'ve been awarded:</p>
        <ul style="color:#374151;line-height:1.8;">
            <li><strong>Trusted Buyer badge</strong> — permanently shown next to your name in reviews.</li>
            <li><strong>' . esc_html( rtrim( rtrim( number_format( $pct, 2 ), '0' ), '.' ) ) . '% lifetime discount</strong> on every order you place, stacking with any other offers.</li>
        </ul>
        <p>The discount is auto-applied at checkout — no code needed.</p>';
        $html = self::email_wrap( 'You\'re now a Trusted Buyer ✓', $body, 'Browse Services', home_url( '/services/' ) );
        $sent = wp_mail( $report->reporter_email, 'You\'re now a Trusted Buyer on Nagaland Me', $html, self::email_headers() );
        NMEP_Logger::info( 'Trusted Buyer email sent', array( 'user_id' => $report->reporter_user_id, 'sent' => $sent ) );
        return $sent;
    }

    private static function notify_admin_of_whistleblower( $report_id, $user, $expert_name, $description, $urls ) {
        $admin_email = get_option( 'admin_email' );
        if ( ! $admin_email ) return;

        $review_url = admin_url( 'admin.php?page=nmep-whistleblower' );
        $body = '<p>A new off-platform activity report has been submitted.</p>
        <p><strong>Reporter:</strong> ' . esc_html( $user->display_name ) . ' (' . esc_html( $user->user_email ) . ')<br>
        <strong>Expert:</strong> ' . esc_html( $expert_name ?: '—' ) . '</p>
        <h4>Description:</h4>
        <div style="background:#F9FAFB;padding:12px;border-radius:6px;white-space:pre-line;">' . esc_html( mb_substr( $description, 0, 500 ) ) . '</div>
        <p><strong>Evidence URLs:</strong> ' . count( $urls ) . ' provided.</p>';
        $html = self::email_wrap( 'New whistleblower report', $body, 'Review in Admin', $review_url );
        wp_mail( $admin_email, '[Nagaland Me] New whistleblower report #' . $report_id, $html, self::email_headers() );
    }

    /* ============================================================
       URL HELPERS
       ============================================================ */

    public static function landing_url() {
        // The premium landing page should have the [nmep_buyer_premium] shortcode.
        // Site owners should create a page with slug /buyer-premium/ that contains it.
        $page = get_page_by_path( 'buyer-premium' );
        if ( $page ) {
            return get_permalink( $page );
        }
        return home_url( '/buyer-premium/' );
    }

    public static function whistleblower_url() {
        $page = get_page_by_path( 'report-expert' );
        if ( $page ) {
            return get_permalink( $page );
        }
        return home_url( '/report-expert/' );
    }

    private static function redirect_error( $message, $fallback_url = '' ) {
        $url = $fallback_url ?: self::landing_url();
        $url = add_query_arg( array(
            'nmep_status' => 'error',
            'nmep_msg'    => urlencode( $message ),
        ), $url );
        wp_safe_redirect( $url );
        exit;
    }
}