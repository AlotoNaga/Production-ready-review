<?php
/**
 * NMEP_Metrics
 *
 * Performance metrics for experts:
 *   - Response rate  (% of incoming buyer messages the expert replied to)
 *   - Avg response time (seconds between first buyer msg and expert reply)
 *   - Last-seen timestamp
 *   - Online status (online | away | offline with configurable away_message)
 *   - Order counters (total, completed, cancelled, on-time, late)
 *
 * Counters live in nmep_expert_metrics and are updated incrementally via
 * event listeners rather than by a periodic recompute — fast reads on the
 * expert dashboard and search card.
 *
 * @package NagalandMeExpertsPayments
 * @since   2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class NMEP_Metrics {

    const MODE_ONLINE  = 'online';
    const MODE_AWAY    = 'away';
    const MODE_OFFLINE = 'offline';

    public static function init() {
        // Order counters
        add_action( NMEP_Events::ORDER_CREATED,   array( __CLASS__, 'on_order_created' ),   10, 2 );
        add_action( NMEP_Events::ORDER_COMPLETED, array( __CLASS__, 'on_order_completed' ), 10 );
        add_action( NMEP_Events::ORDER_AUTO_RELEASED, array( __CLASS__, 'on_order_completed' ), 10 );
        add_action( NMEP_Events::ORDER_CANCELLED, array( __CLASS__, 'on_order_cancelled' ), 10, 1 );
        add_action( NMEP_Events::ORDER_DELIVERED, array( __CLASS__, 'on_order_delivered' ), 10 );

        // Response tracking
        add_action( NMEP_Events::MESSAGE_SENT, array( __CLASS__, 'on_message_sent' ), 10, 4 );

        // Expert heartbeat
        add_action( 'wp_login', array( __CLASS__, 'touch_expert_for_user' ), 10, 2 );
        add_action( 'wp_ajax_nmep_metrics_heartbeat', array( __CLASS__, 'ajax_heartbeat' ) );
        add_action( 'wp_ajax_nmep_metrics_set_mode',  array( __CLASS__, 'ajax_set_mode' ) );
    }

    /* ============================================================
       UPSERT / READ
       ============================================================ */

    public static function get( $expert_id ) {
        global $wpdb;
        $row = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM " . NMEP_Database::table( 'expert_metrics' ) . " WHERE expert_id = %d",
            (int) $expert_id
        ) );
        if ( ! $row ) {
            self::ensure_row( (int) $expert_id );
            return (object) array(
                'expert_id' => (int) $expert_id,
                'orders_total' => 0, 'orders_completed' => 0, 'orders_cancelled' => 0,
                'orders_delivered_on_time' => 0, 'orders_delivered_late' => 0,
                'response_count' => 0, 'response_total_seconds' => 0,
                'response_rate_percent' => 0, 'avg_response_seconds' => 0,
                'disputes_opened' => 0, 'disputes_lost' => 0,
                'current_tier' => NMEP_Tiers::TIER_NEW,
                'availability_mode' => self::MODE_OFFLINE,
                'last_seen_at' => null, 'away_message' => null,
                'tier_locked' => 0,
            );
        }
        return $row;
    }

    private static function ensure_row( $expert_id ) {
        global $wpdb;
        $exists = $wpdb->get_var( $wpdb->prepare(
            "SELECT expert_id FROM " . NMEP_Database::table( 'expert_metrics' ) . " WHERE expert_id = %d", $expert_id
        ) );
        if ( ! $exists ) {
            $wpdb->insert( NMEP_Database::table( 'expert_metrics' ), array( 'expert_id' => $expert_id ) );
        }
    }

    private static function bump( $expert_id, $field, $by = 1 ) {
        global $wpdb;
        self::ensure_row( $expert_id );
        $table = NMEP_Database::table( 'expert_metrics' );
        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
        $wpdb->query( $wpdb->prepare(
            "UPDATE `$table` SET `$field` = `$field` + %d WHERE expert_id = %d",
            (int) $by, (int) $expert_id
        ) );
    }

    /* ============================================================
       ORDER EVENT LISTENERS
       ============================================================ */

    public static function on_order_created( $order_id, $order = null ) {
        if ( ! $order ) $order = NMEP_Orders::get( $order_id );
        if ( ! $order ) return;
        self::bump( (int) $order->expert_id, 'orders_total' );
    }

    public static function on_order_completed( $order_id ) {
        $order = NMEP_Orders::get( $order_id );
        if ( ! $order ) return;
        self::bump( (int) $order->expert_id, 'orders_completed' );
    }

    public static function on_order_cancelled( $order_id ) {
        $order = NMEP_Orders::get( $order_id );
        if ( ! $order ) return;
        self::bump( (int) $order->expert_id, 'orders_cancelled' );
    }

    public static function on_order_delivered( $order_id ) {
        $order = NMEP_Orders::get( $order_id );
        if ( ! $order || ! $order->delivery_due_at ) return;

        $on_time = strtotime( $order->delivered_at ?: 'now' ) <= strtotime( $order->delivery_due_at );
        self::bump( (int) $order->expert_id, $on_time ? 'orders_delivered_on_time' : 'orders_delivered_late' );
    }

    /* ============================================================
       MESSAGE → RESPONSE TIME
       ============================================================ */

    /**
     * Fired by NMEP_Messages::create. Args: order_id, sender_role, message_id, order_object.
     * We track the *first* expert reply after *each* buyer message.
     */
    public static function on_message_sent( $order_id, $sender_role, $message_id = 0, $order = null ) {
        if ( $sender_role !== 'expert' ) return;
        if ( ! $order ) $order = NMEP_Orders::get( $order_id );
        if ( ! $order ) return;

        global $wpdb;
        $msgs_t = NMEP_Database::table( 'order_messages' );

        // Find the most recent buyer message BEFORE this expert message that has
        // not yet been answered. Simplest heuristic: last buyer message where no
        // expert message exists between it and now.
        $last_buyer = $wpdb->get_row( $wpdb->prepare(
            "SELECT id, created_at FROM $msgs_t
             WHERE order_id = %d AND sender_role = 'buyer'
             ORDER BY id DESC LIMIT 1",
            $order_id
        ) );
        if ( ! $last_buyer ) return;

        // Was there already an expert reply in between? If so, don't double-count.
        $already_answered = $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM $msgs_t
             WHERE order_id = %d AND sender_role = 'expert' AND id > %d AND id < %d",
            $order_id, (int) $last_buyer->id, (int) $message_id
        ) );
        if ( (int) $already_answered > 0 ) return;

        $seconds = max( 0, time() - strtotime( $last_buyer->created_at . ' UTC' ) );

        self::bump( (int) $order->expert_id, 'response_count' );
        global $wpdb;
        $table = NMEP_Database::table( 'expert_metrics' );
        $wpdb->query( $wpdb->prepare(
            "UPDATE $table
             SET response_total_seconds = response_total_seconds + %d,
                 avg_response_seconds   = CASE WHEN response_count > 0
                                              THEN (response_total_seconds + %d) / response_count
                                              ELSE %d END
             WHERE expert_id = %d",
            $seconds, $seconds, $seconds, (int) $order->expert_id
        ) );

        // Simple response-rate: # messages answered ÷ # buyer messages over lifetime.
        $buyer_total = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM $msgs_t m
             INNER JOIN " . NMEP_Database::table( 'orders' ) . " o ON o.id = m.order_id
             WHERE o.expert_id = %d AND m.sender_role = 'buyer'",
            (int) $order->expert_id
        ) );
        if ( $buyer_total > 0 ) {
            $current = (int) $wpdb->get_var( $wpdb->prepare(
                "SELECT response_count FROM $table WHERE expert_id = %d", (int) $order->expert_id
            ) );
            $pct = round( min( 100, ( $current / $buyer_total ) * 100 ), 2 );
            $wpdb->update( $table, array( 'response_rate_percent' => $pct ), array( 'expert_id' => (int) $order->expert_id ) );
        }
    }

    /* ============================================================
       ONLINE / AWAY / OFFLINE
       ============================================================ */

    public static function touch_expert_for_user( $user_login, $user ) {
        if ( ! class_exists( 'NMEP_Compat' ) ) return;
        $expert = NMEP_Compat::get_expert_by_user( (int) $user->ID );
        if ( ! $expert ) return;
        self::mark_seen( (int) $expert->id );
    }

    public static function mark_seen( $expert_id ) {
        global $wpdb;
        self::ensure_row( $expert_id );
        $wpdb->update( NMEP_Database::table( 'expert_metrics' ), array(
            'last_seen_at' => current_time( 'mysql' ),
        ), array( 'expert_id' => $expert_id ) );
    }

    public static function set_mode( $expert_id, $mode, $away_message = null ) {
        $mode = in_array( $mode, array( self::MODE_ONLINE, self::MODE_AWAY, self::MODE_OFFLINE ), true ) ? $mode : self::MODE_OFFLINE;
        global $wpdb;
        self::ensure_row( $expert_id );
        $wpdb->update( NMEP_Database::table( 'expert_metrics' ), array(
            'availability_mode' => $mode,
            'away_message'      => $away_message ? substr( (string) $away_message, 0, 200 ) : null,
            'last_seen_at'      => current_time( 'mysql' ),
        ), array( 'expert_id' => $expert_id ) );

        if ( $mode === self::MODE_ONLINE ) {
            NMEP_Events::emit( NMEP_Events::EXPERT_WENT_ONLINE, $expert_id );
        } elseif ( $mode === self::MODE_OFFLINE ) {
            NMEP_Events::emit( NMEP_Events::EXPERT_WENT_OFFLINE, $expert_id );
        }
    }

    public static function ajax_heartbeat() {
        if ( ! is_user_logged_in() ) wp_send_json_error( 'forbidden' );
        $expert = NMEP_Compat::get_expert_by_user( get_current_user_id() );
        if ( ! $expert ) wp_send_json_error( 'not_expert' );
        self::mark_seen( (int) $expert->id );
        wp_send_json_success();
    }

    public static function ajax_set_mode() {
        check_ajax_referer( 'nmep_ajax', 'nonce' );
        if ( ! is_user_logged_in() ) wp_send_json_error( 'forbidden' );
        $expert = NMEP_Compat::get_expert_by_user( get_current_user_id() );
        if ( ! $expert ) wp_send_json_error( 'not_expert' );
        self::set_mode( (int) $expert->id, sanitize_key( $_POST['mode'] ?? '' ), sanitize_text_field( $_POST['away_message'] ?? '' ) );
        wp_send_json_success();
    }

    /**
     * True if expert was seen in the last 2 minutes AND mode is online.
     */
    public static function is_online( $expert_id ) {
        $m = self::get( $expert_id );
        if ( $m->availability_mode !== self::MODE_ONLINE ) return false;
        if ( ! $m->last_seen_at ) return false;
        return ( time() - strtotime( $m->last_seen_at . ' UTC' ) ) <= 120;
    }

    public static function humanize_response_time( $seconds ) {
        $s = (int) $seconds;
        if ( $s < 60 ) return 'Under a minute';
        if ( $s < 3600 ) return round( $s / 60 ) . ' minutes';
        if ( $s < 86400 ) return round( $s / 3600, 1 ) . ' hours';
        return round( $s / 86400, 1 ) . ' days';
    }
}
