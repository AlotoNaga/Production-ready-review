<?php
/**
 * NMEP_GDPR
 *
 * Data export / erasure requests.
 *
 * Flow:
 *   1. Logged-in (or guest-via-email) user submits a request:
 *        POST /?nmep_gdpr_action=request with fields: type (export|erase), email
 *      → row inserted into nmep_gdpr_requests with a verification_token.
 *      → confirmation email sent with a one-click verify link.
 *   2. Clicking the link sets status='verified' and queues the job.
 *   3. WP-Cron nightly handler processes verified requests:
 *        - export: gather all personal data (orders, messages, reviews,
 *          linked-account details), write a JSON file, email a signed
 *          download URL, mark completed.
 *        - erase:  pseudonymise personal fields on orders, messages,
 *          reviews, linked accounts (retain tax-mandatory rows but scrub
 *          buyer_name/email/phone). Mark completed.
 *
 * This is scoped to the marketplace plugin's own tables — does NOT replace
 * WordPress's core privacy tools. Admins can still use Tools > Personal Data.
 *
 * @package NagalandMeExpertsPayments
 * @since   2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class NMEP_GDPR {

    const CRON_HOOK = 'nmep_gdpr_process';

    public static function init() {
        add_action( 'init', array( __CLASS__, 'register_endpoint' ) );
        add_action( self::CRON_HOOK, array( __CLASS__, 'process_pending' ) );

        if ( ! wp_next_scheduled( self::CRON_HOOK ) ) {
            wp_schedule_event( time() + 600, 'hourly', self::CRON_HOOK );
        }
    }

    /* ============================================================
       REQUEST SUBMISSION + EMAIL VERIFICATION
       ============================================================ */

    public static function register_endpoint() {
        add_rewrite_rule( '^nmep-gdpr/verify/([^/]+)/?$', 'index.php?nmep_gdpr_verify=$matches[1]', 'top' );
        add_rewrite_tag( '%nmep_gdpr_verify%', '([^&]+)' );
        add_action( 'template_redirect', array( __CLASS__, 'maybe_handle_request' ) );
    }

    public static function maybe_handle_request() {
        $action = isset( $_POST['nmep_gdpr_action'] ) ? sanitize_key( $_POST['nmep_gdpr_action'] ) : '';
        if ( $action === 'request' ) {
            self::handle_submit();
            return;
        }
        $token = get_query_var( 'nmep_gdpr_verify' );
        if ( $token ) {
            self::handle_verify( sanitize_text_field( $token ) );
        }
    }

    public static function handle_submit() {
        if ( ! isset( $_POST['_wpnonce'] ) || ! wp_verify_nonce( $_POST['_wpnonce'], 'nmep_gdpr' ) ) {
            wp_die( 'Invalid request.' );
        }
        $email = sanitize_email( $_POST['email'] ?? '' );
        $type  = sanitize_key( $_POST['type'] ?? 'export' );
        if ( ! is_email( $email ) || ! in_array( $type, array( 'export', 'erase' ), true ) ) {
            wp_die( 'Please provide a valid email and request type.' );
        }

        global $wpdb;
        $token = wp_generate_password( 40, false, false );
        $wpdb->insert( NMEP_Database::table( 'gdpr_requests' ), array(
            'user_id'     => is_user_logged_in() ? get_current_user_id() : null,
            'email'       => $email,
            'request_type'=> $type,
            'status'      => 'pending',
            'verification_token' => $token,
        ) );

        $verify_url = home_url( '/nmep-gdpr/verify/' . rawurlencode( $token ) . '/' );
        wp_mail( $email, 'Confirm your data request — Nagaland Me Experts',
            "Please confirm your $type request by clicking: $verify_url\n\nIf you did not submit this, ignore this email.",
            array( 'Content-Type: text/plain; charset=UTF-8' ) );

        wp_safe_redirect( add_query_arg( 'nmep_gdpr_submitted', 1, home_url( '/' ) ) );
        exit;
    }

    public static function handle_verify( $token ) {
        global $wpdb;
        $table = NMEP_Database::table( 'gdpr_requests' );
        $row = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM $table WHERE verification_token = %s AND status = 'pending' LIMIT 1", $token
        ) );
        if ( ! $row ) wp_die( 'Invalid or expired verification link.', 'Data request', array( 'response' => 410 ) );

        $wpdb->update( $table, array( 'status' => 'verified' ), array( 'id' => $row->id ) );
        echo '<p style="font-family:Inter,sans-serif; padding:24px;">Thank you — your '
            . esc_html( $row->request_type ) . ' request has been verified and is queued. '
            . 'We will email you once it is complete.</p>';
        exit;
    }

    /* ============================================================
       WORKER
       ============================================================ */

    public static function process_pending() {
        global $wpdb;
        $table = NMEP_Database::table( 'gdpr_requests' );
        $rows  = $wpdb->get_results(
            "SELECT * FROM $table WHERE status = 'verified' ORDER BY id ASC LIMIT 20"
        );
        foreach ( $rows as $r ) {
            if ( $r->request_type === 'export' ) {
                self::fulfil_export( $r );
            } elseif ( $r->request_type === 'erase' ) {
                self::fulfil_erase( $r );
            }
        }
    }

    private static function fulfil_export( $r ) {
        global $wpdb;
        $bundle = self::gather_personal_data( $r->email, (int) $r->user_id );
        $json   = wp_json_encode( $bundle, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE );

        $uploads = wp_upload_dir();
        $dir     = trailingslashit( $uploads['basedir'] ) . 'nmep-gdpr';
        if ( ! is_dir( $dir ) ) wp_mkdir_p( $dir );
        $file    = $dir . '/export-' . $r->id . '-' . wp_generate_password( 16, false ) . '.json';
        file_put_contents( $file, $json );
        $url     = str_replace( trailingslashit( $uploads['basedir'] ), trailingslashit( $uploads['baseurl'] ), $file );

        $wpdb->update( NMEP_Database::table( 'gdpr_requests' ), array(
            'status'       => 'completed',
            'export_url'   => $url,
            'completed_at' => current_time( 'mysql' ),
        ), array( 'id' => $r->id ) );

        wp_mail( $r->email, 'Your data export is ready — Nagaland Me Experts',
            "Your personal data export is ready:\n$url\n\nThis link is private — do not share it.",
            array( 'Content-Type: text/plain; charset=UTF-8' ) );

        NMEP_Compat::audit_log( 'gdpr_export_completed', 'user', (int) $r->user_id, array( 'request_id' => $r->id ) );
    }

    private static function fulfil_erase( $r ) {
        global $wpdb;
        $email = $r->email;

        // Pseudonymise buyer fields on orders; retain numeric / tax fields.
        $wpdb->update( NMEP_Database::table( 'orders' ),
            array( 'buyer_name' => 'Redacted', 'buyer_email' => 'redacted@example.invalid', 'buyer_phone' => null, 'buyer_requirements' => null ),
            array( 'buyer_email' => $email )
        );
        // Pseudonymise messages authored by this user
        $wpdb->query( $wpdb->prepare(
            "UPDATE " . NMEP_Database::table( 'order_messages' ) . "
             SET sender_name = 'Redacted', message = '[redacted]'
             WHERE sender_user_id = %d OR sender_name = %s",
            (int) $r->user_id, $email
        ) );
        // Reviews
        $wpdb->update( NMEP_Database::table( 'reviews' ),
            array( 'buyer_name' => 'Redacted', 'buyer_email' => 'redacted@example.invalid', 'comment' => '[redacted]' ),
            array( 'buyer_email' => $email )
        );
        // Linked accounts — preserve for tax audit but scrub PII
        $wpdb->update( NMEP_Database::table( 'linked_accounts' ),
            array( 'account_email' => 'redacted@example.invalid', 'account_phone' => null, 'account_holder_name' => 'Redacted' ),
            array( 'account_email' => $email )
        );

        $wpdb->update( NMEP_Database::table( 'gdpr_requests' ), array(
            'status'       => 'completed',
            'completed_at' => current_time( 'mysql' ),
        ), array( 'id' => $r->id ) );

        wp_mail( $email, 'Your erasure request is complete — Nagaland Me Experts',
            'Your personal data has been scrubbed from our active records. '
            . 'Tax-mandatory transactional records (invoice totals, dates) are retained per Indian GST regulations.',
            array( 'Content-Type: text/plain; charset=UTF-8' ) );

        NMEP_Compat::audit_log( 'gdpr_erasure_completed', 'user', (int) $r->user_id, array( 'request_id' => $r->id ) );
    }

    public static function gather_personal_data( $email, $user_id = 0 ) {
        global $wpdb;

        $orders = $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM " . NMEP_Database::table( 'orders' ) . " WHERE buyer_email = %s OR buyer_user_id = %d", $email, $user_id
        ), ARRAY_A );

        $reviews = $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM " . NMEP_Database::table( 'reviews' ) . " WHERE buyer_email = %s OR buyer_user_id = %d", $email, $user_id
        ), ARRAY_A );

        $messages = $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM " . NMEP_Database::table( 'order_messages' ) . " WHERE sender_user_id = %d OR sender_name = %s", $user_id, $email
        ), ARRAY_A );

        $linked = $wpdb->get_results( $wpdb->prepare(
            "SELECT id, expert_id, account_email, account_phone, account_holder_name, created_at
             FROM " . NMEP_Database::table( 'linked_accounts' ) . " WHERE account_email = %s", $email
        ), ARRAY_A );

        return array(
            'exported_at' => current_time( 'mysql' ),
            'email'       => $email,
            'user_id'     => (int) $user_id,
            'orders'      => $orders,
            'reviews'     => $reviews,
            'messages'    => $messages,
            'linked_accounts' => $linked,
        );
    }
}
