<?php
/**
 * NMEP_Expert_Profiles v2.1.0
 * Public-facing expert profile pages — SEO-optimized, cached, badge-ready.
 *
 * URL: /expert/{slug}/
 *
 * v2.1.0 — Adds Premium Buyer "Contact Expert" card (locked/unlocked).
 *   — Premium buyers: can reveal phone + email (every reveal is logged).
 *   — Non-premium (or guests): see an upgrade prompt with CTA to /buyer-premium/.
 *   — AJAX action 'nmep_reveal_contact' is provided by NMEP_Buyer_Premium.
 *
 * v2.0.0 UPGRADES:
 * 1. SLUG COLUMN — indexed DB lookup (no more scanning 500 rows)
 * 2. OBJECT CACHE — wp_cache + transient for hot expert lookups
 * 3. HIRE NOW CTA — smart button linking to first service or WhatsApp
 * 4. SEO HOOKS — proper Rank Math + WordPress title/meta integration
 * 5. PROPER EXIT — status_header(200) + nocache_headers
 * 6. BADGE HOOKS — apply_filters for nme-badges plugin integration
 *
 * @version 2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class NMEP_Expert_Profiles {

    /** @var string|null Stashed page title for SEO hooks */
    private static $seo_title = null;

    /** @var string|null Stashed meta description for SEO hooks */
    private static $seo_description = null;

    /** @var string|null Stashed canonical URL */
    private static $seo_canonical = null;

    /** @var string|null Stashed OG image */
    private static $seo_og_image = null;

    public static function init() {
        add_action( 'init', array( __CLASS__, 'register_rewrite' ) );
        add_filter( 'query_vars', array( __CLASS__, 'add_query_var' ) );
        add_action( 'template_redirect', array( __CLASS__, 'maybe_render_expert_profile' ) );

        // Self-healing slug migration (runs once, then never again)
        add_action( 'admin_init', array( __CLASS__, 'maybe_migrate_slugs' ), 5 );
    }

    /* ============================================================
       REWRITE RULES
       ============================================================ */
    public static function register_rewrite() {
        add_rewrite_rule(
            '^expert/([^/]+)/?$',
            'index.php?nmep_expert_slug=$matches[1]',
            'top'
        );
    }

    public static function add_query_var( $vars ) {
        $vars[] = 'nmep_expert_slug';
        return $vars;
    }

    /* ============================================================
       1. SLUG COLUMN — self-migrating indexed lookup
       Runs once on admin_init, adds slug column + populates it
       for all existing experts. Never runs again after completion.
       ============================================================ */
    public static function maybe_migrate_slugs() {
        if ( get_option( 'nmep_slugs_migrated', false ) ) return;

        global $wpdb;
        $table = NMEP_Compat::base_table( 'experts' );

        // Check if column exists
        $has_slug = $wpdb->get_var( "SHOW COLUMNS FROM $table LIKE 'slug'" );

        if ( ! $has_slug ) {
            $wpdb->query( "ALTER TABLE $table ADD COLUMN slug VARCHAR(120) DEFAULT NULL AFTER full_name" );
            $wpdb->query( "ALTER TABLE $table ADD UNIQUE KEY slug (slug)" );
        }

        // Populate slugs for all experts that don't have one
        $experts = $wpdb->get_results( "SELECT id, full_name FROM $table WHERE slug IS NULL OR slug = ''" );
        foreach ( $experts as $e ) {
            $slug = self::generate_unique_slug( $e->full_name, $e->id );
            $wpdb->update( $table, array( 'slug' => $slug ), array( 'id' => $e->id ) );
        }

        update_option( 'nmep_slugs_migrated', true );
        flush_rewrite_rules();
    }

    /**
     * Generate a unique slug from a name.
     * If "aloto-naga" is taken, tries "aloto-naga-2", "aloto-naga-3", etc.
     */
    public static function generate_unique_slug( $name, $exclude_id = 0 ) {
        global $wpdb;
        $table = NMEP_Compat::base_table( 'experts' );
        $base  = sanitize_title( $name );
        if ( empty( $base ) ) $base = 'expert';

        $slug = $base;
        $i    = 2;
        while ( true ) {
            $existing = $wpdb->get_var( $wpdb->prepare(
                "SELECT id FROM $table WHERE slug = %s AND id != %d LIMIT 1",
                $slug, (int) $exclude_id
            ) );
            if ( ! $existing ) break;
            $slug = $base . '-' . $i;
            $i++;
        }
        return $slug;
    }

    /* ============================================================
       SLUG HELPERS
       ============================================================ */
    public static function get_expert_slug( $expert ) {
        if ( ! $expert || ! is_object( $expert ) ) return '';
        if ( ! empty( $expert->slug ) ) return $expert->slug;
        return sanitize_title( $expert->full_name ?? '' );
    }

    public static function get_expert_url( $expert ) {
        return home_url( '/expert/' . self::get_expert_slug( $expert ) . '/' );
    }

    /* ============================================================
       2. CACHED EXPERT LOOKUP — indexed slug query + wp_cache
       ============================================================ */
    public static function get_expert_by_slug( $slug ) {
        if ( empty( $slug ) ) return null;

        $slug = sanitize_title( $slug );

        // Try object cache first (avoids DB hit on same request)
        $cache_key = 'nmep_expert_slug_' . $slug;
        $cached = wp_cache_get( $cache_key, 'nmep_experts' );
        if ( false !== $cached ) {
            return $cached ?: null; // cached empty string = not found
        }

        global $wpdb;
        $table = NMEP_Compat::base_table( 'experts' );

        // Primary: indexed slug column (O(1) lookup)
        $has_slug = $wpdb->get_var( "SHOW COLUMNS FROM $table LIKE 'slug'" );
        if ( $has_slug ) {
            $expert = $wpdb->get_row( $wpdb->prepare(
                "SELECT * FROM $table WHERE slug = %s AND status = 'approved' LIMIT 1",
                $slug
            ) );
            if ( $expert ) {
                wp_cache_set( $cache_key, $expert, 'nmep_experts', 300 );
                return $expert;
            }
        }

        // Fallback: match by sanitized full_name (pre-migration compat)
        $expert = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM $table WHERE status = 'approved' AND LOWER(REPLACE(REPLACE(full_name, ' ', '-'), '.', '')) LIKE %s LIMIT 1",
            '%' . $wpdb->esc_like( $slug ) . '%'
        ) );

        // Final fallback: scan (only if LIKE didn't work, for edge cases)
        if ( ! $expert ) {
            $experts = $wpdb->get_results(
                "SELECT * FROM $table WHERE status = 'approved' LIMIT 200"
            );
            foreach ( $experts as $e ) {
                if ( sanitize_title( $e->full_name ) === $slug ) {
                    $expert = $e;
                    break;
                }
            }
        }

        // Cache the result (even null → cached as empty string to prevent re-query)
        wp_cache_set( $cache_key, $expert ?: '', 'nmep_experts', 300 );

        return $expert;
    }

    /**
     * Clear cache when an expert profile is updated
     */
    public static function invalidate_cache( $expert_id ) {
        $expert = self::get_by_id( $expert_id );
        if ( $expert && ! empty( $expert->slug ) ) {
            wp_cache_delete( 'nmep_expert_slug_' . $expert->slug, 'nmep_experts' );
        }
        wp_cache_delete( 'nmep_expert_id_' . $expert_id, 'nmep_experts' );
    }

    /**
     * Get expert by ID (cached)
     */
    public static function get_by_id( $id ) {
        $cache_key = 'nmep_expert_id_' . (int) $id;
        $cached = wp_cache_get( $cache_key, 'nmep_experts' );
        if ( false !== $cached ) return $cached ?: null;

        global $wpdb;
        $table = NMEP_Compat::base_table( 'experts' );
        $expert = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $table WHERE id = %d", (int) $id ) );
        wp_cache_set( $cache_key, $expert ?: '', 'nmep_experts', 300 );
        return $expert;
    }

    /* ============================================================
       RENDER ENTRY POINT
       5. PROPER EXIT — status_header(200) + nocache for dynamic page
       ============================================================ */
    public static function maybe_render_expert_profile() {
        $slug = get_query_var( 'nmep_expert_slug' );
        if ( empty( $slug ) ) return;

        $expert = self::get_expert_by_slug( $slug );

        if ( ! $expert ) {
            global $wp_query;
            $wp_query->set_404();
            status_header( 404 );
            return;
        }

        // Set proper HTTP status for this dynamic page
        status_header( 200 );
        nocache_headers();

        self::render_full_page( $expert );
        exit;
    }

    /* ============================================================
       4. SEO HOOKS — proper Rank Math + WordPress integration
       ============================================================ */
    private static function setup_seo_hooks( $title, $description, $url, $image ) {
        self::$seo_title       = $title;
        self::$seo_description = $description;
        self::$seo_canonical   = $url;
        self::$seo_og_image    = $image;

        // WordPress native title
        add_filter( 'document_title_parts', function( $parts ) {
            $parts['title'] = NMEP_Expert_Profiles::$seo_title;
            unset( $parts['tagline'] ); // Remove "Just another WordPress site"
            return $parts;
        }, 999 );

        add_filter( 'pre_get_document_title', function() {
            return NMEP_Expert_Profiles::$seo_title;
        }, 999 );

        // Rank Math integration (if active)
        add_filter( 'rank_math/frontend/title', function() {
            return NMEP_Expert_Profiles::$seo_title;
        }, 999 );

        add_filter( 'rank_math/frontend/description', function() {
            return NMEP_Expert_Profiles::$seo_description;
        }, 999 );

        // Open Graph tags (for WhatsApp/Facebook sharing)
        add_action( 'wp_head', function() {
            $title = esc_attr( NMEP_Expert_Profiles::$seo_title );
            $desc  = esc_attr( NMEP_Expert_Profiles::$seo_description );
            $url   = esc_url( NMEP_Expert_Profiles::$seo_canonical );
            $img   = esc_url( NMEP_Expert_Profiles::$seo_og_image ?? '' );

            echo "\n<!-- NMEP Expert Profile SEO -->\n";
            echo '<meta name="description" content="' . $desc . '">' . "\n";
            echo '<link rel="canonical" href="' . $url . '">' . "\n";
            echo '<meta property="og:title" content="' . $title . '">' . "\n";
            echo '<meta property="og:description" content="' . $desc . '">' . "\n";
            echo '<meta property="og:url" content="' . $url . '">' . "\n";
            echo '<meta property="og:type" content="profile">' . "\n";
            if ( $img ) {
                echo '<meta property="og:image" content="' . $img . '">' . "\n";
            }
            echo '<meta name="twitter:card" content="summary">' . "\n";
            echo '<meta name="twitter:title" content="' . $title . '">' . "\n";
            echo '<meta name="twitter:description" content="' . $desc . '">' . "\n";
            echo "<!-- /NMEP Expert Profile SEO -->\n";
        }, 1 );
    }

    /* ============================================================
       FULL PAGE RENDERER
       ============================================================ */
    private static function render_full_page( $expert ) {
        global $wpdb;

        // ── Fetch all data ──
        $services = $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM " . NMEP_Database::table( 'services' ) . "
             WHERE expert_id = %d AND status = 'active'
             ORDER BY orders_count DESC, created_at DESC",
            $expert->id
        ) );

        $stats = $wpdb->get_row( $wpdb->prepare(
            "SELECT COUNT(*) AS total, AVG(rating) AS avg_rating
             FROM " . NMEP_Database::table( 'reviews' ) . "
             WHERE expert_id = %d AND status = 'published'",
            $expert->id
        ) );

        $recent_reviews = $wpdb->get_results( $wpdb->prepare(
            "SELECT r.*, s.title AS service_title
             FROM " . NMEP_Database::table( 'reviews' ) . " r
             LEFT JOIN " . NMEP_Database::table( 'services' ) . " s ON s.id = r.service_id
             WHERE r.expert_id = %d AND r.status = 'published'
             ORDER BY r.created_at DESC LIMIT 5",
            $expert->id
        ) );

        $completed_count = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM " . NMEP_Database::table( 'orders' ) . "
             WHERE expert_id = %d AND status IN ('completed', 'auto_released')",
            $expert->id
        ) );

        $member_since = ! empty( $expert->applied_at ) ? date( 'F Y', strtotime( $expert->applied_at ) ) : ( ! empty( $expert->created_at ) ? date( 'F Y', strtotime( $expert->created_at ) ) : '' );

        // ── SEO data ──
        $expert_url = self::get_expert_url( $expert );
        $photo_url  = ! empty( $expert->profile_photo ) ? esc_url( $expert->profile_photo ) : '';

        $page_title = $expert->full_name;
        if ( ! empty( $expert->tagline ) ) {
            $page_title .= ' — ' . $expert->tagline;
        }
        $page_title .= ' | Nagaland Me Experts';

        $meta_description = ! empty( $expert->bio )
            ? mb_substr( wp_strip_all_tags( $expert->bio ), 0, 155 )
            : 'Hire ' . $expert->full_name . ', a verified Nagaland Me expert. ' . count( $services ) . ' services available.';

        // ── 4. Hook SEO into WordPress + Rank Math BEFORE get_header() ──
        self::setup_seo_hooks( $page_title, $meta_description, $expert_url, $photo_url );

        // ── 3. Hire Now CTA logic ──
        $hire_url   = '';
        $hire_label = 'Hire ' . explode( ' ', $expert->full_name )[0];
        if ( ! empty( $services ) ) {
            // Link to first (most popular) service
            $hire_url = home_url( '/service/' . $services[0]->slug . '/' );
        } else {
            // Fallback: WhatsApp inquiry
            $hire_url   = 'https://wa.me/91' . preg_replace( '/[^0-9]/', '', $expert->phone ?? '' ) . '?text=' . urlencode( 'Hi, I found you on Nagaland Me Experts and I\'d like to discuss a project.' );
            $hire_label = 'Contact ' . explode( ' ', $expert->full_name )[0];
        }

        get_header();
        ?>

        <script type="application/ld+json">
        <?php echo wp_json_encode( self::build_person_schema( $expert, $services, $stats, $completed_count, $expert_url, $photo_url ), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ); ?>
        </script>

        <article class="nmep-expert-profile-page" style="background: var(--nme-bg-soft, #FAF7F0); min-height: 100vh; padding: 40px 0;">
            <div style="max-width: 1100px; margin: 0 auto; padding: 0 20px;">

                <!-- BREADCRUMB -->
                <nav aria-label="Breadcrumb" style="font-size: 0.85rem; color: var(--nme-text-light, #6B7280); margin-bottom: 16px;">
                    <a href="<?php echo esc_url( home_url( '/' ) ); ?>" style="color: var(--nme-emerald, #10B981);">Home</a>
                    <span style="margin: 0 8px;">›</span>
                    <a href="<?php echo esc_url( home_url( '/services/' ) ); ?>" style="color: var(--nme-emerald, #10B981);">Experts</a>
                    <span style="margin: 0 8px;">›</span>
                    <span><?php echo esc_html( $expert->full_name ); ?></span>
                </nav>

                <!-- HERO CARD -->
                <div style="background: white; border-radius: 16px; padding: 32px; margin-bottom: 24px; box-shadow: 0 4px 16px rgba(15, 36, 25, 0.08);">
                    <div style="display: flex; gap: 32px; align-items: flex-start; flex-wrap: wrap;">
                        <div style="flex: 0 0 auto;">
                            <?php if ( $photo_url ) : ?>
                                <img src="<?php echo esc_url( $photo_url ); ?>"
                                     alt="<?php echo esc_attr( $expert->full_name ); ?>"
                                     style="width: 140px; height: 140px; border-radius: 50%; object-fit: cover; border: 4px solid var(--nme-gold, #D4A843);">
                            <?php else : ?>
                                <div style="width: 140px; height: 140px; border-radius: 50%; background: var(--nme-forest, #0F2419); color: var(--nme-gold, #D4A843); display: flex; align-items: center; justify-content: center; font-size: 3rem; font-weight: 700; border: 4px solid var(--nme-gold, #D4A843);">
                                    <?php echo esc_html( strtoupper( substr( $expert->full_name, 0, 1 ) ) ); ?>
                                </div>
                            <?php endif; ?>
                        </div>

                        <div style="flex: 1; min-width: 280px;">
                            <h1 style="margin: 0 0 8px; font-size: 2rem; color: var(--nme-forest, #0F2419);">
                                <?php echo esc_html( $expert->full_name ); ?>
                                <?php if ( ! empty( $expert->is_founding_expert ) ) : ?>
                                    <span title="Founding Expert" style="background: var(--nme-gold, #D4A843); color: #fff; padding: 4px 12px; border-radius: 50px; font-size: 0.7rem; font-weight: 700; vertical-align: middle; margin-left: 8px;">🏆 FOUNDING</span>
                                <?php endif; ?>
                            </h1>

                            <?php
                            // === 6. BADGE DISPLAY (from nme-badges plugin) ===
                            if ( ! empty( $expert->user_id ) ) {
                                echo apply_filters( 'nmep_expert_profile_after_name', '', $expert );
                            }
                            ?>

                            <?php if ( ! empty( $expert->tagline ) ) : ?>
                                <p style="margin: 0 0 12px; font-size: 1.1rem; color: var(--nme-text, #374151); font-style: italic;">
                                    "<?php echo esc_html( $expert->tagline ); ?>"
                                </p>
                            <?php endif; ?>

                            <p style="margin: 0 0 16px; font-size: 0.9rem; color: var(--nme-text-light, #6B7280);">
                                <?php if ( ! empty( $expert->district ) ) : ?>
                                    📍 <?php echo esc_html( $expert->district ); ?>, <?php echo esc_html( $expert->state ?: 'Nagaland' ); ?>
                                <?php endif; ?>
                                <?php if ( $member_since ) : ?>
                                    &nbsp; · &nbsp; Member since <?php echo esc_html( $member_since ); ?>
                                <?php endif; ?>
                                <?php if ( ! empty( $expert->tier ) && $expert->tier !== 'new' ) : ?>
                                    &nbsp; · &nbsp; Tier: <strong style="text-transform: capitalize;"><?php echo esc_html( $expert->tier ); ?></strong>
                                <?php endif; ?>
                            </p>

                            <!-- Quick stats row -->
                            <div style="display: flex; gap: 24px; flex-wrap: wrap; margin-top: 16px;">
                                <?php if ( $stats && $stats->total > 0 ) : ?>
                                    <div>
                                        <div style="font-size: 1.4rem; font-weight: 700; color: var(--nme-emerald, #10B981);">
                                            <?php echo NMEP_Reviews::render_stars( $stats->avg_rating, 16 ); ?> <?php echo number_format( (float) $stats->avg_rating, 1 ); ?>
                                        </div>
                                        <div style="font-size: 0.75rem; color: var(--nme-text-light, #6B7280); text-transform: uppercase; letter-spacing: 0.05em;">
                                            <?php echo (int) $stats->total; ?> Review<?php echo $stats->total > 1 ? 's' : ''; ?>
                                        </div>
                                    </div>
                                <?php endif; ?>

                                <div>
                                    <div style="font-size: 1.4rem; font-weight: 700; color: var(--nme-forest, #0F2419);">
                                        <?php echo $completed_count; ?>
                                    </div>
                                    <div style="font-size: 0.75rem; color: var(--nme-text-light, #6B7280); text-transform: uppercase; letter-spacing: 0.05em;">
                                        Completed Orders
                                    </div>
                                </div>

                                <div>
                                    <div style="font-size: 1.4rem; font-weight: 700; color: var(--nme-forest, #0F2419);">
                                        <?php echo count( $services ); ?>
                                    </div>
                                    <div style="font-size: 0.75rem; color: var(--nme-text-light, #6B7280); text-transform: uppercase; letter-spacing: 0.05em;">
                                        Services Offered
                                    </div>
                                </div>
                            </div>

                            <!-- Social links + 3. HIRE NOW CTA -->
                            <div style="display: flex; align-items: center; gap: 10px; flex-wrap: wrap; margin-top: 20px;">
                                <?php if ( $hire_url ) : ?>
                                    <a href="<?php echo esc_url( $hire_url ); ?>"
                                       style="display: inline-block; background: var(--nme-emerald, #10B981); color: #fff; padding: 10px 24px; border-radius: 50px; text-decoration: none; font-size: 0.95rem; font-weight: 700; transition: all 0.2s; box-shadow: 0 4px 12px rgba(16,185,129,0.3);"
                                       onmouseover="this.style.background='var(--nme-forest, #0F2419)';this.style.boxShadow='0 6px 20px rgba(15,36,25,0.3)';"
                                       onmouseout="this.style.background='var(--nme-emerald, #10B981)';this.style.boxShadow='0 4px 12px rgba(16,185,129,0.3)';">
                                        <?php echo esc_html( $hire_label ); ?> →
                                    </a>
                                <?php endif; ?>

                                <?php if ( ! empty( $expert->youtube_channel ) ) : ?>
                                    <a href="<?php echo esc_url( $expert->youtube_channel ); ?>" target="_blank" rel="noopener" style="display: inline-block; background: #FF0000; color: white; padding: 6px 14px; border-radius: 50px; text-decoration: none; font-size: 0.85rem;">▶ YouTube</a>
                                <?php endif; ?>
                                <?php if ( ! empty( $expert->facebook_page ) ) : ?>
                                    <a href="<?php echo esc_url( $expert->facebook_page ); ?>" target="_blank" rel="noopener" style="display: inline-block; background: #1877F2; color: white; padding: 6px 14px; border-radius: 50px; text-decoration: none; font-size: 0.85rem;">f Facebook</a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- BIO -->
                <?php if ( ! empty( $expert->bio ) ) : ?>
                    <div style="background: white; border-radius: 16px; padding: 32px; margin-bottom: 24px; box-shadow: 0 4px 16px rgba(15, 36, 25, 0.08);">
                        <h2 style="margin: 0 0 16px; font-size: 1.4rem; color: var(--nme-forest, #0F2419);">About <?php echo esc_html( explode( ' ', $expert->full_name )[0] ); ?></h2>
                        <div style="color: var(--nme-text, #374151); line-height: 1.7; white-space: pre-line;">
                            <?php echo esc_html( $expert->bio ); ?>
                        </div>
                    </div>
                <?php endif; ?>

                <!-- v1.5.5 — CONTACT EXPERT CARD (Premium Buyer gated) -->
                <?php if ( class_exists( 'NMEP_Buyer_Premium' ) && ( ! empty( $expert->phone ) || ! empty( $expert->email ) ) ) :
                    $current_uid   = get_current_user_id();
                    $is_premium    = $current_uid && NMEP_Buyer_Premium::is_premium( $current_uid );
                    $premium_url   = NMEP_Buyer_Premium::landing_url();
                    $has_phone     = ! empty( $expert->phone );
                    $has_email     = ! empty( $expert->email );
                ?>
                    <div id="nmep-contact-card" class="nmep-contact-card" data-expert-id="<?php echo (int) $expert->id; ?>"
                         style="background: white; border-radius: 16px; padding: 28px; margin-bottom: 24px; box-shadow: 0 4px 16px rgba(15, 36, 25, 0.08); border-top: 4px solid <?php echo $is_premium ? '#D4A843' : 'var(--nme-border, #E5E7EB)'; ?>;">
                        <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px; margin-bottom: 16px;">
                            <h2 style="margin: 0; font-size: 1.3rem; color: var(--nme-forest, #0F2419);">
                                📞 Contact <?php echo esc_html( explode( ' ', $expert->full_name )[0] ); ?> Directly
                            </h2>
                            <?php if ( $is_premium ) : ?>
                                <span style="display:inline-block;padding:4px 12px;border-radius:50px;font-size:0.7rem;font-weight:700;background:#D4A843;color:#fff;text-transform:uppercase;letter-spacing:0.05em;">★ Premium Buyer</span>
                            <?php endif; ?>
                        </div>

                        <?php if ( $is_premium ) : ?>
                            <p style="margin:0 0 16px;color:var(--nme-text-light,#6B7280);font-size:0.95rem;">
                                As a Premium Buyer, you can contact experts directly for quick questions. For paid work, please use the Hire Now button above — your escrow protection only applies to on-platform orders.
                            </p>
                            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 12px;">
                                <?php if ( $has_phone ) : ?>
                                <div class="nmep-contact-slot" data-contact-type="phone" style="background:var(--nme-bg-soft,#F9FAFB);padding:14px 16px;border-radius:12px;border:1px solid var(--nme-border,#E5E7EB);">
                                    <div style="font-size:0.75rem;color:var(--nme-text-light,#6B7280);text-transform:uppercase;letter-spacing:0.05em;margin-bottom:6px;">Phone / WhatsApp</div>
                                    <div class="nmep-contact-locked" style="display:flex;align-items:center;gap:10px;">
                                        <span style="font-family:monospace;color:var(--nme-text-light,#9CA3AF);letter-spacing:3px;">•••••••••••</span>
                                        <button type="button" class="nmep-reveal-contact-btn nme-btn" data-contact-type="phone" style="padding:6px 14px;min-height:0;font-size:0.85rem;">Show</button>
                                    </div>
                                    <div class="nmep-contact-revealed" style="display:none;">
                                        <a class="nmep-contact-value" href="#" style="color:var(--nme-emerald,#10B981);font-weight:600;font-size:1.05rem;text-decoration:none;"></a>
                                    </div>
                                </div>
                                <?php endif; ?>

                                <?php if ( $has_email ) : ?>
                                <div class="nmep-contact-slot" data-contact-type="email" style="background:var(--nme-bg-soft,#F9FAFB);padding:14px 16px;border-radius:12px;border:1px solid var(--nme-border,#E5E7EB);">
                                    <div style="font-size:0.75rem;color:var(--nme-text-light,#6B7280);text-transform:uppercase;letter-spacing:0.05em;margin-bottom:6px;">Email</div>
                                    <div class="nmep-contact-locked" style="display:flex;align-items:center;gap:10px;">
                                        <span style="font-family:monospace;color:var(--nme-text-light,#9CA3AF);letter-spacing:2px;">••••••@••••••</span>
                                        <button type="button" class="nmep-reveal-contact-btn nme-btn" data-contact-type="email" style="padding:6px 14px;min-height:0;font-size:0.85rem;">Show</button>
                                    </div>
                                    <div class="nmep-contact-revealed" style="display:none;">
                                        <a class="nmep-contact-value" href="#" style="color:var(--nme-emerald,#10B981);font-weight:600;font-size:1.05rem;text-decoration:none;word-break:break-all;"></a>
                                    </div>
                                </div>
                                <?php endif; ?>
                            </div>
                            <p style="font-size:0.8rem;color:var(--nme-text-light,#9CA3AF);margin:14px 0 0;">
                                🔒 Every reveal is logged to discourage abuse.
                            </p>
                        <?php elseif ( class_exists( 'NMEP_Inbox' ) ) : ?>
                            <div style="background:linear-gradient(135deg, rgba(15,36,25,0.03) 0%, rgba(212,168,67,0.06) 100%);padding:24px;border-radius:12px;text-align:center;">
                                <div style="font-size:2.5rem;margin-bottom:8px;">🔒</div>
                                <h3 style="margin:0 0 8px;color:var(--nme-forest,#0F2419);">Unlock direct contact</h3>
                                <p style="margin:0 0 16px;color:var(--nme-text-light,#6B7280);">
                                    Premium Buyers can see <?php echo esc_html( explode( ' ', $expert->full_name )[0] ); ?>'s phone and email on every expert profile — plus get <?php echo esc_html( rtrim( rtrim( number_format( (float) NMEP_Settings::get( 'premium_buyer_discount_percent', 5 ), 2 ), '0' ), '.' ) ); ?>% off every order.
                                </p>
                                <div style="display:flex;gap:10px;justify-content:center;flex-wrap:wrap;">
                                    <a href="<?php echo esc_url( $premium_url ); ?>" class="nme-btn nme-btn-gold" style="padding:10px 22px;">Upgrade to Premium</a>
                                    <a href="<?php echo esc_url( add_query_arg( 'expert_id', (int) $expert->id, NMEP_Inbox::buyer_inbox_url() ) ); ?>" class="nme-btn" style="padding:10px 22px;background:transparent;color:var(--nme-forest,#0F2419);border:2px solid var(--nme-forest,#0F2419);">Send a Message Instead</a>
                                </div>
                            </div>
                        <?php else : ?>
                            <div style="background:var(--nme-bg-soft,#F9FAFB);padding:20px;border-radius:12px;text-align:center;">
                                <p style="margin:0 0 12px;">Upgrade to Premium Buyer to see this expert's direct contact details.</p>
                                <a href="<?php echo esc_url( $premium_url ); ?>" class="nme-btn nme-btn-gold">Get Premium</a>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>

                <!-- SERVICES -->
                <div style="background: white; border-radius: 16px; padding: 32px; margin-bottom: 24px; box-shadow: 0 4px 16px rgba(15, 36, 25, 0.08);">
                    <h2 style="margin: 0 0 24px; font-size: 1.4rem; color: var(--nme-forest, #0F2419);">
                        Services by <?php echo esc_html( explode( ' ', $expert->full_name )[0] ); ?> (<?php echo count( $services ); ?>)
                    </h2>

                    <?php if ( empty( $services ) ) : ?>
                        <p style="color: var(--nme-text-light, #6B7280); text-align: center; padding: 40px 0;">
                            <?php echo esc_html( $expert->full_name ); ?> hasn't published any services yet. Check back soon!
                        </p>
                    <?php else : ?>
                        <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 20px;">
                            <?php foreach ( $services as $service ) :
                                $service_url = home_url( '/service/' . $service->slug . '/' );
                                $cover = ! empty( $service->cover_image ) ? $service->cover_image : '';
                            ?>
                                <a href="<?php echo esc_url( $service_url ); ?>" style="text-decoration: none; color: inherit; display: block;">
                                    <div style="border: 1px solid var(--nme-border, #E5E7EB); border-radius: 12px; overflow: hidden; transition: transform 0.2s, box-shadow 0.2s;" onmouseover="this.style.transform='translateY(-3px)';this.style.boxShadow='0 8px 20px rgba(15,36,25,0.15)';" onmouseout="this.style.transform='';this.style.boxShadow='';">
                                        <?php if ( $cover ) : ?>
                                            <img src="<?php echo esc_url( $cover ); ?>" alt="<?php echo esc_attr( $service->title ); ?>" style="width: 100%; height: 160px; object-fit: cover;">
                                        <?php else : ?>
                                            <?php if ( function_exists( 'nmep_render_service_cover' ) ) : ?>
                                                <?php nmep_render_service_cover( $service, '16/9', array( 'expert_name' => $expert->full_name ) ); ?>
                                            <?php else : ?>
                                                <div style="height: 160px; background: linear-gradient(135deg, var(--nme-forest, #0F2419), var(--nme-emerald, #10B981)); display: flex; align-items: center; justify-content: center; color: var(--nme-gold, #D4A843); font-size: 2.5rem;">★</div>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                        <div style="padding: 16px;">
                                            <h3 style="margin: 0 0 8px; font-size: 1rem; color: var(--nme-forest, #0F2419); line-height: 1.3;">
                                                <?php echo esc_html( $service->title ); ?>
                                            </h3>
                                            <?php if ( ! empty( $service->reviews_count ) && $service->reviews_count > 0 ) : ?>
                                                <div style="font-size: 0.8rem; margin-bottom: 8px;">
                                                    <?php echo NMEP_Reviews::render_stars( $service->avg_rating, 12 ); ?>
                                                    <span style="color: var(--nme-text-light, #6B7280);"><?php echo number_format( (float) $service->avg_rating, 1 ); ?> (<?php echo (int) $service->reviews_count; ?>)</span>
                                                </div>
                                            <?php endif; ?>
                                            <div style="font-size: 0.85rem; color: var(--nme-text-light, #6B7280); margin-bottom: 8px;">Starting at</div>
                                            <div style="font-size: 1.2rem; font-weight: 700; color: var(--nme-emerald, #10B981);">
                                                <?php echo nmep_format_inr( $service->basic_price ); ?>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- REVIEWS -->
                <?php if ( ! empty( $recent_reviews ) ) : ?>
                    <div style="background: white; border-radius: 16px; padding: 32px; margin-bottom: 24px; box-shadow: 0 4px 16px rgba(15, 36, 25, 0.08);">
                        <h2 style="margin: 0 0 24px; font-size: 1.4rem; color: var(--nme-forest, #0F2419);">
                            Recent Reviews
                        </h2>
                        <?php foreach ( $recent_reviews as $review ) : ?>
                            <div style="padding: 20px 0; border-bottom: 1px solid var(--nme-border, #E5E7EB);">
                                <div style="display: flex; justify-content: space-between; flex-wrap: wrap; gap: 8px; margin-bottom: 8px;">
                                    <div>
                                        <strong><?php echo esc_html( $review->buyer_name ); ?></strong>
                                        <?php
                                        // === BUYER BADGES ===
                                        if ( ! empty( $review->buyer_id ) ) {
                                            echo apply_filters( 'nmep_review_after_buyer_name', '', $review->buyer_id );
                                        }
                                        ?>
                                        <span style="color: var(--nme-text-light, #6B7280); font-size: 0.85rem; margin-left: 8px;">
                                            for <em><?php echo esc_html( $review->service_title ); ?></em>
                                        </span>
                                    </div>
                                    <div>
                                        <?php echo NMEP_Reviews::render_stars( $review->rating, 14 ); ?>
                                        <small style="color: var(--nme-text-light, #6B7280); margin-left: 4px;"><?php echo esc_html( date( 'd M Y', strtotime( $review->created_at ) ) ); ?></small>
                                    </div>
                                </div>
                                <p style="margin: 4px 0 0; color: var(--nme-text, #374151); white-space: pre-line;"><?php echo esc_html( $review->comment ); ?></p>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

            </div>
        </article>

        <?php if ( class_exists( 'NMEP_Buyer_Premium' ) && ( ! empty( $expert->phone ) || ! empty( $expert->email ) ) ) : ?>
        <script>
        (function(){
            var card = document.getElementById('nmep-contact-card');
            if (!card) return;
            var expertId = parseInt(card.getAttribute('data-expert-id'), 10) || 0;
            var ajaxUrl  = (window.nmep_data && window.nmep_data.ajax_url) ? window.nmep_data.ajax_url : '<?php echo esc_url( admin_url( 'admin-ajax.php' ) ); ?>';
            var nonce    = (window.nmep_data && window.nmep_data.nonce)    ? window.nmep_data.nonce    : '<?php echo esc_js( wp_create_nonce( 'nmep_ajax' ) ); ?>';

            function reveal(btn){
                var type = btn.getAttribute('data-contact-type');
                var slot = btn.closest('.nmep-contact-slot');
                if (!slot) return;

                btn.disabled = true;
                var originalText = btn.textContent;
                btn.textContent = '…';

                var form = new FormData();
                form.append('action', 'nmep_reveal_contact');
                form.append('nonce', nonce);
                form.append('expert_id', String(expertId));
                form.append('contact_type', type);
                form.append('source', 'profile');

                fetch(ajaxUrl, { method: 'POST', body: form, credentials: 'same-origin' })
                    .then(function(r){ return r.json(); })
                    .then(function(res){
                        if (res && res.success && res.data) {
                            slot.querySelector('.nmep-contact-locked').style.display = 'none';
                            var revealed = slot.querySelector('.nmep-contact-revealed');
                            var link     = revealed.querySelector('.nmep-contact-value');
                            link.textContent = res.data.display || res.data.value;
                            if (type === 'phone') {
                                var digits = String(res.data.value).replace(/\D/g, '');
                                link.href = 'tel:+' + digits;
                            } else {
                                link.href = 'mailto:' + res.data.value;
                            }
                            revealed.style.display = 'block';
                        } else {
                            btn.disabled = false;
                            btn.textContent = originalText;
                            var msg = (res && res.data && res.data.message) ? res.data.message : 'Could not reveal contact.';
                            if (res && res.data && res.data.upgrade_url) {
                                if (confirm(msg + '\n\nUpgrade to Premium Buyer now?')) {
                                    window.location.href = res.data.upgrade_url;
                                }
                            } else {
                                alert(msg);
                            }
                        }
                    })
                    .catch(function(){
                        btn.disabled = false;
                        btn.textContent = originalText;
                        alert('Network error. Please try again.');
                    });
            }

            card.addEventListener('click', function(e){
                var btn = e.target.closest('.nmep-reveal-contact-btn');
                if (!btn) return;
                e.preventDefault();
                reveal(btn);
            });
        })();
        </script>
        <?php endif; ?>

        <?php
        get_footer();
    }

    /* ============================================================
       SCHEMA — Person + ProfessionalService
       ============================================================ */
    private static function build_person_schema( $expert, $services, $stats, $completed_count, $expert_url, $photo_url ) {
        $schema = array(
            '@context' => 'https://schema.org',
            '@type'    => 'ProfessionalService',
            'name'     => $expert->full_name,
            'url'      => $expert_url,
            'description' => ! empty( $expert->bio ) ? wp_strip_all_tags( $expert->bio ) : 'Verified Nagaland Me Expert offering ' . count( $services ) . ' services',
            'priceRange' => '₹199 - ₹9999',
            'areaServed' => array(
                '@type' => 'Country',
                'name'  => 'India',
            ),
        );

        if ( $photo_url ) {
            $schema['image'] = $photo_url;
        }

        if ( ! empty( $expert->district ) ) {
            $schema['address'] = array(
                '@type'           => 'PostalAddress',
                'addressLocality' => $expert->district,
                'addressRegion'   => $expert->state ?: 'Nagaland',
                'addressCountry'  => 'IN',
            );
        }

        if ( $stats && $stats->total > 0 ) {
            $schema['aggregateRating'] = array(
                '@type'       => 'AggregateRating',
                'ratingValue' => round( (float) $stats->avg_rating, 1 ),
                'reviewCount' => (int) $stats->total,
                'bestRating'  => 5,
                'worstRating' => 1,
            );
        }

        if ( ! empty( $services ) ) {
            $offers = array();
            foreach ( $services as $svc ) {
                $offers[] = array(
                    '@type'         => 'Offer',
                    'name'          => $svc->title,
                    'url'           => home_url( '/service/' . $svc->slug . '/' ),
                    'priceCurrency' => 'INR',
                    'price'         => (string) ( $svc->basic_price ?? 0 ),
                );
            }
            $schema['hasOfferCatalog'] = array(
                '@type'           => 'OfferCatalog',
                'name'            => $expert->full_name . ' Services',
                'itemListElement' => $offers,
            );
        }

        $sameAs = array();
        if ( ! empty( $expert->youtube_channel ) ) $sameAs[] = $expert->youtube_channel;
        if ( ! empty( $expert->facebook_page ) )   $sameAs[] = $expert->facebook_page;
        if ( ! empty( $sameAs ) ) {
            $schema['sameAs'] = $sameAs;
        }

        return $schema;
    }
}