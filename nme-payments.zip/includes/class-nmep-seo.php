<?php
/**
 * NMEP_SEO
 * SEO enhancements for the marketplace:
 * - Schema markup (Service, Person, Organization, BreadcrumbList) on service pages
 * - Open Graph + Twitter Card tags
 * - Meta description override (Rank Math friendly)
 * - Canonical URL hints
 * - Robots meta tags (noindex on private pages)
 *
 * Designed to coexist with Rank Math — we only add what Rank Math doesn't,
 * and we use filter hooks Rank Math respects (rank_math/frontend/title, etc.)
 *
 * @version 1.5.0 (Batch F)
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class NMEP_SEO {

    public static function init() {
        // Output schema + meta tags in <head>
        add_action( 'wp_head', array( __CLASS__, 'output_head_tags' ), 5 );

        // Override page title for service pages
        add_filter( 'document_title_parts', array( __CLASS__, 'filter_document_title' ), 20 );

        // Rank Math integration — replace meta description if Rank Math is active
        add_filter( 'rank_math/frontend/description', array( __CLASS__, 'filter_meta_description' ) );
        add_filter( 'rank_math/frontend/title', array( __CLASS__, 'filter_seo_title' ) );

        // Mark private pages as noindex
        add_filter( 'rank_math/frontend/robots', array( __CLASS__, 'filter_robots_for_private_pages' ) );
        add_action( 'wp_head', array( __CLASS__, 'fallback_noindex_meta' ), 1 );

        // Add expert + service sitemaps to Rank Math
        add_filter( 'rank_math/sitemap/providers', array( __CLASS__, 'add_to_rank_math_sitemap' ) );

        // Invalidate sitemap cache when content changes
        add_action( 'nmep_service_status_changed', array( __CLASS__, 'invalidate_sitemap_cache' ) );
        add_action( 'nmep_service_created', array( __CLASS__, 'invalidate_sitemap_cache' ) );
        add_action( 'nme_expert_approved', array( __CLASS__, 'invalidate_sitemap_cache' ) );

        // For Yoast (in case Rank Math isn't active)
        add_filter( 'wpseo_sitemap_index', array( __CLASS__, 'add_to_yoast_sitemap_index' ) );
    }

    /* ============================================================
       OUTPUT HEAD TAGS — schema, OG, twitter
       ============================================================ */
    public static function output_head_tags() {
        $context = self::detect_page_context();
        if ( ! $context ) return;

        switch ( $context['type'] ) {
            case 'service':
                self::output_service_schema( $context['service'] );
                self::output_og_tags_for_service( $context['service'] );
                break;
            case 'services_browse':
                self::output_browse_schema();
                self::output_og_tags_for_browse();
                break;
            case 'expert':
                // Handled inside expert profile renderer
                break;
        }

        // Always output Organization schema on every page
        self::output_organization_schema();
    }

    /* ============================================================
       PAGE CONTEXT DETECTION
       ============================================================ */
    private static function detect_page_context() {
        global $post;

        // Expert profile page (handled by NMEP_Expert_Profiles directly)
        if ( get_query_var( 'nmep_expert_slug' ) ) {
            return array( 'type' => 'expert' );
        }

        if ( ! $post || ! is_singular() ) return null;

        $content = $post->post_content ?? '';

        // Single service page?
        if ( strpos( $content, '[nmep_service_view]' ) !== false ) {
            $service_slug = isset( $_GET['service'] ) ? sanitize_title( wp_unslash( $_GET['service'] ) ) : '';
            // Also try to detect by URL path
            if ( empty( $service_slug ) ) {
                $path = trim( parse_url( $_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH ) ?? '', '/' );
                $parts = explode( '/', $path );
                if ( count( $parts ) >= 2 && $parts[0] === 'service' ) {
                    $service_slug = $parts[1];
                }
            }
            if ( $service_slug ) {
                $service = NMEP_Services::get_by_slug( $service_slug );
                if ( $service ) {
                    return array( 'type' => 'service', 'service' => $service );
                }
            }
        }

        // Browse services page
        if ( strpos( $content, '[nmep_browse_services]' ) !== false ) {
            return array( 'type' => 'services_browse' );
        }

        return null;
    }

    /* ============================================================
       SERVICE SCHEMA + META
       ============================================================ */
    private static function output_service_schema( $service ) {
        $expert = NMEP_Compat::get_expert( $service->expert_id );
        if ( ! $expert ) return;

        $service_url = home_url( '/service/' . $service->slug . '/' );
        $expert_url = NMEP_Expert_Profiles::get_expert_url( $expert );

        $schema = array(
            '@context' => 'https://schema.org',
            '@type'    => 'Service',
            '@id'      => $service_url,
            'name'     => $service->title,
            'url'      => $service_url,
            'description' => wp_strip_all_tags( $service->description ),
            'provider' => array(
                '@type' => 'Person',
                'name'  => $expert->full_name,
                'url'   => $expert_url,
            ),
            'serviceType' => $service->category_name ?? 'Creator Service',
            'areaServed'  => array(
                '@type' => 'Country',
                'name'  => 'India',
            ),
            'offers' => array(
                array(
                    '@type'         => 'Offer',
                    'name'          => 'Basic',
                    'priceCurrency' => 'INR',
                    'price'         => (string) $service->basic_price,
                    'availability'  => 'https://schema.org/InStock',
                    'description'   => wp_strip_all_tags( $service->basic_description ?? '' ),
                ),
                array(
                    '@type'         => 'Offer',
                    'name'          => 'Standard',
                    'priceCurrency' => 'INR',
                    'price'         => (string) $service->standard_price,
                    'availability'  => 'https://schema.org/InStock',
                    'description'   => wp_strip_all_tags( $service->standard_description ?? '' ),
                ),
                array(
                    '@type'         => 'Offer',
                    'name'          => 'Premium',
                    'priceCurrency' => 'INR',
                    'price'         => (string) $service->premium_price,
                    'availability'  => 'https://schema.org/InStock',
                    'description'   => wp_strip_all_tags( $service->premium_description ?? '' ),
                ),
            ),
        );

        if ( ! empty( $service->cover_image ) ) {
            $schema['image'] = $service->cover_image;
        }

        if ( $service->reviews_count > 0 ) {
            $schema['aggregateRating'] = array(
                '@type'       => 'AggregateRating',
                'ratingValue' => round( (float) $service->avg_rating, 1 ),
                'reviewCount' => (int) $service->reviews_count,
                'bestRating'  => 5,
                'worstRating' => 1,
            );
        }

        // Breadcrumb schema
        $breadcrumb = array(
            '@context' => 'https://schema.org',
            '@type'    => 'BreadcrumbList',
            'itemListElement' => array(
                array( '@type' => 'ListItem', 'position' => 1, 'name' => 'Home',     'item' => home_url( '/' ) ),
                array( '@type' => 'ListItem', 'position' => 2, 'name' => 'Services', 'item' => home_url( '/services/' ) ),
                array( '@type' => 'ListItem', 'position' => 3, 'name' => $service->title, 'item' => $service_url ),
            ),
        );

        echo "\n<!-- NMEP Schema -->\n";
        echo '<script type="application/ld+json">' . wp_json_encode( $schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . '</script>' . "\n";
        echo '<script type="application/ld+json">' . wp_json_encode( $breadcrumb, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . '</script>' . "\n";
    }

    private static function output_og_tags_for_service( $service ) {
        $expert = NMEP_Compat::get_expert( $service->expert_id );
        $service_url = home_url( '/service/' . $service->slug . '/' );
        $description = wp_trim_words( wp_strip_all_tags( $service->description ), 30, '...' );
        $image = ! empty( $service->cover_image ) ? $service->cover_image : '';

        echo "\n<!-- NMEP Open Graph -->\n";
        echo '<meta property="og:type" content="product">' . "\n";
        echo '<meta property="og:title" content="' . esc_attr( $service->title ) . ' — Starting at ' . nmep_format_inr( $service->basic_price ) . '">' . "\n";
        echo '<meta property="og:description" content="' . esc_attr( $description ) . '">' . "\n";
        echo '<meta property="og:url" content="' . esc_url( $service_url ) . '">' . "\n";
        echo '<meta property="og:site_name" content="Nagaland Me Experts">' . "\n";
        if ( $image ) {
            echo '<meta property="og:image" content="' . esc_url( $image ) . '">' . "\n";
        }
        echo '<meta property="product:price:amount" content="' . esc_attr( $service->basic_price ) . '">' . "\n";
        echo '<meta property="product:price:currency" content="INR">' . "\n";
        if ( $expert ) {
            echo '<meta property="product:retailer" content="' . esc_attr( $expert->full_name ) . '">' . "\n";
        }

        echo '<meta name="twitter:card" content="summary_large_image">' . "\n";
        echo '<meta name="twitter:title" content="' . esc_attr( $service->title ) . '">' . "\n";
        echo '<meta name="twitter:description" content="' . esc_attr( $description ) . '">' . "\n";
        if ( $image ) {
            echo '<meta name="twitter:image" content="' . esc_url( $image ) . '">' . "\n";
        }
    }

    /* ============================================================
       BROWSE PAGE
       ============================================================ */
    private static function output_browse_schema() {
        $services = NMEP_Services::get_active( array( 'limit' => 50 ) );

        $items = array();
        $position = 1;
        foreach ( $services as $service ) {
            $items[] = array(
                '@type'    => 'ListItem',
                'position' => $position++,
                'url'      => home_url( '/service/' . $service->slug . '/' ),
                'name'     => $service->title,
            );
        }

        $schema = array(
            '@context' => 'https://schema.org',
            '@type'    => 'CollectionPage',
            'name'     => 'Browse Services — Nagaland Me Experts',
            'url'      => home_url( '/services/' ),
            'mainEntity' => array(
                '@type' => 'ItemList',
                'itemListElement' => $items,
            ),
        );

        echo "\n<!-- NMEP Browse Schema -->\n";
        echo '<script type="application/ld+json">' . wp_json_encode( $schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . '</script>' . "\n";
    }

    private static function output_og_tags_for_browse() {
        echo "\n<!-- NMEP Browse OG -->\n";
        echo '<meta property="og:type" content="website">' . "\n";
        echo '<meta property="og:title" content="Browse Services — Nagaland Me Experts">' . "\n";
        echo '<meta property="og:description" content="Hire verified Naga creators for YouTube monetization, video editing, thumbnail design, and more. Escrow-protected payments.">' . "\n";
        echo '<meta property="og:url" content="' . esc_url( home_url( '/services/' ) ) . '">' . "\n";
        echo '<meta property="og:site_name" content="Nagaland Me Experts">' . "\n";
    }

    /* ============================================================
       ORGANIZATION SCHEMA (every page)
       ============================================================ */
    private static function output_organization_schema() {
        static $output = false;
        if ( $output ) return;
        $output = true;

        $schema = array(
            '@context' => 'https://schema.org',
            '@type'    => 'Organization',
            'name'     => 'Nagaland Me Experts',
            'alternateName' => 'NME Experts',
            'url'      => home_url( '/' ),
            'logo'     => apply_filters( 'nmep_organization_logo', '' ),
            'address'  => array(
                '@type'           => 'PostalAddress',
                'streetAddress'   => 'HN 09, Purna Bazar',
                'addressLocality' => 'Dimapur',
                'addressRegion'   => 'Nagaland',
                'postalCode'      => '797112',
                'addressCountry'  => 'IN',
            ),
            'contactPoint' => array(
                '@type'       => 'ContactPoint',
                'telephone'   => '+91-6383359495',
                'email'       => 'info@nagaland.me',
                'contactType' => 'customer support',
                'areaServed'  => 'IN',
            ),
            'sameAs' => array(
                'https://nagaland.me/',
                'https://nagalandai.com/',
                'https://nagalanddictionary.com/',
                'https://nagalandprofiles.com/',
                'https://nagalandnewstoday.com/',
                'https://helpnagaland.com/',
            ),
            'parentOrganization' => array(
                '@type' => 'Organization',
                'name'  => 'Nagaland Me',
                'url'   => 'https://nagaland.me/',
            ),
        );

        echo "\n<!-- NMEP Organization Schema -->\n";
        echo '<script type="application/ld+json">' . wp_json_encode( $schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . '</script>' . "\n";
    }

    /* ============================================================
       TITLE & DESCRIPTION FILTERS
       ============================================================ */
    public static function filter_document_title( $title_parts ) {
        $context = self::detect_page_context();
        if ( ! $context ) return $title_parts;

        if ( $context['type'] === 'service' ) {
            $service = $context['service'];
            $expert = NMEP_Compat::get_expert( $service->expert_id );
            $expert_name = $expert ? $expert->full_name : 'Verified Expert';
            $title_parts['title'] = $service->title . ' by ' . $expert_name;
        } elseif ( $context['type'] === 'services_browse' ) {
            $title_parts['title'] = 'Browse Services — Hire Verified Naga Creators';
        }

        return $title_parts;
    }

    public static function filter_seo_title( $title ) {
        $context = self::detect_page_context();
        if ( ! $context ) return $title;

        if ( $context['type'] === 'service' ) {
            $service = $context['service'];
            $expert = NMEP_Compat::get_expert( $service->expert_id );
            $expert_name = $expert ? $expert->full_name : 'Verified Expert';
            return $service->title . ' by ' . $expert_name . ' — Starting at ' . nmep_format_inr( $service->basic_price ) . ' | Nagaland Me Experts';
        }

        if ( $context['type'] === 'services_browse' ) {
            return 'Browse Services — Hire Verified Naga Creators | Nagaland Me Experts';
        }

        return $title;
    }

    public static function filter_meta_description( $description ) {
        $context = self::detect_page_context();
        if ( ! $context ) return $description;

        if ( $context['type'] === 'service' ) {
            $service = $context['service'];
            $expert = NMEP_Compat::get_expert( $service->expert_id );
            $excerpt = wp_trim_words( wp_strip_all_tags( $service->description ), 25, '...' );
            $expert_name = $expert ? $expert->full_name : 'a verified expert';
            return $excerpt . ' By ' . $expert_name . '. From ' . nmep_format_inr( $service->basic_price ) . '. Escrow-protected payment.';
        }

        if ( $context['type'] === 'services_browse' ) {
            return 'Hire verified Naga creators for YouTube monetization, video editing, thumbnail design, and more. Escrow-protected payments. Starting at ₹199.';
        }

        return $description;
    }

    /* ============================================================
       NOINDEX FOR PRIVATE PAGES
       ============================================================ */
    public static function filter_robots_for_private_pages( $robots ) {
        if ( self::is_private_page() ) {
            $robots['index'] = 'noindex';
            $robots['follow'] = 'nofollow';
        }
        return $robots;
    }

    public static function fallback_noindex_meta() {
        if ( self::is_private_page() ) {
            echo '<meta name="robots" content="noindex, nofollow">' . "\n";
        }
    }

    private static function is_private_page() {
        global $post;
        if ( ! $post || ! is_singular() ) return false;

        $private_shortcodes = array(
            '[nmep_checkout]',
            '[nmep_thank_you]',
            '[nmep_track_order]',
            '[nmep_my_orders]',
            '[nmep_expert_dashboard]',
        );

        foreach ( $private_shortcodes as $sc ) {
            if ( strpos( $post->post_content, $sc ) !== false ) {
                return true;
            }
        }
        return false;
    }

    /* ============================================================
       SITEMAP INTEGRATION
       ============================================================ */

    /**
     * Register custom sitemap providers with Rank Math
     * Filter expects associative array: ['type' => Provider instance]
     */
    public static function add_to_rank_math_sitemap( $external_providers ) {
        if ( ! interface_exists( '\\RankMath\\Sitemap\\Providers\\Provider' ) ) {
            return $external_providers;
        }

        // Load the namespaced provider classes
        require_once dirname( __FILE__ ) . '/class-nmep-sitemap-provider.php';

        if ( class_exists( '\\RankMath\\Sitemap\\Providers\\NMEP_Service_Sitemap' ) ) {
            $external_providers['service'] = new \RankMath\Sitemap\Providers\NMEP_Service_Sitemap();
        }
        if ( class_exists( '\\RankMath\\Sitemap\\Providers\\NMEP_Expert_Sitemap' ) ) {
            $external_providers['expert'] = new \RankMath\Sitemap\Providers\NMEP_Expert_Sitemap();
        }

        return $external_providers;
    }

    /**
     * Invalidate Rank Math sitemap cache when services or experts change
     */
    public static function invalidate_sitemap_cache() {
        if ( class_exists( '\\RankMath\\Sitemap\\Cache' ) ) {
            \RankMath\Sitemap\Cache::invalidate_storage( 'service' );
            \RankMath\Sitemap\Cache::invalidate_storage( 'expert' );
        }
    }

    /**
     * Yoast sitemap fallback (if Rank Math not active)
     */
    public static function add_to_yoast_sitemap_index( $sitemap ) {
        return $sitemap;
    }
}
