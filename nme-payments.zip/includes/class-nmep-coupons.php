<?php
/**
 * NMEP_Coupons
 *
 * Coupon / discount engine for the Nagaland Me Experts marketplace.
 *
 * Supports two coupon owners:
 *   - ADMIN coupons       : platform-wide, any % up to 100
 *   - EXPERT coupons      : scoped to the creating expert's services only,
 *                           % capped by admin setting (default 30%)
 *
 * Critical rule ("commission on original price"):
 *   Commission is calculated on the ORIGINAL service price,
 *   NOT on the discounted amount the buyer pays.
 *   Result: the discount eats into the expert's payout,
 *   not the platform's commission.
 *
 * Example:
 *   Service price: ₹1000. Coupon: 20% off. Commission rate: 15%.
 *   Buyer pays:    ₹800
 *   Platform:      ₹150  (15% of ₹1000)
 *   Expert gets:   ₹650  (₹800 − ₹150)
 *
 * Integration:
 *   Hooks into `nmep_checkout_pricing` (priority 10) fired from
 *   NMEP_Checkout::handle_checkout_start() right before the order row
 *   is inserted. Records usage on `nmep_after_payment_captured`.
 *
 * Database:
 *   Adds 2 new tables (nmep_coupons, nmep_coupon_uses) and 4 columns
 *   to nmep_orders (original_amount, coupon_code, coupon_discount,
 *   discount_source). Idempotent migration runs on admin_init.
 *
 * @package NagalandMeExpertsPayments
 * @version 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class NMEP_Coupons {

    const TYPE_ADMIN  = 'admin';
    const TYPE_EXPERT = 'expert';

    const DISCOUNT_PERCENT = 'percent'; // v1 supports percent only (fixed-amount reserved for future)

    const DB_VERSION_OPTION = 'nmep_coupons_db_version';
    const DB_VERSION        = '1.0.0';

    /* ============================================================
       INIT
       ============================================================ */

    public static function init() {
        // Migrations (idempotent; cheap no-op once done)
        add_action( 'admin_init', array( __CLASS__, 'maybe_migrate' ), 5 );
        // Also run on plugins_loaded for cases where someone visits the frontend first after upgrade
        add_action( 'plugins_loaded', array( __CLASS__, 'maybe_migrate' ), 30 );

        // Checkout pricing filter (added to checkout.php in v1.5.5)
        add_filter( 'nmep_checkout_pricing', array( __CLASS__, 'apply_at_checkout' ), 10, 5 );

        // Record usage after payment actually captured (not just initiated)
        add_action( 'nmep_after_payment_captured', array( __CLASS__, 'record_usage_after_payment' ), 10, 2 );

        // AJAX validation (live preview on checkout page)
        add_action( 'wp_ajax_nmep_validate_coupon',        array( __CLASS__, 'ajax_validate' ) );
        add_action( 'wp_ajax_nopriv_nmep_validate_coupon', array( __CLASS__, 'ajax_validate' ) );

        // Admin
        if ( is_admin() ) {
            add_action( 'admin_menu', array( __CLASS__, 'register_admin_menu' ), 25 );
        }
        add_action( 'admin_post_nmep_admin_save_coupon',   array( __CLASS__, 'handle_admin_save' ) );
        add_action( 'admin_post_nmep_admin_delete_coupon', array( __CLASS__, 'handle_admin_delete' ) );

        // Expert
        add_action( 'admin_post_nmep_expert_save_coupon',   array( __CLASS__, 'handle_expert_save' ) );
        add_action( 'admin_post_nmep_expert_delete_coupon', array( __CLASS__, 'handle_expert_delete' ) );

        // Expert dashboard: shortcode-driven (experts can embed a coupon manager on their own page,
        // OR we can surface it via a filter into the dashboard later).
        add_shortcode( 'nmep_expert_coupons', array( __CLASS__, 'render_expert_coupons_shortcode' ) );
    }

    /* ============================================================
       TABLES / MIGRATION
       ============================================================ */

    /**
     * Return a prefixed table name owned by this module.
     * Reuses the NMEP_Database prefix convention for consistency.
     */
    public static function table( $name ) {
        global $wpdb;
        return $wpdb->prefix . 'nmep_' . $name;
    }

    /**
     * Run migration if not already at current version.
     */
    public static function maybe_migrate() {
        $installed = get_option( self::DB_VERSION_OPTION, '0.0.0' );
        if ( version_compare( $installed, self::DB_VERSION, '>=' ) ) {
            return;
        }
        self::create_tables();
        update_option( self::DB_VERSION_OPTION, self::DB_VERSION, false );
    }

    /**
     * Create tables and augment orders table.
     */
    public static function create_tables() {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        $coupons = self::table( 'coupons' );
        $uses    = self::table( 'coupon_uses' );

        $sql_coupons = "CREATE TABLE $coupons (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            code VARCHAR(60) NOT NULL,
            code_upper VARCHAR(60) NOT NULL,
            owner_type VARCHAR(20) NOT NULL DEFAULT 'admin',
            expert_id BIGINT(20) UNSIGNED DEFAULT NULL,
            created_by_user_id BIGINT(20) UNSIGNED DEFAULT NULL,

            description VARCHAR(200) DEFAULT NULL,
            discount_type VARCHAR(20) NOT NULL DEFAULT 'percent',
            discount_value DECIMAL(6,2) NOT NULL DEFAULT 0.00,

            min_order_amount DECIMAL(10,2) DEFAULT NULL,
            max_discount_amount DECIMAL(10,2) DEFAULT NULL,

            max_uses INT(11) DEFAULT NULL,
            max_uses_per_buyer INT(11) DEFAULT 1,
            uses_count INT(11) NOT NULL DEFAULT 0,

            starts_at DATETIME DEFAULT NULL,
            expires_at DATETIME DEFAULT NULL,
            is_active TINYINT(1) NOT NULL DEFAULT 1,

            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            UNIQUE KEY code_upper (code_upper),
            KEY owner_type (owner_type),
            KEY expert_id (expert_id),
            KEY is_active (is_active),
            KEY expires_at (expires_at)
        ) $charset_collate;";

        $sql_uses = "CREATE TABLE $uses (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            coupon_id BIGINT(20) UNSIGNED NOT NULL,
            order_id BIGINT(20) UNSIGNED NOT NULL,
            buyer_user_id BIGINT(20) UNSIGNED DEFAULT NULL,
            buyer_email VARCHAR(190) DEFAULT NULL,
            discount_amount DECIMAL(10,2) NOT NULL DEFAULT 0.00,
            original_amount DECIMAL(10,2) NOT NULL DEFAULT 0.00,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            UNIQUE KEY order_id (order_id),
            KEY coupon_id (coupon_id),
            KEY buyer_user_id (buyer_user_id),
            KEY buyer_email (buyer_email)
        ) $charset_collate;";

        dbDelta( $sql_coupons );
        dbDelta( $sql_uses );

        // Add discount-tracking columns to orders table (idempotent)
        $orders_table = NMEP_Database::table( 'orders' );
        $cols_needed = array(
            'original_amount'  => "DECIMAL(10,2) DEFAULT NULL AFTER gross_amount",
            'coupon_code'      => "VARCHAR(60) DEFAULT NULL AFTER original_amount",
            'coupon_discount'  => "DECIMAL(10,2) DEFAULT 0.00 AFTER coupon_code",
            'discount_source'  => "VARCHAR(20) DEFAULT NULL AFTER coupon_discount",
        );
        foreach ( $cols_needed as $col => $def ) {
            $exists = $wpdb->get_var( "SHOW COLUMNS FROM $orders_table LIKE '" . esc_sql( $col ) . "'" );
            if ( ! $exists ) {
                $wpdb->query( "ALTER TABLE $orders_table ADD COLUMN $col $def" );
            }
        }

        if ( class_exists( 'NMEP_Logger' ) ) {
            NMEP_Logger::info( 'Coupons tables migrated', array( 'version' => self::DB_VERSION ) );
        }
    }

    /* ============================================================
       CODE HELPERS
       ============================================================ */

    public static function sanitize_code( $code ) {
        $code = strtoupper( trim( (string) $code ) );
        // Strictly A-Z, 0-9, dash, underscore; max 40 chars
        $code = preg_replace( '/[^A-Z0-9_\-]/', '', $code );
        return substr( $code, 0, 40 );
    }

    public static function generate_code( $prefix = 'NME' ) {
        $try = 0;
        do {
            $try++;
            $suffix = strtoupper( wp_generate_password( 6, false, false ) );
            $candidate = substr( $prefix, 0, 6 ) . $suffix;
            $exists = self::get_by_code( $candidate );
        } while ( $exists && $try < 10 );
        return $candidate;
    }

    /* ============================================================
       QUERIES
       ============================================================ */

    public static function get( $id ) {
        global $wpdb;
        return $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM " . self::table( 'coupons' ) . " WHERE id = %d",
            (int) $id
        ) );
    }

    public static function get_by_code( $code ) {
        $code_upper = self::sanitize_code( $code );
        if ( empty( $code_upper ) ) return null;

        global $wpdb;
        return $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM " . self::table( 'coupons' ) . " WHERE code_upper = %s LIMIT 1",
            $code_upper
        ) );
    }

    public static function get_for_expert( $expert_id, $limit = 100 ) {
        global $wpdb;
        return $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM " . self::table( 'coupons' ) . "
             WHERE owner_type = %s AND expert_id = %d
             ORDER BY id DESC LIMIT %d",
            self::TYPE_EXPERT, (int) $expert_id, (int) $limit
        ) );
    }

    public static function get_all_admin( $limit = 200 ) {
        global $wpdb;
        return $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM " . self::table( 'coupons' ) . "
             WHERE owner_type = %s
             ORDER BY id DESC LIMIT %d",
            self::TYPE_ADMIN, (int) $limit
        ) );
    }

    public static function count_uses_by_buyer( $coupon_id, $buyer_user_id, $buyer_email = '' ) {
        global $wpdb;
        if ( $buyer_user_id ) {
            return (int) $wpdb->get_var( $wpdb->prepare(
                "SELECT COUNT(*) FROM " . self::table( 'coupon_uses' ) . "
                 WHERE coupon_id = %d AND buyer_user_id = %d",
                (int) $coupon_id, (int) $buyer_user_id
            ) );
        }
        if ( ! empty( $buyer_email ) ) {
            return (int) $wpdb->get_var( $wpdb->prepare(
                "SELECT COUNT(*) FROM " . self::table( 'coupon_uses' ) . "
                 WHERE coupon_id = %d AND buyer_email = %s",
                (int) $coupon_id, sanitize_email( $buyer_email )
            ) );
        }
        return 0;
    }

    public static function count_active_for_expert( $expert_id ) {
        global $wpdb;
        return (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM " . self::table( 'coupons' ) . "
             WHERE owner_type = %s AND expert_id = %d AND is_active = 1
               AND ( expires_at IS NULL OR expires_at > UTC_TIMESTAMP() )",
            self::TYPE_EXPERT, (int) $expert_id
        ) );
    }

    /* ============================================================
       VALIDATION
       ============================================================ */

    /**
     * Validate a coupon against the context.
     *
     * @return object|WP_Error coupon row on success, WP_Error on failure
     */
    public static function validate( $code, $service, $expert, $buyer_email = '', $buyer_user_id = 0, $gross_amount = 0 ) {
        $coupon = self::get_by_code( $code );
        if ( ! $coupon ) {
            return new WP_Error( 'nmep_coupon_not_found', 'Coupon code not recognised.' );
        }

        // Active?
        if ( empty( $coupon->is_active ) ) {
            return new WP_Error( 'nmep_coupon_inactive', 'This coupon is not active.' );
        }

        // Start / end window (UTC, we stored DATETIME)
        $now = current_time( 'mysql', true ); // GMT
        if ( ! empty( $coupon->starts_at ) && strtotime( $coupon->starts_at ) > strtotime( $now ) ) {
            return new WP_Error( 'nmep_coupon_not_started', 'This coupon is not active yet.' );
        }
        if ( ! empty( $coupon->expires_at ) && strtotime( $coupon->expires_at ) < strtotime( $now ) ) {
            return new WP_Error( 'nmep_coupon_expired', 'This coupon has expired.' );
        }

        // Usage caps
        if ( ! empty( $coupon->max_uses ) && (int) $coupon->uses_count >= (int) $coupon->max_uses ) {
            return new WP_Error( 'nmep_coupon_used_up', 'This coupon has reached its usage limit.' );
        }

        // Per-buyer cap
        $per_buyer = max( 1, (int) $coupon->max_uses_per_buyer );
        $already_used = self::count_uses_by_buyer( $coupon->id, (int) $buyer_user_id, (string) $buyer_email );
        if ( $already_used >= $per_buyer ) {
            return new WP_Error( 'nmep_coupon_buyer_cap', 'You have already used this coupon.' );
        }

        // Min order
        if ( ! empty( $coupon->min_order_amount ) && (float) $gross_amount < (float) $coupon->min_order_amount ) {
            return new WP_Error(
                'nmep_coupon_min_order',
                sprintf( 'This coupon requires a minimum order of %s.', nmep_format_inr( $coupon->min_order_amount ) )
            );
        }

        // Scope: expert-owned coupons only apply to their own services
        if ( $coupon->owner_type === self::TYPE_EXPERT ) {
            if ( ! $expert || (int) $coupon->expert_id !== (int) $expert->id ) {
                return new WP_Error( 'nmep_coupon_scope', 'This coupon is not valid for this service.' );
            }
        }

        return $coupon;
    }

    /**
     * Compute the discount amount for a coupon against a base price.
     *
     * @return float non-negative discount, never greater than $base
     */
    public static function compute_discount( $coupon, $base ) {
        $base = max( 0.0, (float) $base );
        $value = max( 0.0, (float) $coupon->discount_value );

        if ( $coupon->discount_type === self::DISCOUNT_PERCENT ) {
            $pct = min( 100.0, $value );
            $discount = round( $base * ( $pct / 100.0 ), 2 );
        } else {
            // Reserved for 'fixed' — not exposed in v1 UI but computed safely
            $discount = round( $value, 2 );
        }

        // Cap by max_discount_amount if set
        if ( ! empty( $coupon->max_discount_amount ) ) {
            $discount = min( $discount, (float) $coupon->max_discount_amount );
        }

        return max( 0.0, min( $discount, $base ) );
    }

    /* ============================================================
       CHECKOUT HOOK
       ============================================================ */

    /**
     * Filter callback: mutate pricing if a valid coupon is in $_POST['coupon_code'].
     *
     * Implements "commission on original price":
     *   commission_amount = original_price * rate / 100
     *   gross             = original_price - discount
     *   expert_amount     = gross - commission_amount
     *
     * @param array   $pricing
     * @param array   $post_data Raw $_POST (from checkout handler)
     * @param object  $service
     * @param object  $expert
     * @param float   $commission_rate
     * @return array
     */
    public static function apply_at_checkout( $pricing, $post_data, $service, $expert, $commission_rate ) {
        $code = isset( $post_data['coupon_code'] ) ? (string) $post_data['coupon_code'] : '';
        $code = self::sanitize_code( $code );
        if ( $code === '' ) {
            return $pricing;
        }

        $original = isset( $pricing['original_amount'] ) ? (float) $pricing['original_amount'] : (float) $pricing['gross_amount'];
        $buyer_email    = isset( $post_data['buyer_email'] ) ? sanitize_email( $post_data['buyer_email'] ) : '';
        $buyer_user_id  = is_user_logged_in() ? get_current_user_id() : 0;

        $result = self::validate( $code, $service, $expert, $buyer_email, $buyer_user_id, $original );
        if ( is_wp_error( $result ) ) {
            // Silently ignore invalid coupon in the filter path — the checkout handler
            // will see the unchanged pricing. The AJAX validate endpoint is where the
            // user sees errors. But we DO flag so shortcodes can read the error if desired.
            if ( class_exists( 'NMEP_Logger' ) ) {
                NMEP_Logger::warning( 'Coupon rejected at checkout', array(
                    'code'  => $code,
                    'error' => $result->get_error_code(),
                ) );
            }
            return $pricing;
        }

        $coupon   = $result;
        $discount = self::compute_discount( $coupon, $original );
        if ( $discount <= 0 ) {
            return $pricing;
        }

        // Commission stays on ORIGINAL
        $commission = round( $original * ( (float) $commission_rate / 100 ), 2 );
        $new_gross  = round( $original - $discount, 2 );
        // Expert cannot go negative
        $expert_amt = max( 0.0, round( $new_gross - $commission, 2 ) );

        $pricing['original_amount']   = $original;
        $pricing['gross_amount']      = $new_gross;
        $pricing['discount_amount']   = $discount;
        $pricing['commission_amount'] = $commission;
        $pricing['expert_amount']     = $expert_amt;
        $pricing['coupon_code']       = $coupon->code;
        $pricing['coupon_id']         = (int) $coupon->id;
        $pricing['discount_source']   = 'coupon';

        if ( class_exists( 'NMEP_Logger' ) ) {
            NMEP_Logger::info( 'Coupon applied at checkout', array(
                'code'       => $coupon->code,
                'original'   => $original,
                'discount'   => $discount,
                'new_gross'  => $new_gross,
                'commission' => $commission,
                'expert'     => $expert_amt,
            ) );
        }

        return $pricing;
    }

    /* ============================================================
       AJAX VALIDATION (live price preview)
       ============================================================ */

    public static function ajax_validate() {
        if ( ! isset( $_POST['nonce'] ) || ! wp_verify_nonce( $_POST['nonce'], 'nmep_ajax' ) ) {
            wp_send_json_error( array( 'message' => 'Security check failed.' ), 403 );
        }

        // Mild rate limit — 20 per minute per user/IP
        if ( class_exists( 'NMEP_Guard' ) ) {
            if ( ! NMEP_Guard::rate_check( 'coupon_validate', 20, 60, 'user' ) ) {
                wp_send_json_error( array( 'message' => 'Too many attempts. Please wait.' ), 429 );
            }
        }

        $code       = isset( $_POST['code'] ) ? self::sanitize_code( $_POST['code'] ) : '';
        $service_id = isset( $_POST['service_id'] ) ? (int) $_POST['service_id'] : 0;
        $tier       = isset( $_POST['tier'] ) ? sanitize_key( $_POST['tier'] ) : 'basic';
        $email      = isset( $_POST['email'] ) ? sanitize_email( $_POST['email'] ) : '';

        if ( $code === '' ) {
            wp_send_json_error( array( 'message' => 'Enter a coupon code.' ) );
        }
        if ( ! $service_id ) {
            wp_send_json_error( array( 'message' => 'Invalid service.' ) );
        }

        $service = NMEP_Services::get( $service_id );
        if ( ! $service || $service->status !== NMEP_Services::STATUS_ACTIVE ) {
            wp_send_json_error( array( 'message' => 'Service unavailable.' ) );
        }

        $expert = NMEP_Compat::get_expert( $service->expert_id );
        $price  = (float) NMEP_Services::get_package_price( $service, $tier );

        if ( $price <= 0 ) {
            wp_send_json_error( array( 'message' => 'Invalid package.' ) );
        }

        $buyer_user_id = is_user_logged_in() ? get_current_user_id() : 0;
        $result = self::validate( $code, $service, $expert, $email, $buyer_user_id, $price );
        if ( is_wp_error( $result ) ) {
            wp_send_json_error( array(
                'message' => $result->get_error_message(),
                'code'    => $result->get_error_code(),
            ) );
        }

        $coupon   = $result;
        $discount = self::compute_discount( $coupon, $price );
        $final    = max( 0.0, round( $price - $discount, 2 ) );

        wp_send_json_success( array(
            'message'          => sprintf( 'Coupon applied — you save %s.', nmep_format_inr( $discount ) ),
            'code'             => $coupon->code,
            'discount_amount'  => $discount,
            'final_amount'     => $final,
            'original_amount'  => $price,
            'discount_display' => nmep_format_inr( $discount ),
            'final_display'    => nmep_format_inr( $final ),
            'original_display' => nmep_format_inr( $price ),
        ) );
    }

    /* ============================================================
       USAGE RECORDING (after payment captured)
       ============================================================ */

    public static function record_usage_after_payment( $order_id, $order ) {
        if ( ! is_object( $order ) || empty( $order->coupon_code ) ) {
            return;
        }

        $coupon = self::get_by_code( $order->coupon_code );
        if ( ! $coupon ) {
            return;
        }

        global $wpdb;
        $uses_table = self::table( 'coupon_uses' );

        // Idempotent on order_id (UNIQUE KEY)
        $wpdb->query( $wpdb->prepare(
            "INSERT IGNORE INTO $uses_table
             (coupon_id, order_id, buyer_user_id, buyer_email, discount_amount, original_amount, created_at)
             VALUES (%d, %d, %d, %s, %f, %f, %s)",
            (int) $coupon->id,
            (int) $order_id,
            (int) ( $order->buyer_user_id ?? 0 ),
            (string) ( $order->buyer_email ?? '' ),
            (float) ( $order->coupon_discount ?? 0 ),
            (float) ( $order->original_amount ?? $order->gross_amount ?? 0 ),
            current_time( 'mysql' )
        ) );

        // Only increment uses_count if we actually inserted (not a duplicate)
        if ( $wpdb->rows_affected > 0 ) {
            $wpdb->query( $wpdb->prepare(
                "UPDATE " . self::table( 'coupons' ) . " SET uses_count = uses_count + 1 WHERE id = %d",
                (int) $coupon->id
            ) );

            if ( class_exists( 'NMEP_Logger' ) ) {
                NMEP_Logger::info( 'Coupon use recorded', array(
                    'coupon_id' => $coupon->id,
                    'order_id'  => $order_id,
                    'discount'  => $order->coupon_discount,
                ) );
            }
        }
    }

    /* ============================================================
       ADMIN MENU + PAGE
       ============================================================ */

    public static function register_admin_menu() {
        add_submenu_page(
            'nmep-dashboard',
            'Coupons',
            'Coupons',
            'manage_options',
            'nmep-coupons',
            array( __CLASS__, 'render_admin_page' )
        );
    }

    public static function render_admin_page() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( 'Permission denied.' );
        }

        if ( isset( $_GET['nmep_coupon_saved'] ) ) {
            echo '<div class="notice notice-success is-dismissible"><p>Coupon saved.</p></div>';
        }
        if ( isset( $_GET['nmep_coupon_deleted'] ) ) {
            echo '<div class="notice notice-success is-dismissible"><p>Coupon deleted.</p></div>';
        }
        if ( isset( $_GET['nmep_error'] ) ) {
            echo '<div class="notice notice-error"><p>' . esc_html( urldecode( $_GET['nmep_error'] ) ) . '</p></div>';
        }

        $editing_id = isset( $_GET['edit'] ) ? (int) $_GET['edit'] : 0;
        $editing    = $editing_id ? self::get( $editing_id ) : null;

        $admin_coupons = self::get_all_admin();
        ?>
        <div class="wrap nmep-admin">
            <h1>Coupons</h1>
            <p>Create and manage platform-wide discount codes. Expert-created coupons are managed by experts from their dashboard.</p>

            <!-- CREATE / EDIT FORM -->
            <div class="nmep-section" style="background:#fff;padding:20px;border:1px solid #E5E7EB;border-radius:8px;">
                <h2 style="margin-top:0;"><?php echo $editing ? 'Edit Coupon' : 'Create New Coupon'; ?></h2>
                <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                    <input type="hidden" name="action" value="nmep_admin_save_coupon">
                    <?php wp_nonce_field( 'nmep_admin_save_coupon' ); ?>
                    <?php if ( $editing ) : ?>
                        <input type="hidden" name="coupon_id" value="<?php echo (int) $editing->id; ?>">
                    <?php endif; ?>

                    <table class="form-table">
                        <tr>
                            <th><label for="nmep_code">Code *</label></th>
                            <td>
                                <input type="text" id="nmep_code" name="code" required maxlength="40"
                                       value="<?php echo esc_attr( $editing->code ?? '' ); ?>"
                                       style="width:280px;text-transform:uppercase;font-family:monospace;"
                                       placeholder="LAUNCH10">
                                <p class="description">A-Z, 0-9, dash, underscore. Max 40 chars. Will be stored uppercase.</p>
                            </td>
                        </tr>
                        <tr>
                            <th><label>Description</label></th>
                            <td>
                                <input type="text" name="description" maxlength="200"
                                       value="<?php echo esc_attr( $editing->description ?? '' ); ?>"
                                       style="width:480px;"
                                       placeholder="Launch promo 10% off">
                            </td>
                        </tr>
                        <tr>
                            <th><label>Discount (%) *</label></th>
                            <td>
                                <input type="number" name="discount_value" required min="1" max="100" step="0.01"
                                       value="<?php echo esc_attr( $editing->discount_value ?? '10' ); ?>"
                                       style="width:120px;">
                                <span style="color:#6B7280;">Percentage off the order total.</span>
                            </td>
                        </tr>
                        <tr>
                            <th><label>Min Order (₹)</label></th>
                            <td>
                                <input type="number" name="min_order_amount" min="0" step="1"
                                       value="<?php echo esc_attr( $editing->min_order_amount ?? '' ); ?>"
                                       style="width:120px;" placeholder="Optional">
                            </td>
                        </tr>
                        <tr>
                            <th><label>Max Discount (₹)</label></th>
                            <td>
                                <input type="number" name="max_discount_amount" min="0" step="1"
                                       value="<?php echo esc_attr( $editing->max_discount_amount ?? '' ); ?>"
                                       style="width:120px;" placeholder="Optional cap">
                            </td>
                        </tr>
                        <tr>
                            <th><label>Max Total Uses</label></th>
                            <td>
                                <input type="number" name="max_uses" min="1" step="1"
                                       value="<?php echo esc_attr( $editing->max_uses ?? '' ); ?>"
                                       style="width:120px;" placeholder="Unlimited">
                            </td>
                        </tr>
                        <tr>
                            <th><label>Max Per Buyer</label></th>
                            <td>
                                <input type="number" name="max_uses_per_buyer" min="1" step="1"
                                       value="<?php echo esc_attr( $editing->max_uses_per_buyer ?? '1' ); ?>"
                                       style="width:120px;">
                            </td>
                        </tr>
                        <tr>
                            <th><label>Starts At</label></th>
                            <td>
                                <input type="datetime-local" name="starts_at"
                                       value="<?php echo esc_attr( ! empty( $editing->starts_at ) ? date( 'Y-m-d\TH:i', strtotime( $editing->starts_at ) ) : '' ); ?>">
                                <span style="color:#6B7280;">Leave empty to start immediately.</span>
                            </td>
                        </tr>
                        <tr>
                            <th><label>Expires At</label></th>
                            <td>
                                <input type="datetime-local" name="expires_at"
                                       value="<?php echo esc_attr( ! empty( $editing->expires_at ) ? date( 'Y-m-d\TH:i', strtotime( $editing->expires_at ) ) : '' ); ?>">
                                <span style="color:#6B7280;">Leave empty for no expiry.</span>
                            </td>
                        </tr>
                        <tr>
                            <th><label>Active</label></th>
                            <td>
                                <label>
                                    <input type="checkbox" name="is_active" value="1"
                                        <?php checked( $editing ? $editing->is_active : 1 ); ?>>
                                    Coupon is active and redeemable.
                                </label>
                            </td>
                        </tr>
                    </table>

                    <p>
                        <button type="submit" class="button button-primary"><?php echo $editing ? 'Update Coupon' : 'Create Coupon'; ?></button>
                        <?php if ( $editing ) : ?>
                            <a href="<?php echo esc_url( admin_url( 'admin.php?page=nmep-coupons' ) ); ?>" class="button">Cancel</a>
                        <?php endif; ?>
                    </p>
                </form>
            </div>

            <!-- LIST -->
            <h2 style="margin-top:32px;">All Admin Coupons (<?php echo count( $admin_coupons ); ?>)</h2>
            <table class="wp-list-table widefat fixed striped">
                <thead><tr>
                    <th>Code</th>
                    <th>Description</th>
                    <th>Discount</th>
                    <th>Uses</th>
                    <th>Expires</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr></thead>
                <tbody>
                    <?php if ( empty( $admin_coupons ) ) : ?>
                        <tr><td colspan="7" style="text-align:center;padding:40px;">No admin coupons yet.</td></tr>
                    <?php else : foreach ( $admin_coupons as $c ) :
                        $status_label = '';
                        if ( empty( $c->is_active ) ) {
                            $status_label = '<span style="color:#6B7280;">Inactive</span>';
                        } elseif ( ! empty( $c->expires_at ) && strtotime( $c->expires_at ) < time() ) {
                            $status_label = '<span style="color:#D63638;">Expired</span>';
                        } elseif ( ! empty( $c->max_uses ) && (int) $c->uses_count >= (int) $c->max_uses ) {
                            $status_label = '<span style="color:#D63638;">Used up</span>';
                        } else {
                            $status_label = '<span style="color:#10B981;font-weight:600;">Active</span>';
                        }
                    ?>
                    <tr>
                        <td><code style="font-weight:600;"><?php echo esc_html( $c->code ); ?></code></td>
                        <td><?php echo esc_html( $c->description ?: '—' ); ?></td>
                        <td><?php echo esc_html( rtrim( rtrim( $c->discount_value, '0' ), '.' ) ); ?>%</td>
                        <td><?php echo (int) $c->uses_count; ?><?php echo $c->max_uses ? ' / ' . (int) $c->max_uses : ''; ?></td>
                        <td><?php echo $c->expires_at ? esc_html( date( 'd M Y', strtotime( $c->expires_at ) ) ) : '—'; ?></td>
                        <td><?php echo $status_label; ?></td>
                        <td>
                            <a href="<?php echo esc_url( admin_url( 'admin.php?page=nmep-coupons&edit=' . (int) $c->id ) ); ?>" class="button button-small">Edit</a>
                            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline;" onsubmit="return confirm('Delete this coupon? Past orders that used it are preserved.');">
                                <input type="hidden" name="action" value="nmep_admin_delete_coupon">
                                <input type="hidden" name="coupon_id" value="<?php echo (int) $c->id; ?>">
                                <?php wp_nonce_field( 'nmep_admin_delete_coupon_' . $c->id ); ?>
                                <button type="submit" class="button button-small" style="color:#D63638;">Delete</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
        <?php
    }

    /* ============================================================
       ADMIN SAVE / DELETE HANDLERS
       ============================================================ */

    public static function handle_admin_save() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( 'Permission denied.' );
        }
        check_admin_referer( 'nmep_admin_save_coupon' );

        $id = isset( $_POST['coupon_id'] ) ? (int) $_POST['coupon_id'] : 0;
        $code = self::sanitize_code( $_POST['code'] ?? '' );
        if ( $code === '' ) {
            self::admin_redirect_error( 'Coupon code is required.' );
        }

        $data = self::build_data_from_post( $_POST, self::TYPE_ADMIN, null, get_current_user_id() );
        if ( is_wp_error( $data ) ) {
            self::admin_redirect_error( $data->get_error_message() );
        }

        // Uniqueness check (by code_upper), excluding current row on edit
        global $wpdb;
        $existing = $wpdb->get_var( $wpdb->prepare(
            "SELECT id FROM " . self::table( 'coupons' ) . " WHERE code_upper = %s AND id != %d LIMIT 1",
            $data['code_upper'], $id
        ) );
        if ( $existing ) {
            self::admin_redirect_error( 'A coupon with that code already exists.' );
        }

        if ( $id ) {
            $wpdb->update( self::table( 'coupons' ), $data, array( 'id' => $id ) );
        } else {
            $data['created_at'] = current_time( 'mysql' );
            $wpdb->insert( self::table( 'coupons' ), $data );
        }

        if ( class_exists( 'NMEP_Compat' ) ) {
            NMEP_Compat::audit_log( $id ? 'coupon_updated' : 'coupon_created', 'coupon', $id ?: $wpdb->insert_id, array(
                'code' => $data['code_upper'],
                'by'   => 'admin',
            ) );
        }

        wp_safe_redirect( admin_url( 'admin.php?page=nmep-coupons&nmep_coupon_saved=1' ) );
        exit;
    }

    public static function handle_admin_delete() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( 'Permission denied.' );
        }
        $id = isset( $_POST['coupon_id'] ) ? (int) $_POST['coupon_id'] : 0;
        check_admin_referer( 'nmep_admin_delete_coupon_' . $id );

        global $wpdb;
        $wpdb->delete( self::table( 'coupons' ), array( 'id' => $id, 'owner_type' => self::TYPE_ADMIN ) );

        if ( class_exists( 'NMEP_Compat' ) ) {
            NMEP_Compat::audit_log( 'coupon_deleted', 'coupon', $id, array( 'by' => 'admin' ) );
        }

        wp_safe_redirect( admin_url( 'admin.php?page=nmep-coupons&nmep_coupon_deleted=1' ) );
        exit;
    }

    private static function admin_redirect_error( $message ) {
        $url = add_query_arg( 'nmep_error', urlencode( $message ), admin_url( 'admin.php?page=nmep-coupons' ) );
        wp_safe_redirect( $url );
        exit;
    }

    /* ============================================================
       EXPERT UI (shortcode for expert dashboard embed)
       ============================================================ */

    public static function render_expert_coupons_shortcode( $atts ) {
        if ( ! is_user_logged_in() ) {
            return '<div class="nme-card"><p>Please log in to manage your coupons.</p></div>';
        }

        $expert = NMEP_Compat::get_expert_by_user( get_current_user_id() );
        if ( ! $expert || $expert->status !== 'approved' ) {
            return '<div class="nme-card"><p>You must be an approved expert to create coupons.</p></div>';
        }

        $enabled = (bool) NMEP_Settings::get( 'coupon_expert_enabled', true );
        if ( ! $enabled ) {
            return '<div class="nme-card"><p>Expert-created coupons are currently disabled. Contact support for platform-wide promotions.</p></div>';
        }

        $max_pct   = (float) NMEP_Settings::get( 'coupon_expert_max_percent', 30 );
        $max_active = (int) NMEP_Settings::get( 'coupon_expert_max_active', 3 );
        $coupons = self::get_for_expert( $expert->id );

        ob_start();

        // Status messages
        if ( isset( $_GET['nmep_coupon_saved'] ) ) {
            echo '<div class="nme-card" style="border-left:4px solid var(--nme-emerald);background:#ECFDF5;margin-bottom:16px;"><p style="margin:0;color:#065F46;">✅ Coupon saved.</p></div>';
        }
        if ( isset( $_GET['nmep_coupon_deleted'] ) ) {
            echo '<div class="nme-card" style="border-left:4px solid var(--nme-emerald);background:#ECFDF5;margin-bottom:16px;"><p style="margin:0;color:#065F46;">✅ Coupon deleted.</p></div>';
        }
        if ( isset( $_GET['nmep_error'] ) ) {
            echo '<div class="nme-card" style="border-left:4px solid #EF4444;background:#FEF2F2;margin-bottom:16px;"><p style="margin:0;color:#991B1B;">❌ ' . esc_html( urldecode( $_GET['nmep_error'] ) ) . '</p></div>';
        }

        $editing_id = isset( $_GET['edit_coupon'] ) ? (int) $_GET['edit_coupon'] : 0;
        $editing    = null;
        if ( $editing_id ) {
            $cand = self::get( $editing_id );
            if ( $cand && $cand->owner_type === self::TYPE_EXPERT && (int) $cand->expert_id === (int) $expert->id ) {
                $editing = $cand;
            }
        }

        $active_count = self::count_active_for_expert( $expert->id );
        $at_limit = ! $editing && $active_count >= $max_active;
        ?>
        <div class="nme-card">
            <h2 style="margin-top:0;">Your Coupons</h2>
            <p style="color:var(--nme-text-light,#6B7280);">
                Create discount codes that buyers can use on your services.
                You can offer up to <strong><?php echo esc_html( rtrim( rtrim( number_format( $max_pct, 2 ), '0' ), '.' ) ); ?>%</strong> off and run up to <strong><?php echo (int) $max_active; ?></strong> active coupons at a time.
            </p>
            <p style="background:#FFFBEB;border-left:3px solid #D4A843;padding:12px;border-radius:6px;font-size:0.9rem;">
                💡 Platform commission is always calculated on the <strong>original price</strong>, not the discounted price — your discount comes out of your share.
            </p>

            <?php if ( $at_limit ) : ?>
                <div class="nme-card" style="background:#FEF3C7;border-left:4px solid #F59E0B;">
                    <p style="margin:0;">You have reached your active coupon limit (<?php echo (int) $max_active; ?>). Disable or delete an existing coupon to create a new one.</p>
                </div>
            <?php else : ?>
                <h3><?php echo $editing ? 'Edit Coupon' : 'Create New Coupon'; ?></h3>
                <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                    <input type="hidden" name="action" value="nmep_expert_save_coupon">
                    <?php wp_nonce_field( 'nmep_expert_save_coupon' ); ?>
                    <?php if ( $editing ) : ?>
                        <input type="hidden" name="coupon_id" value="<?php echo (int) $editing->id; ?>">
                    <?php endif; ?>

                    <p>
                        <label>Code *</label>
                        <input type="text" name="code" required maxlength="40" style="text-transform:uppercase;font-family:monospace;"
                               value="<?php echo esc_attr( $editing->code ?? '' ); ?>"
                               placeholder="e.g. ALOTO10">
                        <small>A-Z, 0-9, dash, underscore only. Stored uppercase. Must be unique across the platform.</small>
                    </p>
                    <p>
                        <label>Description</label>
                        <input type="text" name="description" maxlength="200"
                               value="<?php echo esc_attr( $editing->description ?? '' ); ?>"
                               placeholder="Shown internally; buyers only see the code.">
                    </p>
                    <p>
                        <label>Discount (%) *</label>
                        <input type="number" name="discount_value" required min="1" max="<?php echo esc_attr( $max_pct ); ?>" step="0.01"
                               value="<?php echo esc_attr( $editing->discount_value ?? '10' ); ?>" style="width:120px;">
                        <small>Max allowed: <?php echo esc_html( $max_pct ); ?>%</small>
                    </p>
                    <p>
                        <label>Max Total Uses (optional)</label>
                        <input type="number" name="max_uses" min="1" step="1" style="width:120px;"
                               value="<?php echo esc_attr( $editing->max_uses ?? '' ); ?>" placeholder="Unlimited">
                    </p>
                    <p>
                        <label>Expires At (optional)</label>
                        <input type="datetime-local" name="expires_at"
                               value="<?php echo esc_attr( ! empty( $editing->expires_at ) ? date( 'Y-m-d\TH:i', strtotime( $editing->expires_at ) ) : '' ); ?>">
                    </p>
                    <p>
                        <label style="display:flex;align-items:center;gap:8px;font-weight:normal;">
                            <input type="checkbox" name="is_active" value="1" <?php checked( $editing ? $editing->is_active : 1 ); ?>>
                            Active (redeemable by buyers)
                        </label>
                    </p>
                    <p>
                        <button type="submit" class="nme-btn nme-btn-gold"><?php echo $editing ? 'Update Coupon' : 'Create Coupon'; ?></button>
                        <?php if ( $editing ) : ?>
                            <a href="<?php echo esc_url( strtok( $_SERVER['REQUEST_URI'], '?' ) ); ?>" class="nme-btn">Cancel</a>
                        <?php endif; ?>
                    </p>
                </form>
            <?php endif; ?>

            <h3 style="margin-top:28px;">Your Active & Past Coupons</h3>
            <?php if ( empty( $coupons ) ) : ?>
                <p style="color:var(--nme-text-light,#6B7280);">You haven't created any coupons yet.</p>
            <?php else : ?>
                <div style="overflow-x:auto;">
                    <table style="width:100%;border-collapse:collapse;min-width:640px;">
                        <thead>
                            <tr style="background:var(--nme-bg-soft,#F9FAFB);border-bottom:2px solid var(--nme-border,#E5E7EB);">
                                <th style="text-align:left;padding:10px;">Code</th>
                                <th style="text-align:left;padding:10px;">Discount</th>
                                <th style="text-align:left;padding:10px;">Uses</th>
                                <th style="text-align:left;padding:10px;">Expires</th>
                                <th style="text-align:left;padding:10px;">Status</th>
                                <th style="text-align:right;padding:10px;">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php foreach ( $coupons as $c ) :
                            $is_expired = ! empty( $c->expires_at ) && strtotime( $c->expires_at ) < time();
                            $is_usedup  = ! empty( $c->max_uses ) && (int) $c->uses_count >= (int) $c->max_uses;
                        ?>
                            <tr style="border-bottom:1px solid var(--nme-border,#E5E7EB);">
                                <td style="padding:10px;"><code style="font-weight:600;"><?php echo esc_html( $c->code ); ?></code></td>
                                <td style="padding:10px;"><?php echo esc_html( rtrim( rtrim( $c->discount_value, '0' ), '.' ) ); ?>%</td>
                                <td style="padding:10px;"><?php echo (int) $c->uses_count; ?><?php echo $c->max_uses ? ' / ' . (int) $c->max_uses : ''; ?></td>
                                <td style="padding:10px;"><?php echo $c->expires_at ? esc_html( date( 'd M Y', strtotime( $c->expires_at ) ) ) : '—'; ?></td>
                                <td style="padding:10px;">
                                    <?php if ( empty( $c->is_active ) ) : ?>
                                        <span style="color:#6B7280;">Inactive</span>
                                    <?php elseif ( $is_expired ) : ?>
                                        <span style="color:#D63638;">Expired</span>
                                    <?php elseif ( $is_usedup ) : ?>
                                        <span style="color:#D63638;">Used up</span>
                                    <?php else : ?>
                                        <span style="color:#10B981;font-weight:600;">Active</span>
                                    <?php endif; ?>
                                </td>
                                <td style="padding:10px;text-align:right;">
                                    <a href="<?php echo esc_url( add_query_arg( 'edit_coupon', (int) $c->id ) ); ?>" class="nme-btn" style="padding:4px 10px;font-size:0.8rem;min-height:0;">Edit</a>
                                    <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline;" onsubmit="return confirm('Delete this coupon?');">
                                        <input type="hidden" name="action" value="nmep_expert_delete_coupon">
                                        <input type="hidden" name="coupon_id" value="<?php echo (int) $c->id; ?>">
                                        <?php wp_nonce_field( 'nmep_expert_delete_coupon_' . $c->id ); ?>
                                        <button type="submit" class="nme-btn" style="padding:4px 10px;font-size:0.8rem;min-height:0;color:#D63638;">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
        <?php
        return ob_get_clean();
    }

    /* ============================================================
       EXPERT SAVE / DELETE HANDLERS
       ============================================================ */

    public static function handle_expert_save() {
        if ( ! is_user_logged_in() ) {
            wp_die( 'Permission denied.' );
        }
        check_admin_referer( 'nmep_expert_save_coupon' );

        $expert = NMEP_Compat::get_expert_by_user( get_current_user_id() );
        if ( ! $expert || $expert->status !== 'approved' ) {
            wp_die( 'You must be an approved expert.' );
        }

        if ( ! NMEP_Settings::get( 'coupon_expert_enabled', true ) ) {
            self::expert_redirect_error( 'Expert-created coupons are currently disabled.' );
        }

        $id   = isset( $_POST['coupon_id'] ) ? (int) $_POST['coupon_id'] : 0;
        $code = self::sanitize_code( $_POST['code'] ?? '' );
        if ( $code === '' ) {
            self::expert_redirect_error( 'Coupon code is required.' );
        }

        // If editing, confirm ownership
        if ( $id ) {
            $existing = self::get( $id );
            if ( ! $existing || $existing->owner_type !== self::TYPE_EXPERT || (int) $existing->expert_id !== (int) $expert->id ) {
                wp_die( 'Permission denied.' );
            }
        }

        // Enforce expert % cap
        $max_pct = (float) NMEP_Settings::get( 'coupon_expert_max_percent', 30 );
        $value   = (float) ( $_POST['discount_value'] ?? 0 );
        if ( $value <= 0 || $value > $max_pct ) {
            self::expert_redirect_error( sprintf( 'Discount must be between 0.01 and %s%%.', rtrim( rtrim( number_format( $max_pct, 2 ), '0' ), '.' ) ) );
        }

        // Enforce active coupons limit (only for new coupons, or if activating a previously inactive one)
        $active_count = self::count_active_for_expert( $expert->id );
        $max_active   = (int) NMEP_Settings::get( 'coupon_expert_max_active', 3 );
        $will_be_active = ! empty( $_POST['is_active'] );
        if ( $will_be_active ) {
            if ( ! $id && $active_count >= $max_active ) {
                self::expert_redirect_error( sprintf( 'Maximum %d active coupons allowed.', $max_active ) );
            }
            if ( $id && ! empty( $existing ) && empty( $existing->is_active ) && $active_count >= $max_active ) {
                self::expert_redirect_error( sprintf( 'Maximum %d active coupons allowed.', $max_active ) );
            }
        }

        $data = self::build_data_from_post( $_POST, self::TYPE_EXPERT, (int) $expert->id, get_current_user_id() );
        if ( is_wp_error( $data ) ) {
            self::expert_redirect_error( $data->get_error_message() );
        }

        // Uniqueness
        global $wpdb;
        $exists = $wpdb->get_var( $wpdb->prepare(
            "SELECT id FROM " . self::table( 'coupons' ) . " WHERE code_upper = %s AND id != %d LIMIT 1",
            $data['code_upper'], $id
        ) );
        if ( $exists ) {
            self::expert_redirect_error( 'That code is already in use. Please choose another.' );
        }

        if ( $id ) {
            $wpdb->update( self::table( 'coupons' ), $data, array( 'id' => $id ) );
        } else {
            $data['created_at'] = current_time( 'mysql' );
            $wpdb->insert( self::table( 'coupons' ), $data );
        }

        if ( class_exists( 'NMEP_Compat' ) ) {
            NMEP_Compat::audit_log( $id ? 'coupon_updated' : 'coupon_created', 'coupon', $id ?: $wpdb->insert_id, array(
                'code'      => $data['code_upper'],
                'expert_id' => (int) $expert->id,
                'by'        => 'expert',
            ) );
        }

        $url = add_query_arg( 'nmep_coupon_saved', 1, wp_get_referer() ?: home_url( '/' ) );
        // Strip edit_coupon + error params
        $url = remove_query_arg( array( 'edit_coupon', 'nmep_error', 'nmep_coupon_deleted' ), $url );
        wp_safe_redirect( $url );
        exit;
    }

    public static function handle_expert_delete() {
        if ( ! is_user_logged_in() ) {
            wp_die( 'Permission denied.' );
        }
        $id = isset( $_POST['coupon_id'] ) ? (int) $_POST['coupon_id'] : 0;
        check_admin_referer( 'nmep_expert_delete_coupon_' . $id );

        $expert = NMEP_Compat::get_expert_by_user( get_current_user_id() );
        if ( ! $expert ) {
            wp_die( 'Permission denied.' );
        }

        $c = self::get( $id );
        if ( ! $c || $c->owner_type !== self::TYPE_EXPERT || (int) $c->expert_id !== (int) $expert->id ) {
            wp_die( 'Permission denied.' );
        }

        global $wpdb;
        $wpdb->delete( self::table( 'coupons' ), array( 'id' => $id ) );

        if ( class_exists( 'NMEP_Compat' ) ) {
            NMEP_Compat::audit_log( 'coupon_deleted', 'coupon', $id, array(
                'expert_id' => (int) $expert->id,
                'by'        => 'expert',
            ) );
        }

        $url = add_query_arg( 'nmep_coupon_deleted', 1, wp_get_referer() ?: home_url( '/' ) );
        $url = remove_query_arg( array( 'edit_coupon', 'nmep_error', 'nmep_coupon_saved' ), $url );
        wp_safe_redirect( $url );
        exit;
    }

    private static function expert_redirect_error( $message ) {
        $url = wp_get_referer() ?: home_url( '/' );
        $url = add_query_arg( 'nmep_error', urlencode( $message ), $url );
        wp_safe_redirect( $url );
        exit;
    }

    /* ============================================================
       SHARED: BUILD DB DATA ARRAY FROM POST
       ============================================================ */

    /**
     * @return array|WP_Error row-ready array or error
     */
    private static function build_data_from_post( $post, $owner_type, $expert_id, $created_by_user_id ) {
        $code = self::sanitize_code( $post['code'] ?? '' );
        if ( $code === '' ) {
            return new WP_Error( 'nmep_bad_code', 'Invalid coupon code.' );
        }

        $value = (float) ( $post['discount_value'] ?? 0 );
        if ( $value <= 0 || $value > 100 ) {
            return new WP_Error( 'nmep_bad_value', 'Discount must be between 0.01 and 100.' );
        }

        $starts_at = ! empty( $post['starts_at'] ) ? date( 'Y-m-d H:i:s', strtotime( $post['starts_at'] ) ) : null;
        $expires_at = ! empty( $post['expires_at'] ) ? date( 'Y-m-d H:i:s', strtotime( $post['expires_at'] ) ) : null;

        if ( $starts_at && $expires_at && strtotime( $starts_at ) >= strtotime( $expires_at ) ) {
            return new WP_Error( 'nmep_bad_dates', 'Expiry must be after the start date.' );
        }

        return array(
            'code'                => $code,
            'code_upper'          => $code, // already uppercase via sanitize
            'owner_type'          => $owner_type,
            'expert_id'           => $expert_id,
            'created_by_user_id'  => (int) $created_by_user_id,
            'description'         => sanitize_text_field( $post['description'] ?? '' ),
            'discount_type'       => self::DISCOUNT_PERCENT,
            'discount_value'      => $value,
            'min_order_amount'    => isset( $post['min_order_amount'] ) && $post['min_order_amount'] !== '' ? (float) $post['min_order_amount'] : null,
            'max_discount_amount' => isset( $post['max_discount_amount'] ) && $post['max_discount_amount'] !== '' ? (float) $post['max_discount_amount'] : null,
            'max_uses'            => isset( $post['max_uses'] ) && $post['max_uses'] !== '' ? max( 1, (int) $post['max_uses'] ) : null,
            'max_uses_per_buyer'  => isset( $post['max_uses_per_buyer'] ) && $post['max_uses_per_buyer'] !== '' ? max( 1, (int) $post['max_uses_per_buyer'] ) : 1,
            'starts_at'           => $starts_at,
            'expires_at'          => $expires_at,
            'is_active'           => ! empty( $post['is_active'] ) ? 1 : 0,
        );
    }
}