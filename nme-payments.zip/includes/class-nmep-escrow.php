<?php
/**
 * NMEP_Escrow
 * Production-grade escrow management via Razorpay Route transfers.
 *
 * Key flows:
 * 1. PLACE HOLD: When payment captured, transfer to expert is created with on_hold=1
 *    (Already happens in Batch C via the order's transfers[] array)
 *    Here we sync the transfer record into our local DB.
 *
 * 2. RELEASE: When buyer approves OR auto-release fires, we update the transfer
 *    on_hold=0, which lets Razorpay settle it to the expert's bank.
 *
 * 3. REVERSE: When refund issued, transfer is reversed (money flows back to platform)
 *
 * @version 1.3.0 (Batch D)
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class NMEP_Escrow {

    public static function init() {
        // After payment captured, sync transfer record from Razorpay
        add_action( 'nmep_after_payment_captured', array( __CLASS__, 'sync_transfer_after_payment' ), 10, 2 );

        // Hook for buyer approval
        add_action( 'nmep_after_order_approved', array( __CLASS__, 'release_to_expert' ), 10, 1 );

        // Hook for cron auto-release
        add_action( 'nmep_cron_auto_release', array( __CLASS__, 'process_auto_releases' ) );
    }

    /* ============================================================
       SYNC TRANSFER FROM RAZORPAY (post-payment)
       ============================================================ */

    /**
     * After payment captured, fetch transfers from Razorpay and save locally.
     * Razorpay creates the transfer automatically because we passed transfers[]
     * in the order creation.
     */
    public static function sync_transfer_after_payment( $order_id, $order = null ) {
        if ( ! $order ) {
            $order = NMEP_Orders::get( $order_id );
        }
        if ( ! $order || empty( $order->razorpay_payment_id ) ) {
            return false;
        }

        // Fetch transfers from Razorpay
        $response = NMEP_Razorpay_Client::fetch_transfers_for_payment( $order->razorpay_payment_id );

        if ( is_wp_error( $response ) ) {
            NMEP_Logger::warning( 'Could not fetch transfers from Razorpay (likely no Linked Account)', array(
                'order_id' => $order_id,
                'error'    => $response->get_error_message(),
            ) );
            return false;
        }

        if ( empty( $response['items'] ) || ! is_array( $response['items'] ) ) {
            NMEP_Logger::info( 'No transfers found for payment (no Route Linked Account)', array(
                'order_id' => $order_id,
            ) );
            return false;
        }

        global $wpdb;
        $transfers_table = NMEP_Database::table( 'transfers' );
        $linked_account = NMEP_Linked_Accounts::get_for_expert( $order->expert_id );
        $linked_id = $linked_account ? (int) $linked_account->id : 0;

        foreach ( $response['items'] as $transfer ) {
            // Check if already saved
            $existing = $wpdb->get_var( $wpdb->prepare(
                "SELECT id FROM $transfers_table WHERE razorpay_transfer_id = %s",
                $transfer['id']
            ) );

            if ( $existing ) continue;

            // Save transfer record
            $wpdb->insert( $transfers_table, array(
                'order_id'             => (int) $order_id,
                'linked_account_id'    => $linked_id,
                'mode'                 => $order->mode,
                'razorpay_transfer_id' => sanitize_text_field( $transfer['id'] ),
                'razorpay_recipient'   => sanitize_text_field( $transfer['recipient'] ?? '' ),
                'amount'               => nmep_to_rupees( $transfer['amount'] ?? 0 ),
                'currency'             => sanitize_text_field( $transfer['currency'] ?? 'INR' ),
                'status'               => sanitize_text_field( $transfer['status'] ?? 'pending' ),
                'on_hold'              => ! empty( $transfer['on_hold'] ) ? 1 : 0,
                'on_hold_until'        => ! empty( $transfer['on_hold_until'] ) ? date( 'Y-m-d H:i:s', $transfer['on_hold_until'] ) : null,
                'api_response'         => wp_json_encode( $transfer ),
            ) );

            // Update order with transfer ID (use first one)
            if ( empty( $order->razorpay_transfer_id ) ) {
                NMEP_Orders::update( $order_id, array(
                    'razorpay_transfer_id' => sanitize_text_field( $transfer['id'] ),
                ) );
            }

            NMEP_Logger::info( 'Transfer synced to local DB', array(
                'order_id'    => $order_id,
                'transfer_id' => $transfer['id'],
                'amount'      => nmep_to_rupees( $transfer['amount'] ?? 0 ),
            ) );
        }

        return true;
    }

    /* ============================================================
       RELEASE ESCROW TO EXPERT
       ============================================================ */

    /**
     * Release escrow to expert.
     * Updates the Razorpay transfer to remove the hold, allowing settlement.
     */
    public static function release_to_expert( $order_id, $reason = 'buyer_approved' ) {
        $order = NMEP_Orders::get( $order_id );
        if ( ! $order ) {
            NMEP_Logger::error( 'release_to_expert: order not found', array( 'order_id' => $order_id ) );
            return false;
        }

        // Already released?
        if ( $order->escrow_status === NMEP_Orders::ESCROW_RELEASED ) {
            NMEP_Logger::info( 'release_to_expert: already released (idempotent)', array( 'order_id' => $order_id ) );
            return true;
        }

        // Must be in holding state
        if ( $order->escrow_status !== NMEP_Orders::ESCROW_HOLDING ) {
            NMEP_Logger::warning( 'release_to_expert: cannot release from current escrow status', array(
                'order_id'      => $order_id,
                'escrow_status' => $order->escrow_status,
            ) );
            return false;
        }

        global $wpdb;
        $transfers_table = NMEP_Database::table( 'transfers' );

        // Get all transfers for this order
        $transfers = $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM $transfers_table WHERE order_id = %d AND on_hold = 1",
            $order_id
        ) );

        if ( empty( $transfers ) ) {
            // No transfers to release — likely no Linked Account was attached
            // Mark escrow as released anyway (test mode or non-Route flow)
            NMEP_Orders::update( $order_id, array(
                'escrow_status' => NMEP_Orders::ESCROW_RELEASED,
                'released_at'   => current_time( 'mysql' ),
                'status'        => $reason === 'auto_released' ? NMEP_Orders::STATUS_AUTO_RELEASED : NMEP_Orders::STATUS_COMPLETED,
            ) );

            NMEP_Logger::info( 'release_to_expert: no transfers to release (marked released anyway)', array(
                'order_id' => $order_id,
                'reason'   => $reason,
            ) );

            NMEP_Compat::audit_log( 'escrow_released', 'order', $order_id, array( 'reason' => $reason, 'no_transfers' => true ) );

            // Send completion email
            if ( class_exists( 'NMEP_Emails' ) ) {
                $order = NMEP_Orders::get( $order_id );
                NMEP_Emails::send_order_completed( $order );
            }

            if ( class_exists( 'NMEP_Events' ) ) {
                if ( $reason === 'auto_released' ) {
                    NMEP_Events::emit( NMEP_Events::ORDER_AUTO_RELEASED, $order_id );
                } else {
                    NMEP_Events::emit( NMEP_Events::ORDER_COMPLETED, $order_id, $reason );
                }
            }

            return true;
        }

        $any_failed = false;

        // Update each transfer to remove hold
        foreach ( $transfers as $transfer ) {
            $response = NMEP_Razorpay_Client::update_transfer( $transfer->razorpay_transfer_id, array(
                'on_hold' => 0,
            ) );

            if ( is_wp_error( $response ) ) {
                $any_failed = true;
                NMEP_Logger::error( 'Failed to release transfer hold', array(
                    'order_id'    => $order_id,
                    'transfer_id' => $transfer->razorpay_transfer_id,
                    'error'       => $response->get_error_message(),
                ) );
                continue;
            }

            $wpdb->update( $transfers_table, array(
                'on_hold'      => 0,
                'on_hold_until' => null,
                'api_response' => wp_json_encode( $response ),
                'status'       => $response['status'] ?? 'pending',
            ), array( 'id' => $transfer->id ) );

            NMEP_Logger::info( 'Transfer hold released', array(
                'order_id'    => $order_id,
                'transfer_id' => $transfer->razorpay_transfer_id,
                'amount'      => $transfer->amount,
            ) );
        }

        if ( $any_failed ) {
            NMEP_Logger::error( 'release_to_expert: some transfers failed to release', array( 'order_id' => $order_id ) );
            return false;
        }

        // Update order
        NMEP_Orders::update( $order_id, array(
            'escrow_status' => NMEP_Orders::ESCROW_RELEASED,
            'released_at'   => current_time( 'mysql' ),
            'status'        => $reason === 'auto_released' ? NMEP_Orders::STATUS_AUTO_RELEASED : NMEP_Orders::STATUS_COMPLETED,
        ) );

        NMEP_Compat::audit_log( 'escrow_released', 'order', $order_id, array(
            'reason' => $reason,
            'amount' => $order->expert_amount,
        ) );

        // Send completion email
        if ( class_exists( 'NMEP_Emails' ) ) {
            $order = NMEP_Orders::get( $order_id );
            NMEP_Emails::send_order_completed( $order );
        }

        do_action( 'nmep_escrow_released', $order_id, $reason );

        // Fire canonical high-level events.
        if ( class_exists( 'NMEP_Events' ) ) {
            if ( $reason === 'auto_released' ) {
                NMEP_Events::emit( NMEP_Events::ORDER_AUTO_RELEASED, $order_id );
            } else {
                NMEP_Events::emit( NMEP_Events::ORDER_COMPLETED, $order_id, $reason );
            }
            NMEP_Events::emit( NMEP_Events::PAYOUT_SCHEDULED, $order_id, (float) $order->expert_amount );
        }

        return true;
    }

    /* ============================================================
       AUTO-RELEASE (CRON)
       ============================================================ */

    /**
     * Cron: Process all orders due for auto-release.
     * Runs hourly. Checks for orders where:
     * - status = delivered
     * - escrow_status = holding
     * - auto_release_at <= NOW()
     */
    public static function process_auto_releases() {
        $orders = NMEP_Orders::get_pending_auto_release();

        if ( empty( $orders ) ) {
            return;
        }

        NMEP_Logger::info( 'Auto-release cron: processing ' . count( $orders ) . ' orders' );

        $released = 0;
        $failed = 0;

        foreach ( $orders as $order ) {
            $result = self::release_to_expert( $order->id, 'auto_released' );
            if ( $result ) {
                $released++;
            } else {
                $failed++;
            }
        }

        NMEP_Logger::info( 'Auto-release cron complete', array(
            'total'    => count( $orders ),
            'released' => $released,
            'failed'   => $failed,
        ) );
    }

    /* ============================================================
       REVERSE FOR REFUND
       ============================================================ */

    /**
     * Reverse escrow transfer (for refund).
     * Pulls money back from expert's Linked Account to platform.
     */
    public static function reverse_for_refund( $order_id, $amount = null ) {
        $order = NMEP_Orders::get( $order_id );
        if ( ! $order ) return false;

        global $wpdb;
        $transfers_table = NMEP_Database::table( 'transfers' );

        $transfers = $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM $transfers_table WHERE order_id = %d AND status NOT IN ('reversed', 'failed')",
            $order_id
        ) );

        if ( empty( $transfers ) ) {
            NMEP_Logger::info( 'reverse_for_refund: no transfers to reverse', array( 'order_id' => $order_id ) );
            return true;
        }

        foreach ( $transfers as $transfer ) {
            $reverse_amount_paise = $amount !== null ? nmep_to_paise( $amount ) : null;
            $response = NMEP_Razorpay_Client::reverse_transfer( $transfer->razorpay_transfer_id, $reverse_amount_paise );

            if ( is_wp_error( $response ) ) {
                NMEP_Logger::error( 'Failed to reverse transfer', array(
                    'order_id'    => $order_id,
                    'transfer_id' => $transfer->razorpay_transfer_id,
                    'error'       => $response->get_error_message(),
                ) );
                continue;
            }

            $wpdb->update( $transfers_table, array(
                'status'       => 'reversed',
                'api_response' => wp_json_encode( $response ),
            ), array( 'id' => $transfer->id ) );

            NMEP_Logger::info( 'Transfer reversed for refund', array(
                'order_id'    => $order_id,
                'transfer_id' => $transfer->razorpay_transfer_id,
            ) );
        }

        NMEP_Orders::update( $order_id, array( 'escrow_status' => NMEP_Orders::ESCROW_REVERSED ) );

        return true;
    }
}
