<?php
/**
 * NMEP_Migrations
 *
 * Schema evolution for v2.0.0. Runs on plugin activation and on admin_init
 * when the stored `nmep_db_version` is behind. All statements are wrapped in
 * dbDelta-friendly form or explicit ALTER TABLE IF NOT EXISTS guards.
 *
 * Adding a new migration:
 *   1. Bump NMEP_DB_VERSION in nme-payments.php (also NMEP_VERSION).
 *   2. Append a new `self::upgrade_X_Y_Z( $current )` branch below.
 *   3. Increment the guard in that branch.
 *
 * @package NagalandMeExpertsPayments
 * @since   2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class NMEP_Migrations {

    const TARGET_VERSION = '2.0.0';

    public static function run() {
        $current = (string) get_option( 'nmep_db_version', '0.0.0' );

        if ( version_compare( $current, self::TARGET_VERSION, '>=' ) ) {
            return; // Already up to date
        }

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        self::upgrade_to_2_0_0( $current );

        update_option( 'nmep_db_version', self::TARGET_VERSION );
        NMEP_Logger::info( 'NMEP migrations applied', array( 'from' => $current, 'to' => self::TARGET_VERSION ) );
    }

    /* ============================================================
       2.0.0 — PAYOUTS, INVOICES, DISPUTES, TIERS, METRICS, EXTRAS,
               REVIEW UPGRADES, PORTFOLIO, AVAILABILITY, 2FA, AUDIT, GDPR
       ============================================================ */
    private static function upgrade_to_2_0_0( $current ) {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();

        /* ---------- Payout Ledger ---------- */
        $sql = "CREATE TABLE " . NMEP_Database::table( 'payouts' ) . " (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            order_id BIGINT(20) UNSIGNED NOT NULL,
            expert_id BIGINT(20) UNSIGNED NOT NULL,
            transfer_id BIGINT(20) UNSIGNED DEFAULT NULL,
            razorpay_transfer_id VARCHAR(50) DEFAULT NULL,
            method VARCHAR(20) DEFAULT 'bank',
            amount DECIMAL(12,2) NOT NULL DEFAULT 0.00,
            currency VARCHAR(10) NOT NULL DEFAULT 'INR',
            status VARCHAR(30) NOT NULL DEFAULT 'scheduled',
            scheduled_at DATETIME DEFAULT NULL,
            settled_at DATETIME DEFAULT NULL,
            failure_reason TEXT DEFAULT NULL,
            utr VARCHAR(60) DEFAULT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY order_id (order_id),
            KEY expert_id (expert_id),
            KEY status (status),
            KEY razorpay_transfer_id (razorpay_transfer_id)
        ) $charset_collate;";
        dbDelta( $sql );

        /* ---------- Invoices ---------- */
        $sql = "CREATE TABLE " . NMEP_Database::table( 'invoices' ) . " (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            order_id BIGINT(20) UNSIGNED NOT NULL,
            invoice_number VARCHAR(40) NOT NULL,
            financial_year VARCHAR(9) NOT NULL,
            issued_to_name VARCHAR(160) NOT NULL,
            issued_to_email VARCHAR(190) NOT NULL,
            issued_to_gstin VARCHAR(20) DEFAULT NULL,
            issued_to_state VARCHAR(80) DEFAULT NULL,
            place_of_supply VARCHAR(80) DEFAULT NULL,
            taxable_amount DECIMAL(12,2) NOT NULL DEFAULT 0.00,
            cgst_rate DECIMAL(5,2) NOT NULL DEFAULT 0.00,
            cgst_amount DECIMAL(12,2) NOT NULL DEFAULT 0.00,
            sgst_rate DECIMAL(5,2) NOT NULL DEFAULT 0.00,
            sgst_amount DECIMAL(12,2) NOT NULL DEFAULT 0.00,
            igst_rate DECIMAL(5,2) NOT NULL DEFAULT 0.00,
            igst_amount DECIMAL(12,2) NOT NULL DEFAULT 0.00,
            total_tax DECIMAL(12,2) NOT NULL DEFAULT 0.00,
            grand_total DECIMAL(12,2) NOT NULL DEFAULT 0.00,
            pdf_url VARCHAR(500) DEFAULT NULL,
            html_snapshot LONGTEXT DEFAULT NULL,
            issued_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            UNIQUE KEY invoice_number (invoice_number),
            KEY order_id (order_id),
            KEY financial_year (financial_year)
        ) $charset_collate;";
        dbDelta( $sql );

        /* ---------- Dispute Evidence ---------- */
        $sql = "CREATE TABLE " . NMEP_Database::table( 'dispute_evidence' ) . " (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            dispute_id BIGINT(20) UNSIGNED NOT NULL,
            uploaded_by BIGINT(20) UNSIGNED DEFAULT NULL,
            uploaded_role VARCHAR(20) NOT NULL,
            file_url VARCHAR(500) NOT NULL,
            file_mime VARCHAR(80) DEFAULT NULL,
            file_size INT UNSIGNED DEFAULT 0,
            note TEXT DEFAULT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY dispute_id (dispute_id)
        ) $charset_collate;";
        dbDelta( $sql );

        /* ---------- Expert Tier History ---------- */
        $sql = "CREATE TABLE " . NMEP_Database::table( 'expert_tier_history' ) . " (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            expert_id BIGINT(20) UNSIGNED NOT NULL,
            from_tier VARCHAR(30) DEFAULT NULL,
            to_tier VARCHAR(30) NOT NULL,
            reason VARCHAR(200) DEFAULT NULL,
            changed_by BIGINT(20) UNSIGNED DEFAULT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY expert_id (expert_id),
            KEY to_tier (to_tier)
        ) $charset_collate;";
        dbDelta( $sql );

        /* ---------- Expert Metrics (denormalised counters) ---------- */
        $sql = "CREATE TABLE " . NMEP_Database::table( 'expert_metrics' ) . " (
            expert_id BIGINT(20) UNSIGNED NOT NULL,
            orders_total INT UNSIGNED NOT NULL DEFAULT 0,
            orders_completed INT UNSIGNED NOT NULL DEFAULT 0,
            orders_cancelled INT UNSIGNED NOT NULL DEFAULT 0,
            orders_delivered_on_time INT UNSIGNED NOT NULL DEFAULT 0,
            orders_delivered_late INT UNSIGNED NOT NULL DEFAULT 0,
            response_count INT UNSIGNED NOT NULL DEFAULT 0,
            response_total_seconds BIGINT UNSIGNED NOT NULL DEFAULT 0,
            response_rate_percent DECIMAL(5,2) NOT NULL DEFAULT 0.00,
            avg_response_seconds INT UNSIGNED NOT NULL DEFAULT 0,
            disputes_opened INT UNSIGNED NOT NULL DEFAULT 0,
            disputes_lost INT UNSIGNED NOT NULL DEFAULT 0,
            current_tier VARCHAR(30) NOT NULL DEFAULT 'new',
            availability_mode VARCHAR(20) NOT NULL DEFAULT 'online',
            last_seen_at DATETIME DEFAULT NULL,
            away_message VARCHAR(200) DEFAULT NULL,
            tier_locked TINYINT(1) NOT NULL DEFAULT 0,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY  (expert_id),
            KEY current_tier (current_tier)
        ) $charset_collate;";
        dbDelta( $sql );

        /* ---------- Service Add-ons (extras) ---------- */
        $sql = "CREATE TABLE " . NMEP_Database::table( 'service_extras' ) . " (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            service_id BIGINT(20) UNSIGNED NOT NULL,
            sort_order INT NOT NULL DEFAULT 0,
            title VARCHAR(120) NOT NULL,
            description VARCHAR(400) DEFAULT NULL,
            price DECIMAL(10,2) NOT NULL DEFAULT 0.00,
            extra_delivery_days INT NOT NULL DEFAULT 0,
            is_active TINYINT(1) NOT NULL DEFAULT 1,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY service_id (service_id)
        ) $charset_collate;";
        dbDelta( $sql );

        $sql = "CREATE TABLE " . NMEP_Database::table( 'order_extras' ) . " (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            order_id BIGINT(20) UNSIGNED NOT NULL,
            extra_id BIGINT(20) UNSIGNED NOT NULL,
            title VARCHAR(120) NOT NULL,
            price DECIMAL(10,2) NOT NULL DEFAULT 0.00,
            extra_delivery_days INT NOT NULL DEFAULT 0,
            PRIMARY KEY  (id),
            KEY order_id (order_id)
        ) $charset_collate;";
        dbDelta( $sql );

        /* ---------- Review upgrades ---------- */
        $sql = "CREATE TABLE " . NMEP_Database::table( 'review_reports' ) . " (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            review_id BIGINT(20) UNSIGNED NOT NULL,
            reported_by BIGINT(20) UNSIGNED DEFAULT NULL,
            reason VARCHAR(200) NOT NULL,
            note TEXT DEFAULT NULL,
            status VARCHAR(20) NOT NULL DEFAULT 'open',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            resolved_at DATETIME DEFAULT NULL,
            PRIMARY KEY  (id),
            KEY review_id (review_id),
            KEY status (status)
        ) $charset_collate;";
        dbDelta( $sql );

        // Seller→buyer reviews (separate table so it can't collide with existing unique order_id index)
        $sql = "CREATE TABLE " . NMEP_Database::table( 'buyer_reviews' ) . " (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            order_id BIGINT(20) UNSIGNED NOT NULL,
            expert_id BIGINT(20) UNSIGNED NOT NULL,
            buyer_user_id BIGINT(20) UNSIGNED DEFAULT NULL,
            buyer_email VARCHAR(190) NOT NULL,
            rating TINYINT(1) NOT NULL DEFAULT 5,
            communication_rating TINYINT(1) NOT NULL DEFAULT 5,
            instructions_rating TINYINT(1) NOT NULL DEFAULT 5,
            payment_rating TINYINT(1) NOT NULL DEFAULT 5,
            comment LONGTEXT NOT NULL,
            is_public TINYINT(1) NOT NULL DEFAULT 0,
            status VARCHAR(20) NOT NULL DEFAULT 'published',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            UNIQUE KEY order_id (order_id),
            KEY buyer_user_id (buyer_user_id),
            KEY expert_id (expert_id)
        ) $charset_collate;";
        dbDelta( $sql );

        /* ---------- Portfolio ---------- */
        $sql = "CREATE TABLE " . NMEP_Database::table( 'portfolio' ) . " (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            expert_id BIGINT(20) UNSIGNED NOT NULL,
            title VARCHAR(200) NOT NULL,
            description LONGTEXT DEFAULT NULL,
            image_url VARCHAR(500) DEFAULT NULL,
            external_url VARCHAR(500) DEFAULT NULL,
            sort_order INT NOT NULL DEFAULT 0,
            is_public TINYINT(1) NOT NULL DEFAULT 1,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY expert_id (expert_id)
        ) $charset_collate;";
        dbDelta( $sql );

        $sql = "CREATE TABLE " . NMEP_Database::table( 'expert_languages' ) . " (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            expert_id BIGINT(20) UNSIGNED NOT NULL,
            language VARCHAR(60) NOT NULL,
            proficiency VARCHAR(30) NOT NULL DEFAULT 'conversational',
            PRIMARY KEY  (id),
            UNIQUE KEY expert_lang (expert_id, language)
        ) $charset_collate;";
        dbDelta( $sql );

        $sql = "CREATE TABLE " . NMEP_Database::table( 'expert_certifications' ) . " (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            expert_id BIGINT(20) UNSIGNED NOT NULL,
            title VARCHAR(200) NOT NULL,
            issuer VARCHAR(200) DEFAULT NULL,
            issued_year INT DEFAULT NULL,
            credential_url VARCHAR(500) DEFAULT NULL,
            sort_order INT NOT NULL DEFAULT 0,
            PRIMARY KEY  (id),
            KEY expert_id (expert_id)
        ) $charset_collate;";
        dbDelta( $sql );

        /* ---------- 2FA ---------- */
        $sql = "CREATE TABLE " . NMEP_Database::table( 'user_2fa' ) . " (
            user_id BIGINT(20) UNSIGNED NOT NULL,
            secret VARCHAR(64) NOT NULL,
            enabled TINYINT(1) NOT NULL DEFAULT 0,
            backup_codes TEXT DEFAULT NULL,
            last_used_at DATETIME DEFAULT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (user_id)
        ) $charset_collate;";
        dbDelta( $sql );

        /* ---------- Audit log (structured) ---------- */
        $sql = "CREATE TABLE " . NMEP_Database::table( 'audit_log' ) . " (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            actor_user_id BIGINT(20) UNSIGNED DEFAULT NULL,
            actor_role VARCHAR(30) DEFAULT NULL,
            event VARCHAR(80) NOT NULL,
            subject_type VARCHAR(40) DEFAULT NULL,
            subject_id BIGINT(20) UNSIGNED DEFAULT NULL,
            ip VARCHAR(64) DEFAULT NULL,
            user_agent VARCHAR(255) DEFAULT NULL,
            meta LONGTEXT DEFAULT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY event (event),
            KEY subject_type_id (subject_type, subject_id),
            KEY created_at (created_at)
        ) $charset_collate;";
        dbDelta( $sql );

        /* ---------- GDPR requests ---------- */
        $sql = "CREATE TABLE " . NMEP_Database::table( 'gdpr_requests' ) . " (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id BIGINT(20) UNSIGNED DEFAULT NULL,
            email VARCHAR(190) NOT NULL,
            request_type VARCHAR(20) NOT NULL,
            status VARCHAR(20) NOT NULL DEFAULT 'pending',
            verification_token VARCHAR(64) DEFAULT NULL,
            export_url VARCHAR(500) DEFAULT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            completed_at DATETIME DEFAULT NULL,
            PRIMARY KEY  (id),
            KEY user_id (user_id),
            KEY email (email)
        ) $charset_collate;";
        dbDelta( $sql );

        /* ---------- SMS / WhatsApp log ---------- */
        $sql = "CREATE TABLE " . NMEP_Database::table( 'sms_log' ) . " (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            channel VARCHAR(20) NOT NULL,
            recipient VARCHAR(40) NOT NULL,
            template VARCHAR(60) DEFAULT NULL,
            payload LONGTEXT DEFAULT NULL,
            provider_id VARCHAR(100) DEFAULT NULL,
            status VARCHAR(20) NOT NULL DEFAULT 'queued',
            response LONGTEXT DEFAULT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY recipient (recipient),
            KEY status (status)
        ) $charset_collate;";
        dbDelta( $sql );

        /* ---------- Message attachments (structured, with MIME/size) ---------- */
        $sql = "CREATE TABLE " . NMEP_Database::table( 'message_attachments' ) . " (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            message_id BIGINT(20) UNSIGNED NOT NULL,
            file_url VARCHAR(500) NOT NULL,
            file_mime VARCHAR(80) DEFAULT NULL,
            file_size INT UNSIGNED DEFAULT 0,
            original_name VARCHAR(200) DEFAULT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY message_id (message_id)
        ) $charset_collate;";
        dbDelta( $sql );

        /* ---------- Subcategories (lightweight, parent-child) ---------- */
        $sql = "CREATE TABLE " . NMEP_Database::table( 'subcategories' ) . " (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            category_id BIGINT(20) UNSIGNED NOT NULL,
            slug VARCHAR(120) NOT NULL,
            name VARCHAR(120) NOT NULL,
            sort_order INT NOT NULL DEFAULT 0,
            is_active TINYINT(1) NOT NULL DEFAULT 1,
            PRIMARY KEY  (id),
            UNIQUE KEY slug (slug),
            KEY category_id (category_id)
        ) $charset_collate;";
        dbDelta( $sql );

        /* ---------- Additive columns on existing tables (idempotent) ---------- */
        self::add_column_if_missing( NMEP_Database::table( 'services' ), 'subcategory_id', "BIGINT(20) UNSIGNED DEFAULT NULL AFTER category_id" );
        self::add_column_if_missing( NMEP_Database::table( 'services' ), 'has_extras',     "TINYINT(1) NOT NULL DEFAULT 0 AFTER tags" );

        self::add_column_if_missing( NMEP_Database::table( 'orders' ), 'extras_total',   "DECIMAL(10,2) NOT NULL DEFAULT 0.00 AFTER gross_amount" );
        self::add_column_if_missing( NMEP_Database::table( 'orders' ), 'tax_amount',     "DECIMAL(10,2) NOT NULL DEFAULT 0.00 AFTER commission_amount" );
        self::add_column_if_missing( NMEP_Database::table( 'orders' ), 'invoice_id',     "BIGINT(20) UNSIGNED DEFAULT NULL AFTER api_response" );
        self::add_column_if_missing( NMEP_Database::table( 'orders' ), 'payment_retries','TINYINT UNSIGNED NOT NULL DEFAULT 0 AFTER invoice_id' );

        self::add_column_if_missing( NMEP_Database::table( 'disputes' ), 'sla_due_at',     "DATETIME DEFAULT NULL AFTER status" );
        self::add_column_if_missing( NMEP_Database::table( 'disputes' ), 'escalated_at',   "DATETIME DEFAULT NULL AFTER sla_due_at" );
        self::add_column_if_missing( NMEP_Database::table( 'disputes' ), 'expert_response','LONGTEXT DEFAULT NULL AFTER description' );

        self::add_column_if_missing( NMEP_Database::table( 'reviews' ), 'communication_rating', "TINYINT(1) NOT NULL DEFAULT 0 AFTER rating" );
        self::add_column_if_missing( NMEP_Database::table( 'reviews' ), 'as_described_rating',  "TINYINT(1) NOT NULL DEFAULT 0 AFTER communication_rating" );
        self::add_column_if_missing( NMEP_Database::table( 'reviews' ), 'recommend_rating',     "TINYINT(1) NOT NULL DEFAULT 0 AFTER as_described_rating" );
        self::add_column_if_missing( NMEP_Database::table( 'reviews' ), 'is_flagged',           "TINYINT(1) NOT NULL DEFAULT 0 AFTER status" );

        self::add_column_if_missing( NMEP_Database::table( 'order_messages' ), 'blocked_reason', "VARCHAR(60) DEFAULT NULL AFTER is_read" );

        self::add_column_if_missing( NMEP_Database::table( 'linked_accounts' ), 'payout_method', "VARCHAR(20) NOT NULL DEFAULT 'bank' AFTER bank_ifsc" );
        self::add_column_if_missing( NMEP_Database::table( 'linked_accounts' ), 'upi_vpa',       "VARCHAR(100) DEFAULT NULL AFTER payout_method" );
        self::add_column_if_missing( NMEP_Database::table( 'linked_accounts' ), 'razorpay_fund_account_id', "VARCHAR(60) DEFAULT NULL AFTER upi_vpa" );

        /* ---------- Composite indexes ---------- */
        self::add_index_if_missing( NMEP_Database::table( 'orders' ), 'expert_status',   'KEY expert_status (expert_id, status)' );
        self::add_index_if_missing( NMEP_Database::table( 'orders' ), 'buyer_status',    'KEY buyer_status (buyer_user_id, status)' );
        self::add_index_if_missing( NMEP_Database::table( 'orders' ), 'created_desc',    'KEY created_desc (created_at)' );
    }

    /* ============================================================
       UTILITIES
       ============================================================ */
    public static function add_column_if_missing( $table, $column, $definition ) {
        global $wpdb;
        $exists = $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
             WHERE TABLE_SCHEMA = %s AND TABLE_NAME = %s AND COLUMN_NAME = %s",
            DB_NAME, $table, $column
        ) );
        if ( (int) $exists === 0 ) {
            // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
            $wpdb->query( "ALTER TABLE `$table` ADD COLUMN `$column` $definition" );
        }
    }

    public static function add_index_if_missing( $table, $index_name, $definition ) {
        global $wpdb;
        $exists = $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM INFORMATION_SCHEMA.STATISTICS
             WHERE TABLE_SCHEMA = %s AND TABLE_NAME = %s AND INDEX_NAME = %s",
            DB_NAME, $table, $index_name
        ) );
        if ( (int) $exists === 0 ) {
            // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
            $wpdb->query( "ALTER TABLE `$table` ADD $definition" );
        }
    }
}
