<?php
/**
 * NMEP_Services
 * Service/gig CRUD operations, validation, status management.
 *
 * Lifecycle: draft -> pending_review -> active -> paused -> archived
 *                 -> rejected (back to draft after edit)
 *
 * @package NagalandMeExpertsPayments
 * @version 1.1.0 (Batch B)
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class NMEP_Services {

    // Service status lifecycle
    const STATUS_DRAFT          = 'draft';
    const STATUS_PENDING_REVIEW = 'pending_review';
    const STATUS_ACTIVE         = 'active';
    const STATUS_PAUSED         = 'paused';
    const STATUS_REJECTED       = 'rejected';
    const STATUS_ARCHIVED       = 'archived';

    // Maximum services per expert (configurable in future)
    const MAX_ACTIVE_SERVICES_PER_EXPERT = 10;

    public static function init() {
        add_action( 'admin_post_nmep_save_service',     array( __CLASS__, 'handle_save' ) );
        add_action( 'admin_post_nmep_submit_service',   array( __CLASS__, 'handle_submit_for_review' ) );
        add_action( 'admin_post_nmep_pause_service',    array( __CLASS__, 'handle_pause' ) );
        add_action( 'admin_post_nmep_resume_service',   array( __CLASS__, 'handle_resume' ) );
        add_action( 'admin_post_nmep_delete_service',   array( __CLASS__, 'handle_delete' ) );
        add_action( 'admin_post_nmep_approve_service',  array( __CLASS__, 'handle_admin_approve' ) );
        add_action( 'admin_post_nmep_reject_service',   array( __CLASS__, 'handle_admin_reject' ) );

        // Track service views (for stats)
        add_action( 'nmep_service_viewed', array( __CLASS__, 'increment_view_count' ), 10, 1 );
    }

    /* ============================================================
       READ OPERATIONS
       ============================================================ */

    public static function get( $id ) {
        global $wpdb;
        return $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM " . NMEP_Database::table( 'services' ) . " WHERE id = %d",
            (int) $id
        ) );
    }

    public static function get_by_slug( $slug ) {
        global $wpdb;
        return $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM " . NMEP_Database::table( 'services' ) . " WHERE slug = %s",
            sanitize_title( $slug )
        ) );
    }

    /**
     * Get services for a specific expert (any status)
     */
    public static function get_for_expert( $expert_id, $status = null ) {
        global $wpdb;

        $where = $wpdb->prepare( "WHERE expert_id = %d", (int) $expert_id );
        if ( $status ) {
            $where .= $wpdb->prepare( " AND status = %s", $status );
        }

        return $wpdb->get_results(
            "SELECT * FROM " . NMEP_Database::table( 'services' ) . "
             $where ORDER BY created_at DESC"
        );
    }

    /**
     * Get active services for public display
     */
    public static function get_active( $args = array() ) {
        global $wpdb;

        $defaults = array(
            'expert_id'   => 0,
            'category_id' => 0,
            'limit'       => 24,
            'offset'      => 0,
            'order_by'    => 'popular', // popular | newest | rating | price_low | price_high
            'search'      => '',
        );
        $args = wp_parse_args( $args, $defaults );

        $where_clauses = array( "s.status = 'active'" );
        $params = array();

        if ( $args['expert_id'] ) {
            $where_clauses[] = "s.expert_id = %d";
            $params[] = (int) $args['expert_id'];
        }

        if ( $args['category_id'] ) {
            $where_clauses[] = "s.category_id = %d";
            $params[] = (int) $args['category_id'];
        }

        if ( $args['search'] ) {
            $like = '%' . $wpdb->esc_like( $args['search'] ) . '%';
            $where_clauses[] = "(s.title LIKE %s OR s.short_description LIKE %s OR s.tags LIKE %s)";
            $params[] = $like;
            $params[] = $like;
            $params[] = $like;
        }

        $where = 'WHERE ' . implode( ' AND ', $where_clauses );

        // Order
        switch ( $args['order_by'] ) {
            case 'newest':
                $order = "ORDER BY s.created_at DESC";
                break;
            case 'rating':
                $order = "ORDER BY s.avg_rating DESC, s.reviews_count DESC";
                break;
            case 'price_low':
                $order = "ORDER BY s.basic_price ASC";
                break;
            case 'price_high':
                $order = "ORDER BY s.basic_price DESC";
                break;
            case 'popular':
            default:
                $order = "ORDER BY s.orders_count DESC, s.avg_rating DESC, s.created_at DESC";
        }

        $params[] = (int) $args['limit'];
        $params[] = (int) $args['offset'];

        $sql = "SELECT s.*, e.full_name AS expert_name, e.tier AS expert_tier, e.profile_photo AS expert_photo, e.is_founding_expert
                FROM " . NMEP_Database::table( 'services' ) . " s
                LEFT JOIN " . NMEP_Compat::base_table( 'experts' ) . " e ON e.id = s.expert_id
                $where $order LIMIT %d OFFSET %d";

        return $wpdb->get_results( $wpdb->prepare( $sql, $params ) );
    }

    /**
     * Get pending services for admin review
     */
    public static function get_pending_review( $limit = 50 ) {
        global $wpdb;
        return $wpdb->get_results( $wpdb->prepare(
            "SELECT s.*, e.full_name AS expert_name, e.email AS expert_email
             FROM " . NMEP_Database::table( 'services' ) . " s
             LEFT JOIN " . NMEP_Compat::base_table( 'experts' ) . " e ON e.id = s.expert_id
             WHERE s.status = %s
             ORDER BY s.updated_at ASC
             LIMIT %d",
            self::STATUS_PENDING_REVIEW, $limit
        ) );
    }

    public static function count_by_status( $status, $expert_id = null ) {
        global $wpdb;
        if ( $expert_id ) {
            return (int) $wpdb->get_var( $wpdb->prepare(
                "SELECT COUNT(*) FROM " . NMEP_Database::table( 'services' ) . "
                 WHERE status = %s AND expert_id = %d",
                $status, (int) $expert_id
            ) );
        }
        return (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM " . NMEP_Database::table( 'services' ) . " WHERE status = %s",
            $status
        ) );
    }

    /* ============================================================
       PACKAGE TIER HELPERS
       ============================================================ */

    /**
     * v1.5.4: Map internal tier slugs to friendly display names
     * Internal: basic / standard / premium  (kept for DB compat)
     * Display:  Starter / Standard / Pro
     */
    public static function get_friendly_tier_name( $tier ) {
        $map = array(
            'basic'    => 'Starter',
            'standard' => 'Standard',
            'premium'  => 'Pro',
        );
        return $map[ strtolower( $tier ) ] ?? ucfirst( $tier );
    }

    public static function get_package_price( $service, $tier ) {
        $tier = strtolower( $tier );
        if ( ! in_array( $tier, array( 'basic', 'standard', 'premium' ), true ) ) {
            return 0;
        }
        $field = $tier . '_price';
        return (float) ( $service->$field ?? 0 );
    }

    /**
     * v1.5.4: Returns seller's custom title if set, else friendly name (Starter/Standard/Pro)
     */
    public static function get_package_title( $service, $tier ) {
        $field = strtolower( $tier ) . '_title';
        $custom = trim( (string) ( $service->$field ?? '' ) );
        if ( $custom !== '' ) return $custom;
        return self::get_friendly_tier_name( $tier );
    }

    /**
     * v1.5.4: Returns array of tiers that have a price set (in order)
     */
    public static function get_active_tiers( $service ) {
        $tiers = array();
        foreach ( array( 'basic', 'standard', 'premium' ) as $tier ) {
            if ( (float) $service->{$tier . '_price'} > 0 ) {
                $tiers[] = $tier;
            }
        }
        return $tiers;
    }

    public static function get_delivery_days( $service, $tier ) {
        $field = strtolower( $tier ) . '_delivery_days';
        return (int) ( $service->$field ?? 3 );
    }

    public static function get_revisions( $service, $tier ) {
        $field = strtolower( $tier ) . '_revisions';
        return (int) ( $service->$field ?? 1 );
    }

    public static function get_package_features( $service, $tier ) {
        $field = strtolower( $tier ) . '_features';
        $raw = $service->$field ?? '';
        if ( ! $raw ) return array();
        return array_filter( array_map( 'trim', explode( "\n", $raw ) ) );
    }

    /**
     * Check if expert has reached max active services limit
     */
    public static function has_reached_active_limit( $expert_id ) {
        $count = self::count_by_status( self::STATUS_ACTIVE, $expert_id );
        $count += self::count_by_status( self::STATUS_PENDING_REVIEW, $expert_id );
        return $count >= self::MAX_ACTIVE_SERVICES_PER_EXPERT;
    }

    /* ============================================================
       SAVE / UPDATE
       ============================================================ */

    /**
     * Handle service save (from expert form)
     */
    public static function handle_save() {
        if ( ! is_user_logged_in() ) {
            wp_die( 'You must be logged in.' );
        }

        if ( ! isset( $_POST['nmep_nonce'] ) || ! wp_verify_nonce( $_POST['nmep_nonce'], 'nmep_save_service' ) ) {
            wp_die( 'Security check failed.' );
        }

        $expert = NMEP_Compat::get_expert_by_user( get_current_user_id() );
        if ( ! $expert || $expert->status !== 'approved' ) {
            wp_die( 'You must be an approved expert to create services.' );
        }

        $service_id = isset( $_POST['service_id'] ) ? (int) $_POST['service_id'] : 0;
        $data = self::sanitize_service_input( $_POST, $expert->id );

        // Validate
        $errors = self::validate( $data, $service_id );
        if ( ! empty( $errors ) ) {
            self::redirect_with_error( implode( ' | ', $errors ), $service_id );
            return;
        }

        if ( $service_id > 0 ) {
            // UPDATE existing
            $existing = self::get( $service_id );
            if ( ! $existing || (int) $existing->expert_id !== (int) $expert->id ) {
                wp_die( 'Permission denied: this service does not belong to you.' );
            }

            // If service was active and is now edited, send back to pending review
            if ( $existing->status === self::STATUS_ACTIVE ) {
                $data['status'] = self::STATUS_PENDING_REVIEW;
            } elseif ( $existing->status === self::STATUS_REJECTED ) {
                $data['status'] = self::STATUS_DRAFT;
            } else {
                $data['status'] = $existing->status;
            }

            $result = self::update( $service_id, $data );
            if ( $result === false ) {
                self::redirect_with_error( 'Could not save service. Please try again.', $service_id );
                return;
            }

            NMEP_Logger::info( 'Service updated', array( 'service_id' => $service_id, 'expert_id' => $expert->id ) );
            self::redirect_with_success( 'Service saved successfully.', $service_id );
        } else {
            // CREATE new
            if ( self::has_reached_active_limit( $expert->id ) ) {
                self::redirect_with_error( 'You have reached the maximum of ' . self::MAX_ACTIVE_SERVICES_PER_EXPERT . ' active services. Pause one before adding more.', 0 );
                return;
            }

            $data['expert_id'] = (int) $expert->id;
            $data['status'] = self::STATUS_DRAFT;
            $data['slug'] = NMEP_Database::generate_service_slug( $data['title'], $expert->id );

            $new_id = self::create( $data );
            if ( ! $new_id ) {
                self::redirect_with_error( 'Could not create service. Please try again.', 0 );
                return;
            }

            NMEP_Logger::info( 'Service created', array( 'service_id' => $new_id, 'expert_id' => $expert->id ) );
            NMEP_Compat::audit_log( 'service_created', 'service', $new_id, array(
                'expert_id' => $expert->id,
                'title'     => $data['title'],
            ) );

            self::redirect_with_success( 'Service draft created. Add more details, then submit for review.', $new_id );
        }
    }

    /**
     * Handle "Submit for Review"
     */
    public static function handle_submit_for_review() {
        if ( ! is_user_logged_in() ) wp_die( 'Login required.' );

        $service_id = isset( $_POST['service_id'] ) ? (int) $_POST['service_id'] : 0;
        if ( ! wp_verify_nonce( $_POST['_wpnonce'] ?? '', 'nmep_submit_service_' . $service_id ) ) {
            wp_die( 'Invalid request.' );
        }

        $expert = NMEP_Compat::get_expert_by_user( get_current_user_id() );
        $service = self::get( $service_id );

        if ( ! $expert || ! $service || (int) $service->expert_id !== (int) $expert->id ) {
            wp_die( 'Permission denied.' );
        }

        // Validate completeness
        $errors = self::validate_for_submission( $service );
        if ( ! empty( $errors ) ) {
            self::redirect_with_error( 'Cannot submit: ' . implode( ', ', $errors ), $service_id );
            return;
        }

        self::update( $service_id, array( 'status' => self::STATUS_PENDING_REVIEW ) );

        NMEP_Logger::info( 'Service submitted for review', array( 'service_id' => $service_id ) );
        NMEP_Compat::audit_log( 'service_submitted_for_review', 'service', $service_id );

        self::redirect_with_success( 'Service submitted for review. We will review it within 24-48 hours.', $service_id );
    }

    /**
     * Pause an active service (expert action)
     */
    public static function handle_pause() {
        if ( ! is_user_logged_in() ) wp_die( 'Login required.' );

        $service_id = isset( $_POST['service_id'] ) ? (int) $_POST['service_id'] : 0;
        if ( ! wp_verify_nonce( $_POST['_wpnonce'] ?? '', 'nmep_pause_service_' . $service_id ) ) {
            wp_die( 'Invalid request.' );
        }

        $expert = NMEP_Compat::get_expert_by_user( get_current_user_id() );
        $service = self::get( $service_id );

        if ( ! $expert || ! $service || (int) $service->expert_id !== (int) $expert->id ) {
            wp_die( 'Permission denied.' );
        }

        self::update( $service_id, array( 'status' => self::STATUS_PAUSED ) );
        NMEP_Logger::info( 'Service paused by expert', array( 'service_id' => $service_id ) );

        self::redirect_with_success( 'Service paused. It is no longer visible to buyers.', $service_id );
    }

    /**
     * Resume a paused service
     */
    public static function handle_resume() {
        if ( ! is_user_logged_in() ) wp_die( 'Login required.' );

        $service_id = isset( $_POST['service_id'] ) ? (int) $_POST['service_id'] : 0;
        if ( ! wp_verify_nonce( $_POST['_wpnonce'] ?? '', 'nmep_resume_service_' . $service_id ) ) {
            wp_die( 'Invalid request.' );
        }

        $expert = NMEP_Compat::get_expert_by_user( get_current_user_id() );
        $service = self::get( $service_id );

        if ( ! $expert || ! $service || (int) $service->expert_id !== (int) $expert->id ) {
            wp_die( 'Permission denied.' );
        }

        self::update( $service_id, array( 'status' => self::STATUS_ACTIVE ) );
        NMEP_Logger::info( 'Service resumed', array( 'service_id' => $service_id ) );

        self::redirect_with_success( 'Service resumed. It is now visible to buyers again.', $service_id );
    }

    /**
     * Delete (archive) a service
     */
    public static function handle_delete() {
        if ( ! is_user_logged_in() ) wp_die( 'Login required.' );

        $service_id = isset( $_POST['service_id'] ) ? (int) $_POST['service_id'] : 0;
        if ( ! wp_verify_nonce( $_POST['_wpnonce'] ?? '', 'nmep_delete_service_' . $service_id ) ) {
            wp_die( 'Invalid request.' );
        }

        $expert = NMEP_Compat::get_expert_by_user( get_current_user_id() );
        $service = self::get( $service_id );

        if ( ! $expert || ! $service || (int) $service->expert_id !== (int) $expert->id ) {
            wp_die( 'Permission denied.' );
        }

        // Check if there are active orders
        global $wpdb;
        $active_orders = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM " . NMEP_Database::table( 'orders' ) . "
             WHERE service_id = %d AND status IN ('paid', 'in_progress', 'delivered', 'revision', 'disputed')",
            $service_id
        ) );

        if ( $active_orders > 0 ) {
            self::redirect_with_error( 'Cannot delete: this service has ' . $active_orders . ' active orders. Pause it instead.', $service_id );
            return;
        }

        // Soft delete (archive)
        self::update( $service_id, array( 'status' => self::STATUS_ARCHIVED ) );
        NMEP_Logger::info( 'Service archived', array( 'service_id' => $service_id ) );
        NMEP_Compat::audit_log( 'service_archived', 'service', $service_id );

        self::redirect_with_success( 'Service archived.', 0 );
    }

    /**
     * Admin approves a service
     */
    public static function handle_admin_approve() {
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Permission denied.' );

        $service_id = isset( $_POST['service_id'] ) ? (int) $_POST['service_id'] : 0;
        if ( ! wp_verify_nonce( $_POST['_wpnonce'] ?? '', 'nmep_approve_service_' . $service_id ) ) {
            wp_die( 'Invalid request.' );
        }

        self::update( $service_id, array(
            'status'           => self::STATUS_ACTIVE,
            'approved_at'      => current_time( 'mysql' ),
            'approved_by'      => get_current_user_id(),
            'rejection_reason' => null,
        ) );

        $service = self::get( $service_id );
        NMEP_Logger::info( 'Service approved by admin', array( 'service_id' => $service_id ) );
        NMEP_Compat::audit_log( 'service_approved', 'service', $service_id );

        // Notify the expert
        if ( class_exists( 'NMEP_Emails' ) && method_exists( 'NMEP_Emails', 'send_service_approved' ) ) {
            NMEP_Emails::send_service_approved( $service );
        }

        wp_safe_redirect( admin_url( 'admin.php?page=nmep-services-review&approved=1' ) );
        exit;
    }

    /**
     * Admin rejects a service
     */
    public static function handle_admin_reject() {
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Permission denied.' );

        $service_id = isset( $_POST['service_id'] ) ? (int) $_POST['service_id'] : 0;
        if ( ! wp_verify_nonce( $_POST['_wpnonce'] ?? '', 'nmep_reject_service_' . $service_id ) ) {
            wp_die( 'Invalid request.' );
        }

        $reason = sanitize_textarea_field( $_POST['rejection_reason'] ?? '' );
        if ( empty( $reason ) ) {
            wp_die( 'Please provide a rejection reason.' );
        }

        self::update( $service_id, array(
            'status'           => self::STATUS_REJECTED,
            'rejection_reason' => $reason,
        ) );

        $service = self::get( $service_id );
        NMEP_Logger::info( 'Service rejected by admin', array( 'service_id' => $service_id, 'reason' => $reason ) );
        NMEP_Compat::audit_log( 'service_rejected', 'service', $service_id, array( 'reason' => $reason ) );

        if ( class_exists( 'NMEP_Emails' ) && method_exists( 'NMEP_Emails', 'send_service_rejected' ) ) {
            NMEP_Emails::send_service_rejected( $service, $reason );
        }

        wp_safe_redirect( admin_url( 'admin.php?page=nmep-services-review&rejected=1' ) );
        exit;
    }

    /* ============================================================
       LOW-LEVEL CRUD
       ============================================================ */

    public static function create( $data ) {
        global $wpdb;
        $defaults = array(
            'created_at' => current_time( 'mysql' ),
            'updated_at' => current_time( 'mysql' ),
            'status'     => self::STATUS_DRAFT,
        );
        $data = wp_parse_args( $data, $defaults );

        $result = $wpdb->insert( NMEP_Database::table( 'services' ), $data );
        if ( ! $result ) {
            NMEP_Logger::error( 'Failed to insert service', array( 'error' => $wpdb->last_error ) );
            return false;
        }
        return (int) $wpdb->insert_id;
    }

    public static function update( $id, $data ) {
        global $wpdb;
        return $wpdb->update( NMEP_Database::table( 'services' ), $data, array( 'id' => (int) $id ) );
    }

    /* ============================================================
       SANITIZATION & VALIDATION
       ============================================================ */

    private static function sanitize_service_input( $post, $expert_id ) {
        return array(
            'title'              => sanitize_text_field( $post['title'] ?? '' ),
            'short_description'  => sanitize_text_field( $post['short_description'] ?? '' ),
            'short_pitch'        => sanitize_text_field( $post['short_pitch'] ?? '' ),
            'description'        => wp_kses_post( $post['description'] ?? '' ),
            'category_id'        => (int) ( $post['category_id'] ?? 0 ),
            'cover_image'        => esc_url_raw( $post['cover_image'] ?? '' ),
            'video_url'          => esc_url_raw( $post['video_url'] ?? '' ),

            'basic_title'           => sanitize_text_field( $post['basic_title'] ?? '' ),
            'basic_price'           => self::sanitize_optional_price( $post['basic_price'] ?? '' ),
            'basic_delivery_days'   => max( 1, (int) ( $post['basic_delivery_days'] ?? 3 ) ),
            'basic_revisions'       => max( 0, (int) ( $post['basic_revisions'] ?? 1 ) ),
            'basic_features'        => sanitize_textarea_field( $post['basic_features'] ?? '' ),

            'standard_title'        => sanitize_text_field( $post['standard_title'] ?? '' ),
            'standard_price'        => self::sanitize_optional_price( $post['standard_price'] ?? '' ),
            'standard_delivery_days' => max( 1, (int) ( $post['standard_delivery_days'] ?? 5 ) ),
            'standard_revisions'    => max( 0, (int) ( $post['standard_revisions'] ?? 2 ) ),
            'standard_features'     => sanitize_textarea_field( $post['standard_features'] ?? '' ),

            'premium_title'         => sanitize_text_field( $post['premium_title'] ?? '' ),
            'premium_price'         => self::sanitize_optional_price( $post['premium_price'] ?? '' ),
            'premium_delivery_days' => max( 1, (int) ( $post['premium_delivery_days'] ?? 7 ) ),
            'premium_revisions'     => max( 0, (int) ( $post['premium_revisions'] ?? 3 ) ),
            'premium_features'      => sanitize_textarea_field( $post['premium_features'] ?? '' ),

            'requirements'       => sanitize_textarea_field( $post['requirements'] ?? '' ),
            'tags'               => sanitize_text_field( $post['tags'] ?? '' ),
            'updated_at'         => current_time( 'mysql' ),
        );
    }

    private static function sanitize_price( $value ) {
        $price = (float) preg_replace( '/[^0-9.]/', '', (string) $value );
        if ( $price < 0 ) $price = 0;
        return round( $price, 2 );
    }

    /**
     * v1.5.4: Sanitize an OPTIONAL price (returns NULL if empty)
     */
    private static function sanitize_optional_price( $value ) {
        $value = trim( (string) $value );
        if ( $value === '' ) return null;
        $price = (float) preg_replace( '/[^0-9.]/', '', $value );
        if ( $price <= 0 ) return null;
        return round( $price, 2 );
    }

    /**
     * Validate service input — basic field validation
     * v1.5.4: At least ONE tier price required (not specifically Basic)
     */
    private static function validate( $data, $service_id = 0 ) {
        $errors = array();

        if ( empty( $data['title'] ) || strlen( $data['title'] ) < 10 ) {
            $errors[] = 'Title must be at least 10 characters';
        }
        if ( strlen( $data['title'] ) > 200 ) {
            $errors[] = 'Title must be under 200 characters';
        }
        if ( empty( $data['category_id'] ) ) {
            $errors[] = 'Please select a category';
        }
        if ( empty( $data['short_description'] ) || strlen( $data['short_description'] ) < 30 ) {
            $errors[] = 'Short description must be at least 30 characters';
        }

        $min = (float) NMEP_Settings::get( 'min_order_amount', 199 );
        $max = (float) NMEP_Settings::get( 'max_order_amount', 9999 );

        // v1.5.4: At least ONE tier must have a valid price (not specifically Basic)
        $basic_p    = (float) ( $data['basic_price'] ?? 0 );
        $standard_p = (float) ( $data['standard_price'] ?? 0 );
        $premium_p  = (float) ( $data['premium_price'] ?? 0 );

        $has_any_price = ( $basic_p >= $min ) || ( $standard_p >= $min ) || ( $premium_p >= $min );
        if ( ! $has_any_price ) {
            $errors[] = 'At least one package must have a price of at least ' . nmep_format_inr( $min );
        }

        // Validate each tier IF it has a price (price > 0 means tier is "active")
        if ( $basic_p > 0 && $basic_p < $min ) {
            $errors[] = 'Starter package price must be at least ' . nmep_format_inr( $min );
        }
        if ( $basic_p > $max ) {
            $errors[] = 'Starter package price cannot exceed ' . nmep_format_inr( $max );
        }
        if ( $standard_p > 0 && $standard_p < $min ) {
            $errors[] = 'Standard package price must be at least ' . nmep_format_inr( $min );
        }
        if ( $standard_p > $max ) {
            $errors[] = 'Standard package price cannot exceed ' . nmep_format_inr( $max );
        }
        if ( $premium_p > 0 && $premium_p < $min ) {
            $errors[] = 'Pro package price must be at least ' . nmep_format_inr( $min );
        }
        if ( $premium_p > $max ) {
            $errors[] = 'Pro package price cannot exceed ' . nmep_format_inr( $max );
        }

        // If multiple tiers, enforce ascending order (only when all are set)
        if ( $basic_p > 0 && $standard_p > 0 && $standard_p < $basic_p ) {
            $errors[] = 'Standard package must cost more than Starter';
        }
        if ( $standard_p > 0 && $premium_p > 0 && $premium_p < $standard_p ) {
            $errors[] = 'Pro package must cost more than Standard';
        }
        if ( $basic_p > 0 && $premium_p > 0 && $standard_p == 0 && $premium_p < $basic_p ) {
            $errors[] = 'Pro package must cost more than Starter';
        }

        return $errors;
    }

    /**
     * Validate that a service is COMPLETE enough to submit for review
     * v1.5.4: Cover image NO LONGER REQUIRED (auto-placeholder will be used)
     */
    private static function validate_for_submission( $service ) {
        $errors = array();

        if ( empty( $service->title ) || strlen( $service->title ) < 10 ) $errors[] = 'title is too short';
        if ( empty( $service->short_description ) ) $errors[] = 'short description missing';
        if ( empty( $service->description ) || strlen( $service->description ) < 100 ) $errors[] = 'full description must be at least 100 characters';
        if ( empty( $service->category_id ) ) $errors[] = 'category not set';

        // At least ONE tier must have a price
        $has_price = ( (float) $service->basic_price > 0 ) || ( (float) $service->standard_price > 0 ) || ( (float) $service->premium_price > 0 );
        if ( ! $has_price ) $errors[] = 'no package has a price set';

        // The tier with the lowest filled price should have features listed
        $lowest_filled = null;
        foreach ( array( 'basic', 'standard', 'premium' ) as $tier ) {
            $price = (float) $service->{$tier . '_price'};
            if ( $price > 0 ) {
                if ( empty( $service->{$tier . '_features'} ) ) {
                    $errors[] = ucfirst( $tier === 'premium' ? 'Pro' : $tier ) . ' package needs to list what is included';
                }
                if ( $lowest_filled === null ) $lowest_filled = $tier;
            }
        }

        // Cover image NO LONGER required - auto-placeholder will be used
        return $errors;
    }

    /* ============================================================
       UI HELPERS
       ============================================================ */

    /**
     * v1.5.4: Preserve form data via transient so users don't lose typing on error
     */
    private static function redirect_with_error( $message, $service_id = 0 ) {
        // Save form data to transient (5 min) so we can repopulate the form
        if ( ! empty( $_POST ) ) {
            $user_id = get_current_user_id();
            if ( $user_id ) {
                set_transient( 'nmep_form_data_' . $user_id, $_POST, 5 * MINUTE_IN_SECONDS );
            }
        }

        // Always redirect to the form (not dashboard home) so error stays visible
        $base_url = nmep_get_page_url( 'expert-dashboard', '/expert-dashboard/' );
        $url = add_query_arg( array(
            'nmep_status' => 'error',
            'nmep_msg'    => urlencode( $message ),
        ), $base_url );

        if ( $service_id > 0 ) {
            $url = add_query_arg( 'edit_service', $service_id, $url );
        } else {
            $url = add_query_arg( 'action', 'new', $url );
        }

        wp_safe_redirect( $url );
        exit;
    }

    private static function redirect_with_success( $message, $service_id = 0 ) {
        // Clear any stored form data on success
        $user_id = get_current_user_id();
        if ( $user_id ) {
            delete_transient( 'nmep_form_data_' . $user_id );
        }

        $url = nmep_get_page_url( 'expert-dashboard', '/expert-dashboard/' );
        $url = add_query_arg( array(
            'nmep_status' => 'success',
            'nmep_msg'    => urlencode( $message ),
        ), $url );
        if ( $service_id ) {
            $url = add_query_arg( 'edit_service', $service_id, $url );
        }
        wp_safe_redirect( $url );
        exit;
    }

    /**
     * Get badge HTML for service status
     */
    public static function get_status_badge( $status ) {
        $map = array(
            self::STATUS_DRAFT          => array( 'label' => 'Draft',          'color' => '#6B7280' ),
            self::STATUS_PENDING_REVIEW => array( 'label' => 'Under Review',   'color' => '#F59E0B' ),
            self::STATUS_ACTIVE         => array( 'label' => 'Active',         'color' => '#10B981' ),
            self::STATUS_PAUSED         => array( 'label' => 'Paused',         'color' => '#6366F1' ),
            self::STATUS_REJECTED       => array( 'label' => 'Rejected',       'color' => '#EF4444' ),
            self::STATUS_ARCHIVED       => array( 'label' => 'Archived',       'color' => '#9CA3AF' ),
        );
        $b = isset( $map[ $status ] ) ? $map[ $status ] : $map[ self::STATUS_DRAFT ];
        return sprintf(
            '<span style="display:inline-block;padding:4px 10px;border-radius:50px;font-size:0.7rem;font-weight:700;background:%s;color:#fff;text-transform:uppercase;letter-spacing:0.05em;">%s</span>',
            esc_attr( $b['color'] ), esc_html( $b['label'] )
        );
    }

    public static function increment_view_count( $service_id ) {
        global $wpdb;
        $wpdb->query( $wpdb->prepare(
            "UPDATE " . NMEP_Database::table( 'services' ) . " SET views = views + 1 WHERE id = %d",
            (int) $service_id
        ) );
    }

    public static function get_service_url( $service ) {
        if ( ! $service ) return home_url();
        return home_url( '/service/' . $service->slug . '/' );
    }
}
