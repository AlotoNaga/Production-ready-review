<?php
/**
 * NMEP_Orders
 * Core order management — creation, lifecycle, queries.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class NMEP_Orders {

    // Status constants for order lifecycle
    const STATUS_INITIATED   = 'initiated';     // Order created, payment pending
    const STATUS_PAID        = 'paid';          // Payment captured, escrow holding
    const STATUS_IN_PROGRESS = 'in_progress';   // Expert working
    const STATUS_DELIVERED   = 'delivered';     // Expert delivered work
    const STATUS_REVISION    = 'revision';      // Buyer requested revision
    const STATUS_COMPLETED   = 'completed';     // Buyer approved + funds released
    const STATUS_AUTO_RELEASED = 'auto_released'; // Funds released automatically
    const STATUS_CANCELLED   = 'cancelled';
    const STATUS_REFUNDED    = 'refunded';
    const STATUS_DISPUTED    = 'disputed';

    // Payment status
    const PAYMENT_PENDING    = 'pending';
    const PAYMENT_CAPTURED   = 'captured';
    const PAYMENT_FAILED     = 'failed';
    const PAYMENT_REFUNDED   = 'refunded';

    // Escrow status
    const ESCROW_PENDING     = 'pending';
    const ESCROW_HOLDING     = 'holding';
    const ESCROW_RELEASED    = 'released';
    const ESCROW_REVERSED    = 'reversed';

    public static function init() {
        // Hooks for Batch C
    }

    /**
     * Create a new order (called from checkout)
     */
    public static function create( $data ) {
        global $wpdb;

        $defaults = array(
            'order_number'     => NMEP_Database::generate_order_number(),
            'view_token'       => NMEP_Database::generate_view_token(),
            'mode'             => NMEP_Settings::get_mode(),
            'status'           => self::STATUS_INITIATED,
            'payment_status'   => self::PAYMENT_PENDING,
            'escrow_status'    => self::ESCROW_PENDING,
            'delivery_status'  => 'pending',
            'currency'         => 'INR',
            'commission_rate'  => NMEP_Settings::get( 'default_commission_rate', 15 ),
        );

        $data = wp_parse_args( $data, $defaults );

        $result = $wpdb->insert( NMEP_Database::table( 'orders' ), $data );
        if ( ! $result ) {
            NMEP_Logger::error( 'Failed to insert order', array( 'error' => $wpdb->last_error ) );
            return false;
        }

        $order_id = (int) $wpdb->insert_id;

        NMEP_Logger::info( 'Order created', array(
            'order_id'     => $order_id,
            'order_number' => $data['order_number'],
            'gross_amount' => $data['gross_amount'] ?? 0,
        ) );

        // Emit canonical lifecycle event. Subscribers: badges, analytics, CRM, SMS…
        if ( class_exists( 'NMEP_Events' ) ) {
            NMEP_Events::emit( NMEP_Events::ORDER_CREATED, $order_id, self::get( $order_id ) );
        }

        return $order_id;
    }

    /**
     * Cancel an order. Emits ORDER_CANCELLED. Used by admin, cron (stale unpaid),
     * and dispute-resolution flows.
     *
     * @param int    $order_id
     * @param string $reason
     * @param int    $actor_user_id  0 = system
     * @return bool
     */
    public static function cancel( $order_id, $reason = '', $actor_user_id = 0 ) {
        $order = self::get( $order_id );
        if ( ! $order ) return false;

        if ( in_array( $order->status, array( self::STATUS_COMPLETED, self::STATUS_AUTO_RELEASED, self::STATUS_REFUNDED, self::STATUS_CANCELLED ), true ) ) {
            return false;
        }

        self::update( $order_id, array(
            'status'       => self::STATUS_CANCELLED,
            'cancelled_at' => current_time( 'mysql' ),
        ) );

        if ( class_exists( 'NMEP_Compat' ) ) {
            NMEP_Compat::audit_log( 'order_cancelled', 'order', $order_id, array(
                'reason'          => $reason,
                'cancelled_by'    => (int) $actor_user_id,
            ) );
        }

        if ( class_exists( 'NMEP_Events' ) ) {
            NMEP_Events::emit( NMEP_Events::ORDER_CANCELLED, $order_id, $reason, (int) $actor_user_id );
        }

        return true;
    }

    /**
     * Get order by ID
     */
    public static function get( $id ) {
        global $wpdb;
        return $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM " . NMEP_Database::table( 'orders' ) . " WHERE id = %d",
            (int) $id
        ) );
    }

    /**
     * Get order by order number
     */
    public static function get_by_number( $order_number ) {
        global $wpdb;
        return $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM " . NMEP_Database::table( 'orders' ) . " WHERE order_number = %s",
            sanitize_text_field( $order_number )
        ) );
    }

    /**
     * Get order by Razorpay order ID
     */
    public static function get_by_razorpay_order_id( $razorpay_order_id ) {
        global $wpdb;
        return $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM " . NMEP_Database::table( 'orders' ) . " WHERE razorpay_order_id = %s",
            sanitize_text_field( $razorpay_order_id )
        ) );
    }

    /**
     * Update order
     */
    public static function update( $id, $data ) {
        global $wpdb;
        $result = $wpdb->update( NMEP_Database::table( 'orders' ), $data, array( 'id' => (int) $id ) );

        if ( false === $result ) {
            NMEP_Logger::error( 'Failed to update order', array(
                'order_id' => $id,
                'error'    => $wpdb->last_error,
            ) );
        }

        return $result;
    }

    /**
     * Calculate commission split
     */
    public static function calculate_split( $gross_amount, $commission_rate ) {
        $commission_amount = round( ( (float) $gross_amount ) * ( (float) $commission_rate / 100 ), 2 );
        $expert_amount = round( (float) $gross_amount - $commission_amount, 2 );

        return array(
            'gross'      => (float) $gross_amount,
            'commission' => $commission_amount,
            'expert'     => $expert_amount,
        );
    }

    /**
     * Get orders for a buyer
     */
    public static function get_for_buyer( $email_or_user_id, $limit = 50 ) {
        global $wpdb;

        if ( is_numeric( $email_or_user_id ) ) {
            return $wpdb->get_results( $wpdb->prepare(
                "SELECT * FROM " . NMEP_Database::table( 'orders' ) . "
                 WHERE buyer_user_id = %d ORDER BY created_at DESC LIMIT %d",
                (int) $email_or_user_id, $limit
            ) );
        }

        return $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM " . NMEP_Database::table( 'orders' ) . "
             WHERE buyer_email = %s ORDER BY created_at DESC LIMIT %d",
            sanitize_email( $email_or_user_id ), $limit
        ) );
    }

    /**
     * Get orders for an expert
     */
    public static function get_for_expert( $expert_id, $limit = 50 ) {
        global $wpdb;
        return $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM " . NMEP_Database::table( 'orders' ) . "
             WHERE expert_id = %d ORDER BY created_at DESC LIMIT %d",
            (int) $expert_id, $limit
        ) );
    }

    /**
     * Get orders that should auto-release (for cron)
     */
    public static function get_pending_auto_release() {
        global $wpdb;
        return $wpdb->get_results(
            "SELECT * FROM " . NMEP_Database::table( 'orders' ) . "
             WHERE status = 'delivered'
               AND escrow_status = 'holding'
               AND auto_release_at IS NOT NULL
               AND auto_release_at <= UTC_TIMESTAMP()
             LIMIT 50"
        );
    }
}
