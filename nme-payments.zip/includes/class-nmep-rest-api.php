<?php
/**
 * NMEP_REST_API
 *
 * REST API v1 for the React Native / Expo mobile app.
 *
 * Namespace: nmep/v1
 *
 * Authentication:
 *   App clients exchange WP username + password for a long-lived
 *   bearer token at POST /nmep/v1/auth/login. The token hash is stored
 *   in option `nmep_api_tokens_v1` (associative array: token_hash =>
 *   { user_id, created_at, last_used_at }). On subsequent requests the
 *   token is sent as `Authorization: Bearer <token>`.
 *
 * Endpoints (all JSON):
 *   POST /auth/login
 *   POST /auth/logout                (auth required)
 *   GET  /me                         (auth required)
 *   GET  /services                   (paginated, filters: category, subcategory, q, tier)
 *   GET  /services/{id}
 *   GET  /experts/{id}               (public expert profile)
 *   GET  /orders                     (auth required — buyer OR expert)
 *   GET  /orders/{id}                (auth required)
 *   GET  /orders/{id}/messages       (auth required)
 *   POST /orders/{id}/messages       (auth required)
 *   POST /reviews                    (auth required — buyer after completion)
 *
 * All writes enforce nonce-like verification by virtue of the bearer
 * token (client proves session ownership per request); rate-limited via
 * NMEP_Guard when available.
 *
 * @package NagalandMeExpertsPayments
 * @since   2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class NMEP_REST_API {

    const NAMESPACE_V1       = 'nmep/v1';
    const TOKEN_OPTION       = 'nmep_api_tokens_v1';
    const TOKEN_TTL_SECONDS  = 60 * DAY_IN_SECONDS;

    public static function init() {
        add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
    }

    public static function register_routes() {
        // AUTH
        register_rest_route( self::NAMESPACE_V1, '/auth/login', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'route_login' ),
            'permission_callback' => '__return_true',
            'args'                => array(
                'username' => array( 'required' => true, 'type' => 'string' ),
                'password' => array( 'required' => true, 'type' => 'string' ),
            ),
        ) );
        register_rest_route( self::NAMESPACE_V1, '/auth/logout', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'route_logout' ),
            'permission_callback' => array( __CLASS__, 'require_auth' ),
        ) );

        // SESSION
        register_rest_route( self::NAMESPACE_V1, '/me', array(
            'methods'             => 'GET',
            'callback'            => array( __CLASS__, 'route_me' ),
            'permission_callback' => array( __CLASS__, 'require_auth' ),
        ) );

        // SERVICES
        register_rest_route( self::NAMESPACE_V1, '/services', array(
            'methods'             => 'GET',
            'callback'            => array( __CLASS__, 'route_services_list' ),
            'permission_callback' => '__return_true',
        ) );
        register_rest_route( self::NAMESPACE_V1, '/services/(?P<id>\d+)', array(
            'methods'             => 'GET',
            'callback'            => array( __CLASS__, 'route_service_show' ),
            'permission_callback' => '__return_true',
        ) );

        // EXPERTS (public profile)
        register_rest_route( self::NAMESPACE_V1, '/experts/(?P<id>\d+)', array(
            'methods'             => 'GET',
            'callback'            => array( __CLASS__, 'route_expert_show' ),
            'permission_callback' => '__return_true',
        ) );

        // ORDERS
        register_rest_route( self::NAMESPACE_V1, '/orders', array(
            'methods'             => 'GET',
            'callback'            => array( __CLASS__, 'route_orders_list' ),
            'permission_callback' => array( __CLASS__, 'require_auth' ),
        ) );
        register_rest_route( self::NAMESPACE_V1, '/orders/(?P<id>\d+)', array(
            'methods'             => 'GET',
            'callback'            => array( __CLASS__, 'route_order_show' ),
            'permission_callback' => array( __CLASS__, 'require_auth' ),
        ) );

        // MESSAGES
        register_rest_route( self::NAMESPACE_V1, '/orders/(?P<id>\d+)/messages', array(
            array(
                'methods'             => 'GET',
                'callback'            => array( __CLASS__, 'route_messages_list' ),
                'permission_callback' => array( __CLASS__, 'require_auth' ),
            ),
            array(
                'methods'             => 'POST',
                'callback'            => array( __CLASS__, 'route_message_create' ),
                'permission_callback' => array( __CLASS__, 'require_auth' ),
                'args'                => array(
                    'message' => array( 'required' => true, 'type' => 'string' ),
                ),
            ),
        ) );

        // REVIEWS
        register_rest_route( self::NAMESPACE_V1, '/reviews', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'route_review_create' ),
            'permission_callback' => array( __CLASS__, 'require_auth' ),
            'args'                => array(
                'order_id' => array( 'required' => true, 'type' => 'integer' ),
                'rating'   => array( 'required' => true, 'type' => 'integer' ),
                'comment'  => array( 'required' => true, 'type' => 'string' ),
            ),
        ) );
    }

    /* ============================================================
       AUTH: TOKEN STORE
       ============================================================ */

    private static function all_tokens() {
        $raw = get_option( self::TOKEN_OPTION, array() );
        return is_array( $raw ) ? $raw : array();
    }

    private static function save_tokens( $tokens ) {
        update_option( self::TOKEN_OPTION, $tokens, false );
    }

    private static function issue_token( $user_id ) {
        $plain = wp_generate_password( 48, false, false );
        $hash  = hash( 'sha256', $plain );
        $tokens = self::all_tokens();
        $tokens[ $hash ] = array(
            'user_id'      => (int) $user_id,
            'created_at'   => time(),
            'last_used_at' => time(),
        );
        self::prune_expired( $tokens );
        self::save_tokens( $tokens );
        return $plain;
    }

    private static function lookup_token( $plain ) {
        if ( empty( $plain ) || ! is_string( $plain ) ) return null;
        $hash = hash( 'sha256', $plain );
        $tokens = self::all_tokens();
        if ( empty( $tokens[ $hash ] ) ) return null;

        $entry = $tokens[ $hash ];
        if ( time() - (int) $entry['created_at'] > self::TOKEN_TTL_SECONDS ) {
            unset( $tokens[ $hash ] );
            self::save_tokens( $tokens );
            return null;
        }

        $tokens[ $hash ]['last_used_at'] = time();
        self::save_tokens( $tokens );
        return (int) $entry['user_id'];
    }

    private static function revoke_token( $plain ) {
        if ( empty( $plain ) ) return;
        $hash = hash( 'sha256', $plain );
        $tokens = self::all_tokens();
        if ( isset( $tokens[ $hash ] ) ) {
            unset( $tokens[ $hash ] );
            self::save_tokens( $tokens );
        }
    }

    private static function prune_expired( &$tokens ) {
        $cutoff = time() - self::TOKEN_TTL_SECONDS;
        foreach ( $tokens as $hash => $entry ) {
            if ( (int) $entry['created_at'] < $cutoff ) {
                unset( $tokens[ $hash ] );
            }
        }
    }

    /* ============================================================
       AUTH: PERMISSION CHECK
       ============================================================ */

    public static function require_auth( WP_REST_Request $request ) {
        $token = self::extract_bearer_token( $request );
        $user_id = self::lookup_token( $token );
        if ( ! $user_id ) {
            return new WP_Error( 'nmep_unauthorized', 'Invalid or expired token.', array( 'status' => 401 ) );
        }
        // Set current user for downstream checks
        wp_set_current_user( $user_id );
        return true;
    }

    private static function extract_bearer_token( WP_REST_Request $request ) {
        $header = $request->get_header( 'authorization' );
        if ( ! $header ) return '';
        if ( stripos( $header, 'Bearer ' ) === 0 ) {
            return trim( substr( $header, 7 ) );
        }
        return '';
    }

    /* ============================================================
       ROUTE: AUTH
       ============================================================ */

    public static function route_login( WP_REST_Request $request ) {
        $username = trim( (string) $request->get_param( 'username' ) );
        $password = (string) $request->get_param( 'password' );

        if ( class_exists( 'NMEP_Guard' ) ) {
            if ( ! NMEP_Guard::rate_check( 'api_login', 10, 60, 'ip' ) ) {
                return self::err( 'rate_limited', 'Too many login attempts. Try again shortly.', 429 );
            }
        }

        $user = wp_authenticate( $username, $password );
        if ( is_wp_error( $user ) ) {
            return self::err( 'invalid_credentials', 'Invalid username or password.', 401 );
        }

        $token = self::issue_token( $user->ID );
        return self::ok( array(
            'token'      => $token,
            'expires_in' => self::TOKEN_TTL_SECONDS,
            'user'       => self::serialize_user( $user ),
        ) );
    }

    public static function route_logout( WP_REST_Request $request ) {
        $token = self::extract_bearer_token( $request );
        self::revoke_token( $token );
        return self::ok( array( 'message' => 'Logged out.' ) );
    }

    public static function route_me( WP_REST_Request $request ) {
        $user = wp_get_current_user();
        if ( ! $user || ! $user->ID ) {
            return self::err( 'no_session', 'No user in session.', 401 );
        }
        return self::ok( self::serialize_user( $user ) );
    }

    private static function serialize_user( $user ) {
        $out = array(
            'id'           => (int) $user->ID,
            'username'     => $user->user_login,
            'display_name' => $user->display_name,
            'email'        => $user->user_email,
            'roles'        => (array) $user->roles,
            'is_expert'    => false,
            'expert'       => null,
        );
        if ( class_exists( 'NMEP_Compat' ) ) {
            $expert = NMEP_Compat::get_expert_by_user( (int) $user->ID );
            if ( $expert ) {
                $out['is_expert'] = true;
                $out['expert'] = array(
                    'id'        => (int) $expert->id,
                    'full_name' => $expert->full_name,
                    'status'    => $expert->status,
                );
            }
        }
        return $out;
    }

    /* ============================================================
       ROUTE: SERVICES
       ============================================================ */

    public static function route_services_list( WP_REST_Request $request ) {
        $args = array(
            'per_page'       => min( 50, max( 1, (int) $request->get_param( 'per_page' ) ?: 20 ) ),
            'page'           => max( 1, (int) $request->get_param( 'page' ) ?: 1 ),
            'category_id'    => (int) $request->get_param( 'category' ),
            'subcategory_id' => (int) $request->get_param( 'subcategory' ),
            'q'              => sanitize_text_field( (string) $request->get_param( 'q' ) ),
            'status'         => 'active',
        );

        global $wpdb;
        $table   = NMEP_Database::table( 'services' );
        $where   = array( "s.status = 'active'" );
        $params  = array();

        if ( $args['category_id'] ) {
            $where[] = "s.category_id = %d"; $params[] = $args['category_id'];
        }
        if ( $args['subcategory_id'] ) {
            $where[] = "s.subcategory_id = %d"; $params[] = $args['subcategory_id'];
        }
        if ( $args['q'] !== '' ) {
            $like = '%' . $wpdb->esc_like( $args['q'] ) . '%';
            $where[] = "(s.title LIKE %s OR s.short_description LIKE %s)";
            $params[] = $like; $params[] = $like;
        }

        $where_sql = implode( ' AND ', $where );
        $offset    = ( $args['page'] - 1 ) * $args['per_page'];

        $count_sql = "SELECT COUNT(*) FROM $table s WHERE $where_sql";
        $total     = (int) $wpdb->get_var( $params ? $wpdb->prepare( $count_sql, $params ) : $count_sql );

        $list_sql = "SELECT s.* FROM $table s WHERE $where_sql ORDER BY s.id DESC LIMIT %d OFFSET %d";
        $list_params = array_merge( $params, array( $args['per_page'], $offset ) );
        $rows = $wpdb->get_results( $wpdb->prepare( $list_sql, $list_params ) );

        return self::ok( array(
            'total'    => $total,
            'page'     => $args['page'],
            'per_page' => $args['per_page'],
            'items'    => array_map( array( __CLASS__, 'serialize_service_summary' ), $rows ),
        ) );
    }

    public static function route_service_show( WP_REST_Request $request ) {
        $id = (int) $request['id'];
        $service = NMEP_Services::get( $id );
        if ( ! $service ) return self::err( 'not_found', 'Service not found.', 404 );

        $expert = NMEP_Compat::get_expert( (int) $service->expert_id );

        $extras = array();
        if ( class_exists( 'NMEP_Service_Extras' ) ) {
            $extras = NMEP_Service_Extras::list_for_service( $id, true );
        }

        return self::ok( array(
            'service' => self::serialize_service_full( $service ),
            'expert'  => $expert ? self::serialize_expert_summary( $expert ) : null,
            'extras'  => $extras,
        ) );
    }

    private static function serialize_service_summary( $s ) {
        return array(
            'id'                => (int) $s->id,
            'title'             => $s->title,
            'short_description' => $s->short_description ?? '',
            'category_id'       => (int) ( $s->category_id ?? 0 ),
            'subcategory_id'    => (int) ( $s->subcategory_id ?? 0 ),
            'basic_price'       => isset( $s->basic_price ) ? (float) $s->basic_price : null,
            'expert_id'         => (int) $s->expert_id,
            'cover_url'         => $s->cover_url ?? null,
        );
    }

    private static function serialize_service_full( $s ) {
        $base = self::serialize_service_summary( $s );
        $base['description']    = $s->description ?? '';
        $base['tags']           = $s->tags ?? '';
        $base['basic_package']  = array(
            'price'         => isset( $s->basic_price )    ? (float) $s->basic_price    : null,
            'delivery_days' => isset( $s->basic_delivery ) ? (int) $s->basic_delivery   : null,
            'revisions'     => isset( $s->basic_revisions ) ? (int) $s->basic_revisions : null,
        );
        return $base;
    }

    /* ============================================================
       ROUTE: EXPERTS
       ============================================================ */

    public static function route_expert_show( WP_REST_Request $request ) {
        $id     = (int) $request['id'];
        $expert = NMEP_Compat::get_expert( $id );
        if ( ! $expert ) return self::err( 'not_found', 'Expert not found.', 404 );

        $profile = self::serialize_expert_summary( $expert );

        // Let Phase 3G attach portfolio / languages / certs / availability
        $profile = apply_filters( 'nmep_public_expert_profile', $profile, $expert );

        // Tier + metrics
        if ( class_exists( 'NMEP_Metrics' ) ) {
            $m = NMEP_Metrics::get( $id );
            $profile['metrics'] = array(
                'orders_completed'      => (int) $m->orders_completed,
                'response_rate_percent' => (float) $m->response_rate_percent,
                'avg_response_seconds'  => (int) $m->avg_response_seconds,
                'current_tier'          => $m->current_tier,
            );
        }

        return self::ok( $profile );
    }

    private static function serialize_expert_summary( $e ) {
        return array(
            'id'        => (int) $e->id,
            'full_name' => $e->full_name,
            'avatar'    => $e->avatar_url ?? null,
            'bio'       => $e->bio ?? '',
            'status'    => $e->status ?? 'approved',
        );
    }

    /* ============================================================
       ROUTE: ORDERS
       ============================================================ */

    public static function route_orders_list( WP_REST_Request $request ) {
        $user_id = get_current_user_id();
        $role    = sanitize_key( (string) $request->get_param( 'role' ) ); // 'buyer' | 'expert'
        $page    = max( 1, (int) $request->get_param( 'page' ) ?: 1 );
        $per     = min( 50, max( 1, (int) $request->get_param( 'per_page' ) ?: 20 ) );

        global $wpdb;
        $table = NMEP_Database::table( 'orders' );
        $where = array();
        $params = array();

        if ( $role === 'expert' ) {
            $expert = NMEP_Compat::get_expert_by_user( $user_id );
            if ( ! $expert ) return self::err( 'not_expert', 'Not an expert account.', 403 );
            $where[] = "expert_id = %d"; $params[] = (int) $expert->id;
        } else {
            $where[] = "buyer_user_id = %d"; $params[] = $user_id;
        }

        $where_sql = implode( ' AND ', $where );
        $total = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM $table WHERE $where_sql", $params
        ) );

        $offset = ( $page - 1 ) * $per;
        $list_params = array_merge( $params, array( $per, $offset ) );
        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM $table WHERE $where_sql ORDER BY id DESC LIMIT %d OFFSET %d",
            $list_params
        ) );

        return self::ok( array(
            'total'    => $total,
            'page'     => $page,
            'per_page' => $per,
            'items'    => array_map( array( __CLASS__, 'serialize_order_summary' ), $rows ),
        ) );
    }

    public static function route_order_show( WP_REST_Request $request ) {
        $id = (int) $request['id'];
        $order = NMEP_Orders::get( $id );
        if ( ! $order ) return self::err( 'not_found', 'Order not found.', 404 );

        $role = self::check_order_access( $order );
        if ( is_wp_error( $role ) ) return $role;

        return self::ok( array(
            'order' => self::serialize_order_full( $order ),
            'role'  => $role,
        ) );
    }

    private static function check_order_access( $order ) {
        $user_id = get_current_user_id();
        if ( (int) $order->buyer_user_id === $user_id ) return 'buyer';

        $expert = NMEP_Compat::get_expert_by_user( $user_id );
        if ( $expert && (int) $expert->id === (int) $order->expert_id ) return 'expert';

        return self::err( 'forbidden', 'Not your order.', 403 );
    }

    private static function serialize_order_summary( $o ) {
        return array(
            'id'             => (int) $o->id,
            'order_number'   => $o->order_number,
            'service_title'  => $o->service_title,
            'status'         => $o->status,
            'payment_status' => $o->payment_status,
            'gross_amount'   => (float) $o->gross_amount,
            'delivery_due_at' => $o->delivery_due_at ?? null,
            'created_at'     => $o->created_at,
        );
    }

    private static function serialize_order_full( $o ) {
        $base = self::serialize_order_summary( $o );
        $base['buyer_name']        = $o->buyer_name;
        $base['expert_id']         = (int) $o->expert_id;
        $base['service_id']        = (int) $o->service_id;
        $base['buyer_requirements'] = $o->buyer_requirements ?? '';
        $base['delivery_days']     = (int) ( $o->delivery_days ?? 0 );
        $base['revisions_allowed'] = (int) ( $o->revisions_allowed ?? 0 );
        return $base;
    }

    /* ============================================================
       ROUTE: MESSAGES
       ============================================================ */

    public static function route_messages_list( WP_REST_Request $request ) {
        $id = (int) $request['id'];
        $order = NMEP_Orders::get( $id );
        if ( ! $order ) return self::err( 'not_found', 'Order not found.', 404 );

        $role = self::check_order_access( $order );
        if ( is_wp_error( $role ) ) return $role;

        $messages = NMEP_Messages::get_for_order( $id );
        NMEP_Messages::mark_read_for_order( $id, $role );

        $out = array_map( function ( $m ) {
            return array(
                'id'          => (int) $m->id,
                'sender_role' => $m->sender_role,
                'sender_name' => $m->sender_name,
                'message'     => $m->message,
                'attachments' => ! empty( $m->attachment_urls ) ? (array) json_decode( $m->attachment_urls, true ) : array(),
                'created_at'  => $m->created_at,
            );
        }, $messages );

        return self::ok( array( 'items' => $out ) );
    }

    public static function route_message_create( WP_REST_Request $request ) {
        $id = (int) $request['id'];
        $order = NMEP_Orders::get( $id );
        if ( ! $order ) return self::err( 'not_found', 'Order not found.', 404 );

        $role = self::check_order_access( $order );
        if ( is_wp_error( $role ) ) return $role;

        $message = sanitize_textarea_field( (string) $request->get_param( 'message' ) );
        if ( strlen( $message ) < 1 ) return self::err( 'empty', 'Message cannot be empty.', 400 );
        if ( strlen( $message ) > 5000 ) return self::err( 'too_long', 'Message too long.', 400 );

        $user_id = get_current_user_id();
        $sender_name = ( $role === 'expert' )
            ? ( NMEP_Compat::get_expert_by_user( $user_id )->full_name ?? 'Expert' )
            : ( $order->buyer_name ?: 'Buyer' );

        global $wpdb;
        $wpdb->insert( NMEP_Database::table( 'order_messages' ), array(
            'order_id'       => $id,
            'sender_user_id' => $user_id,
            'sender_role'    => $role,
            'sender_name'    => $sender_name,
            'message'        => $message,
            'is_read'        => 0,
        ) );
        $message_id = (int) $wpdb->insert_id;

        if ( class_exists( 'NMEP_Events' ) ) {
            NMEP_Events::emit( NMEP_Events::MESSAGE_SENT, $id, $role, $message_id, $order );
        }

        return self::ok( array(
            'id'         => $message_id,
            'created_at' => current_time( 'mysql' ),
        ), 201 );
    }

    /* ============================================================
       ROUTE: REVIEWS
       ============================================================ */

    public static function route_review_create( WP_REST_Request $request ) {
        $order_id = (int) $request->get_param( 'order_id' );
        $rating   = max( 1, min( 5, (int) $request->get_param( 'rating' ) ) );
        $comment  = sanitize_textarea_field( (string) $request->get_param( 'comment' ) );

        if ( strlen( $comment ) < 10 ) {
            return self::err( 'too_short', 'Comment must be at least 10 characters.', 400 );
        }

        $order = NMEP_Orders::get( $order_id );
        if ( ! $order ) return self::err( 'not_found', 'Order not found.', 404 );

        if ( (int) $order->buyer_user_id !== get_current_user_id() ) {
            return self::err( 'forbidden', 'Only the buyer can review.', 403 );
        }
        if ( ! in_array( $order->status, array( 'completed', 'auto_released' ), true ) ) {
            return self::err( 'not_completed', 'You can only review after the order is completed.', 400 );
        }

        global $wpdb;
        $existing = $wpdb->get_var( $wpdb->prepare(
            "SELECT id FROM " . NMEP_Database::table( 'reviews' ) . " WHERE order_id = %d", $order_id
        ) );
        if ( $existing ) {
            return self::err( 'already_reviewed', 'You have already reviewed this order.', 409 );
        }

        $wpdb->insert( NMEP_Database::table( 'reviews' ), array(
            'order_id'      => $order_id,
            'service_id'    => (int) $order->service_id,
            'expert_id'     => (int) $order->expert_id,
            'buyer_user_id' => (int) $order->buyer_user_id,
            'buyer_name'    => $order->buyer_name,
            'buyer_email'   => $order->buyer_email,
            'rating'        => $rating,
            'comment'       => $comment,
            'status'        => 'published',
        ) );
        $review_id = (int) $wpdb->insert_id;

        if ( class_exists( 'NMEP_Events' ) ) {
            NMEP_Events::emit( NMEP_Events::REVIEW_SUBMITTED, $order_id, $review_id, $rating );
        }

        return self::ok( array( 'id' => $review_id ), 201 );
    }

    /* ============================================================
       RESPONSE HELPERS
       ============================================================ */

    private static function ok( $payload, $status = 200 ) {
        return new WP_REST_Response( $payload, $status );
    }

    private static function err( $code, $message, $status = 400 ) {
        return new WP_Error( 'nmep_' . $code, $message, array( 'status' => $status ) );
    }
}
