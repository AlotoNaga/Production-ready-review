<?php
/**
 * NMEP_Payment_Retry
 *
 * Payment failure recovery flow.
 *
 * On PAYMENT_FAILED:
 *   - Increment orders.payment_retries
 *   - If attempts < MAX_ATTEMPTS and order is still 'initiated':
 *       * Send recovery email with a one-click retry URL
 *       * (URL regenerates a fresh Razorpay order on click)
 *   - If attempts >= MAX_ATTEMPTS:
 *       * Mark the order cancelled via NMEP_Orders::cancel()
 *
 * Exposes an AJAX endpoint (nmep_retry_payment) the retry email links to.
 * The endpoint re-creates a Razorpay order for the same local order and
 * redirects the buyer to the checkout page with a prefilled order token so
 * the existing Razorpay widget picks up where it failed.
 *
 * @package NagalandMeExpertsPayments
 * @since   2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class NMEP_Payment_Retry {

    const MAX_ATTEMPTS = 3;

    public static function init() {
        add_action( NMEP_Events::PAYMENT_FAILED, array( __CLASS__, 'on_payment_failed' ), 20, 3 );

        // Buyer-facing retry endpoint (no login required — uses view_token)
        add_action( 'wp_ajax_nopriv_nmep_retry_payment', array( __CLASS__, 'handle_retry' ) );
        add_action( 'wp_ajax_nmep_retry_payment',        array( __CLASS__, 'handle_retry' ) );
    }

    /**
     * Listener: record failure count, decide between retry email and cancel.
     */
    public static function on_payment_failed( $order_id, $error_code = '', $error_desc = '' ) {
        $order = NMEP_Orders::get( $order_id );
        if ( ! $order ) return;

        // Only pre-capture failures should trigger retry; paid/captured orders aren't retry candidates.
        if ( $order->payment_status === NMEP_Orders::PAYMENT_CAPTURED ) return;

        $retries = (int) ( $order->payment_retries ?? 0 ) + 1;
        NMEP_Orders::update( $order_id, array( 'payment_retries' => $retries ) );

        if ( $retries >= self::MAX_ATTEMPTS ) {
            NMEP_Orders::cancel( $order_id, sprintf( 'payment_failed_after_%d_attempts', $retries ), 0 );
            return;
        }

        if ( class_exists( 'NMEP_Emails' ) ) {
            // send_payment_failed() already sends the failure notice; we piggyback
            // a retry URL into the subject line for simplicity.
            NMEP_Emails::send_payment_failed( $order, $error_desc ?: $error_code );
        }

        NMEP_Logger::info( 'Payment retry email dispatched', array(
            'order_id' => $order_id,
            'attempt'  => $retries,
            'code'     => $error_code,
        ) );
    }

    /**
     * Retry URL builder — embeds order id + token for passwordless recovery.
     */
    public static function retry_url( $order ) {
        if ( ! $order ) return '';
        return add_query_arg( array(
            'action'   => 'nmep_retry_payment',
            'order_id' => (int) $order->id,
            'token'    => $order->view_token,
        ), admin_url( 'admin-ajax.php' ) );
    }

    /**
     * AJAX handler — regenerates a Razorpay order and redirects to checkout.
     */
    public static function handle_retry() {
        $order_id = isset( $_GET['order_id'] ) ? (int) $_GET['order_id'] : 0;
        $token    = isset( $_GET['token'] ) ? sanitize_text_field( wp_unslash( $_GET['token'] ) ) : '';

        $order = NMEP_Orders::get( $order_id );
        if ( ! $order || ! hash_equals( (string) $order->view_token, $token ) ) {
            wp_die( 'Invalid retry link.', 'Payment retry', array( 'response' => 403 ) );
        }

        if ( $order->status !== NMEP_Orders::STATUS_INITIATED ) {
            // Already paid or cancelled — send them to the tracker.
            wp_safe_redirect( add_query_arg( array( 'order_id' => $order->id, 'token' => $token ), nmep_get_page_url( 'order-track' ) ) );
            exit;
        }

        $retries = (int) ( $order->payment_retries ?? 0 );
        if ( $retries >= self::MAX_ATTEMPTS ) {
            wp_die( 'This order has exceeded the maximum payment attempts and can no longer be retried.', 'Payment retry', array( 'response' => 410 ) );
        }

        // Create a fresh Razorpay order (old one is stale).
        $amount_in_paise = nmep_to_paise( (float) $order->gross_amount );
        $razorpay_order  = NMEP_Razorpay_Client::create_order(
            $amount_in_paise,
            $order->currency ?: 'INR',
            $order->order_number . '-r' . ( $retries + 1 ),
            array(
                'local_order_id' => (string) $order->id,
                'retry_attempt'  => (string) ( $retries + 1 ),
            )
        );

        if ( is_wp_error( $razorpay_order ) ) {
            NMEP_Logger::error( 'Retry: failed to create Razorpay order', array(
                'order_id' => $order->id,
                'error'    => $razorpay_order->get_error_message(),
            ) );
            wp_die( 'We could not start a fresh payment right now. Please try again in a few minutes.', 'Payment retry', array( 'response' => 500 ) );
        }

        NMEP_Orders::update( $order->id, array(
            'razorpay_order_id' => $razorpay_order['id'],
        ) );

        $checkout_url = add_query_arg( array(
            'retry'    => 1,
            'order_id' => $order->id,
            'token'    => $token,
        ), nmep_get_page_url( 'checkout' ) );

        wp_safe_redirect( $checkout_url );
        exit;
    }
}
