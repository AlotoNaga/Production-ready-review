<?php
/**
 * NMEP_Linked_Accounts
 * Manages Razorpay Route Linked Accounts for experts.
 * Each expert gets a Linked Account so we can split payments to them.
 *
 * @version 0.3.0  2026-04
 *   - Drop legal_info.pan from individual payload (Razorpay v2 API breaking change)
 *   - Stakeholder phone.primary must be 8–11 digits (no country code) — was sending +91XXXXXXXXXX (12)
 *   - Route product: POST /products with only {product_name,tnc_accepted}, then PATCH /products/{id}
 *     with settlements; v2 now rejects settlements in the initial POST
 *   - Auto-sync bank details to Razorpay when the base plugin fires
 *     nme_after_bank_change_approved. Admin-post fallback
 *     (nmep_sync_bank_to_razorpay) provided for manual retry.
 *   - One-shot wp-cron heal for stranded accounts (razorpay_account_id set,
 *     product_config_id empty) — auto-provisions their Route product via
 *     sync_bank_to_razorpay on the next page load after deploy.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class NMEP_Linked_Accounts {

    public static function init() {
        // Hook: when an expert is approved by admin, create their Linked Account
        add_action( 'nmep_after_expert_approved', array( __CLASS__, 'create_for_expert' ), 10, 1 );

        // Hook: when the base plugin approves a bank-change request, push the
        // new bank details to Razorpay so settlements route to the new account.
        add_action( 'nme_after_bank_change_approved', array( __CLASS__, 'handle_bank_change_approved' ), 10, 2 );

        // AJAX: admin manually retry creating a linked account
        add_action( 'admin_post_nmep_create_linked_account', array( __CLASS__, 'admin_create_linked_account' ) );

        // AJAX: admin manual retry for pushing bank details to Razorpay
        // (belt-and-suspenders for the auto-sync path above).
        add_action( 'admin_post_nmep_sync_bank_to_razorpay', array( __CLASS__, 'admin_sync_bank_to_razorpay' ) );

        // Cron target for the one-shot stranded-account heal below.
        add_action( 'nmep_heal_stranded_linked_accounts', array( __CLASS__, 'heal_stranded_linked_accounts' ) );

        // One-shot migration: for experts whose initial Route product
        // provisioning never completed (razorpay_account_id set, but
        // product_config_id empty — the cohort created before the
        // POST+PATCH two-step fix landed), auto-push their bank details
        // via sync_bank_to_razorpay on the next cron tick. Gated by an
        // option so it runs exactly once, with the admin-post fallback
        // still available for anything it can't heal unattended.
        if ( ! get_option( 'nmep_linked_accounts_030_healed' ) ) {
            if ( ! wp_next_scheduled( 'nmep_heal_stranded_linked_accounts' ) ) {
                wp_schedule_single_event( time() + 60, 'nmep_heal_stranded_linked_accounts' );
            }
        }
    }

    /**
     * One-shot background task — scan for linked accounts with a Razorpay
     * account id but no Route product config id, and auto-run the bank sync
     * flow for each. Runs via wp-cron (wp_schedule_single_event) so it can't
     * block a user-facing page load. Marks itself done via an option flag.
     */
    public static function heal_stranded_linked_accounts() {
        global $wpdb;

        if ( get_option( 'nmep_linked_accounts_030_healed' ) ) {
            return;
        }

        $table = NMEP_Database::table( 'linked_accounts' );

        // Pull at most 100 rows — production cohort is ~2 accounts; the cap
        // is defensive so a misconfiguration can't hammer Razorpay in a loop.
        $rows = $wpdb->get_results(
            "SELECT id, expert_id
               FROM {$table}
              WHERE razorpay_account_id IS NOT NULL
                AND razorpay_account_id != ''
                AND ( razorpay_product_config_id IS NULL OR razorpay_product_config_id = '' )
              LIMIT 100"
        );

        if ( empty( $rows ) ) {
            update_option( 'nmep_linked_accounts_030_healed', 1, false );
            return;
        }

        NMEP_Logger::info( 'Auto-heal: scanning stranded linked accounts', array(
            'count' => count( $rows ),
        ) );

        $ok   = 0;
        $fail = 0;
        foreach ( $rows as $row ) {
            $result = self::sync_bank_to_razorpay( (int) $row->expert_id );
            if ( is_wp_error( $result ) ) {
                $fail++;
                NMEP_Logger::warning( 'Auto-heal failed for expert', array(
                    'expert_id' => (int) $row->expert_id,
                    'error'     => $result->get_error_message(),
                    'code'      => $result->get_error_code(),
                ) );
            } else {
                $ok++;
            }
        }

        NMEP_Logger::info( 'Auto-heal finished', array(
            'healed' => $ok,
            'failed' => $fail,
        ) );

        // Mark done regardless — individual failures have been logged + audited
        // and can be retried via nmep_sync_bank_to_razorpay.
        update_option( 'nmep_linked_accounts_030_healed', 1, false );
    }

    /**
     * Create Linked Account for an expert
     *
     * @param int $expert_id NMEX expert ID
     * @return int|WP_Error Linked account local ID on success
     */
    public static function create_for_expert( $expert_id ) {
        global $wpdb;

        // Get expert from base plugin
        $expert = NMEP_Compat::get_expert( $expert_id );
        if ( ! $expert ) {
            return new WP_Error( 'nmep_expert_not_found', 'Expert not found' );
        }

        // Check if Linked Account already exists for current mode
        $mode = NMEP_Settings::get_mode();
        $existing = self::get_for_expert( $expert_id, $mode );
        if ( $existing && ! empty( $existing->razorpay_account_id ) ) {
            NMEP_Logger::info( 'Linked Account already exists', array(
                'expert_id' => $expert_id,
                'mode'      => $mode,
                'account_id' => $existing->razorpay_account_id,
            ) );
            return (int) $existing->id;
        }

        // If a previous attempt left a stub row (no razorpay_account_id), remove it
        // so we can re-attempt creation without hitting the UNIQUE(expert_id, mode) key.
        if ( $existing && empty( $existing->razorpay_account_id ) ) {
            $deleted = $wpdb->delete(
                NMEP_Database::table( 'linked_accounts' ),
                array( 'id' => (int) $existing->id ),
                array( '%d' )
            );
            NMEP_Logger::info( 'Removed stale linked account stub before retry', array(
                'expert_id'  => $expert_id,
                'mode'       => $mode,
                'stale_id'   => (int) $existing->id,
                'deleted'    => (int) $deleted,
            ) );
        }

        // Build payload for Razorpay
        $payload = self::build_account_payload( $expert );
        if ( is_wp_error( $payload ) ) {
            NMEP_Logger::error( 'Cannot build linked account payload', array(
                'expert_id' => $expert_id,
                'error'     => $payload->get_error_message(),
            ) );
            return $payload;
        }

        NMEP_Logger::info( 'Creating Linked Account for expert', array(
            'expert_id' => $expert_id,
            'mode'      => $mode,
        ) );

        // Save initial record (status: pending)
        $local_id = self::insert_local_record( $expert, $mode, $payload );
        if ( is_wp_error( $local_id ) ) {
            return $local_id;
        }

        // Call Razorpay API
        $response = NMEP_Razorpay_Client::create_linked_account( $payload );

        if ( is_wp_error( $response ) ) {
            self::update_local_record( $local_id, array(
                'status'         => 'failed',
                'failure_reason' => $response->get_error_message(),
                'api_response'   => wp_json_encode( $response->get_error_data() ),
            ) );
            return $response;
        }

        // Update local record with Razorpay details
        $update = array(
            'razorpay_account_id' => isset( $response['id'] ) ? sanitize_text_field( $response['id'] ) : null,
            'status'              => isset( $response['status'] ) ? sanitize_text_field( $response['status'] ) : 'created',
            'api_response'        => wp_json_encode( $response ),
        );

        self::update_local_record( $local_id, $update );

        NMEP_Logger::info( 'Linked Account created successfully', array(
            'expert_id'   => $expert_id,
            'account_id'  => isset( $response['id'] ) ? $response['id'] : null,
            'status'      => isset( $response['status'] ) ? $response['status'] : null,
        ) );

        // Audit log
        NMEP_Compat::audit_log( 'linked_account_created', 'expert', $expert_id, array(
            'razorpay_account_id' => isset( $response['id'] ) ? $response['id'] : null,
            'mode' => $mode,
        ) );

        // Now create stakeholder (required for KYC)
        if ( ! empty( $response['id'] ) ) {
            self::create_stakeholder_for_expert( $local_id, $expert, $response['id'] );

            // Then request Route product
            self::request_route_product_for_account( $local_id, $expert, $response['id'] );
        }

        return $local_id;
    }

    /**
     * Build the Razorpay account creation payload
     */
    private static function build_account_payload( $expert ) {
        if ( empty( $expert->email ) || empty( $expert->phone ) || empty( $expert->full_name ) ) {
            return new WP_Error( 'nmep_missing_required_fields', 'Expert missing required fields (email, phone, name)' );
        }

        if ( empty( $expert->bank_account_number ) || empty( $expert->bank_ifsc ) ) {
            return new WP_Error( 'nmep_missing_bank_details', 'Expert has not provided bank account details' );
        }

        if ( empty( $expert->pan_number ) ) {
            return new WP_Error( 'nmep_missing_pan', 'Expert has not provided PAN number' );
        }

        // Razorpay Route requires a real registered address. street1 and street2
        // must both be non-empty and postal_code must be a 6-digit Indian PIN.
        // These fields were added to the experts schema in nme_db_version 0.5.0.
        $street  = isset( $expert->street_address ) ? trim( (string) $expert->street_address ) : '';
        $village = isset( $expert->village_locality ) ? trim( (string) $expert->village_locality ) : '';
        $pincode = isset( $expert->postal_code ) ? preg_replace( '/\D/', '', (string) $expert->postal_code ) : '';

        if ( $street === '' || $village === '' || ! preg_match( '/^\d{6}$/', $pincode ) ) {
            return new WP_Error(
                'nmep_missing_address',
                'Expert registered address is incomplete. Street address, village/locality and a 6-digit PIN code are all required by Razorpay before a Linked Account can be created.'
            );
        }

        $city    = $expert->district ? sanitize_text_field( $expert->district ) : 'Dimapur';
        $state   = $expert->state ? sanitize_text_field( $expert->state ) : 'NAGALAND';

        // Build the payload per Razorpay's spec
        //
        // NOTE (2026-04 — v0.2.2): For business_type=individual, Razorpay's
        // current v2 /accounts API REJECTS any `legal_info.pan` value with
        // "The company pan field is invalid for business type: individual".
        // Razorpay treats legal_info.pan as COMPANY PAN, valid only for
        // proprietorship / partnership / private_limited / public_limited /
        // llp / ngo / trust / society. For individuals, PAN must be sent
        // on the stakeholder (kyc.pan) — which create_stakeholder_for_expert()
        // does immediately after this account is created.
        $payload = array(
            'email'         => sanitize_email( $expert->email ),
            'phone'         => self::format_phone( $expert->phone ),
            'type'          => 'route',
            'reference_id'  => 'NMEX_EXPERT_' . (int) $expert->id,
            'legal_business_name' => sanitize_text_field( $expert->full_name ),
            'business_type' => 'individual',
            'contact_name'  => sanitize_text_field( $expert->full_name ),
            'profile' => array(
                'category'    => 'others',
                // NOTE (2026-04 — v0.2.2): Razorpay rejects subcategory=professional_services
                // under category=others with "Invalid business subcategory for business
                // category: others". professional_services is only valid under
                // category=services. For category=others, the universal fallback is
                // 'others' (also accepts 'not_elsewhere_classified'). This has no impact
                // on payout eligibility or KYC — it's purely a business-classification tag.
                'subcategory' => 'others',
                'description' => 'Creator services expert on Nagaland Me Experts marketplace',
                'addresses'   => array(
                    'registered' => array(
                        'street1'     => sanitize_text_field( $street ),
                        'street2'     => sanitize_text_field( $village ),
                        'city'        => $city,
                        'state'       => $state,
                        'postal_code' => $pincode,
                        'country'     => 'IN',
                    ),
                ),
            ),
            // legal_info intentionally omitted — see note above.
        );

        return $payload;
    }

    /**
     * Create stakeholder for the linked account
     */
    private static function create_stakeholder_for_expert( $local_id, $expert, $razorpay_account_id ) {
        // NOTE (2026-04 — v0.2.3): stakeholder phone.primary must be 8–11 digits
        // with NO country-code prefix. Sending the +91XXXXXXXXXX form that the
        // account-level `phone` field accepts trips Razorpay's validator:
        // "The primary must be between 8 and 11 digits."
        $payload = array(
            'name'    => sanitize_text_field( $expert->full_name ),
            'email'   => sanitize_email( $expert->email ),
            'phone'   => array(
                'primary' => self::format_phone_digits_only( $expert->phone ),
            ),
            'kyc'     => array(
                'pan' => strtoupper( $expert->pan_number ),
            ),
        );

        $response = NMEP_Razorpay_Client::create_stakeholder( $razorpay_account_id, $payload );

        if ( is_wp_error( $response ) ) {
            NMEP_Logger::warning( 'Failed to create stakeholder', array(
                'expert_id'  => $expert->id,
                'account_id' => $razorpay_account_id,
                'error'      => $response->get_error_message(),
            ) );
            return $response;
        }

        if ( ! empty( $response['id'] ) ) {
            self::update_local_record( $local_id, array(
                'razorpay_stakeholder_id' => sanitize_text_field( $response['id'] ),
            ) );
            NMEP_Logger::info( 'Stakeholder created', array(
                'expert_id'      => $expert->id,
                'stakeholder_id' => $response['id'],
            ) );
        }

        return $response;
    }

    /**
     * Request Route product configuration with bank details.
     *
     * NOTE (2026-04 — v0.2.3): Razorpay split this into a two-step flow. The
     * initial POST /accounts/{id}/products must contain ONLY
     * {product_name, tnc_accepted}; sending settlements alongside now returns
     * "settlements is/are not required and should not be sent". After the
     * product is provisioned, issue a PATCH /accounts/{id}/products/{product_id}
     * with the settlements block to attach bank details.
     */
    private static function request_route_product_for_account( $local_id, $expert, $razorpay_account_id ) {
        // Step 1 — provision the Route product on the linked account.
        $create_payload = array(
            'product_name' => 'route',
            'tnc_accepted' => true,
        );

        $response = NMEP_Razorpay_Client::request_route_product( $razorpay_account_id, $create_payload );

        if ( is_wp_error( $response ) ) {
            NMEP_Logger::warning( 'Failed to request Route product', array(
                'expert_id'  => $expert->id,
                'account_id' => $razorpay_account_id,
                'error'      => $response->get_error_message(),
            ) );
            return $response;
        }

        $product_id = ! empty( $response['id'] ) ? sanitize_text_field( $response['id'] ) : '';

        if ( $product_id !== '' ) {
            self::update_local_record( $local_id, array(
                'razorpay_product_config_id' => $product_id,
                'activation_status'          => isset( $response['activation_status'] ) ? sanitize_text_field( $response['activation_status'] ) : 'pending',
            ) );
            NMEP_Logger::info( 'Route product requested', array(
                'expert_id'  => $expert->id,
                'product_id' => $product_id,
            ) );
        } else {
            // Without an id we can't run step 2 — surface this clearly instead of
            // silently skipping the settlements attach.
            NMEP_Logger::error( 'Route product response missing id; cannot attach settlements', array(
                'expert_id'  => $expert->id,
                'account_id' => $razorpay_account_id,
                'response'   => $response,
            ) );
            return $response;
        }

        // Step 2 — attach settlements (bank details) via PATCH.
        $settlements_payload = array(
            'settlements' => array(
                'account_number'   => preg_replace( '/\D/', '', $expert->bank_account_number ),
                'ifsc_code'        => strtoupper( str_replace( ' ', '', $expert->bank_ifsc ) ),
                'beneficiary_name' => sanitize_text_field( $expert->bank_account_holder ?: $expert->full_name ),
            ),
        );

        $patch = NMEP_Razorpay_Client::update_route_product( $razorpay_account_id, $product_id, $settlements_payload );

        if ( is_wp_error( $patch ) ) {
            NMEP_Logger::warning( 'Failed to attach settlements to Route product', array(
                'expert_id'  => $expert->id,
                'account_id' => $razorpay_account_id,
                'product_id' => $product_id,
                'error'      => $patch->get_error_message(),
            ) );
            return $patch;
        }

        if ( isset( $patch['activation_status'] ) ) {
            self::update_local_record( $local_id, array(
                'activation_status' => sanitize_text_field( $patch['activation_status'] ),
            ) );
        }

        NMEP_Logger::info( 'Route product settlements attached', array(
            'expert_id'         => $expert->id,
            'product_id'        => $product_id,
            'activation_status' => isset( $patch['activation_status'] ) ? $patch['activation_status'] : null,
        ) );

        return $patch;
    }

    /**
     * Insert initial linked account record
     */
    private static function insert_local_record( $expert, $mode, $payload ) {
        global $wpdb;

        $result = $wpdb->insert( NMEP_Database::table( 'linked_accounts' ), array(
            'expert_id'           => (int) $expert->id,
            'user_id'             => (int) $expert->user_id,
            'mode'                => $mode,
            'account_email'       => sanitize_email( $expert->email ),
            'account_phone'       => self::format_phone( $expert->phone ),
            'account_holder_name' => sanitize_text_field( $expert->full_name ),
            'business_type'       => 'individual',
            'business_category'   => 'others',
            'business_subcategory' => 'others',
            'bank_account_number' => $expert->bank_account_number,
            'bank_ifsc'           => strtoupper( $expert->bank_ifsc ),
            'beneficiary_name'    => $expert->bank_account_holder ?: $expert->full_name,
            'address_city'        => $expert->district ?: 'Dimapur',
            'address_state'       => $expert->state ?: 'NAGALAND',
            'address_country'     => 'IN',
            'pan_number'          => strtoupper( $expert->pan_number ),
            'status'              => 'pending',
            'verification_status' => 'pending',
            'activation_status'   => 'pending',
        ) );

        if ( ! $result ) {
            // Surface the real DB error so operators can see why the insert failed
            // (previously silent — failures were invisible in the Logs screen).
            NMEP_Logger::error( 'DB insert failed for linked account', array(
                'expert_id'  => (int) $expert->id,
                'mode'       => $mode,
                'mysql_error'=> $wpdb->last_error,
            ) );
            return new WP_Error(
                'nmep_db_insert_failed',
                'Could not save linked account record: ' . ( $wpdb->last_error ?: 'unknown DB error' )
            );
        }

        return (int) $wpdb->insert_id;
    }

    /**
     * Update local linked account record
     */
    private static function update_local_record( $local_id, $data ) {
        global $wpdb;
        return $wpdb->update( NMEP_Database::table( 'linked_accounts' ), $data, array( 'id' => (int) $local_id ) );
    }

    /**
     * Get Linked Account for an expert in a specific mode
     */
    public static function get_for_expert( $expert_id, $mode = null ) {
        global $wpdb;

        if ( $mode === null ) {
            $mode = NMEP_Settings::get_mode();
        }

        return $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM " . NMEP_Database::table( 'linked_accounts' ) . "
             WHERE expert_id = %d AND mode = %s",
            (int) $expert_id, $mode
        ) );
    }

    /**
     * Check if expert has an active Linked Account ready to receive transfers
     */
    public static function is_ready_for_transfers( $expert_id, $mode = null ) {
        $account = self::get_for_expert( $expert_id, $mode );
        if ( ! $account ) {
            return false;
        }

        // In test mode, even pending accounts can receive transfers
        if ( ( $mode ?: NMEP_Settings::get_mode() ) === 'test' ) {
            return ! empty( $account->razorpay_account_id );
        }

        // In live mode, require activation
        return ! empty( $account->razorpay_account_id ) &&
               in_array( $account->activation_status, array( 'activated', 'verified' ), true );
    }

    /**
     * Refresh status from Razorpay (called via cron or admin button)
     */
    public static function refresh_status( $local_id ) {
        global $wpdb;

        $record = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM " . NMEP_Database::table( 'linked_accounts' ) . " WHERE id = %d",
            (int) $local_id
        ) );

        if ( ! $record || empty( $record->razorpay_account_id ) ) {
            return false;
        }

        $response = NMEP_Razorpay_Client::fetch_linked_account( $record->razorpay_account_id );
        if ( is_wp_error( $response ) ) {
            return $response;
        }

        $update = array(
            'status'             => isset( $response['status'] ) ? sanitize_text_field( $response['status'] ) : $record->status,
            'api_response'       => wp_json_encode( $response ),
        );

        self::update_local_record( $local_id, $update );

        return true;
    }

    /**
     * Format phone number for Razorpay (must be 10 digits without country code, or with +91 prefix)
     */
    private static function format_phone( $phone ) {
        $digits = preg_replace( '/\D/', '', (string) $phone );

        // Strip India country code if present
        if ( strlen( $digits ) === 12 && substr( $digits, 0, 2 ) === '91' ) {
            $digits = substr( $digits, 2 );
        } elseif ( strlen( $digits ) === 13 && substr( $digits, 0, 3 ) === '910' ) {
            $digits = substr( $digits, 3 );
        }

        // Razorpay requires +91 format for Indian numbers
        if ( strlen( $digits ) === 10 ) {
            return '+91' . $digits;
        }

        return '+' . $digits;
    }

    /**
     * Return a phone as digits only (no country code, no +) for Razorpay fields
     * that require 8–11 digits, e.g. stakeholder phone.primary. Strips the
     * Indian country code if the incoming value is stored as +91XXXXXXXXXX.
     */
    private static function format_phone_digits_only( $phone ) {
        $digits = preg_replace( '/\D/', '', (string) $phone );

        if ( strlen( $digits ) === 12 && substr( $digits, 0, 2 ) === '91' ) {
            $digits = substr( $digits, 2 );
        } elseif ( strlen( $digits ) === 13 && substr( $digits, 0, 3 ) === '910' ) {
            $digits = substr( $digits, 3 );
        }

        return $digits;
    }

    /**
     * Hook: handle bank-change approval from the base plugin.
     *
     * Pushes the fresh bank details (already written to nme_experts by
     * NME_Change_Requests::approve_request) to Razorpay. Errors are logged
     * and recorded in the audit trail; we do NOT re-throw because the hook
     * caller has already released held payouts and sent confirmation email.
     * Admins can retry manually via nmep_sync_bank_to_razorpay.
     *
     * @param int   $expert_id NMEX expert id.
     * @param array $new_bank  Fields that were updated (unused here — we read
     *                         fresh from DB for consistency, but kept in the
     *                         signature so future subscribers can use it).
     */
    public static function handle_bank_change_approved( $expert_id, $new_bank = array() ) {
        $result = self::sync_bank_to_razorpay( (int) $expert_id );

        if ( is_wp_error( $result ) ) {
            NMEP_Logger::error( 'Bank sync to Razorpay failed after change-request approval', array(
                'expert_id' => (int) $expert_id,
                'error'     => $result->get_error_message(),
                'code'      => $result->get_error_code(),
            ) );
            NMEP_Compat::audit_log( 'linked_account_bank_sync_failed', 'expert', (int) $expert_id, array(
                'error' => $result->get_error_message(),
            ) );
        }
    }

    /**
     * Push the expert's current bank details (as stored in nme_experts) to
     * their Razorpay Route linked account. Handles both cases:
     *
     *   - Account has a Route product already — PATCH /products/{id} with
     *     fresh settlements.
     *   - Account has no Route product yet — run the two-step provisioning
     *     (POST product, PATCH settlements) via
     *     request_route_product_for_account().
     *
     * If the expert has no Razorpay account yet, this is a no-op (creation
     * will pick up fresh bank details on its own).
     *
     * @param int $expert_id NMEX expert id.
     * @return array|true|WP_Error Razorpay response on success, true on
     *                             intentional no-op, WP_Error on failure.
     */
    public static function sync_bank_to_razorpay( $expert_id ) {
        $expert_id = (int) $expert_id;
        if ( $expert_id <= 0 ) {
            return new WP_Error( 'nmep_invalid_expert', 'Invalid expert id.' );
        }

        $expert = NMEP_Compat::get_expert( $expert_id );
        if ( ! $expert ) {
            return new WP_Error( 'nmep_expert_not_found', 'Expert not found.' );
        }

        $mode   = NMEP_Settings::get_mode();
        $record = self::get_for_expert( $expert_id, $mode );

        if ( ! $record || empty( $record->razorpay_account_id ) ) {
            NMEP_Logger::info( 'Bank sync skipped: no Razorpay account on file', array(
                'expert_id' => $expert_id,
                'mode'      => $mode,
            ) );
            return true;
        }

        // Validate defensively — Razorpay's error messages for malformed
        // settlements are opaque, so fail early with a clear diagnostic.
        $account_number = preg_replace( '/\D/', '', (string) $expert->bank_account_number );
        $ifsc           = strtoupper( str_replace( ' ', '', (string) $expert->bank_ifsc ) );
        $beneficiary    = trim( (string) ( $expert->bank_account_holder ?: $expert->full_name ) );

        if ( $account_number === '' || strlen( $account_number ) < 9 || strlen( $account_number ) > 18 ) {
            return new WP_Error( 'nmep_invalid_bank_account', 'Bank account number must be 9–18 digits.' );
        }
        if ( ! preg_match( '/^[A-Z]{4}0[A-Z0-9]{6}$/', $ifsc ) ) {
            return new WP_Error( 'nmep_invalid_ifsc', 'IFSC code format is invalid.' );
        }
        if ( $beneficiary === '' ) {
            return new WP_Error( 'nmep_missing_beneficiary', 'Beneficiary name is required.' );
        }

        // No Route product yet → provision it (two-step POST+PATCH). That
        // helper reads bank details straight off $expert, so it'll pick up
        // the freshly-written values.
        if ( empty( $record->razorpay_product_config_id ) ) {
            NMEP_Logger::info( 'Bank sync: no Route product yet, provisioning now', array(
                'expert_id'  => $expert_id,
                'account_id' => $record->razorpay_account_id,
            ) );
            $response = self::request_route_product_for_account( (int) $record->id, $expert, $record->razorpay_account_id );
            if ( is_wp_error( $response ) ) {
                return $response;
            }
        } else {
            // PATCH only — the common path when an onboarded expert changes bank.
            $settlements_payload = array(
                'settlements' => array(
                    'account_number'   => $account_number,
                    'ifsc_code'        => $ifsc,
                    'beneficiary_name' => sanitize_text_field( $beneficiary ),
                ),
            );

            $response = NMEP_Razorpay_Client::update_route_product(
                $record->razorpay_account_id,
                $record->razorpay_product_config_id,
                $settlements_payload
            );

            if ( is_wp_error( $response ) ) {
                return $response;
            }
        }

        // Mirror the snapshot locally so admin screens reflect what's live.
        self::update_local_record( (int) $record->id, array(
            'bank_account_number' => $account_number,
            'bank_ifsc'           => $ifsc,
            'beneficiary_name'    => $beneficiary,
            'activation_status'   => isset( $response['activation_status'] )
                ? sanitize_text_field( $response['activation_status'] )
                : $record->activation_status,
        ) );

        NMEP_Logger::info( 'Bank synced to Razorpay', array(
            'expert_id'  => $expert_id,
            'account_id' => $record->razorpay_account_id,
            'product_id' => $record->razorpay_product_config_id,
        ) );

        NMEP_Compat::audit_log( 'linked_account_bank_synced', 'expert', $expert_id, array(
            'razorpay_account_id' => $record->razorpay_account_id,
            'mode'                => $mode,
        ) );

        return $response;
    }

    /**
     * Admin action: manually re-push bank details to Razorpay (retry the
     * sync flow, e.g. after a transient failure or for accounts that were
     * onboarded before the auto-sync hook existed).
     */
    public static function admin_sync_bank_to_razorpay() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( 'Permission denied' );
        }

        $expert_id = isset( $_POST['expert_id'] ) ? (int) $_POST['expert_id'] : 0;
        $nonce     = isset( $_POST['_wpnonce'] ) ? $_POST['_wpnonce'] : '';

        if ( ! wp_verify_nonce( $nonce, 'nmep_sync_bank_' . $expert_id ) ) {
            wp_die( 'Invalid request' );
        }

        $result = self::sync_bank_to_razorpay( $expert_id );

        $redirect = admin_url( 'admin.php?page=nmep-linked-accounts' );
        if ( is_wp_error( $result ) ) {
            $redirect = add_query_arg( 'nmep_error', urlencode( $result->get_error_message() ), $redirect );
        } else {
            $redirect = add_query_arg( 'nmep_success', urlencode( 'Bank details pushed to Razorpay.' ), $redirect );
        }

        wp_safe_redirect( $redirect );
        exit;
    }

    /**
     * Admin action: manually trigger Linked Account creation
     */
    public static function admin_create_linked_account() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( 'Permission denied' );
        }

        $expert_id = isset( $_POST['expert_id'] ) ? (int) $_POST['expert_id'] : 0;
        if ( ! wp_verify_nonce( $_POST['_wpnonce'] ?? '', 'nmep_create_linked_' . $expert_id ) ) {
            wp_die( 'Invalid request' );
        }

        $result = self::create_for_expert( $expert_id );

        $redirect = admin_url( 'admin.php?page=nmep-linked-accounts' );
        if ( is_wp_error( $result ) ) {
            $redirect = add_query_arg( 'nmep_error', urlencode( $result->get_error_message() ), $redirect );
        } else {
            $redirect = add_query_arg( 'nmep_success', '1', $redirect );
        }

        wp_safe_redirect( $redirect );
        exit;
    }
}