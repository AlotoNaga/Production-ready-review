<?php
/**
 * NMEP_Compat
 * Defensive compatibility layer for base plugin (Nagaland Me Experts) methods.
 *
 * If a method we depend on doesn't exist on the base plugin (because it's an
 * older version or a method wasn't implemented yet), we provide safe fallbacks
 * here so the payments plugin doesn't crash.
 *
 * @version 1.1.0 (Batch B)
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class NMEP_Compat {

    /**
     * Safely get expert by WordPress user ID
     */
    public static function get_expert_by_user( $user_id ) {
        if ( class_exists( 'NME_Experts' ) && method_exists( 'NME_Experts', 'get_by_user' ) ) {
            return NME_Experts::get_by_user( $user_id );
        }

        // Fallback: query the experts table directly
        if ( class_exists( 'NME_Database' ) ) {
            global $wpdb;
            $table = NME_Database::table( 'experts' );
            return $wpdb->get_row( $wpdb->prepare(
                "SELECT * FROM $table WHERE user_id = %d LIMIT 1",
                (int) $user_id
            ) );
        }

        return null;
    }

    /**
     * Safely get expert by ID
     */
    public static function get_expert( $expert_id ) {
        if ( class_exists( 'NME_Experts' ) && method_exists( 'NME_Experts', 'get' ) ) {
            return NME_Experts::get( $expert_id );
        }

        if ( class_exists( 'NME_Database' ) ) {
            global $wpdb;
            $table = NME_Database::table( 'experts' );
            return $wpdb->get_row( $wpdb->prepare(
                "SELECT * FROM $table WHERE id = %d LIMIT 1",
                (int) $expert_id
            ) );
        }

        return null;
    }

    /**
     * Safely get tier badge HTML
     */
    public static function get_tier_badge( $tier ) {
        if ( class_exists( 'NME_Experts' ) && method_exists( 'NME_Experts', 'get_tier_badge' ) ) {
            return NME_Experts::get_tier_badge( $tier );
        }

        // Fallback badges
        $tier = strtolower( (string) $tier );
        $map = array(
            'new'     => array( 'label' => 'New',      'color' => '#9CA3AF' ),
            'rising'  => array( 'label' => 'Rising',   'color' => '#3B82F6' ),
            'pro'     => array( 'label' => 'Pro',      'color' => '#10B981' ),
            'top_pro' => array( 'label' => 'Top Pro',  'color' => '#D4A843' ),
        );
        $b = isset( $map[ $tier ] ) ? $map[ $tier ] : $map['new'];
        return sprintf(
            '<span style="display:inline-block;padding:2px 8px;border-radius:50px;font-size:0.7rem;font-weight:700;background:%s;color:#fff;text-transform:uppercase;letter-spacing:0.05em;">%s</span>',
            esc_attr( $b['color'] ),
            esc_html( $b['label'] )
        );
    }

    /**
     * Safely get all categories
     */
    public static function get_all_categories() {
        if ( class_exists( 'NME_Categories' ) && method_exists( 'NME_Categories', 'get_all' ) ) {
            return NME_Categories::get_all();
        }

        // Fallback: query categories table
        if ( class_exists( 'NME_Database' ) ) {
            global $wpdb;
            $table = NME_Database::table( 'categories' );
            return $wpdb->get_results( "SELECT * FROM $table WHERE is_active = 1 ORDER BY sort_order ASC, name ASC" );
        }

        return array();
    }

    /**
     * Safely get category by slug
     */
    public static function get_category_by_slug( $slug ) {
        if ( class_exists( 'NME_Categories' ) && method_exists( 'NME_Categories', 'get_by_slug' ) ) {
            return NME_Categories::get_by_slug( $slug );
        }

        if ( class_exists( 'NME_Database' ) ) {
            global $wpdb;
            $table = NME_Database::table( 'categories' );
            return $wpdb->get_row( $wpdb->prepare(
                "SELECT * FROM $table WHERE slug = %s LIMIT 1",
                sanitize_title( $slug )
            ) );
        }

        return null;
    }

    /**
     * Safely get category by ID
     */
    public static function get_category_by_id( $id ) {
        if ( class_exists( 'NME_Categories' ) && method_exists( 'NME_Categories', 'get_by_id' ) ) {
            return NME_Categories::get_by_id( $id );
        }

        if ( class_exists( 'NME_Database' ) ) {
            global $wpdb;
            $table = NME_Database::table( 'categories' );
            return $wpdb->get_row( $wpdb->prepare(
                "SELECT * FROM $table WHERE id = %d LIMIT 1",
                (int) $id
            ) );
        }

        return null;
    }

    /**
     * Safely write to audit log (no-op if base plugin missing)
     */
    public static function audit_log( $action, $entity_type, $entity_id = null, $context = array() ) {
        if ( class_exists( 'NME_Database' ) && method_exists( 'NME_Database', 'audit_log' ) ) {
            NME_Database::audit_log( $action, $entity_type, $entity_id, $context );
        } else {
            // Fall back to our own logger
            NMEP_Logger::info( 'Audit (no base plugin log): ' . $action, array(
                'entity_type' => $entity_type,
                'entity_id'   => $entity_id,
                'context'     => $context,
            ) );
        }
    }

    /**
     * Get a base plugin database table name safely
     */
    public static function base_table( $name ) {
        if ( class_exists( 'NME_Database' ) && method_exists( 'NME_Database', 'table' ) ) {
            return NME_Database::table( $name );
        }
        // Best guess: prefix + nme_
        global $wpdb;
        return $wpdb->prefix . 'nme_' . $name;
    }
}
