<?php
/**
 * NMEP_Logger
 * Production-grade logging for payment debugging.
 * Logs to a dedicated file in wp-content/uploads/nmep-logs/
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class NMEP_Logger {

    const LEVEL_DEBUG    = 'debug';
    const LEVEL_INFO     = 'info';
    const LEVEL_WARNING  = 'warning';
    const LEVEL_ERROR    = 'error';
    const LEVEL_CRITICAL = 'critical';

    /**
     * Get the log directory path
     */
    private static function log_dir() {
        $upload_dir = wp_upload_dir();
        $log_dir = $upload_dir['basedir'] . '/nmep-logs';

        if ( ! file_exists( $log_dir ) ) {
            wp_mkdir_p( $log_dir );

            // Protect log directory from public access
            file_put_contents( $log_dir . '/.htaccess', "Order deny,allow\nDeny from all\n" );
            file_put_contents( $log_dir . '/index.html', '' );
        }

        return $log_dir;
    }

    /**
     * Get current log file path (rotated daily)
     */
    private static function log_file() {
        return self::log_dir() . '/nmep-' . date( 'Y-m-d' ) . '.log';
    }

    /**
     * Write a log entry
     */
    public static function log( $message, $level = self::LEVEL_INFO, $context = array() ) {
        // Skip debug logs in production unless explicitly enabled
        if ( $level === self::LEVEL_DEBUG && ! self::is_debug_enabled() ) {
            return;
        }

        $timestamp = current_time( 'Y-m-d H:i:s' );
        $level_upper = strtoupper( $level );

        $entry = "[{$timestamp}] [{$level_upper}] {$message}";

        if ( ! empty( $context ) ) {
            // Sanitize context — never log full keys or secrets
            $context = self::sanitize_context( $context );
            $entry .= ' | Context: ' . wp_json_encode( $context );
        }

        $entry .= PHP_EOL;

        // Append to log file
        @file_put_contents( self::log_file(), $entry, FILE_APPEND | LOCK_EX );

        // Critical errors also fire a WordPress action for monitoring
        if ( $level === self::LEVEL_CRITICAL ) {
            do_action( 'nmep_critical_error', $message, $context );
        }
    }

    /**
     * Convenience methods
     */
    public static function debug( $message, $context = array() ) {
        self::log( $message, self::LEVEL_DEBUG, $context );
    }

    public static function info( $message, $context = array() ) {
        self::log( $message, self::LEVEL_INFO, $context );
    }

    public static function warning( $message, $context = array() ) {
        self::log( $message, self::LEVEL_WARNING, $context );
    }

    public static function error( $message, $context = array() ) {
        self::log( $message, self::LEVEL_ERROR, $context );
    }

    public static function critical( $message, $context = array() ) {
        self::log( $message, self::LEVEL_CRITICAL, $context );
    }

    /**
     * Sanitize context to never log secrets
     */
    private static function sanitize_context( $context ) {
        $sensitive_keys = array(
            'key_secret',
            'webhook_secret',
            'password',
            'pass',
            'api_key',
            'authorization',
            'bank_account_number',
            'pan_number',
        );

        if ( ! is_array( $context ) ) {
            return $context;
        }

        foreach ( $context as $key => $value ) {
            $key_lower = strtolower( $key );
            foreach ( $sensitive_keys as $sensitive ) {
                if ( strpos( $key_lower, $sensitive ) !== false ) {
                    $context[ $key ] = '***REDACTED***';
                    break;
                }
            }

            if ( is_array( $value ) ) {
                $context[ $key ] = self::sanitize_context( $value );
            }
        }

        return $context;
    }

    /**
     * Check if debug logging is enabled
     */
    private static function is_debug_enabled() {
        return defined( 'WP_DEBUG' ) && WP_DEBUG && get_option( 'nmep_enable_debug_logs', false );
    }

    /**
     * Get recent log entries (for admin display)
     */
    public static function get_recent( $lines = 100 ) {
        $file = self::log_file();
        if ( ! file_exists( $file ) ) {
            return array();
        }

        $contents = file( $file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES );
        if ( empty( $contents ) ) {
            return array();
        }

        return array_slice( $contents, -$lines );
    }

    /**
     * Clean up old log files (keep last 30 days)
     */
    public static function cleanup_old_logs() {
        $log_dir = self::log_dir();
        $files = glob( $log_dir . '/nmep-*.log' );
        if ( ! is_array( $files ) ) {
            return;
        }

        $cutoff = strtotime( '-30 days' );

        foreach ( $files as $file ) {
            if ( filemtime( $file ) < $cutoff ) {
                @unlink( $file );
            }
        }
    }
}
