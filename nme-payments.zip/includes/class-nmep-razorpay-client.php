<?php
/**
 * NMEP_Razorpay_Client
 * Production-grade Razorpay API client.
 *
 * Handles:
 * - HTTP requests with retries
 * - Authentication
 * - Signature verification
 * - Error handling
 * - Rate limiting awareness
 *
 * API versions:
 *   v1 — orders, payments, transfers, refunds, payouts, contacts, fund_accounts.
 *   v2 — Route onboarding only: linked accounts, stakeholders, product configuration.
 * Razorpay split those endpoints across versions. Do not move v1 calls to v2 or
 * vice-versa; the payloads and behaviours differ.
 *
 * @version 0.2.2  2026-04  Add update_route_product() for PATCH /products/{id} (v2 now rejects settlements in initial POST)
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class NMEP_Razorpay_Client {

    const API_BASE    = 'https://api.razorpay.com/v1';
    const API_BASE_V2 = 'https://api.razorpay.com/v2';
    const TIMEOUT     = 30;
    const MAX_RETRIES = 2;

    /**
     * Make API request to Razorpay
     *
     * @param string     $method      GET, POST, PUT, DELETE, PATCH
     * @param string     $path        Path after the version segment (e.g. '/orders' or '/accounts')
     * @param array|null $data        Request body for POST/PUT/PATCH
     * @param string     $api_version 'v1' (default) or 'v2'. Use 'v2' only for Route onboarding endpoints
     *                                (accounts, stakeholders, products). See class docblock.
     * @return array|WP_Error
     */
    public static function request( $method, $path, $data = null, $api_version = 'v1' ) {
        if ( ! NMEP_Settings::is_api_configured() ) {
            return new WP_Error( 'nmep_api_not_configured', 'Razorpay API keys are not configured.' );
        }

        $key_id     = NMEP_Settings::get_api_key_id();
        $key_secret = NMEP_Settings::get_api_key_secret();
        $base       = ( $api_version === 'v2' ) ? self::API_BASE_V2 : self::API_BASE;
        $url        = $base . $path;

        $args = array(
            'timeout'     => self::TIMEOUT,
            'redirection' => 5,
            'httpversion' => '1.1',
            'sslverify'   => true,
            'headers'     => array(
                'Authorization' => 'Basic ' . base64_encode( $key_id . ':' . $key_secret ),
                'Content-Type'  => 'application/json',
                'Accept'        => 'application/json',
                'User-Agent'    => 'NagalandMeExperts/' . NMEP_VERSION . ' WordPress/' . get_bloginfo( 'version' ),
            ),
            'method'      => strtoupper( $method ),
        );

        if ( $data !== null && in_array( strtoupper( $method ), array( 'POST', 'PUT', 'PATCH' ), true ) ) {
            $args['body'] = wp_json_encode( $data );
        }

        // Log request (without sensitive data)
        NMEP_Logger::debug( 'Razorpay API request', array(
            'method'      => $method,
            'path'        => $path,
            'api_version' => $api_version,
            'mode'        => NMEP_Settings::get_mode(),
        ) );

        // Try with retries for transient failures
        $attempts = 0;
        $last_error = null;

        while ( $attempts <= self::MAX_RETRIES ) {
            $attempts++;
            $response = wp_remote_request( $url, $args );

            if ( is_wp_error( $response ) ) {
                $last_error = $response;
                NMEP_Logger::warning( 'Razorpay API request failed (attempt ' . $attempts . ')', array(
                    'error' => $response->get_error_message(),
                    'path'  => $path,
                ) );

                // Retry only on network errors
                if ( $attempts <= self::MAX_RETRIES ) {
                    sleep( 1 ); // brief backoff
                    continue;
                }

                return new WP_Error( 'nmep_api_network_error', 'Network error: ' . $response->get_error_message() );
            }

            // Got HTTP response — break out of retry loop
            break;
        }

        $code = (int) wp_remote_retrieve_response_code( $response );
        $body = wp_remote_retrieve_body( $response );
        $json = json_decode( $body, true );

        // Handle non-2xx responses
        if ( $code < 200 || $code >= 300 ) {
            $error_msg = 'Razorpay API error';
            $error_code = 'nmep_api_error';
            $error_description = '';

            if ( is_array( $json ) && isset( $json['error'] ) ) {
                $error_description = isset( $json['error']['description'] ) ? $json['error']['description'] : '';
                $error_code = isset( $json['error']['code'] ) ? $json['error']['code'] : 'nmep_api_error';
                $error_msg = $error_description ?: $error_msg;
            }

            NMEP_Logger::error( 'Razorpay API error response', array(
                'http_code'   => $code,
                'path'        => $path,
                'api_version' => $api_version,
                'error'       => $error_description,
                'code'        => $error_code,
            ) );

            return new WP_Error( 'nmep_api_error', $error_msg, array(
                'http_code'   => $code,
                'api_version' => $api_version,
                'razorpay_error' => $error_code,
                'description' => $error_description,
                'body'        => $body,
            ) );
        }

        // Success
        if ( ! is_array( $json ) ) {
            return array();
        }

        return $json;
    }

    /**
     * Convenience methods (v1 — default Razorpay API surface)
     */
    public static function get( $path ) {
        return self::request( 'GET', $path );
    }

    public static function post( $path, $data ) {
        return self::request( 'POST', $path, $data );
    }

    public static function put( $path, $data ) {
        return self::request( 'PUT', $path, $data );
    }

    public static function patch( $path, $data ) {
        return self::request( 'PATCH', $path, $data );
    }

    public static function delete( $path ) {
        return self::request( 'DELETE', $path );
    }

    /**
     * Convenience methods (v2 — Route onboarding: accounts / stakeholders / products)
     * Use these only for endpoints documented under /v2 by Razorpay. See class docblock.
     */
    public static function get_v2( $path ) {
        return self::request( 'GET', $path, null, 'v2' );
    }

    public static function post_v2( $path, $data ) {
        return self::request( 'POST', $path, $data, 'v2' );
    }

    public static function patch_v2( $path, $data ) {
        return self::request( 'PATCH', $path, $data, 'v2' );
    }

    /**
     * Verify Razorpay payment signature
     *
     * @param string $razorpay_order_id
     * @param string $razorpay_payment_id
     * @param string $razorpay_signature
     * @return bool
     */
    public static function verify_payment_signature( $razorpay_order_id, $razorpay_payment_id, $razorpay_signature ) {
        $secret = NMEP_Settings::get_api_key_secret();
        if ( empty( $secret ) ) {
            return false;
        }

        $payload = $razorpay_order_id . '|' . $razorpay_payment_id;
        $expected = hash_hmac( 'sha256', $payload, $secret );

        return hash_equals( $expected, (string) $razorpay_signature );
    }

    /**
     * Verify webhook signature
     *
     * @param string $body Raw request body
     * @param string $signature X-Razorpay-Signature header value
     * @return bool
     */
    public static function verify_webhook_signature( $body, $signature ) {
        $secret = NMEP_Settings::get_webhook_secret();
        if ( empty( $secret ) ) {
            return false;
        }

        $expected = hash_hmac( 'sha256', $body, $secret );
        return hash_equals( $expected, (string) $signature );
    }

    /* ============================================================
       HIGH-LEVEL API METHODS — ORDERS (v1)
       ============================================================ */

    /**
     * Create a Razorpay order with optional Route transfers
     */
    public static function create_order( $amount_paise, $currency = 'INR', $receipt = null, $notes = array(), $transfers = null ) {
        $payload = array(
            'amount'   => (int) $amount_paise,
            'currency' => $currency,
            'receipt'  => $receipt ?: 'rcpt_' . wp_rand( 10000, 99999 ),
            'notes'    => is_array( $notes ) ? $notes : array(),
        );

        // For Razorpay Route, attach transfers
        if ( is_array( $transfers ) && ! empty( $transfers ) ) {
            $payload['transfers'] = $transfers;
        }

        return self::post( '/orders', $payload );
    }

    /**
     * Fetch an order
     */
    public static function fetch_order( $razorpay_order_id ) {
        return self::get( '/orders/' . rawurlencode( $razorpay_order_id ) );
    }

    /**
     * Fetch a payment
     */
    public static function fetch_payment( $razorpay_payment_id ) {
        return self::get( '/payments/' . rawurlencode( $razorpay_payment_id ) );
    }

    /* ============================================================
       LINKED ACCOUNTS (RAZORPAY ROUTE — v2)
       ------------------------------------------------------------
       These endpoints live under /v2. Do NOT switch them to /v1 —
       Razorpay's gateway returns a bare 404 ("The requested URL was
       not found on the server.") for /v1/accounts.
       ============================================================ */

    /**
     * Create a Linked Account (an expert's Razorpay sub-account)
     */
    public static function create_linked_account( $payload ) {
        return self::post_v2( '/accounts', $payload );
    }

    /**
     * Fetch a Linked Account
     */
    public static function fetch_linked_account( $account_id ) {
        return self::get_v2( '/accounts/' . rawurlencode( $account_id ) );
    }

    /**
     * Update a Linked Account
     */
    public static function update_linked_account( $account_id, $payload ) {
        return self::patch_v2( '/accounts/' . rawurlencode( $account_id ), $payload );
    }

    /**
     * Create a Stakeholder for a Linked Account
     */
    public static function create_stakeholder( $account_id, $payload ) {
        return self::post_v2( '/accounts/' . rawurlencode( $account_id ) . '/stakeholders', $payload );
    }

    /**
     * Request Route product configuration for a Linked Account
     */
    public static function request_route_product( $account_id, $payload ) {
        return self::post_v2( '/accounts/' . rawurlencode( $account_id ) . '/products', $payload );
    }

    /**
     * Update (PATCH) a Route product configuration — used to attach settlements
     * after the initial POST. Razorpay v2 now rejects `settlements` in the POST
     * body with "settlements is/are not required and should not be sent", so the
     * two-call pattern is mandatory: POST {product_name,tnc_accepted} then PATCH
     * {settlements:{...}} on /accounts/{id}/products/{product_id}.
     */
    public static function update_route_product( $account_id, $product_id, $payload ) {
        return self::patch_v2(
            '/accounts/' . rawurlencode( $account_id ) . '/products/' . rawurlencode( $product_id ),
            $payload
        );
    }

    /* ============================================================
       TRANSFERS (RAZORPAY ROUTE — v1)
       ============================================================ */

    /**
     * Create a transfer from a captured payment
     */
    public static function create_transfer_from_payment( $razorpay_payment_id, $transfers ) {
        return self::post( '/payments/' . rawurlencode( $razorpay_payment_id ) . '/transfers', array(
            'transfers' => $transfers,
        ) );
    }

    /**
     * Fetch transfers for a payment
     */
    public static function fetch_transfers_for_payment( $razorpay_payment_id ) {
        return self::get( '/payments/' . rawurlencode( $razorpay_payment_id ) . '/transfers' );
    }

    /**
     * Reverse a transfer (move money back from Linked Account to platform)
     */
    public static function reverse_transfer( $transfer_id, $amount_paise = null ) {
        $payload = array();
        if ( $amount_paise !== null ) {
            $payload['amount'] = (int) $amount_paise;
        }
        return self::post( '/transfers/' . rawurlencode( $transfer_id ) . '/reversals', $payload );
    }

    /**
     * Update transfer hold status
     */
    public static function update_transfer( $transfer_id, $payload ) {
        return self::patch( '/transfers/' . rawurlencode( $transfer_id ), $payload );
    }

    /* ============================================================
       REFUNDS (v1)
       ============================================================ */

    /**
     * Create a refund for a payment
     */
    public static function create_refund( $razorpay_payment_id, $amount_paise = null, $notes = array() ) {
        $payload = array();
        if ( $amount_paise !== null ) {
            $payload['amount'] = (int) $amount_paise;
        }
        if ( ! empty( $notes ) ) {
            $payload['notes'] = $notes;
        }
        // For Route: also reverse all linked transfers
        $payload['reverse_all'] = 1;

        return self::post( '/payments/' . rawurlencode( $razorpay_payment_id ) . '/refund', $payload );
    }
}