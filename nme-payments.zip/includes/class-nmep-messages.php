<?php
/**
 * NMEP_Messages
 * Buyer ↔ Expert messaging within an order context.
 * Uses existing wp_nmep_order_messages table (already created in Batch A).
 *
 * @version 1.4.0 (Batch E)
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class NMEP_Messages {

    public static function init() {
        // Buyer (token-auth) and Expert (logged-in) can both send
        add_action( 'admin_post_nopriv_nmep_send_message', array( __CLASS__, 'handle_send_message' ) );
        add_action( 'admin_post_nmep_send_message',         array( __CLASS__, 'handle_send_message' ) );
    }

    public static function handle_send_message() {
        $order_id = isset( $_POST['order_id'] ) ? (int) $_POST['order_id'] : 0;
        $token    = sanitize_text_field( $_POST['token'] ?? '' );
        $role     = sanitize_key( $_POST['role'] ?? '' );
        $message  = sanitize_textarea_field( $_POST['message'] ?? '' );
        $attachment_url = esc_url_raw( $_POST['attachment_url'] ?? '' );

        // Phase 5B: screen message content (redact contact info / blocked words).
        $blocked_reason = null;
        $screen_matched = array();
        if ( class_exists( 'NMEP_Moderation' ) ) {
            $screened = NMEP_Moderation::screen_message( $message );
            $message        = $screened['text'];
            $blocked_reason = $screened['blocked_reason'];
            $screen_matched = $screened['matched'];
        }

        // Phase 5B: validate uploaded attachment if present.
        $uploaded_attachment = null;
        if ( ! empty( $_FILES['attachment_file']['name'] ) && class_exists( 'NMEP_Moderation' ) ) {
            $result = NMEP_Moderation::handle_upload( $_FILES['attachment_file'] );
            if ( is_wp_error( $result ) ) {
                wp_die( esc_html( $result->get_error_message() ) );
            }
            $uploaded_attachment = $result;
            $attachment_url      = $result['url'];
        }

        if ( ! wp_verify_nonce( $_POST['_wpnonce'] ?? '', 'nmep_send_message_' . $order_id ) ) {
            wp_die( 'Security check failed.' );
        }

        $order = NMEP_Orders::get( $order_id );
        if ( ! $order ) {
            wp_die( 'Order not found.' );
        }

        // Authorize
        $sender_user_id = null;
        $sender_name    = '';
        $authorized = false;

        if ( $role === 'buyer' && $order->view_token === $token ) {
            $authorized    = true;
            $sender_user_id = $order->buyer_user_id ?: null;
            $sender_name   = $order->buyer_name;
        } elseif ( $role === 'expert' && is_user_logged_in() ) {
            $expert = NMEP_Compat::get_expert_by_user( get_current_user_id() );
            if ( $expert && (int) $expert->id === (int) $order->expert_id ) {
                $authorized = true;
                $sender_user_id = get_current_user_id();
                $sender_name = $expert->full_name;
            }
        }

        if ( ! $authorized ) {
            wp_die( 'Permission denied.' );
        }

        if ( empty( $message ) || strlen( $message ) < 1 ) {
            wp_die( 'Message cannot be empty.' );
        }
        if ( strlen( $message ) > 5000 ) {
            wp_die( 'Message too long (max 5000 chars).' );
        }

        global $wpdb;
        $wpdb->insert( NMEP_Database::table( 'order_messages' ), array(
            'order_id'        => $order_id,
            'sender_user_id'  => $sender_user_id,
            'sender_role'     => $role,
            'sender_name'     => $sender_name,
            'message'         => $message,
            'attachment_urls' => $attachment_url ? wp_json_encode( array( $attachment_url ) ) : null,
            'is_read'         => 0,
            'blocked_reason'  => $blocked_reason,
        ) );

        $message_id = (int) $wpdb->insert_id;

        // Persist structured attachment row (MIME/size) if uploaded via multipart form.
        if ( $uploaded_attachment && class_exists( 'NMEP_Moderation' ) ) {
            NMEP_Moderation::persist_attachment( $message_id, $uploaded_attachment );
        }

        NMEP_Logger::info( 'Order message sent', array(
            'order_id'       => $order_id,
            'message_id'     => $message_id,
            'role'           => $role,
            'blocked_reason' => $blocked_reason,
            'matched'        => $screen_matched,
        ) );

        // Emit canonical event for metrics / audit / analytics subscribers.
        if ( class_exists( 'NMEP_Events' ) ) {
            NMEP_Events::emit( NMEP_Events::MESSAGE_SENT, (int) $order_id, $role, $message_id, $order );
        }

        // Notify the OTHER party
        if ( class_exists( 'NMEP_Emails' ) ) {
            NMEP_Emails::send_new_message_notification( $order, $role, $message );
        }

        // Redirect back
        if ( $role === 'buyer' ) {
            $url = add_query_arg( array(
                'order' => $order->order_number,
                'token' => $order->view_token,
                'nmep_status' => 'success',
                'nmep_msg' => urlencode( 'Message sent.' ),
            ), nmep_get_page_url( 'order-track' ) );
        } else {
            $url = add_query_arg( array(
                'nmep_status' => 'success',
                'nmep_msg' => urlencode( 'Message sent to buyer.' ),
            ), nmep_get_page_url( 'expert-dashboard' ) );
        }
        wp_safe_redirect( $url . '#messages' );
        exit;
    }

    /* ============================================================
       QUERIES
       ============================================================ */

    public static function get_for_order( $order_id ) {
        global $wpdb;
        return $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM " . NMEP_Database::table( 'order_messages' ) . "
             WHERE order_id = %d
             ORDER BY created_at ASC",
            (int) $order_id
        ) );
    }

    public static function get_unread_count_for_expert( $expert_id ) {
        global $wpdb;
        return (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM " . NMEP_Database::table( 'order_messages' ) . " m
             LEFT JOIN " . NMEP_Database::table( 'orders' ) . " o ON o.id = m.order_id
             WHERE o.expert_id = %d AND m.sender_role = 'buyer' AND m.is_read = 0",
            (int) $expert_id
        ) );
    }

    public static function mark_read_for_order( $order_id, $reader_role ) {
        global $wpdb;
        // Mark all messages NOT from reader as read
        $wpdb->query( $wpdb->prepare(
            "UPDATE " . NMEP_Database::table( 'order_messages' ) . "
             SET is_read = 1 WHERE order_id = %d AND sender_role != %s",
            (int) $order_id, sanitize_key( $reader_role )
        ) );
    }

    /* ============================================================
       UI: Render conversation thread
       ============================================================ */

    public static function render_thread( $order, $current_role, $send_form_action_url ) {
        $messages = self::get_for_order( $order->id );

        // Mark as read
        self::mark_read_for_order( $order->id, $current_role );

        ob_start();
        ?>
        <div class="nme-card nme-mt-3" id="messages">
            <h3 style="margin-top: 0;">💬 Order Messages</h3>

            <?php if ( empty( $messages ) ) : ?>
                <p style="color: var(--nme-text-light, #6B7280);">No messages yet. Start the conversation below.</p>
            <?php else : ?>
                <div style="max-height: 500px; overflow-y: auto; padding: 8px; background: var(--nme-bg-soft, #F9FAFB); border-radius: 8px; margin-bottom: 16px;">
                    <?php foreach ( $messages as $msg ) :
                        $is_mine = $msg->sender_role === $current_role;
                        $is_system = $msg->is_delivery || $msg->is_revision_request;
                    ?>
                        <div style="display: flex; <?php echo $is_mine ? 'justify-content: flex-end;' : ''; ?> margin-bottom: 12px;">
                            <div style="max-width: 75%; <?php echo $is_mine ? 'background: var(--nme-emerald, #10B981); color: white;' : 'background: white; color: var(--nme-text, #374151);'; ?> padding: 12px 16px; border-radius: 16px; <?php echo $is_system ? 'border: 2px solid #D4A843;' : ''; ?>">
                                <div style="font-size: 0.75rem; opacity: 0.7; margin-bottom: 4px;">
                                    <strong><?php echo esc_html( $msg->sender_name ); ?></strong>
                                    · <?php echo esc_html( strtoupper( $msg->sender_role ) ); ?>
                                    <?php if ( $msg->is_delivery ) echo ' · 📦 DELIVERY'; ?>
                                    <?php if ( $msg->is_revision_request ) echo ' · 🔄 REVISION'; ?>
                                </div>
                                <div style="white-space: pre-line; word-break: break-word;"><?php echo esc_html( $msg->message ); ?></div>
                                <?php
                                $attachments = ! empty( $msg->attachment_urls ) ? json_decode( $msg->attachment_urls, true ) : array();
                                if ( ! empty( $attachments ) && is_array( $attachments ) ) :
                                    foreach ( $attachments as $url ) :
                                ?>
                                    <div style="margin-top: 6px; font-size: 0.85rem;">📎 <a href="<?php echo esc_url( $url ); ?>" target="_blank" style="color: <?php echo $is_mine ? '#FFD700' : 'var(--nme-emerald, #10B981)'; ?>;">View attachment</a></div>
                                <?php
                                    endforeach;
                                endif;
                                ?>
                                <div style="font-size: 0.7rem; opacity: 0.6; margin-top: 4px; text-align: right;">
                                    <?php echo esc_html( human_time_diff( strtotime( $msg->created_at ), current_time( 'timestamp' ) ) ); ?> ago
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

            <form method="post" action="<?php echo esc_url( $send_form_action_url ); ?>" enctype="multipart/form-data">
                <input type="hidden" name="action" value="nmep_send_message">
                <input type="hidden" name="order_id" value="<?php echo (int) $order->id; ?>">
                <input type="hidden" name="token" value="<?php echo esc_attr( $order->view_token ); ?>">
                <input type="hidden" name="role" value="<?php echo esc_attr( $current_role ); ?>">
                <?php wp_nonce_field( 'nmep_send_message_' . $order->id ); ?>

                <p>
                    <textarea name="message" rows="3" required maxlength="5000" placeholder="Type your message..." style="width: 100%; padding: 10px; border: 1px solid var(--nme-border, #E5E7EB); border-radius: 8px;"></textarea>
                </p>
                <p>
                    <input type="url" name="attachment_url" placeholder="Optional: attachment URL (Drive, Dropbox, etc.)" style="width: 100%; padding: 8px; border: 1px solid var(--nme-border, #E5E7EB); border-radius: 8px;">
                </p>
                <p>
                    <label style="font-size:0.85rem;color:var(--nme-text-light,#6B7280);">Or upload a file:</label>
                    <input type="file" name="attachment_file" accept=".jpg,.jpeg,.png,.webp,.gif,.pdf,.doc,.docx,.xls,.xlsx,.csv,.txt,.zip" />
                </p>
                <p>
                    <button type="submit" class="nme-btn nme-btn-gold">Send Message</button>
                </p>
            </form>
        </div>
        <?php
        return ob_get_clean();
    }
}
