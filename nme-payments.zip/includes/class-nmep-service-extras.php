<?php
/**
 * NMEP_Service_Extras
 *
 * Gig add-ons (a.k.a. "extras") — paid upsells experts can attach to any
 * service (extra revision, 24h delivery, source files, HD export, etc.).
 *
 * Schema:
 *   nmep_service_extras (service-level templates — owned by the expert)
 *   nmep_order_extras   (snapshot copy attached to a paid order)
 *
 * Pricing integration:
 *   Hooks `nmep_checkout_pricing` at priority 5 (BEFORE coupon @ 10 and
 *   buyer-premium @ 20/30). Adds sum of selected extras to gross_amount
 *   and original_amount, then recomputes commission and expert split at
 *   the service's commission rate.
 *
 * Delivery impact:
 *   Each extra may bump delivery_days by `extra_delivery_days`. Applied
 *   once the order is created, via NMEP_Events::ORDER_CREATED listener,
 *   and written back to orders.delivery_days + delivery_due_at.
 *
 * @package NagalandMeExpertsPayments
 * @since   2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class NMEP_Service_Extras {

    /** @var array<int,array> Selected extras captured during checkout for the current request */
    private static $request_selection = array();

    public static function init() {
        add_filter( 'nmep_checkout_pricing', array( __CLASS__, 'apply_extras_pricing' ), 5, 5 );
        add_action( NMEP_Events::ORDER_CREATED, array( __CLASS__, 'persist_order_extras' ), 5, 2 );

        // Expert-facing management (expert dashboard form posts)
        add_action( 'admin_post_nmep_save_service_extra',   array( __CLASS__, 'handle_save' ) );
        add_action( 'admin_post_nmep_delete_service_extra', array( __CLASS__, 'handle_delete' ) );
    }

    /* ============================================================
       CRUD
       ============================================================ */

    public static function list_for_service( $service_id, $active_only = true ) {
        global $wpdb;
        $table = NMEP_Database::table( 'service_extras' );
        $sql = "SELECT * FROM $table WHERE service_id = %d";
        if ( $active_only ) $sql .= " AND is_active = 1";
        $sql .= " ORDER BY sort_order ASC, id ASC";
        return $wpdb->get_results( $wpdb->prepare( $sql, (int) $service_id ) );
    }

    public static function get( $extra_id ) {
        global $wpdb;
        return $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM " . NMEP_Database::table( 'service_extras' ) . " WHERE id = %d",
            (int) $extra_id
        ) );
    }

    public static function save( $data ) {
        global $wpdb;
        $table = NMEP_Database::table( 'service_extras' );

        $payload = array(
            'service_id'          => (int) ( $data['service_id'] ?? 0 ),
            'sort_order'          => (int) ( $data['sort_order'] ?? 0 ),
            'title'               => substr( sanitize_text_field( $data['title'] ?? '' ), 0, 120 ),
            'description'         => substr( sanitize_text_field( $data['description'] ?? '' ), 0, 400 ),
            'price'               => max( 0.0, round( (float) ( $data['price'] ?? 0 ), 2 ) ),
            'extra_delivery_days' => max( 0, (int) ( $data['extra_delivery_days'] ?? 0 ) ),
            'is_active'           => ! empty( $data['is_active'] ) ? 1 : 0,
        );

        if ( ! empty( $data['id'] ) ) {
            $wpdb->update( $table, $payload, array( 'id' => (int) $data['id'] ) );
            return (int) $data['id'];
        }
        $wpdb->insert( $table, $payload );
        return (int) $wpdb->insert_id;
    }

    public static function delete( $extra_id ) {
        global $wpdb;
        return (bool) $wpdb->delete( NMEP_Database::table( 'service_extras' ), array( 'id' => (int) $extra_id ) );
    }

    /* ============================================================
       ADMIN-POST HANDLERS (expert dashboard)
       ============================================================ */

    public static function handle_save() {
        if ( ! is_user_logged_in() ) wp_die( 'Please log in.' );
        if ( ! wp_verify_nonce( $_POST['_wpnonce'] ?? '', 'nmep_save_service_extra' ) ) {
            wp_die( 'Security check failed.' );
        }

        $service_id = (int) ( $_POST['service_id'] ?? 0 );
        $service    = $service_id ? NMEP_Services::get( $service_id ) : null;
        if ( ! $service ) wp_die( 'Service not found.' );

        $expert = NMEP_Compat::get_expert_by_user( get_current_user_id() );
        if ( ! $expert || (int) $expert->id !== (int) $service->expert_id ) {
            wp_die( 'Permission denied.' );
        }

        $id = self::save( array(
            'id'                  => (int) ( $_POST['id'] ?? 0 ),
            'service_id'          => $service_id,
            'sort_order'          => (int) ( $_POST['sort_order'] ?? 0 ),
            'title'               => $_POST['title']       ?? '',
            'description'         => $_POST['description'] ?? '',
            'price'               => $_POST['price']       ?? 0,
            'extra_delivery_days' => $_POST['extra_delivery_days'] ?? 0,
            'is_active'           => ! empty( $_POST['is_active'] ),
        ) );

        NMEP_Logger::info( 'Service extra saved', array( 'extra_id' => $id, 'service_id' => $service_id ) );

        wp_safe_redirect( add_query_arg(
            array( 'nmep_status' => 'success', 'nmep_msg' => urlencode( 'Add-on saved.' ) ),
            nmep_get_page_url( 'expert-dashboard' )
        ) . '#extras' );
        exit;
    }

    public static function handle_delete() {
        if ( ! is_user_logged_in() ) wp_die( 'Please log in.' );

        $extra_id = (int) ( $_POST['id'] ?? 0 );
        if ( ! wp_verify_nonce( $_POST['_wpnonce'] ?? '', 'nmep_delete_service_extra_' . $extra_id ) ) {
            wp_die( 'Security check failed.' );
        }

        $extra   = self::get( $extra_id );
        $service = $extra ? NMEP_Services::get( (int) $extra->service_id ) : null;
        if ( ! $extra || ! $service ) wp_die( 'Add-on not found.' );

        $expert = NMEP_Compat::get_expert_by_user( get_current_user_id() );
        if ( ! $expert || (int) $expert->id !== (int) $service->expert_id ) {
            wp_die( 'Permission denied.' );
        }

        self::delete( $extra_id );
        wp_safe_redirect( add_query_arg(
            array( 'nmep_status' => 'success', 'nmep_msg' => urlencode( 'Add-on deleted.' ) ),
            nmep_get_page_url( 'expert-dashboard' )
        ) . '#extras' );
        exit;
    }

    /* ============================================================
       CHECKOUT PRICING FILTER
       ============================================================ */

    public static function apply_extras_pricing( $pricing, $post, $service, $expert, $commission_rate ) {
        if ( ! is_array( $pricing ) || empty( $service ) ) return $pricing;

        $raw_ids = $post['extra_ids'] ?? array();
        if ( ! is_array( $raw_ids ) ) $raw_ids = array( $raw_ids );
        $ids = array_filter( array_map( 'intval', $raw_ids ) );
        if ( empty( $ids ) ) {
            self::$request_selection = array();
            return $pricing;
        }

        // Fetch only active extras that belong to this service
        global $wpdb;
        $placeholders = implode( ',', array_fill( 0, count( $ids ), '%d' ) );
        $params       = array_merge( array( (int) $service->id ), $ids );
        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM " . NMEP_Database::table( 'service_extras' ) . "
             WHERE service_id = %d AND is_active = 1 AND id IN ($placeholders)",
            $params
        ) );
        if ( empty( $rows ) ) return $pricing;

        $extras_sum   = 0.0;
        $extras_days  = 0;
        $selected     = array();
        foreach ( $rows as $row ) {
            $extras_sum  += (float) $row->price;
            $extras_days += (int) $row->extra_delivery_days;
            $selected[]   = array(
                'id'                  => (int) $row->id,
                'title'               => $row->title,
                'price'               => (float) $row->price,
                'extra_delivery_days' => (int) $row->extra_delivery_days,
            );
        }

        self::$request_selection = $selected;

        // Add extras to both gross and original price.
        $new_gross    = round( (float) $pricing['gross_amount']    + $extras_sum, 2 );
        $new_original = round( (float) $pricing['original_amount'] + $extras_sum, 2 );

        // Recompute split at the service's effective commission rate.
        $rate = (float) $commission_rate;
        $new_commission = round( $new_gross * ( $rate / 100 ), 2 );
        $new_expert     = max( 0.0, round( $new_gross - $new_commission, 2 ) );

        $pricing['gross_amount']      = $new_gross;
        $pricing['original_amount']   = $new_original;
        $pricing['commission_amount'] = $new_commission;
        $pricing['expert_amount']     = $new_expert;

        return $pricing;
    }

    /* ============================================================
       POST-ORDER PERSISTENCE
       ============================================================ */

    public static function persist_order_extras( $order_id, $order = null ) {
        if ( empty( self::$request_selection ) ) return;
        if ( ! $order ) $order = NMEP_Orders::get( $order_id );
        if ( ! $order ) return;

        global $wpdb;
        $table = NMEP_Database::table( 'order_extras' );
        $total_extra_days = 0;

        foreach ( self::$request_selection as $extra ) {
            $wpdb->insert( $table, array(
                'order_id'            => (int) $order_id,
                'extra_id'            => (int) $extra['id'],
                'title'               => substr( (string) $extra['title'], 0, 120 ),
                'price'               => (float) $extra['price'],
                'extra_delivery_days' => (int) $extra['extra_delivery_days'],
            ) );
            $total_extra_days += (int) $extra['extra_delivery_days'];
        }

        if ( $total_extra_days > 0 ) {
            $new_days = (int) $order->delivery_days + $total_extra_days;
            $update = array( 'delivery_days' => $new_days );

            if ( ! empty( $order->delivery_due_at ) ) {
                $update['delivery_due_at'] = gmdate(
                    'Y-m-d H:i:s',
                    strtotime( $order->delivery_due_at . ' UTC' ) + ( $total_extra_days * DAY_IN_SECONDS )
                );
            }
            NMEP_Orders::update( (int) $order_id, $update );
        }

        NMEP_Logger::info( 'Order extras persisted', array(
            'order_id'    => (int) $order_id,
            'count'       => count( self::$request_selection ),
            'extra_days'  => $total_extra_days,
        ) );

        // Reset for the next request in the same PHP process.
        self::$request_selection = array();
    }

    public static function get_for_order( $order_id ) {
        global $wpdb;
        return $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM " . NMEP_Database::table( 'order_extras' ) . "
             WHERE order_id = %d ORDER BY id ASC",
            (int) $order_id
        ) );
    }

    /* ============================================================
       UI: buyer-facing extras picker
       ============================================================ */

    public static function render_picker( $service_id ) {
        $extras = self::list_for_service( (int) $service_id );
        if ( empty( $extras ) ) return '';

        ob_start();
        ?>
        <div class="nme-extras-picker" style="margin: 16px 0; padding: 16px; background: var(--nme-bg-soft, #F9FAFB); border-radius: 8px;">
            <h4 style="margin-top: 0;">Boost your order with add-ons</h4>
            <?php foreach ( $extras as $extra ) : ?>
                <label style="display: flex; align-items: flex-start; gap: 10px; margin-bottom: 10px; cursor: pointer;">
                    <input type="checkbox" name="extra_ids[]" value="<?php echo (int) $extra->id; ?>" style="margin-top: 4px;">
                    <span style="flex: 1;">
                        <strong><?php echo esc_html( $extra->title ); ?></strong>
                        <span style="float: right; color: var(--nme-emerald, #10B981); font-weight: 600;">
                            + <?php echo esc_html( nmep_format_inr( $extra->price ) ); ?>
                            <?php if ( $extra->extra_delivery_days > 0 ) : ?>
                                · +<?php echo (int) $extra->extra_delivery_days; ?>d
                            <?php endif; ?>
                        </span>
                        <?php if ( ! empty( $extra->description ) ) : ?>
                            <div style="font-size: 0.85rem; color: var(--nme-text-light, #6B7280); margin-top: 2px;">
                                <?php echo esc_html( $extra->description ); ?>
                            </div>
                        <?php endif; ?>
                    </span>
                </label>
            <?php endforeach; ?>
        </div>
        <?php
        return ob_get_clean();
    }
}
