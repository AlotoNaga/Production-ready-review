<?php
/**
 * NMEP_2FA
 *
 * TOTP-based two-factor authentication (RFC 6238).
 *
 * - Works with any standard authenticator app (Google Authenticator, 1Password,
 *   Authy, Raycast, etc.).
 * - Secret is stored per user in the nmep_user_2fa table.
 * - 10 single-use backup codes generated on enrol.
 * - Verification hook runs on `wp_authenticate_user` — we challenge *before*
 *   cookie issuance so a stolen password alone doesn't sign someone in.
 *
 * Dependency-free: TOTP + QR are generated locally (QR uses a public chart
 * URL only for first-time setup; secret is base32 so it's already copyable
 * as text for users who prefer manual entry).
 *
 * @package NagalandMeExpertsPayments
 * @since   2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class NMEP_2FA {

    const ISSUER = 'Nagaland Me Experts';
    const TIME_STEP = 30;
    const DIGITS = 6;
    const WINDOW = 1; // accept one step before + after for clock drift

    public static function init() {
        // Gate login when enrolled + verified
        add_filter( 'authenticate', array( __CLASS__, 'maybe_challenge' ), 50, 3 );

        // Account page — enrol / disable / view backup codes
        add_action( 'show_user_profile', array( __CLASS__, 'render_profile_section' ) );
        add_action( 'edit_user_profile', array( __CLASS__, 'render_profile_section' ) );

        // AJAX: verify a code during enrolment
        add_action( 'wp_ajax_nmep_2fa_verify_setup', array( __CLASS__, 'ajax_verify_setup' ) );
        add_action( 'wp_ajax_nmep_2fa_disable',     array( __CLASS__, 'ajax_disable' ) );
    }

    /* ============================================================
       AUTH GATE
       ============================================================ */

    /**
     * Runs during login. If user has 2FA enabled, require a valid code via
     * the 'nmep_2fa_code' POST field, otherwise reject with a retry error.
     */
    public static function maybe_challenge( $user, $username, $password ) {
        if ( ! $user instanceof WP_User ) return $user;
        if ( is_wp_error( $user ) )       return $user;

        $row = self::get_row( $user->ID );
        if ( ! $row || ! $row->enabled ) return $user;

        $code = isset( $_POST['nmep_2fa_code'] ) ? trim( sanitize_text_field( wp_unslash( $_POST['nmep_2fa_code'] ) ) ) : '';
        if ( $code === '' ) {
            return new WP_Error( 'nmep_2fa_required',
                '<strong>2FA required.</strong> Enter the 6-digit code from your authenticator app (or a backup code).' );
        }

        if ( self::verify_code( $user->ID, $code ) ) {
            return $user;
        }

        return new WP_Error( 'nmep_2fa_invalid',
            '<strong>Invalid 2FA code.</strong> Please try again.' );
    }

    /* ============================================================
       ENROLMENT
       ============================================================ */

    public static function get_row( $user_id ) {
        global $wpdb;
        return $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM " . NMEP_Database::table( 'user_2fa' ) . " WHERE user_id = %d",
            (int) $user_id
        ) );
    }

    public static function start_setup( $user_id ) {
        $row = self::get_row( $user_id );
        if ( $row && $row->enabled ) {
            return array( 'already_enrolled' => true );
        }

        $secret = self::random_base32_secret( 20 );

        global $wpdb;
        $table = NMEP_Database::table( 'user_2fa' );
        if ( $row ) {
            $wpdb->update( $table, array( 'secret' => $secret, 'enabled' => 0 ), array( 'user_id' => (int) $user_id ) );
        } else {
            $wpdb->insert( $table, array( 'user_id' => (int) $user_id, 'secret' => $secret, 'enabled' => 0 ) );
        }

        return array(
            'secret'      => $secret,
            'otpauth_url' => self::otpauth_url( $user_id, $secret ),
        );
    }

    public static function finish_setup( $user_id, $code ) {
        $row = self::get_row( $user_id );
        if ( ! $row ) return false;
        if ( ! self::verify_totp( $row->secret, $code ) ) return false;

        $backup = self::generate_backup_codes();

        global $wpdb;
        $wpdb->update( NMEP_Database::table( 'user_2fa' ), array(
            'enabled'      => 1,
            'backup_codes' => wp_json_encode( array_map( 'wp_hash_password', $backup ) ),
            'last_used_at' => current_time( 'mysql' ),
        ), array( 'user_id' => (int) $user_id ) );

        NMEP_Compat::audit_log( 'user_2fa_enabled', 'user', $user_id, array() );
        return $backup;
    }

    public static function disable( $user_id ) {
        global $wpdb;
        $wpdb->delete( NMEP_Database::table( 'user_2fa' ), array( 'user_id' => (int) $user_id ) );
        NMEP_Compat::audit_log( 'user_2fa_disabled', 'user', $user_id, array() );
    }

    /* ============================================================
       VERIFICATION
       ============================================================ */

    public static function verify_code( $user_id, $code ) {
        $code = preg_replace( '/\s+/', '', (string) $code );
        $row  = self::get_row( $user_id );
        if ( ! $row ) return false;

        if ( strlen( $code ) === self::DIGITS && ctype_digit( $code ) ) {
            if ( self::verify_totp( $row->secret, $code ) ) {
                global $wpdb;
                $wpdb->update( NMEP_Database::table( 'user_2fa' ), array(
                    'last_used_at' => current_time( 'mysql' ),
                ), array( 'user_id' => (int) $user_id ) );
                return true;
            }
        }

        // Backup code path
        $codes = json_decode( (string) $row->backup_codes, true );
        if ( is_array( $codes ) ) {
            foreach ( $codes as $i => $hash ) {
                if ( wp_check_password( $code, $hash ) ) {
                    unset( $codes[ $i ] );
                    global $wpdb;
                    $wpdb->update( NMEP_Database::table( 'user_2fa' ), array(
                        'backup_codes' => wp_json_encode( array_values( $codes ) ),
                        'last_used_at' => current_time( 'mysql' ),
                    ), array( 'user_id' => (int) $user_id ) );
                    return true;
                }
            }
        }

        return false;
    }

    /**
     * RFC 6238 TOTP verification with ±WINDOW clock drift tolerance.
     */
    public static function verify_totp( $base32_secret, $code ) {
        $code = (string) $code;
        if ( strlen( $code ) !== self::DIGITS || ! ctype_digit( $code ) ) return false;

        $now = time();
        for ( $i = -self::WINDOW; $i <= self::WINDOW; $i++ ) {
            $t = (int) floor( ( $now + ( $i * self::TIME_STEP ) ) / self::TIME_STEP );
            if ( hash_equals( self::totp_at( $base32_secret, $t ), $code ) ) return true;
        }
        return false;
    }

    public static function totp_at( $base32_secret, $counter ) {
        $secret = self::base32_decode( $base32_secret );
        $bin    = pack( 'N*', 0 ) . pack( 'N*', $counter );
        $hmac   = hash_hmac( 'sha1', $bin, $secret, true );
        $offset = ord( $hmac[ strlen( $hmac ) - 1 ] ) & 0x0F;
        $part   = substr( $hmac, $offset, 4 );
        $value  = ( ( ord( $part[0] ) & 0x7F ) << 24 ) | ( ord( $part[1] ) << 16 ) | ( ord( $part[2] ) << 8 ) | ord( $part[3] );
        return str_pad( (string) ( $value % ( 10 ** self::DIGITS ) ), self::DIGITS, '0', STR_PAD_LEFT );
    }

    /* ============================================================
       BASE32 + SECRETS
       ============================================================ */

    public static function random_base32_secret( $length = 20 ) {
        $alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
        $bytes    = random_bytes( $length );
        $out = '';
        for ( $i = 0; $i < $length; $i++ ) {
            $out .= $alphabet[ ord( $bytes[ $i ] ) & 0x1F ];
        }
        return $out;
    }

    public static function base32_decode( $b32 ) {
        $alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
        $b32      = rtrim( strtoupper( $b32 ), '=' );
        $bits     = '';
        for ( $i = 0, $n = strlen( $b32 ); $i < $n; $i++ ) {
            $pos = strpos( $alphabet, $b32[ $i ] );
            if ( $pos === false ) continue;
            $bits .= str_pad( decbin( $pos ), 5, '0', STR_PAD_LEFT );
        }
        $out = '';
        for ( $i = 0, $n = strlen( $bits ); $i + 8 <= $n; $i += 8 ) {
            $out .= chr( bindec( substr( $bits, $i, 8 ) ) );
        }
        return $out;
    }

    public static function otpauth_url( $user_id, $secret ) {
        $user = get_user_by( 'id', $user_id );
        $label = rawurlencode( self::ISSUER . ':' . ( $user ? $user->user_email : 'user' ) );
        $issuer = rawurlencode( self::ISSUER );
        return sprintf( 'otpauth://totp/%s?secret=%s&issuer=%s&algorithm=SHA1&digits=%d&period=%d',
            $label, $secret, $issuer, self::DIGITS, self::TIME_STEP );
    }

    public static function generate_backup_codes( $count = 10 ) {
        $out = array();
        for ( $i = 0; $i < $count; $i++ ) {
            $out[] = strtolower( substr( bin2hex( random_bytes( 5 ) ), 0, 10 ) );
        }
        return $out;
    }

    /* ============================================================
       PROFILE UI
       ============================================================ */

    public static function render_profile_section( $user ) {
        if ( ! $user instanceof WP_User ) return;
        $row     = self::get_row( $user->ID );
        $enabled = $row && $row->enabled;
        ?>
        <h2>Two-Factor Authentication</h2>
        <table class="form-table"><tbody>
            <tr>
                <th>Status</th>
                <td>
                    <?php if ( $enabled ) : ?>
                        <strong style="color:#0a7558;">Enabled</strong> &middot; Last used: <?php echo $row->last_used_at ? esc_html( $row->last_used_at ) : 'never'; ?>
                        <p>
                            <button type="button" class="button" id="nmep-2fa-disable" data-user="<?php echo (int) $user->ID; ?>">Disable 2FA</button>
                        </p>
                    <?php else : ?>
                        <span style="color:#B91C1C;">Not enabled.</span>
                        <?php $setup = self::start_setup( $user->ID ); ?>
                        <?php if ( ! empty( $setup['secret'] ) ) : ?>
                            <p>Scan this code in your authenticator app, or enter the secret manually:</p>
                            <div style="font-family:monospace; font-size:18px; letter-spacing:2px; padding:8px 12px; background:#F9FAFB; border:1px solid #E5E7EB; display:inline-block;">
                                <?php echo esc_html( $setup['secret'] ); ?>
                            </div>
                            <p>Then enter the 6-digit code to confirm:
                                <input type="text" id="nmep-2fa-code" maxlength="6" style="width:80px;">
                                <button type="button" class="button button-primary" id="nmep-2fa-verify" data-user="<?php echo (int) $user->ID; ?>">Verify & Enable</button>
                            </p>
                            <div id="nmep-2fa-backup-codes" style="display:none; margin-top:12px; padding:12px; background:#FEF3C7; border:1px solid #FDE68A;">
                                <strong>Save these backup codes.</strong> Each works once if you lose your device.
                                <pre id="nmep-2fa-backup-codes-list" style="font-family:monospace;"></pre>
                            </div>
                        <?php endif; ?>
                    <?php endif; ?>
                </td>
            </tr>
        </tbody></table>
        <script>
        (function(){
            var verify = document.getElementById('nmep-2fa-verify');
            if ( verify ) verify.addEventListener('click', function(){
                var code = document.getElementById('nmep-2fa-code').value;
                var user = this.getAttribute('data-user');
                var fd = new FormData(); fd.append('action','nmep_2fa_verify_setup');
                fd.append('user_id', user); fd.append('code', code);
                fd.append('_wpnonce','<?php echo esc_js( wp_create_nonce( 'nmep_2fa' ) ); ?>');
                fetch(ajaxurl,{method:'POST',body:fd,credentials:'same-origin'})
                    .then(r=>r.json()).then(function(j){
                        if ( ! j.success ) { alert( j.data || 'Invalid code' ); return; }
                        document.getElementById('nmep-2fa-backup-codes-list').textContent = (j.data.backup_codes||[]).join('\n');
                        document.getElementById('nmep-2fa-backup-codes').style.display = 'block';
                    });
            });
            var disable = document.getElementById('nmep-2fa-disable');
            if ( disable ) disable.addEventListener('click', function(){
                if (!confirm('Disable 2FA?')) return;
                var user = this.getAttribute('data-user');
                var fd = new FormData(); fd.append('action','nmep_2fa_disable');
                fd.append('user_id', user);
                fd.append('_wpnonce','<?php echo esc_js( wp_create_nonce( 'nmep_2fa' ) ); ?>');
                fetch(ajaxurl,{method:'POST',body:fd,credentials:'same-origin'})
                    .then(r=>r.json()).then(function(){ location.reload(); });
            });
        })();
        </script>
        <?php
    }

    /* ============================================================
       AJAX
       ============================================================ */

    public static function ajax_verify_setup() {
        check_ajax_referer( 'nmep_2fa' );
        $user_id = (int) ( $_POST['user_id'] ?? 0 );
        if ( ! current_user_can( 'edit_user', $user_id ) ) wp_send_json_error( 'forbidden' );

        $code   = sanitize_text_field( wp_unslash( $_POST['code'] ?? '' ) );
        $backup = self::finish_setup( $user_id, $code );
        if ( ! $backup ) wp_send_json_error( 'Invalid code' );
        wp_send_json_success( array( 'backup_codes' => $backup ) );
    }

    public static function ajax_disable() {
        check_ajax_referer( 'nmep_2fa' );
        $user_id = (int) ( $_POST['user_id'] ?? 0 );
        if ( ! current_user_can( 'edit_user', $user_id ) ) wp_send_json_error( 'forbidden' );
        self::disable( $user_id );
        wp_send_json_success();
    }
}
