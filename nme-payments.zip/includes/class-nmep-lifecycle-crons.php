<?php
/**
 * NMEP_Lifecycle_Crons
 *
 * Background jobs that drive the order lifecycle:
 *   - Delivery-due reminders       (T-24h + overdue)
 *   - Revision-due reminders       (T-24h + overdue)
 *   - Auto-cancel stale unpaid     (initiated >30 min)
 *   - Dispute auto-escalation      (72h SLA)
 *
 * Invariants:
 *   - Each job is idempotent per order (guarded by short-lived postmeta-like options).
 *   - All jobs bounded by LIMIT to avoid runaway loops on large tables.
 *   - Every job logs a single summary line.
 *
 * @package NagalandMeExpertsPayments
 * @since   2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class NMEP_Lifecycle_Crons {

    const HOOK_DELIVERY_REMINDERS = 'nmep_cron_delivery_reminders';
    const HOOK_REVISION_REMINDERS = 'nmep_cron_revision_reminders';
    const HOOK_AUTO_CANCEL_STALE  = 'nmep_cron_auto_cancel_stale';
    const HOOK_DISPUTE_SLA        = 'nmep_cron_dispute_sla';

    /** Unpaid orders older than this are auto-cancelled. */
    const STALE_UNPAID_MINUTES = 60;

    /** How many orders to process per cron tick. */
    const BATCH_LIMIT = 50;

    public static function init() {
        add_action( self::HOOK_DELIVERY_REMINDERS, array( __CLASS__, 'run_delivery_reminders' ) );
        add_action( self::HOOK_REVISION_REMINDERS, array( __CLASS__, 'run_revision_reminders' ) );
        add_action( self::HOOK_AUTO_CANCEL_STALE,  array( __CLASS__, 'run_auto_cancel_stale' ) );
        add_action( self::HOOK_DISPUTE_SLA,        array( __CLASS__, 'run_dispute_sla' ) );
    }

    public static function schedule() {
        $now = time();
        if ( ! wp_next_scheduled( self::HOOK_DELIVERY_REMINDERS ) ) wp_schedule_event( $now, 'hourly',     self::HOOK_DELIVERY_REMINDERS );
        if ( ! wp_next_scheduled( self::HOOK_REVISION_REMINDERS ) ) wp_schedule_event( $now, 'hourly',     self::HOOK_REVISION_REMINDERS );
        if ( ! wp_next_scheduled( self::HOOK_AUTO_CANCEL_STALE ) )  wp_schedule_event( $now, 'hourly',     self::HOOK_AUTO_CANCEL_STALE );
        if ( ! wp_next_scheduled( self::HOOK_DISPUTE_SLA ) )        wp_schedule_event( $now, 'hourly',     self::HOOK_DISPUTE_SLA );
    }

    public static function unschedule() {
        wp_clear_scheduled_hook( self::HOOK_DELIVERY_REMINDERS );
        wp_clear_scheduled_hook( self::HOOK_REVISION_REMINDERS );
        wp_clear_scheduled_hook( self::HOOK_AUTO_CANCEL_STALE );
        wp_clear_scheduled_hook( self::HOOK_DISPUTE_SLA );
    }

    /* ============================================================
       DELIVERY REMINDERS
       ============================================================ */

    /**
     * Email the expert when delivery is approaching or past due.
     * Sends at most TWO reminders per order:
     *   - 24h before delivery_due_at   (flag: delivery_soon)
     *   - On or after delivery_due_at  (flag: delivery_overdue)
     */
    public static function run_delivery_reminders() {
        global $wpdb;
        $orders_table = NMEP_Database::table( 'orders' );

        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT id, expert_id, buyer_email, buyer_name, order_number, service_title,
                    delivery_due_at, delivery_days
             FROM $orders_table
             WHERE status IN ('paid','in_progress','revision')
               AND delivery_due_at IS NOT NULL
               AND delivery_due_at <= DATE_ADD(UTC_TIMESTAMP(), INTERVAL 24 HOUR)
             LIMIT %d",
            self::BATCH_LIMIT
        ) );

        $sent = 0;
        foreach ( $rows as $o ) {
            $due_ts = strtotime( $o->delivery_due_at . ' UTC' );
            $is_overdue = $due_ts <= time();
            $flag = $is_overdue ? 'delivery_overdue' : 'delivery_soon';

            if ( self::already_reminded( $o->id, $flag ) ) continue;

            if ( class_exists( 'NMEP_Emails' ) && method_exists( 'NMEP_Emails', 'send_delivery_reminder' ) ) {
                NMEP_Emails::send_delivery_reminder( $o, $is_overdue );
            }
            if ( class_exists( 'NMEP_MSG91' ) && $is_overdue ) {
                NMEP_MSG91::notify_expert_delivery_overdue( (int) $o->expert_id, $o->order_number );
            }

            self::mark_reminded( $o->id, $flag );
            $sent++;
        }

        NMEP_Logger::info( 'Delivery-reminders cron complete', array( 'checked' => count( $rows ), 'sent' => $sent ) );
    }

    /* ============================================================
       REVISION REMINDERS (expert side)
       ============================================================ */

    public static function run_revision_reminders() {
        global $wpdb;
        $orders_table = NMEP_Database::table( 'orders' );

        // Revision requested >48h ago and no new delivery yet.
        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT id, expert_id, order_number, updated_at
             FROM $orders_table
             WHERE status = 'revision'
               AND updated_at <= DATE_SUB(UTC_TIMESTAMP(), INTERVAL 48 HOUR)
             LIMIT %d",
            self::BATCH_LIMIT
        ) );

        $sent = 0;
        foreach ( $rows as $o ) {
            if ( self::already_reminded( $o->id, 'revision_overdue' ) ) continue;

            if ( class_exists( 'NMEP_Emails' ) && method_exists( 'NMEP_Emails', 'send_revision_overdue_reminder' ) ) {
                NMEP_Emails::send_revision_overdue_reminder( $o );
            }
            self::mark_reminded( $o->id, 'revision_overdue' );
            $sent++;
        }

        NMEP_Logger::info( 'Revision-reminders cron complete', array( 'checked' => count( $rows ), 'sent' => $sent ) );
    }

    /* ============================================================
       AUTO-CANCEL STALE UNPAID
       ============================================================ */

    public static function run_auto_cancel_stale() {
        global $wpdb;
        $orders_table = NMEP_Database::table( 'orders' );

        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT id FROM $orders_table
             WHERE status = 'initiated'
               AND payment_status IN ('pending','failed')
               AND created_at <= DATE_SUB(UTC_TIMESTAMP(), INTERVAL %d MINUTE)
             LIMIT %d",
            self::STALE_UNPAID_MINUTES,
            self::BATCH_LIMIT
        ) );

        $cancelled = 0;
        foreach ( $rows as $r ) {
            if ( NMEP_Orders::cancel( (int) $r->id, 'stale_unpaid_auto_cancel', 0 ) ) {
                $cancelled++;
            }
        }

        NMEP_Logger::info( 'Auto-cancel-stale cron complete', array( 'checked' => count( $rows ), 'cancelled' => $cancelled ) );
    }

    /* ============================================================
       DISPUTE SLA — 72 HOUR AUTO-ESCALATION
       ============================================================ */

    public static function run_dispute_sla() {
        if ( ! class_exists( 'NMEP_Dispute_SLA' ) ) return;
        NMEP_Dispute_SLA::auto_escalate_overdue();
    }

    /* ============================================================
       HELPERS — reminder idempotency (stored as options with TTL)
       ============================================================ */

    private static function already_reminded( $order_id, $flag ) {
        return (bool) get_transient( self::reminder_key( $order_id, $flag ) );
    }

    private static function mark_reminded( $order_id, $flag ) {
        set_transient( self::reminder_key( $order_id, $flag ), 1, 14 * DAY_IN_SECONDS );
    }

    private static function reminder_key( $order_id, $flag ) {
        return 'nmep_reminder_' . sanitize_key( $flag ) . '_' . (int) $order_id;
    }
}
