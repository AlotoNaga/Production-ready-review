<?php
/**
 * NMEP_Reviews
 * Buyer reviews & ratings system. Buyers can review expert after order completion.
 * Updates service avg_rating and reviews_count automatically.
 *
 * @version 1.4.0 (Batch E)
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class NMEP_Reviews {

    public static function init() {
        add_action( 'admin_post_nopriv_nmep_submit_review', array( __CLASS__, 'handle_submit_review' ) );
        add_action( 'admin_post_nmep_submit_review',         array( __CLASS__, 'handle_submit_review' ) );

        // Hook into order completion to remind buyer
        add_action( 'nmep_escrow_released', array( __CLASS__, 'send_review_reminder' ), 20, 1 );
    }

    /* ============================================================
       SUBMIT REVIEW
       ============================================================ */

    public static function handle_submit_review() {
        $order_id = isset( $_POST['order_id'] ) ? (int) $_POST['order_id'] : 0;
        $token    = sanitize_text_field( $_POST['token'] ?? '' );

        if ( ! wp_verify_nonce( $_POST['_wpnonce'] ?? '', 'nmep_review_' . $order_id ) ) {
            wp_die( 'Security check failed.' );
        }

        $order = NMEP_Orders::get( $order_id );
        if ( ! $order || $order->view_token !== $token ) {
            wp_die( 'Permission denied.' );
        }

        // Order must be completed
        if ( ! in_array( $order->status, array( NMEP_Orders::STATUS_COMPLETED, NMEP_Orders::STATUS_AUTO_RELEASED ), true ) ) {
            self::redirect_to_track_with_error( $order, 'You can only review completed orders.' );
            return;
        }

        // Check if review already exists for this order
        if ( self::exists_for_order( $order_id ) ) {
            self::redirect_to_track_with_error( $order, 'You have already reviewed this order.' );
            return;
        }

        $rating = (int) ( $_POST['rating'] ?? 0 );
        $comment = sanitize_textarea_field( $_POST['comment'] ?? '' );
        $would_recommend = ! empty( $_POST['would_recommend'] ) ? 1 : 0;

        // Validate
        if ( $rating < 1 || $rating > 5 ) {
            self::redirect_to_track_with_error( $order, 'Please select a rating between 1 and 5 stars.' );
            return;
        }
        if ( strlen( $comment ) < 10 ) {
            self::redirect_to_track_with_error( $order, 'Please write a review of at least 10 characters.' );
            return;
        }
        if ( strlen( $comment ) > 2000 ) {
            self::redirect_to_track_with_error( $order, 'Review must be under 2000 characters.' );
            return;
        }

        global $wpdb;
        $reviews_table = NMEP_Database::table( 'reviews' );

        $result = $wpdb->insert( $reviews_table, array(
            'order_id'        => $order_id,
            'service_id'      => (int) $order->service_id,
            'expert_id'       => (int) $order->expert_id,
            'buyer_user_id'   => (int) ( $order->buyer_user_id ?: 0 ),
            'buyer_name'      => $order->buyer_name,
            'buyer_email'     => $order->buyer_email,
            'rating'          => $rating,
            'comment'         => $comment,
            'would_recommend' => $would_recommend,
            'status'          => 'published',
        ) );

        if ( ! $result ) {
            NMEP_Logger::error( 'Failed to insert review', array( 'order_id' => $order_id, 'error' => $wpdb->last_error ) );
            self::redirect_to_track_with_error( $order, 'Could not save review. Please try again.' );
            return;
        }

        $review_id = (int) $wpdb->insert_id;

        // Update service stats
        self::recalculate_service_stats( $order->service_id );

        // Update expert stats (if base plugin tracks them)
        self::recalculate_expert_stats( $order->expert_id );

        NMEP_Logger::info( 'Review submitted', array(
            'review_id' => $review_id,
            'order_id'  => $order_id,
            'rating'    => $rating,
        ) );

        NMEP_Compat::audit_log( 'review_submitted', 'order', $order_id, array(
            'rating'    => $rating,
            'review_id' => $review_id,
        ) );

        // Notify expert of new review
        if ( class_exists( 'NMEP_Emails' ) ) {
            NMEP_Emails::send_new_review_to_expert( $order, $rating, $comment );
        }

        do_action( 'nmep_review_submitted', $review_id, $order_id );

        $url = add_query_arg( array(
            'order'       => $order->order_number,
            'token'       => $order->view_token,
            'nmep_status' => 'success',
            'nmep_msg'    => urlencode( '🌟 Thank you for your review! It helps the expert and other buyers.' ),
        ), nmep_get_page_url( 'order-track' ) );
        wp_safe_redirect( $url );
        exit;
    }

    /* ============================================================
       STAT RECALCULATION
       ============================================================ */

    /**
     * Recalculate service avg_rating and reviews_count
     */
    public static function recalculate_service_stats( $service_id ) {
        global $wpdb;
        $reviews_table = NMEP_Database::table( 'reviews' );
        $services_table = NMEP_Database::table( 'services' );

        $stats = $wpdb->get_row( $wpdb->prepare(
            "SELECT COUNT(*) AS reviews_count, AVG(rating) AS avg_rating
             FROM $reviews_table
             WHERE service_id = %d AND status = 'published'",
            (int) $service_id
        ) );

        if ( ! $stats ) return;

        $wpdb->update( $services_table, array(
            'avg_rating'    => (float) $stats->avg_rating,
            'reviews_count' => (int) $stats->reviews_count,
        ), array( 'id' => (int) $service_id ) );
    }

    /**
     * Recalculate expert-level stats (if base plugin has those fields)
     */
    public static function recalculate_expert_stats( $expert_id ) {
        global $wpdb;
        $reviews_table = NMEP_Database::table( 'reviews' );
        $experts_table = NMEP_Compat::base_table( 'experts' );

        $stats = $wpdb->get_row( $wpdb->prepare(
            "SELECT COUNT(*) AS total_reviews, AVG(rating) AS avg_rating
             FROM $reviews_table
             WHERE expert_id = %d AND status = 'published'",
            (int) $expert_id
        ) );

        if ( ! $stats ) return;

        // Check if experts table has avg_rating column before updating
        $has_avg = $wpdb->get_results( "SHOW COLUMNS FROM $experts_table LIKE 'avg_rating'" );
        if ( ! empty( $has_avg ) ) {
            $wpdb->update( $experts_table, array(
                'avg_rating'    => (float) $stats->avg_rating,
                'total_reviews' => (int) $stats->total_reviews,
            ), array( 'id' => (int) $expert_id ) );
        }
    }

    /* ============================================================
       REVIEW REMINDER (sent X days after order completion)
       ============================================================ */

    public static function send_review_reminder( $order_id ) {
        // Schedule a reminder email 1 day after release (only if no review yet)
        wp_schedule_single_event( time() + DAY_IN_SECONDS, 'nmep_review_reminder_async', array( $order_id ) );
    }

    /* ============================================================
       QUERIES
       ============================================================ */

    public static function exists_for_order( $order_id ) {
        global $wpdb;
        return (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM " . NMEP_Database::table( 'reviews' ) . " WHERE order_id = %d",
            (int) $order_id
        ) ) > 0;
    }

    public static function get_for_order( $order_id ) {
        global $wpdb;
        return $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM " . NMEP_Database::table( 'reviews' ) . " WHERE order_id = %d LIMIT 1",
            (int) $order_id
        ) );
    }

    public static function get_for_service( $service_id, $limit = 20 ) {
        global $wpdb;
        return $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM " . NMEP_Database::table( 'reviews' ) . "
             WHERE service_id = %d AND status = 'published'
             ORDER BY created_at DESC LIMIT %d",
            (int) $service_id, (int) $limit
        ) );
    }

    public static function get_for_expert( $expert_id, $limit = 20 ) {
        global $wpdb;
        return $wpdb->get_results( $wpdb->prepare(
            "SELECT r.*, s.title AS service_title, s.slug AS service_slug
             FROM " . NMEP_Database::table( 'reviews' ) . " r
             LEFT JOIN " . NMEP_Database::table( 'services' ) . " s ON s.id = r.service_id
             WHERE r.expert_id = %d AND r.status = 'published'
             ORDER BY r.created_at DESC LIMIT %d",
            (int) $expert_id, (int) $limit
        ) );
    }

    /* ============================================================
       UI HELPER — render stars
       ============================================================ */

    public static function render_stars( $rating, $size = 16 ) {
        $rating = (float) $rating;
        $full = floor( $rating );
        $half = ( $rating - $full ) >= 0.5 ? 1 : 0;
        $empty = 5 - $full - $half;

        $html = '<span style="color:#F59E0B;font-size:' . (int) $size . 'px;display:inline-block;letter-spacing:1px;">';
        for ( $i = 0; $i < $full; $i++ ) $html .= '★';
        if ( $half ) $html .= '⯨';
        for ( $i = 0; $i < $empty; $i++ ) $html .= '<span style="color:#E5E7EB;">★</span>';
        $html .= '</span>';
        return $html;
    }

    private static function redirect_to_track_with_error( $order, $message ) {
        $url = add_query_arg( array(
            'order'       => $order->order_number,
            'token'       => $order->view_token,
            'nmep_status' => 'error',
            'nmep_msg'    => urlencode( $message ),
        ), nmep_get_page_url( 'order-track' ) );
        wp_safe_redirect( $url );
        exit;
    }
}

// Async hook for review reminder
add_action( 'nmep_review_reminder_async', function( $order_id ) {
    $order = NMEP_Orders::get( $order_id );
    if ( ! $order ) return;
    if ( NMEP_Reviews::exists_for_order( $order_id ) ) return; // already reviewed

    if ( class_exists( 'NMEP_Emails' ) && method_exists( 'NMEP_Emails', 'send_review_reminder' ) ) {
        NMEP_Emails::send_review_reminder( $order );
    }
}, 10, 1 );
