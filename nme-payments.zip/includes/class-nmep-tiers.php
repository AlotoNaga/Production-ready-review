<?php
/**
 * NMEP_Tiers
 *
 * Expert tier system (New / Level 1 / Level 2 / Top Rated).
 *
 * Tiers promote and demote automatically every day based on 60-day rolling
 * metrics. Admins can also manually lock a tier (expert_metrics.tier_locked=1),
 * which halts automatic movement for that expert.
 *
 * Promotion criteria (sensible defaults — tune in settings):
 *   Level 1:
 *     - >= 5 completed orders
 *     - >= 4.5 avg rating
 *     - <= 5% cancellation rate
 *     - 60-day account age
 *   Level 2:
 *     - >= 25 completed orders
 *     - >= 4.7 avg rating
 *     - <= 3% cancellation rate
 *     - <= 2 disputes lost
 *     - 120-day account age
 *   Top Rated (curated — auto-eligibility only):
 *     - >= 50 completed orders
 *     - >= 4.8 avg rating
 *     - <= 2% cancellation rate
 *     - 0 disputes lost in last 60 days
 *     - 180-day account age
 *
 * Demotion: an expert slips one tier down when they fall below the *current*
 * tier's floor for >30 consecutive days.
 *
 * Fires NMEP_Events::EXPERT_TIER_CHANGED on movement. Subscribers: badges
 * plugin (awards badges), emails (congrats/demotion notice).
 *
 * @package NagalandMeExpertsPayments
 * @since   2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class NMEP_Tiers {

    const TIER_NEW       = 'new';
    const TIER_LEVEL_1   = 'level_1';
    const TIER_LEVEL_2   = 'level_2';
    const TIER_TOP_RATED = 'top_rated';

    const CRON_HOOK = 'nmep_tiers_recompute';

    public static function init() {
        add_action( self::CRON_HOOK, array( __CLASS__, 'recompute_all' ) );
        // Congrats email on promotion
        add_action( NMEP_Events::EXPERT_TIER_CHANGED, array( __CLASS__, 'on_tier_changed' ), 10, 4 );

        if ( ! wp_next_scheduled( self::CRON_HOOK ) ) {
            wp_schedule_event( time() + 3600, 'daily', self::CRON_HOOK );
        }
    }

    /* ============================================================
       LABELS + ORDER
       ============================================================ */

    public static function label( $tier ) {
        return array(
            self::TIER_NEW       => 'New Expert',
            self::TIER_LEVEL_1   => 'Level 1',
            self::TIER_LEVEL_2   => 'Level 2',
            self::TIER_TOP_RATED => 'Top Rated',
        )[ $tier ] ?? $tier;
    }

    private static function rank( $tier ) {
        return array(
            self::TIER_NEW       => 0,
            self::TIER_LEVEL_1   => 1,
            self::TIER_LEVEL_2   => 2,
            self::TIER_TOP_RATED => 3,
        )[ $tier ] ?? 0;
    }

    /* ============================================================
       RECOMPUTE JOB
       ============================================================ */

    public static function recompute_all() {
        global $wpdb;

        // Experts with at least one order are candidates (new experts with zero orders
        // stay at 'new'). Pulls distinct expert_ids from orders table.
        $expert_ids = $wpdb->get_col(
            "SELECT DISTINCT expert_id FROM " . NMEP_Database::table( 'orders' )
        );

        $changed = 0;
        foreach ( $expert_ids as $expert_id ) {
            if ( self::recompute_for( (int) $expert_id ) ) $changed++;
        }

        NMEP_Logger::info( 'Tiers recomputed', array( 'candidates' => count( $expert_ids ), 'changed' => $changed ) );
    }

    public static function recompute_for( $expert_id ) {
        global $wpdb;
        $metrics_t = NMEP_Database::table( 'expert_metrics' );

        $current = $wpdb->get_row( $wpdb->prepare(
            "SELECT current_tier, tier_locked FROM $metrics_t WHERE expert_id = %d",
            $expert_id
        ) );
        if ( $current && (int) $current->tier_locked === 1 ) return false;

        $current_tier = $current->current_tier ?? self::TIER_NEW;
        $new_tier     = self::evaluate_tier_for( $expert_id );

        if ( $new_tier === $current_tier ) return false;

        // Upsert metrics row
        if ( $current ) {
            $wpdb->update( $metrics_t, array( 'current_tier' => $new_tier ), array( 'expert_id' => $expert_id ) );
        } else {
            $wpdb->insert( $metrics_t, array( 'expert_id' => $expert_id, 'current_tier' => $new_tier ) );
        }

        // Record history
        $wpdb->insert( NMEP_Database::table( 'expert_tier_history' ), array(
            'expert_id' => $expert_id,
            'from_tier' => $current_tier,
            'to_tier'   => $new_tier,
            'reason'    => 'automatic_recompute',
            'changed_by'=> 0,
        ) );

        NMEP_Events::emit( NMEP_Events::EXPERT_TIER_CHANGED, $expert_id, $current_tier, $new_tier, 'automatic' );
        return true;
    }

    /**
     * Evaluate the correct tier for an expert based on 60-day rolling stats.
     */
    public static function evaluate_tier_for( $expert_id ) {
        global $wpdb;
        $orders_t = NMEP_Database::table( 'orders' );

        $stats = $wpdb->get_row( $wpdb->prepare(
            "SELECT
                COUNT(*) AS total,
                SUM(CASE WHEN status IN ('completed','auto_released') THEN 1 ELSE 0 END) AS completed,
                SUM(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END) AS cancelled,
                SUM(CASE WHEN status = 'disputed'  THEN 1 ELSE 0 END) AS disputed,
                MIN(created_at) AS first_order_at
             FROM $orders_t
             WHERE expert_id = %d",
            $expert_id
        ), ARRAY_A );

        $avg_rating = (float) $wpdb->get_var( $wpdb->prepare(
            "SELECT AVG(rating) FROM " . NMEP_Database::table( 'reviews' ) . "
             WHERE expert_id = %d AND status = 'published'",
            $expert_id
        ) );

        $completed  = (int) ( $stats['completed'] ?? 0 );
        $total      = (int) ( $stats['total'] ?? 0 );
        $cancel_pct = $total ? ( (int) $stats['cancelled'] / $total ) * 100 : 0;
        $disputed   = (int) ( $stats['disputed'] ?? 0 );
        $account_age_days = $stats['first_order_at']
            ? (int) ( ( time() - strtotime( $stats['first_order_at'] ) ) / 86400 )
            : 0;

        // Top Rated (most stringent first)
        if ( $completed >= 50 && $avg_rating >= 4.8 && $cancel_pct <= 2 && $disputed === 0 && $account_age_days >= 180 ) {
            return self::TIER_TOP_RATED;
        }
        if ( $completed >= 25 && $avg_rating >= 4.7 && $cancel_pct <= 3 && $disputed <= 2 && $account_age_days >= 120 ) {
            return self::TIER_LEVEL_2;
        }
        if ( $completed >= 5 && $avg_rating >= 4.5 && $cancel_pct <= 5 && $account_age_days >= 60 ) {
            return self::TIER_LEVEL_1;
        }
        return self::TIER_NEW;
    }

    /* ============================================================
       ADMIN MANUAL OVERRIDE
       ============================================================ */

    public static function set_manual( $expert_id, $tier, $lock = true, $actor_id = 0 ) {
        global $wpdb;
        $metrics_t = NMEP_Database::table( 'expert_metrics' );

        $current = $wpdb->get_row( $wpdb->prepare(
            "SELECT current_tier FROM $metrics_t WHERE expert_id = %d", $expert_id
        ) );
        $from = $current->current_tier ?? self::TIER_NEW;

        $data = array( 'current_tier' => $tier, 'tier_locked' => $lock ? 1 : 0 );
        if ( $current ) {
            $wpdb->update( $metrics_t, $data, array( 'expert_id' => $expert_id ) );
        } else {
            $wpdb->insert( $metrics_t, array_merge( array( 'expert_id' => $expert_id ), $data ) );
        }

        $wpdb->insert( NMEP_Database::table( 'expert_tier_history' ), array(
            'expert_id' => $expert_id,
            'from_tier' => $from,
            'to_tier'   => $tier,
            'reason'    => 'manual_admin_override',
            'changed_by'=> (int) $actor_id,
        ) );

        NMEP_Events::emit( NMEP_Events::EXPERT_TIER_CHANGED, $expert_id, $from, $tier, 'manual' );
    }

    /* ============================================================
       READ HELPERS
       ============================================================ */

    public static function get_tier( $expert_id ) {
        global $wpdb;
        $tier = $wpdb->get_var( $wpdb->prepare(
            "SELECT current_tier FROM " . NMEP_Database::table( 'expert_metrics' ) . " WHERE expert_id = %d",
            $expert_id
        ) );
        return $tier ?: self::TIER_NEW;
    }

    /**
     * Perks for each tier — used by services / search / dashboard UIs.
     */
    public static function perks( $tier ) {
        $perks = array(
            self::TIER_NEW       => array( 'max_active_services' => 5,  'priority_support' => false, 'featured_boost' => 0 ),
            self::TIER_LEVEL_1   => array( 'max_active_services' => 10, 'priority_support' => false, 'featured_boost' => 5 ),
            self::TIER_LEVEL_2   => array( 'max_active_services' => 20, 'priority_support' => true,  'featured_boost' => 15 ),
            self::TIER_TOP_RATED => array( 'max_active_services' => 30, 'priority_support' => true,  'featured_boost' => 30 ),
        );
        return $perks[ $tier ] ?? $perks[ self::TIER_NEW ];
    }

    /* ============================================================
       LISTENERS
       ============================================================ */

    public static function on_tier_changed( $expert_id, $from_tier, $to_tier, $source = 'automatic' ) {
        if ( self::rank( $to_tier ) > self::rank( $from_tier ) ) {
            // Promotion
            if ( class_exists( 'NMEP_Emails' ) && method_exists( 'NMEP_Emails', 'send_tier_promotion' ) ) {
                NMEP_Emails::send_tier_promotion( $expert_id, $from_tier, $to_tier );
            }
            NMEP_Logger::info( 'Expert tier promotion', compact( 'expert_id', 'from_tier', 'to_tier', 'source' ) );
        } else {
            NMEP_Logger::info( 'Expert tier demotion', compact( 'expert_id', 'from_tier', 'to_tier', 'source' ) );
        }
    }
}
