<?php
namespace RankMath\Sitemap\Providers;

/**
 * NMEP Sitemap Providers — Properly namespaced for Rank Math
 *
 * Two custom sitemaps registered with Rank Math:
 * - service-sitemap.xml — all active services (with images)
 * - expert-sitemap.xml — all approved experts (with profile photos)
 *
 * @version 1.5.2 (Batch F hotfix 2)
 */

defined( 'ABSPATH' ) || exit;

// Only define classes if Rank Math's Provider interface exists
if ( ! interface_exists( '\\RankMath\\Sitemap\\Providers\\Provider' ) ) {
    return;
}

/* ============================================================
   SERVICE SITEMAP PROVIDER
   ============================================================ */
class NMEP_Service_Sitemap implements Provider {

    public function handles_type( $type ) {
        return 'service' === $type;
    }

    public function get_index_links( $max_entries ) {
        global $wpdb;
        $table = \NMEP_Database::table( 'services' );

        $count = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $table WHERE status = 'active'" );
        if ( $count === 0 ) return array();

        $last_modified = $wpdb->get_var( "SELECT MAX(updated_at) FROM $table WHERE status = 'active'" );
        if ( ! $last_modified ) $last_modified = current_time( 'mysql' );

        $pages = (int) ceil( $count / $max_entries );
        $links = array();

        for ( $i = 0; $i < $pages; $i++ ) {
            $page_num = $i === 0 ? '' : ( $i + 1 );
            $links[] = array(
                'loc'     => \RankMath\Sitemap\Router::get_base_url( "service-sitemap{$page_num}.xml" ),
                'lastmod' => $last_modified,
            );
        }
        return $links;
    }

    public function get_sitemap_links( $type, $max_entries, $current_page ) {
        global $wpdb;
        $table = \NMEP_Database::table( 'services' );

        $offset = ( $current_page - 1 ) * $max_entries;

        $services = $wpdb->get_results( $wpdb->prepare(
            "SELECT slug, updated_at, cover_image, title FROM $table
             WHERE status = 'active'
             ORDER BY updated_at DESC LIMIT %d OFFSET %d",
            $max_entries, $offset
        ) );

        $links = array();
        foreach ( $services as $svc ) {
            $entry = array(
                'loc'    => home_url( '/service/' . $svc->slug . '/' ),
                'mod'    => $svc->updated_at,
                'images' => array(),
            );
            if ( ! empty( $svc->cover_image ) ) {
                $entry['images'][] = array(
                    'src'   => $svc->cover_image,
                    'title' => $svc->title,
                );
            }
            $links[] = $entry;
        }
        return $links;
    }
}

/* ============================================================
   EXPERT SITEMAP PROVIDER
   ============================================================ */
class NMEP_Expert_Sitemap implements Provider {

    public function handles_type( $type ) {
        return 'expert' === $type;
    }

    public function get_index_links( $max_entries ) {
        global $wpdb;
        $table = \NMEP_Compat::base_table( 'experts' );

        $count = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $table WHERE status = 'approved'" );
        if ( $count === 0 ) return array();

        $last_modified = $wpdb->get_var( "SELECT MAX(updated_at) FROM $table WHERE status = 'approved'" );
        if ( ! $last_modified ) $last_modified = current_time( 'mysql' );

        $pages = (int) ceil( $count / $max_entries );
        $links = array();

        for ( $i = 0; $i < $pages; $i++ ) {
            $page_num = $i === 0 ? '' : ( $i + 1 );
            $links[] = array(
                'loc'     => \RankMath\Sitemap\Router::get_base_url( "expert-sitemap{$page_num}.xml" ),
                'lastmod' => $last_modified,
            );
        }
        return $links;
    }

    public function get_sitemap_links( $type, $max_entries, $current_page ) {
        global $wpdb;
        $table = \NMEP_Compat::base_table( 'experts' );

        $offset = ( $current_page - 1 ) * $max_entries;

        $experts = $wpdb->get_results( $wpdb->prepare(
            "SELECT full_name, updated_at, profile_photo FROM $table
             WHERE status = 'approved'
             ORDER BY updated_at DESC LIMIT %d OFFSET %d",
            $max_entries, $offset
        ) );

        $links = array();
        foreach ( $experts as $expert ) {
            $entry = array(
                'loc'    => home_url( '/expert/' . sanitize_title( $expert->full_name ) . '/' ),
                'mod'    => $expert->updated_at,
                'images' => array(),
            );
            if ( ! empty( $expert->profile_photo ) ) {
                $entry['images'][] = array(
                    'src'   => $expert->profile_photo,
                    'title' => $expert->full_name,
                );
            }
            $links[] = $entry;
        }
        return $links;
    }
}
