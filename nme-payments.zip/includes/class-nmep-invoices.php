<?php
/**
 * NMEP_Invoices
 *
 * Platform-issued tax invoices.
 *
 * Only the platform has a GSTIN — experts do not. Each order that is paid
 * generates exactly one tax invoice issued by the platform (business_name /
 * gst_number in settings) to the buyer. Tax treatment follows the GST
 * place-of-supply rules:
 *
 *   - Buyer state == platform state  →  CGST + SGST (each at half the rate)
 *   - Buyer state != platform state  →  IGST (at the full rate)
 *
 * The invoice number uses a per-financial-year counter:
 *   PREFIX/FY/SEQ  e.g. NME/2526/0001
 *
 * Rendering is HTML; buyers click "Download PDF" which triggers
 * window.print() to save as PDF (no heavy PDF library dependency — keeps
 * the plugin small and avoids composer requirements).
 *
 * @package NagalandMeExpertsPayments
 * @since   2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class NMEP_Invoices {

    public static function init() {
        add_action( NMEP_Events::ORDER_PAID, array( __CLASS__, 'on_order_paid' ), 10, 2 );

        // Public invoice view (token-gated — no login required)
        add_action( 'init', array( __CLASS__, 'register_rewrite' ) );
        add_action( 'template_redirect', array( __CLASS__, 'maybe_render_invoice' ) );
    }

    public static function register_rewrite() {
        add_rewrite_rule( '^nmep-invoice/([^/]+)/?$', 'index.php?nmep_invoice_token=$matches[1]', 'top' );
        add_rewrite_tag( '%nmep_invoice_token%', '([^&]+)' );
    }

    public static function maybe_render_invoice() {
        $token = get_query_var( 'nmep_invoice_token' );
        if ( ! $token ) return;

        $token = sanitize_text_field( $token );
        list( $order_id, $hash ) = array_pad( explode( '-', $token, 2 ), 2, '' );
        $order = NMEP_Orders::get( (int) $order_id );
        if ( ! $order ) return;

        $expected = hash_hmac( 'sha256', 'invoice:' . $order->id, wp_salt( 'auth' ) );
        if ( ! hash_equals( substr( $expected, 0, 32 ), (string) $hash ) ) {
            status_header( 403 );
            wp_die( 'Invalid invoice link.' );
        }

        $invoice = self::get_for_order( $order->id );
        if ( ! $invoice ) {
            status_header( 404 );
            wp_die( 'Invoice not yet generated.' );
        }

        self::render_html( $invoice, $order );
        exit;
    }

    /* ============================================================
       EVENT LISTENERS
       ============================================================ */

    /**
     * Generate an invoice once the order is paid. Idempotent per order.
     */
    public static function on_order_paid( $order_id, $order = null ) {
        if ( ! $order ) $order = NMEP_Orders::get( $order_id );
        if ( ! $order ) return;

        // Already have an invoice for this order?
        if ( self::get_for_order( $order_id ) ) return;

        $calc = self::calculate_tax( (float) $order->gross_amount, $order );
        $number = self::next_invoice_number();
        $fy     = self::financial_year_for( current_time( 'Y-m-d' ) );

        global $wpdb;
        $wpdb->insert( NMEP_Database::table( 'invoices' ), array(
            'order_id'        => (int) $order_id,
            'invoice_number'  => $number,
            'financial_year'  => $fy,
            'issued_to_name'  => $order->buyer_name,
            'issued_to_email' => $order->buyer_email,
            'issued_to_gstin' => null,
            'issued_to_state' => null,
            'place_of_supply' => self::infer_place_of_supply( $order ),
            'taxable_amount'  => $calc['taxable'],
            'cgst_rate'       => $calc['cgst_rate'],
            'cgst_amount'     => $calc['cgst_amount'],
            'sgst_rate'       => $calc['sgst_rate'],
            'sgst_amount'     => $calc['sgst_amount'],
            'igst_rate'       => $calc['igst_rate'],
            'igst_amount'     => $calc['igst_amount'],
            'total_tax'       => $calc['total_tax'],
            'grand_total'     => $calc['grand_total'],
            'issued_at'       => current_time( 'mysql' ),
        ) );
        $invoice_id = (int) $wpdb->insert_id;

        NMEP_Orders::update( $order_id, array(
            'invoice_id' => $invoice_id,
            'tax_amount' => $calc['total_tax'],
        ) );

        NMEP_Logger::info( 'Invoice generated', array(
            'invoice_id' => $invoice_id,
            'number'     => $number,
            'order_id'   => $order_id,
            'total'      => $calc['grand_total'],
        ) );

        // Email the buyer with a download link.
        if ( class_exists( 'NMEP_Emails' ) ) {
            $url = self::public_url( $order );
            NMEP_Emails::send_invoice_to_buyer( $order, $url );
        }
    }

    /* ============================================================
       GST CALCULATION
       ============================================================ */

    /**
     * Given a gross amount, split it into taxable + GST components.
     *
     * NOTE: We treat gross_amount as tax-inclusive (buyer pays the sticker
     * price — tax is carved out on our books). This matches how most Indian
     * marketplaces present pricing to consumers.
     */
    public static function calculate_tax( $gross, $order ) {
        $rate = (float) NMEP_Settings::get( 'gst_rate_percent', 18 );
        $inclusive_factor = 1 + ( $rate / 100 );

        $taxable  = round( $gross / $inclusive_factor, 2 );
        $total_tax = round( $gross - $taxable, 2 );

        $same_state = self::is_intra_state( $order );
        if ( $same_state ) {
            $cgst = round( $total_tax / 2, 2 );
            $sgst = round( $total_tax - $cgst, 2 ); // avoid rounding drift
            return array(
                'taxable'     => $taxable,
                'cgst_rate'   => round( $rate / 2, 2 ),
                'cgst_amount' => $cgst,
                'sgst_rate'   => round( $rate / 2, 2 ),
                'sgst_amount' => $sgst,
                'igst_rate'   => 0,
                'igst_amount' => 0,
                'total_tax'   => $total_tax,
                'grand_total' => $gross,
            );
        }

        return array(
            'taxable'     => $taxable,
            'cgst_rate'   => 0,
            'cgst_amount' => 0,
            'sgst_rate'   => 0,
            'sgst_amount' => 0,
            'igst_rate'   => $rate,
            'igst_amount' => $total_tax,
            'total_tax'   => $total_tax,
            'grand_total' => $gross,
        );
    }

    /**
     * Place-of-supply matches buyer state if known; otherwise falls back to
     * the platform state (intra-state by default).
     */
    private static function infer_place_of_supply( $order ) {
        // We don't collect buyer state at checkout today. Operators can wire
        // this once the checkout form captures it.
        return NMEP_Settings::get( 'business_state', 'Nagaland' );
    }

    private static function is_intra_state( $order ) {
        // Until we collect buyer state, assume intra-state. Once the checkout
        // collects state, compare it to settings.business_state.
        return true;
    }

    /* ============================================================
       NUMBERING (per FY)
       ============================================================ */

    public static function financial_year_for( $date_ymd ) {
        $ts = strtotime( $date_ymd );
        $y  = (int) date( 'Y', $ts );
        $m  = (int) date( 'n', $ts );
        if ( $m >= 4 ) {
            return sprintf( '%02d%02d', $y % 100, ( $y + 1 ) % 100 );
        }
        return sprintf( '%02d%02d', ( $y - 1 ) % 100, $y % 100 );
    }

    /**
     * Get the next invoice number for the current financial year.
     * Uses a serialised option so concurrent writes don't collide.
     */
    public static function next_invoice_number() {
        $fy     = self::financial_year_for( current_time( 'Y-m-d' ) );
        $prefix = (string) NMEP_Settings::get( 'invoice_prefix', 'NME' );

        $option = 'nmep_invoice_counter_' . $fy;
        $seq    = (int) get_option( $option, 0 ) + 1;
        update_option( $option, $seq, false );

        return sprintf( '%s/%s/%04d', $prefix, $fy, $seq );
    }

    /* ============================================================
       QUERIES + URLs
       ============================================================ */

    public static function get( $invoice_id ) {
        global $wpdb;
        return $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM " . NMEP_Database::table( 'invoices' ) . " WHERE id = %d",
            (int) $invoice_id
        ) );
    }

    public static function get_for_order( $order_id ) {
        global $wpdb;
        return $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM " . NMEP_Database::table( 'invoices' ) . " WHERE order_id = %d",
            (int) $order_id
        ) );
    }

    /**
     * Public invoice URL (token-gated, no login required).
     */
    public static function public_url( $order ) {
        $hash  = substr( hash_hmac( 'sha256', 'invoice:' . $order->id, wp_salt( 'auth' ) ), 0, 32 );
        $token = $order->id . '-' . $hash;
        return home_url( '/nmep-invoice/' . rawurlencode( $token ) . '/' );
    }

    /* ============================================================
       HTML RENDERING (print-to-PDF via browser)
       ============================================================ */

    public static function render_html( $invoice, $order ) {
        $gstin   = esc_html( NMEP_Settings::get( 'gst_number', '' ) );
        $biz     = esc_html( NMEP_Settings::get( 'business_name', 'Nagaland Me' ) );
        $address = esc_html( NMEP_Settings::get( 'business_address', '' ) );
        $email   = esc_html( NMEP_Settings::get( 'support_email', '' ) );
        $phone   = esc_html( NMEP_Settings::get( 'support_phone', '' ) );

        $fmt = function ( $n ) { return '₹' . number_format( (float) $n, 2 ); };

        header( 'Content-Type: text/html; charset=utf-8' );
        ?><!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Tax Invoice <?php echo esc_html( $invoice->invoice_number ); ?></title>
<style>
  :root { --ink:#0F2419; --gold:#D4A843; --rule:#E5E7EB; --bg:#fff; }
  * { box-sizing:border-box; }
  body { font-family:'Inter',-apple-system,Segoe UI,Arial,sans-serif; color:var(--ink); background:var(--bg); margin:0; padding:32px; }
  .sheet { max-width:820px; margin:0 auto; border:1px solid var(--rule); padding:40px; }
  h1 { font-family:'DM Serif Display',Georgia,serif; font-size:28px; margin:0 0 4px; letter-spacing:.5px; }
  .muted { color:#6B7280; font-size:12px; }
  .grid { display:grid; grid-template-columns:1fr 1fr; gap:32px; margin-top:24px; }
  table { width:100%; border-collapse:collapse; margin-top:24px; font-size:13px; }
  th, td { text-align:left; padding:10px 8px; border-bottom:1px solid var(--rule); }
  th { background:#F9FAFB; font-weight:600; }
  .right { text-align:right; }
  .totals { margin-top:16px; width:100%; max-width:320px; margin-left:auto; font-size:13px; }
  .totals td { padding:6px 8px; border:0; }
  .totals .grand { border-top:2px solid var(--ink); font-weight:700; font-size:15px; }
  .gold { color:var(--gold); font-weight:600; letter-spacing:1px; font-size:11px; }
  .footer { margin-top:40px; font-size:11px; color:#6B7280; text-align:center; border-top:1px dashed var(--rule); padding-top:16px; }
  .print-btn { position:fixed; top:16px; right:16px; background:var(--ink); color:#fff; border:0; padding:10px 16px; border-radius:6px; font-size:13px; cursor:pointer; }
  @media print { .print-btn { display:none; } body { padding:0; } .sheet { border:0; } }
</style>
</head>
<body>
<button class="print-btn" onclick="window.print()">Download PDF</button>
<div class="sheet">
  <div style="display:flex; justify-content:space-between; align-items:flex-start;">
    <div>
      <div class="gold">★ NAGALAND ME EXPERTS</div>
      <h1>Tax Invoice</h1>
      <div class="muted">Invoice No: <?php echo esc_html( $invoice->invoice_number ); ?></div>
      <div class="muted">Dated: <?php echo esc_html( date_i18n( 'd M Y', strtotime( $invoice->issued_at ) ) ); ?></div>
    </div>
    <div style="text-align:right;">
      <strong><?php echo $biz; ?></strong><br>
      <span class="muted"><?php echo nl2br( $address ); ?></span><br>
      <span class="muted">GSTIN: <?php echo $gstin; ?></span><br>
      <span class="muted"><?php echo $email; ?> &middot; <?php echo $phone; ?></span>
    </div>
  </div>

  <div class="grid">
    <div>
      <div class="muted">Billed To</div>
      <strong><?php echo esc_html( $invoice->issued_to_name ); ?></strong><br>
      <span class="muted"><?php echo esc_html( $invoice->issued_to_email ); ?></span>
    </div>
    <div>
      <div class="muted">Order</div>
      <strong><?php echo esc_html( $order->order_number ); ?></strong><br>
      <span class="muted">Place of supply: <?php echo esc_html( $invoice->place_of_supply ); ?></span>
    </div>
  </div>

  <table>
    <thead>
      <tr>
        <th>Description</th>
        <th class="right">Amount</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>
          <strong><?php echo esc_html( $order->service_title ); ?></strong><br>
          <span class="muted"><?php echo esc_html( $order->package_title ); ?> &middot; <?php echo (int) $order->delivery_days; ?> days delivery</span>
        </td>
        <td class="right"><?php echo $fmt( $invoice->taxable_amount ); ?></td>
      </tr>
    </tbody>
  </table>

  <table class="totals">
    <tr><td>Taxable amount</td><td class="right"><?php echo $fmt( $invoice->taxable_amount ); ?></td></tr>
    <?php if ( (float) $invoice->cgst_amount > 0 ) : ?>
      <tr><td>CGST (<?php echo esc_html( $invoice->cgst_rate ); ?>%)</td><td class="right"><?php echo $fmt( $invoice->cgst_amount ); ?></td></tr>
      <tr><td>SGST (<?php echo esc_html( $invoice->sgst_rate ); ?>%)</td><td class="right"><?php echo $fmt( $invoice->sgst_amount ); ?></td></tr>
    <?php endif; ?>
    <?php if ( (float) $invoice->igst_amount > 0 ) : ?>
      <tr><td>IGST (<?php echo esc_html( $invoice->igst_rate ); ?>%)</td><td class="right"><?php echo $fmt( $invoice->igst_amount ); ?></td></tr>
    <?php endif; ?>
    <tr class="grand"><td>Grand total</td><td class="right"><?php echo $fmt( $invoice->grand_total ); ?></td></tr>
  </table>

  <div class="footer">
    This is a computer-generated invoice issued by <?php echo $biz; ?>.<br>
    For questions about this invoice, contact <?php echo $email; ?>.
  </div>
</div>
</body>
</html><?php
    }
}
