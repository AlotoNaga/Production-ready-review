<?php
/**
 * NMEP_Coupons_V2
 *
 * Advanced coupon rules on top of NMEP_Coupons:
 *   - First-order-only: redeemable only by a buyer who has never paid before
 *   - Category scope:   coupon limited to services in a whitelist of
 *                       category_ids (stored as JSON array on the coupons row)
 *   - Service scope:    coupon limited to specific service_ids
 *   - Stacking:         a stack-compatible coupon can be combined with a
 *                       second coupon via the POST key `stack_coupon_code`
 *
 * Migration (idempotent — adds 4 columns to nmep_coupons).
 *
 * Integration:
 *   Hooks nmep_checkout_pricing at priority 15 — runs AFTER the base
 *   coupon handler (priority 10). If the base coupon violates the new
 *   rules, V2 reverses it (restoring pre-discount pricing). If the base
 *   coupon allows stacking, V2 then applies a second coupon from
 *   stack_coupon_code on top of the reduced gross, keeping commission on
 *   the combined original price.
 *
 * Admin UI:
 *   Separate submenu page 'Coupon Rules' where admins toggle the advanced
 *   flags per coupon so we don't have to modify the existing coupon form.
 *
 * @package NagalandMeExpertsPayments
 * @since   2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class NMEP_Coupons_V2 {

    const DB_VERSION_OPTION = 'nmep_coupons_v2_db_version';
    const DB_VERSION        = '1.0.0';

    public static function init() {
        add_action( 'admin_init',    array( __CLASS__, 'maybe_migrate' ), 6 );
        add_action( 'plugins_loaded', array( __CLASS__, 'maybe_migrate' ), 40 );

        add_filter( 'nmep_checkout_pricing', array( __CLASS__, 'apply_advanced_rules' ), 15, 5 );

        if ( is_admin() ) {
            add_action( 'admin_menu', array( __CLASS__, 'register_admin_menu' ), 26 );
            add_action( 'admin_post_nmep_coupon_rules_save', array( __CLASS__, 'handle_rules_save' ) );
        }
    }

    /* ============================================================
       MIGRATION
       ============================================================ */

    public static function maybe_migrate() {
        $installed = get_option( self::DB_VERSION_OPTION, '0.0.0' );
        if ( version_compare( $installed, self::DB_VERSION, '>=' ) ) return;

        if ( ! class_exists( 'NMEP_Coupons' ) ) return; // parent module must be present

        global $wpdb;
        $table = NMEP_Coupons::table( 'coupons' );

        $cols = array(
            'first_order_only'  => "TINYINT(1) NOT NULL DEFAULT 0",
            'allow_stacking'    => "TINYINT(1) NOT NULL DEFAULT 0",
            'category_scope'    => "TEXT DEFAULT NULL",
            'service_scope'     => "TEXT DEFAULT NULL",
        );

        foreach ( $cols as $col => $def ) {
            $exists = $wpdb->get_var( "SHOW COLUMNS FROM $table LIKE '" . esc_sql( $col ) . "'" );
            if ( ! $exists ) {
                $wpdb->query( "ALTER TABLE $table ADD COLUMN $col $def" );
            }
        }

        update_option( self::DB_VERSION_OPTION, self::DB_VERSION, false );
        NMEP_Logger::info( 'NMEP_Coupons_V2 migrated', array( 'version' => self::DB_VERSION ) );
    }

    /* ============================================================
       RULE EVALUATION
       ============================================================ */

    /**
     * Evaluate a coupon against a buyer + service context.
     *
     * @return true|WP_Error
     */
    public static function check_advanced_rules( $coupon, $service, $buyer_email, $buyer_user_id ) {
        // First-order-only
        if ( ! empty( $coupon->first_order_only ) ) {
            if ( self::buyer_has_paid_before( (int) $buyer_user_id, (string) $buyer_email ) ) {
                return new WP_Error( 'nmep_coupon_not_first_order', 'This coupon is for new buyers only.' );
            }
        }

        // Category scope
        if ( ! empty( $coupon->category_scope ) ) {
            $cats = self::decode_list( $coupon->category_scope );
            if ( ! empty( $cats ) && ( empty( $service->category_id ) || ! in_array( (int) $service->category_id, $cats, true ) ) ) {
                return new WP_Error( 'nmep_coupon_category_scope', 'This coupon is not valid for this service category.' );
            }
        }

        // Service scope
        if ( ! empty( $coupon->service_scope ) ) {
            $svc = self::decode_list( $coupon->service_scope );
            if ( ! empty( $svc ) && ! in_array( (int) $service->id, $svc, true ) ) {
                return new WP_Error( 'nmep_coupon_service_scope', 'This coupon is not valid for this service.' );
            }
        }

        return true;
    }

    public static function buyer_has_paid_before( $buyer_user_id, $buyer_email ) {
        global $wpdb;
        $orders = NMEP_Database::table( 'orders' );

        if ( $buyer_user_id ) {
            $n = (int) $wpdb->get_var( $wpdb->prepare(
                "SELECT COUNT(*) FROM $orders
                 WHERE buyer_user_id = %d AND payment_status = 'paid'",
                (int) $buyer_user_id
            ) );
            if ( $n > 0 ) return true;
        }

        if ( ! empty( $buyer_email ) ) {
            $n = (int) $wpdb->get_var( $wpdb->prepare(
                "SELECT COUNT(*) FROM $orders
                 WHERE buyer_email = %s AND payment_status = 'paid'",
                sanitize_email( $buyer_email )
            ) );
            if ( $n > 0 ) return true;
        }

        return false;
    }

    private static function decode_list( $raw ) {
        if ( empty( $raw ) ) return array();
        $decoded = json_decode( $raw, true );
        if ( ! is_array( $decoded ) ) return array();
        return array_values( array_filter( array_map( 'intval', $decoded ) ) );
    }

    /* ============================================================
       CHECKOUT FILTER (priority 15)
       ============================================================ */

    public static function apply_advanced_rules( $pricing, $post, $service, $expert, $commission_rate ) {
        if ( ! is_array( $pricing ) || empty( $service ) ) return $pricing;

        $buyer_email   = isset( $post['buyer_email'] ) ? sanitize_email( $post['buyer_email'] ) : '';
        $buyer_user_id = is_user_logged_in() ? get_current_user_id() : 0;

        // If priority-10 applied a coupon, recheck advanced rules. On failure, revert.
        $applied = ! empty( $pricing['coupon_code'] ) && ( $pricing['discount_source'] ?? '' ) === 'coupon';
        $base_coupon = null;
        if ( $applied ) {
            $base_coupon = NMEP_Coupons::get_by_code( $pricing['coupon_code'] );
            if ( $base_coupon ) {
                $check = self::check_advanced_rules( $base_coupon, $service, $buyer_email, $buyer_user_id );
                if ( is_wp_error( $check ) ) {
                    NMEP_Logger::warning( 'Base coupon blocked by V2 rules', array(
                        'code'  => $pricing['coupon_code'],
                        'error' => $check->get_error_code(),
                    ) );
                    $pricing = self::revert_coupon_pricing( $pricing, $commission_rate );
                    $applied = false;
                    $base_coupon = null;
                }
            }
        }

        // Stack-coupon handling
        $stack_code = isset( $post['stack_coupon_code'] ) ? NMEP_Coupons::sanitize_code( $post['stack_coupon_code'] ) : '';
        if ( $stack_code === '' ) return $pricing;

        // Duplicate guard
        if ( $applied && strcasecmp( $stack_code, (string) $pricing['coupon_code'] ) === 0 ) {
            return $pricing;
        }

        // Stacking is only allowed if the BASE coupon (or no base) permits it
        if ( $applied && empty( $base_coupon->allow_stacking ) ) {
            NMEP_Logger::info( 'Stacking rejected: base coupon does not allow stacking', array(
                'base_code'  => $pricing['coupon_code'],
                'stack_code' => $stack_code,
            ) );
            return $pricing;
        }

        $stack = NMEP_Coupons::get_by_code( $stack_code );
        if ( ! $stack ) return $pricing;

        // The stack coupon itself must allow stacking too
        if ( empty( $stack->allow_stacking ) ) return $pricing;

        // Full validation on stack coupon
        $valid = NMEP_Coupons::validate(
            $stack_code,
            $service,
            $expert,
            $buyer_email,
            $buyer_user_id,
            (float) $pricing['original_amount']
        );
        if ( is_wp_error( $valid ) ) return $pricing;

        $advanced = self::check_advanced_rules( $stack, $service, $buyer_email, $buyer_user_id );
        if ( is_wp_error( $advanced ) ) return $pricing;

        // Compute stack discount on the already-discounted gross, but cap at gross.
        $stack_discount = NMEP_Coupons::compute_discount( $stack, (float) $pricing['gross_amount'] );
        if ( $stack_discount <= 0 ) return $pricing;

        $new_gross           = max( 0.0, round( (float) $pricing['gross_amount'] - $stack_discount, 2 ) );
        $total_discount      = round( (float) $pricing['discount_amount'] + $stack_discount, 2 );
        $original            = (float) $pricing['original_amount'];
        $commission          = round( $original * ( (float) $commission_rate / 100 ), 2 );
        $expert_amt          = max( 0.0, round( $new_gross - $commission, 2 ) );

        $pricing['gross_amount']      = $new_gross;
        $pricing['discount_amount']   = $total_discount;
        $pricing['commission_amount'] = $commission;
        $pricing['expert_amount']     = $expert_amt;
        $pricing['coupon_code']       = $applied
            ? ( $pricing['coupon_code'] . '+' . $stack->code )
            : $stack->code;
        $pricing['coupon_id']         = $applied
            ? (int) $pricing['coupon_id']
            : (int) $stack->id;
        $pricing['discount_source']   = 'coupon_stack';

        NMEP_Logger::info( 'Coupon stack applied', array(
            'base_code'  => $applied ? $pricing['coupon_code'] : null,
            'stack_code' => $stack->code,
            'new_gross'  => $new_gross,
            'total_disc' => $total_discount,
        ) );

        return $pricing;
    }

    private static function revert_coupon_pricing( $pricing, $commission_rate ) {
        $original  = (float) $pricing['original_amount'];
        $commission = round( $original * ( (float) $commission_rate / 100 ), 2 );
        $pricing['gross_amount']      = $original;
        $pricing['discount_amount']   = 0.0;
        $pricing['commission_amount'] = $commission;
        $pricing['expert_amount']     = max( 0.0, round( $original - $commission, 2 ) );
        $pricing['coupon_code']       = '';
        $pricing['coupon_id']         = 0;
        $pricing['discount_source']   = '';
        return $pricing;
    }

    /* ============================================================
       ADMIN UI — coupon advanced-rules table
       ============================================================ */

    public static function register_admin_menu() {
        add_submenu_page(
            'nmep-dashboard',
            'Coupon Rules',
            'Coupon Rules',
            'manage_options',
            'nmep-coupon-rules',
            array( __CLASS__, 'render_admin_page' )
        );
    }

    public static function render_admin_page() {
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Permission denied.' );

        global $wpdb;
        $coupons = $wpdb->get_results(
            "SELECT id, code, description, owner_type, is_active,
                    first_order_only, allow_stacking, category_scope, service_scope
             FROM " . NMEP_Coupons::table( 'coupons' ) . "
             ORDER BY id DESC LIMIT 300"
        );

        if ( isset( $_GET['saved'] ) ) {
            echo '<div class="notice notice-success is-dismissible"><p>Advanced rules saved.</p></div>';
        }
        ?>
        <div class="wrap nmep-admin">
            <h1>Coupon Rules (Advanced)</h1>
            <p>Per-coupon flags for first-order gating, stacking, and category/service scope.
               JSON fields accept an array of numeric IDs, e.g. <code>[12, 34, 56]</code>.</p>

            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                <input type="hidden" name="action" value="nmep_coupon_rules_save">
                <?php wp_nonce_field( 'nmep_coupon_rules_save' ); ?>

                <table class="wp-list-table widefat fixed striped">
                    <thead><tr>
                        <th>Code</th>
                        <th>Owner</th>
                        <th>First-order only</th>
                        <th>Allow stacking</th>
                        <th>Category IDs (JSON)</th>
                        <th>Service IDs (JSON)</th>
                    </tr></thead>
                    <tbody>
                    <?php if ( empty( $coupons ) ) : ?>
                        <tr><td colspan="6" style="text-align:center;padding:30px;">No coupons yet.</td></tr>
                    <?php else : foreach ( $coupons as $c ) : ?>
                        <tr>
                            <td><code style="font-weight:600;"><?php echo esc_html( $c->code ); ?></code>
                                <br><small><?php echo esc_html( $c->description ?: '' ); ?></small></td>
                            <td><?php echo esc_html( ucfirst( $c->owner_type ) ); ?>
                                <?php if ( empty( $c->is_active ) ) echo ' <span style="color:#6B7280;">(inactive)</span>'; ?></td>
                            <td><input type="checkbox" name="first_order[<?php echo (int) $c->id; ?>]" value="1" <?php checked( ! empty( $c->first_order_only ) ); ?>></td>
                            <td><input type="checkbox" name="allow_stacking[<?php echo (int) $c->id; ?>]" value="1" <?php checked( ! empty( $c->allow_stacking ) ); ?>></td>
                            <td><input type="text" style="width:160px;font-family:monospace;" name="category_scope[<?php echo (int) $c->id; ?>]" value="<?php echo esc_attr( $c->category_scope ?: '' ); ?>" placeholder="[]"></td>
                            <td><input type="text" style="width:160px;font-family:monospace;" name="service_scope[<?php echo (int) $c->id; ?>]" value="<?php echo esc_attr( $c->service_scope ?: '' ); ?>" placeholder="[]"></td>
                        </tr>
                    <?php endforeach; endif; ?>
                    </tbody>
                </table>

                <p style="margin-top:16px;"><button type="submit" class="button button-primary">Save Rules</button></p>
            </form>
        </div>
        <?php
    }

    public static function handle_rules_save() {
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Permission denied.' );
        check_admin_referer( 'nmep_coupon_rules_save' );

        global $wpdb;
        $table = NMEP_Coupons::table( 'coupons' );

        // We iterate the scope fields because they include every editable coupon (even unchecked boxes).
        $cat_inputs  = $_POST['category_scope']  ?? array();
        $svc_inputs  = $_POST['service_scope']   ?? array();
        $first_map   = $_POST['first_order']     ?? array();
        $stack_map   = $_POST['allow_stacking']  ?? array();

        $ids = array_unique( array_map( 'intval', array_keys( array_merge( $cat_inputs, $svc_inputs ) ) ) );

        $updated = 0;
        foreach ( $ids as $id ) {
            if ( ! $id ) continue;

            $cat_raw = isset( $cat_inputs[ $id ] ) ? (string) $cat_inputs[ $id ] : '';
            $svc_raw = isset( $svc_inputs[ $id ] ) ? (string) $svc_inputs[ $id ] : '';

            $cat_json = self::normalize_json_list( $cat_raw );
            $svc_json = self::normalize_json_list( $svc_raw );

            $wpdb->update( $table, array(
                'first_order_only' => ! empty( $first_map[ $id ] ) ? 1 : 0,
                'allow_stacking'   => ! empty( $stack_map[ $id ] ) ? 1 : 0,
                'category_scope'   => $cat_json,
                'service_scope'    => $svc_json,
            ), array( 'id' => (int) $id ) );
            $updated++;
        }

        NMEP_Logger::info( 'Coupon V2 rules saved', array( 'count' => $updated ) );

        wp_safe_redirect( admin_url( 'admin.php?page=nmep-coupon-rules&saved=1' ) );
        exit;
    }

    private static function normalize_json_list( $raw ) {
        $raw = trim( (string) $raw );
        if ( $raw === '' ) return null;
        $decoded = json_decode( $raw, true );
        if ( ! is_array( $decoded ) ) return null;
        $ints = array_values( array_filter( array_map( 'intval', $decoded ) ) );
        return empty( $ints ) ? null : wp_json_encode( $ints );
    }
}
