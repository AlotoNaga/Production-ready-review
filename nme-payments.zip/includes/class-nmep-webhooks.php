<?php
/**
 * NMEP_Webhooks
 * Production-grade webhook handler for Razorpay events.
 *
 * Features:
 * - HMAC-SHA256 signature verification
 * - Idempotency via event_id deduplication
 * - Event-specific routing
 * - Always returns 200 (after security check) to prevent Razorpay from retrying
 *
 * @version 1.2.0 (Batch C)
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class NMEP_Webhooks {

    public static function init() {
        add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
    }

    public static function register_routes() {
        register_rest_route( 'nmep/v1', '/webhook', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_webhook' ),
            'permission_callback' => '__return_true',
        ) );
    }

    /**
     * Main webhook handler
     */
    public static function handle_webhook( WP_REST_Request $request ) {
        $body = $request->get_body();
        $signature = $request->get_header( 'x-razorpay-signature' );

        // Verify signature first — drop unsigned/invalid requests
        if ( empty( $signature ) ) {
            NMEP_Logger::warning( 'Webhook received without signature header' );
            return new WP_REST_Response( array( 'error' => 'missing_signature' ), 401 );
        }

        if ( ! NMEP_Razorpay_Client::verify_webhook_signature( $body, $signature ) ) {
            NMEP_Logger::critical( 'Webhook signature verification FAILED', array(
                'signature_provided' => substr( $signature, 0, 20 ) . '...',
            ) );
            return new WP_REST_Response( array( 'error' => 'invalid_signature' ), 401 );
        }

        // Parse JSON
        $payload = json_decode( $body, true );
        if ( ! is_array( $payload ) || empty( $payload['event'] ) ) {
            NMEP_Logger::warning( 'Webhook payload invalid or missing event field' );
            return new WP_REST_Response( array( 'error' => 'invalid_payload' ), 400 );
        }

        $event_type = sanitize_text_field( $payload['event'] );
        $event_id   = isset( $payload['id'] ) ? sanitize_text_field( $payload['id'] ) : '';

        // If no event ID, generate one based on payload hash (still allows idempotency)
        if ( empty( $event_id ) ) {
            $event_id = 'inferred_' . md5( $body );
        }

        NMEP_Logger::info( 'Webhook received', array(
            'event_type' => $event_type,
            'event_id'   => $event_id,
        ) );

        // Idempotency check
        global $wpdb;
        $webhook_table = NMEP_Database::table( 'webhook_events' );

        $existing = $wpdb->get_row( $wpdb->prepare(
            "SELECT id, processing_status FROM $webhook_table WHERE event_id = %s",
            $event_id
        ) );

        if ( $existing && $existing->processing_status === 'processed' ) {
            NMEP_Logger::info( 'Webhook event already processed (idempotency check)', array(
                'event_id' => $event_id,
            ) );
            return new WP_REST_Response( array( 'ok' => true, 'note' => 'already_processed' ), 200 );
        }

        // Insert (or update) webhook event record
        if ( ! $existing ) {
            $wpdb->insert( $webhook_table, array(
                'event_id'         => $event_id,
                'event_type'       => $event_type,
                'mode'             => NMEP_Settings::get_mode(),
                'payload'          => $body,
                'processing_status' => 'pending',
            ) );
            $webhook_event_id = (int) $wpdb->insert_id;
        } else {
            $webhook_event_id = (int) $existing->id;
        }

        // Process the event
        try {
            self::route_event( $event_type, $payload );

            $wpdb->update( $webhook_table, array(
                'processing_status' => 'processed',
                'processed_at'      => current_time( 'mysql' ),
            ), array( 'id' => $webhook_event_id ) );

        } catch ( Exception $e ) {
            NMEP_Logger::error( 'Webhook processing exception', array(
                'event_type' => $event_type,
                'error'      => $e->getMessage(),
            ) );

            $wpdb->update( $webhook_table, array(
                'processing_status' => 'failed',
                'error_message'     => $e->getMessage(),
            ), array( 'id' => $webhook_event_id ) );
        }

        // Always return 200 after signature check passed — Razorpay will retry on non-2xx
        return new WP_REST_Response( array( 'ok' => true ), 200 );
    }

    /**
     * Route the event to the correct handler
     */
    private static function route_event( $event_type, $payload ) {
        $handlers = array(
            'payment.captured'                => array( __CLASS__, 'handle_payment_captured' ),
            'payment.failed'                  => array( __CLASS__, 'handle_payment_failed' ),
            'order.paid'                      => array( __CLASS__, 'handle_order_paid' ),
            'refund.created'                  => array( __CLASS__, 'handle_refund_created' ),
            'refund.processed'                => array( __CLASS__, 'handle_refund_processed' ),
            'refund.failed'                   => array( __CLASS__, 'handle_refund_failed' ),
            'transfer.processed'              => array( __CLASS__, 'handle_transfer_processed' ),
            'transfer.failed'                 => array( __CLASS__, 'handle_transfer_failed' ),
            'account.updated'                 => array( __CLASS__, 'handle_account_updated' ),
            'product.route.under_review'      => array( __CLASS__, 'handle_route_status_change' ),
            'product.route.activated'         => array( __CLASS__, 'handle_route_status_change' ),
            'product.route.needs_clarification' => array( __CLASS__, 'handle_route_status_change' ),
            'product.route.rejected'          => array( __CLASS__, 'handle_route_status_change' ),
        );

        if ( isset( $handlers[ $event_type ] ) ) {
            call_user_func( $handlers[ $event_type ], $payload );
        } else {
            NMEP_Logger::info( 'Webhook event type not handled (logged only)', array(
                'event_type' => $event_type,
            ) );
        }
    }

    /* ============================================================
       EVENT HANDLERS
       ============================================================ */

    /**
     * payment.captured — payment was successfully captured
     * This is a backup in case the redirect-based verification didn't complete.
     */
    public static function handle_payment_captured( $payload ) {
        $payment = $payload['payload']['payment']['entity'] ?? null;
        if ( ! $payment ) return;

        $razorpay_order_id   = $payment['order_id'] ?? '';
        $razorpay_payment_id = $payment['id'] ?? '';

        if ( empty( $razorpay_order_id ) || empty( $razorpay_payment_id ) ) {
            NMEP_Logger::warning( 'payment.captured webhook missing order_id or payment_id' );
            return;
        }

        $order = NMEP_Orders::get_by_razorpay_order_id( $razorpay_order_id );
        if ( ! $order ) {
            NMEP_Logger::warning( 'payment.captured: local order not found', array(
                'razorpay_order_id' => $razorpay_order_id,
            ) );
            return;
        }

        // If already paid, skip
        if ( $order->payment_status === NMEP_Orders::PAYMENT_CAPTURED ) {
            NMEP_Logger::info( 'payment.captured: order already marked captured (idempotent)' );
            return;
        }

        // Mark as paid (this is the safety net for cases where redirect verify didn't run)
        $auto_release_days = (int) NMEP_Settings::get( 'auto_release_days', 5 );
        $now = current_time( 'mysql' );

        NMEP_Orders::update( $order->id, array(
            'razorpay_payment_id' => $razorpay_payment_id,
            'status'              => NMEP_Orders::STATUS_PAID,
            'payment_status'      => NMEP_Orders::PAYMENT_CAPTURED,
            'escrow_status'       => NMEP_Orders::ESCROW_HOLDING,
            'paid_at'             => $now,
            'delivery_due_at'     => date( 'Y-m-d H:i:s', strtotime( "+{$order->delivery_days} days" ) ),
            'auto_release_at'     => date( 'Y-m-d H:i:s', strtotime( "+{$auto_release_days} days" ) ),
        ) );

        NMEP_Logger::info( 'payment.captured: order marked paid via webhook (safety net)', array(
            'order_id' => $order->id,
        ) );

        // Increment service order count
        global $wpdb;
        $wpdb->query( $wpdb->prepare(
            "UPDATE " . NMEP_Database::table( 'services' ) . " SET orders_count = orders_count + 1 WHERE id = %d",
            (int) $order->service_id
        ) );

        $order = NMEP_Orders::get( $order->id );
        do_action( 'nmep_after_payment_captured', $order->id, $order );

        if ( class_exists( 'NMEP_Events' ) ) {
            NMEP_Events::emit( NMEP_Events::ORDER_PAID, $order->id, $order );
            NMEP_Events::emit( NMEP_Events::ORDER_ACCEPTED, $order->id, $order );
            NMEP_Events::emit( NMEP_Events::ORDER_IN_PROGRESS, $order->id, $order );
        }

        if ( class_exists( 'NMEP_Emails' ) ) {
            NMEP_Emails::send_order_confirmation( $order );
            NMEP_Emails::send_payment_received_to_expert( $order );
            NMEP_Emails::send_admin_new_order( $order );
        }
    }

    /**
     * payment.failed — payment attempt failed
     */
    public static function handle_payment_failed( $payload ) {
        $payment = $payload['payload']['payment']['entity'] ?? null;
        if ( ! $payment ) return;

        $razorpay_order_id = $payment['order_id'] ?? '';
        if ( empty( $razorpay_order_id ) ) return;

        $order = NMEP_Orders::get_by_razorpay_order_id( $razorpay_order_id );
        if ( ! $order ) return;

        NMEP_Orders::update( $order->id, array(
            'payment_status' => NMEP_Orders::PAYMENT_FAILED,
        ) );

        NMEP_Logger::warning( 'payment.failed event processed', array(
            'order_id'   => $order->id,
            'error_code' => $payment['error_code'] ?? '',
        ) );

        if ( class_exists( 'NMEP_Events' ) ) {
            NMEP_Events::emit(
                NMEP_Events::PAYMENT_FAILED,
                $order->id,
                $payment['error_code'] ?? '',
                $payment['error_description'] ?? ''
            );
        }

        if ( class_exists( 'NMEP_Emails' ) && method_exists( 'NMEP_Emails', 'send_payment_failed' ) ) {
            NMEP_Emails::send_payment_failed( $order, $payment['error_description'] ?? '' );
        }
    }

    /**
     * order.paid — Razorpay confirms order is fully paid
     * Generally redundant with payment.captured but logged for completeness
     */
    public static function handle_order_paid( $payload ) {
        $rzp_order = $payload['payload']['order']['entity'] ?? null;
        if ( ! $rzp_order ) return;

        $razorpay_order_id = $rzp_order['id'] ?? '';
        $order = NMEP_Orders::get_by_razorpay_order_id( $razorpay_order_id );
        if ( ! $order ) return;

        NMEP_Logger::info( 'order.paid event received', array(
            'order_id' => $order->id,
        ) );
    }

    /**
     * refund.created / refund.processed / refund.failed — refund lifecycle
     * Full handling in Batch D, here we just log
     */
    public static function handle_refund_created( $payload ) {
        NMEP_Logger::info( 'refund.created webhook received (full handler in Batch D)' );
    }

    public static function handle_refund_processed( $payload ) {
        $refund = $payload['payload']['refund']['entity'] ?? null;
        if ( ! $refund ) return;

        $razorpay_refund_id  = $refund['id'] ?? '';
        $razorpay_payment_id = $refund['payment_id'] ?? '';

        global $wpdb;
        // Find order by payment_id
        $order = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM " . NMEP_Database::table( 'orders' ) . " WHERE razorpay_payment_id = %s",
            $razorpay_payment_id
        ) );

        if ( ! $order ) {
            NMEP_Logger::warning( 'refund.processed: order not found', array( 'payment_id' => $razorpay_payment_id ) );
            return;
        }

        // Update refund record
        $refund_table = NMEP_Database::table( 'refunds' );
        $existing_refund = $wpdb->get_row( $wpdb->prepare(
            "SELECT id FROM $refund_table WHERE razorpay_refund_id = %s",
            $razorpay_refund_id
        ) );

        if ( $existing_refund ) {
            $wpdb->update( $refund_table, array(
                'status'       => 'processed',
                'processed_at' => current_time( 'mysql' ),
                'api_response' => wp_json_encode( $refund ),
            ), array( 'id' => $existing_refund->id ) );
        }

        // Update order
        NMEP_Orders::update( $order->id, array(
            'status'         => NMEP_Orders::STATUS_REFUNDED,
            'payment_status' => NMEP_Orders::PAYMENT_REFUNDED,
            'escrow_status'  => NMEP_Orders::ESCROW_REVERSED,
        ) );

        NMEP_Logger::info( 'refund.processed: order updated', array(
            'order_id'  => $order->id,
            'refund_id' => $razorpay_refund_id,
        ) );
    }

    public static function handle_refund_failed( $payload ) {
        $refund = $payload['payload']['refund']['entity'] ?? null;
        if ( ! $refund ) return;

        global $wpdb;
        $refund_table = NMEP_Database::table( 'refunds' );
        $wpdb->update( $refund_table,
            array(
                'status'         => 'failed',
                'failure_reason' => $refund['error_description'] ?? 'Unknown',
            ),
            array( 'razorpay_refund_id' => $refund['id'] ?? '' )
        );

        NMEP_Logger::error( 'refund.failed event', array(
            'refund_id' => $refund['id'] ?? '',
            'reason'    => $refund['error_description'] ?? '',
        ) );
    }

    /**
     * transfer.processed — Route transfer to expert succeeded
     */
    public static function handle_transfer_processed( $payload ) {
        $transfer = $payload['payload']['transfer']['entity'] ?? null;
        if ( ! $transfer ) return;

        $razorpay_transfer_id = $transfer['id'] ?? '';

        global $wpdb;
        $transfers_table = NMEP_Database::table( 'transfers' );
        $existing = $wpdb->get_row( $wpdb->prepare(
            "SELECT id FROM $transfers_table WHERE razorpay_transfer_id = %s",
            $razorpay_transfer_id
        ) );

        if ( $existing ) {
            $wpdb->update( $transfers_table, array(
                'status'       => 'processed',
                'settled_at'   => current_time( 'mysql' ),
                'api_response' => wp_json_encode( $transfer ),
            ), array( 'id' => $existing->id ) );

            NMEP_Logger::info( 'transfer.processed: transfer updated', array(
                'transfer_id' => $razorpay_transfer_id,
            ) );

            // Fire payout-completed event for ledger + notifications
            $row = $wpdb->get_row( $wpdb->prepare( "SELECT order_id, amount FROM $transfers_table WHERE id = %d", $existing->id ) );
            if ( $row && class_exists( 'NMEP_Events' ) ) {
                NMEP_Events::emit( NMEP_Events::PAYOUT_COMPLETED, (int) $row->order_id, (float) $row->amount, $razorpay_transfer_id );
            }
        }
    }

    public static function handle_transfer_failed( $payload ) {
        $transfer = $payload['payload']['transfer']['entity'] ?? null;
        if ( ! $transfer ) return;

        global $wpdb;
        $wpdb->update( NMEP_Database::table( 'transfers' ),
            array(
                'status'         => 'failed',
                'failure_reason' => $transfer['failure_reason'] ?? 'Unknown',
            ),
            array( 'razorpay_transfer_id' => $transfer['id'] ?? '' )
        );

        NMEP_Logger::error( 'transfer.failed event', array(
            'transfer_id' => $transfer['id'] ?? '',
            'reason'      => $transfer['failure_reason'] ?? '',
        ) );

        if ( class_exists( 'NMEP_Events' ) ) {
            $row = $wpdb->get_row( $wpdb->prepare(
                "SELECT order_id, amount FROM " . NMEP_Database::table( 'transfers' ) . " WHERE razorpay_transfer_id = %s",
                $transfer['id'] ?? ''
            ) );
            if ( $row ) {
                NMEP_Events::emit( NMEP_Events::PAYOUT_FAILED, (int) $row->order_id, (float) $row->amount, $transfer['failure_reason'] ?? '' );
            }
        }
    }

    /**
     * account.updated — Linked Account status changed
     */
    public static function handle_account_updated( $payload ) {
        $account = $payload['payload']['account']['entity'] ?? null;
        if ( ! $account ) return;

        $razorpay_account_id = $account['id'] ?? '';
        if ( empty( $razorpay_account_id ) ) return;

        global $wpdb;
        $wpdb->update( NMEP_Database::table( 'linked_accounts' ),
            array(
                'status'       => $account['status'] ?? 'unknown',
                'api_response' => wp_json_encode( $account ),
            ),
            array( 'razorpay_account_id' => $razorpay_account_id )
        );

        NMEP_Logger::info( 'account.updated: linked account status changed', array(
            'account_id' => $razorpay_account_id,
            'new_status' => $account['status'] ?? '',
        ) );
    }

    /**
     * product.route.* — Route product activation lifecycle
     */
    public static function handle_route_status_change( $payload ) {
        $entity = $payload['payload']['account']['entity'] ?? null;
        if ( ! $entity ) {
            $entity = $payload['payload']['product']['entity'] ?? null;
        }

        $event = $payload['event'] ?? '';
        $razorpay_account_id = $entity['account_id'] ?? ( $entity['id'] ?? '' );

        if ( $razorpay_account_id ) {
            $activation_status = 'pending';
            if ( strpos( $event, 'activated' ) !== false ) $activation_status = 'activated';
            elseif ( strpos( $event, 'rejected' ) !== false ) $activation_status = 'rejected';
            elseif ( strpos( $event, 'needs_clarification' ) !== false ) $activation_status = 'needs_clarification';
            elseif ( strpos( $event, 'under_review' ) !== false ) $activation_status = 'under_review';

            global $wpdb;
            $wpdb->update( NMEP_Database::table( 'linked_accounts' ),
                array( 'activation_status' => $activation_status ),
                array( 'razorpay_account_id' => $razorpay_account_id )
            );

            NMEP_Logger::info( 'Route product status changed', array(
                'account_id'        => $razorpay_account_id,
                'event'             => $event,
                'activation_status' => $activation_status,
            ) );
        }
    }
}
