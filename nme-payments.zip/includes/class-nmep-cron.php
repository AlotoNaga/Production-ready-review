<?php
/**
 * NMEP_Cron
 * Cron jobs: auto-release escrow, refresh linked account status, cleanup logs.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class NMEP_Cron {

    const HOOK_AUTO_RELEASE  = 'nmep_cron_auto_release';
    const HOOK_REFRESH_ACCOUNTS = 'nmep_cron_refresh_accounts';
    const HOOK_CLEANUP_LOGS  = 'nmep_cron_cleanup_logs';

    public static function init() {
        add_action( self::HOOK_AUTO_RELEASE, array( 'NMEP_Escrow', 'process_auto_releases' ) );
        add_action( self::HOOK_REFRESH_ACCOUNTS, array( __CLASS__, 'refresh_pending_accounts' ) );
        add_action( self::HOOK_CLEANUP_LOGS, array( 'NMEP_Logger', 'cleanup_old_logs' ) );
    }

    public static function schedule() {
        if ( ! wp_next_scheduled( self::HOOK_AUTO_RELEASE ) ) {
            wp_schedule_event( time(), 'hourly', self::HOOK_AUTO_RELEASE );
        }
        if ( ! wp_next_scheduled( self::HOOK_REFRESH_ACCOUNTS ) ) {
            wp_schedule_event( time(), 'twicedaily', self::HOOK_REFRESH_ACCOUNTS );
        }
        if ( ! wp_next_scheduled( self::HOOK_CLEANUP_LOGS ) ) {
            wp_schedule_event( time(), 'daily', self::HOOK_CLEANUP_LOGS );
        }
    }

    public static function unschedule() {
        wp_clear_scheduled_hook( self::HOOK_AUTO_RELEASE );
        wp_clear_scheduled_hook( self::HOOK_REFRESH_ACCOUNTS );
        wp_clear_scheduled_hook( self::HOOK_CLEANUP_LOGS );
    }

    public static function refresh_pending_accounts() {
        global $wpdb;
        $rows = $wpdb->get_results(
            "SELECT id FROM " . NMEP_Database::table( 'linked_accounts' ) . "
             WHERE status NOT IN ('activated', 'failed')
             LIMIT 20"
        );
        foreach ( $rows as $r ) {
            NMEP_Linked_Accounts::refresh_status( (int) $r->id );
        }
    }
}
