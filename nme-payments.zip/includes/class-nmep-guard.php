<?php
/**
 * NMEP_Guard v1.0.0
 *
 * Production-grade helper class for the Nagaland Me Experts marketplace.
 * Drop-in utility — no existing code changes required to install.
 *
 * Features:
 * 1. RATE LIMITING — transient-based throttle for checkout, uploads, forms
 * 2. DASHBOARD CACHE — transient cache for expensive stat queries
 * 3. CENTRAL VALIDATOR — validate service data, checkout data, etc.
 * 4. ANALYTICS HOOKS — fire do_action events for key business moments
 * 5. PAGINATION HELPER — generate paginated queries + nav HTML
 *
 * Usage: NMEP_Guard::method_name()
 *
 * @version 1.0.0
 */
if ( ! defined( 'ABSPATH' ) ) exit;

class NMEP_Guard {

    /* ============================================================
       1. RATE LIMITING — transient-based throttle
       ============================================================ */

    /**
     * Check if an action is rate-limited.
     *
     * @param string $action  Action key (e.g., 'checkout', 'upload', 'contact')
     * @param int    $limit   Max attempts within $window
     * @param int    $window  Time window in seconds (default 60)
     * @param string $scope   'user' (per user) or 'ip' (per IP)
     * @return bool True if allowed, false if rate-limited
     */
    public static function rate_check( $action, $limit = 5, $window = 60, $scope = 'user' ) {
        $key = self::rate_key( $action, $scope );
        $data = get_transient( $key );

        if ( ! $data ) {
            $data = array( 'count' => 1, 'first' => time() );
            set_transient( $key, $data, $window );
            return true;
        }

        // Window expired — reset
        if ( time() - $data['first'] > $window ) {
            $data = array( 'count' => 1, 'first' => time() );
            set_transient( $key, $data, $window );
            return true;
        }

        // Within window — increment
        $data['count']++;
        set_transient( $key, $data, $window - ( time() - $data['first'] ) );

        return $data['count'] <= $limit;
    }

    /**
     * Get remaining attempts for an action.
     */
    public static function rate_remaining( $action, $limit = 5, $scope = 'user' ) {
        $key  = self::rate_key( $action, $scope );
        $data = get_transient( $key );
        if ( ! $data ) return $limit;
        return max( 0, $limit - $data['count'] );
    }

    /**
     * Build a unique rate limit key.
     */
    private static function rate_key( $action, $scope ) {
        $id = $scope === 'user' && is_user_logged_in()
            ? 'u' . get_current_user_id()
            : 'ip' . md5( $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0' );
        return 'nmep_rl_' . $action . '_' . $id;
    }

    /**
     * Enforce rate limit — dies with error if exceeded.
     *
     * Usage:  NMEP_Guard::rate_enforce( 'checkout', 3, 300 );
     *         // Max 3 checkouts per 5 minutes per user
     */
    public static function rate_enforce( $action, $limit = 5, $window = 60, $scope = 'user' ) {
        if ( ! self::rate_check( $action, $limit, $window, $scope ) ) {
            wp_die(
                '<div style="max-width:500px;margin:80px auto;font-family:sans-serif;text-align:center;">'
                . '<h2 style="color:#991B1B;">Too Many Requests</h2>'
                . '<p style="color:#6B7280;">Please wait a moment before trying again.</p>'
                . '<p><a href="' . esc_url( home_url( '/' ) ) . '" style="color:#10B981;">← Back to Home</a></p>'
                . '</div>',
                'Rate Limited',
                array( 'response' => 429 )
            );
        }
    }

    /* ============================================================
       2. DASHBOARD CACHE — transient-based stat caching
       ============================================================ */

    /**
     * Get cached dashboard stats for an expert.
     * Caches earnings, orders, reviews for 5 minutes.
     *
     * @param int $expert_id
     * @return object { total_earnings, pending_earnings, completed_count, review_count, avg_rating }
     */
    public static function get_dashboard_stats( $expert_id ) {
        $cache_key = 'nmep_dash_stats_' . (int) $expert_id;
        $cached = get_transient( $cache_key );
        if ( $cached !== false ) return $cached;

        global $wpdb;
        $orders_table  = NMEP_Database::table( 'orders' );
        $reviews_table = NMEP_Database::table( 'reviews' );

        $stats = new \stdClass();

        $stats->total_earnings = (float) $wpdb->get_var( $wpdb->prepare(
            "SELECT COALESCE(SUM(expert_amount),0) FROM $orders_table WHERE expert_id = %d AND status IN ('completed','auto_released')",
            $expert_id
        ) );

        $stats->pending_earnings = (float) $wpdb->get_var( $wpdb->prepare(
            "SELECT COALESCE(SUM(expert_amount),0) FROM $orders_table WHERE expert_id = %d AND status IN ('paid','in_progress','delivered','revision') AND escrow_status = 'holding'",
            $expert_id
        ) );

        $stats->completed_count = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM $orders_table WHERE expert_id = %d AND status IN ('completed','auto_released')",
            $expert_id
        ) );

        $stats->active_orders = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM $orders_table WHERE expert_id = %d AND status IN ('paid','in_progress','delivered','revision')",
            $expert_id
        ) );

        $review_data = $wpdb->get_row( $wpdb->prepare(
            "SELECT COUNT(*) AS cnt, COALESCE(AVG(rating),0) AS avg_r FROM $reviews_table WHERE expert_id = %d AND status = 'published'",
            $expert_id
        ) );
        $stats->review_count = (int) ( $review_data->cnt ?? 0 );
        $stats->avg_rating   = round( (float) ( $review_data->avg_r ?? 0 ), 1 );

        set_transient( $cache_key, $stats, 300 ); // 5 min cache
        return $stats;
    }

    /**
     * Invalidate dashboard cache (call after order status change, review, etc.)
     */
    public static function invalidate_dashboard( $expert_id ) {
        delete_transient( 'nmep_dash_stats_' . (int) $expert_id );
    }

    /* ============================================================
       3. CENTRAL VALIDATOR
       ============================================================ */

    /**
     * Validate service data before save.
     *
     * @param array $data  Service form data
     * @return array  Empty if valid, or array of error strings
     */
    public static function validate_service( $data ) {
        $errors = array();

        if ( empty( $data['title'] ) || strlen( $data['title'] ) < 10 ) {
            $errors[] = 'Service title must be at least 10 characters.';
        }
        if ( strlen( $data['title'] ?? '' ) > 160 ) {
            $errors[] = 'Service title cannot exceed 160 characters.';
        }
        if ( empty( $data['description'] ) || strlen( $data['description'] ) < 50 ) {
            $errors[] = 'Description must be at least 50 characters.';
        }
        if ( empty( $data['category_id'] ) || (int) $data['category_id'] < 1 ) {
            $errors[] = 'Please select a category.';
        }

        // At least one tier must have a price
        $has_price = false;
        foreach ( array( 'basic', 'standard', 'premium' ) as $tier ) {
            $price = (float) ( $data[ $tier . '_price' ] ?? 0 );
            if ( $price > 0 ) {
                $has_price = true;
                $min = (int) ( $data['min_price'] ?? 199 );
                $max = (int) ( $data['max_price'] ?? 9999 );
                if ( $price < $min ) $errors[] = ucfirst( $tier ) . " price must be at least ₹$min.";
                if ( $price > $max ) $errors[] = ucfirst( $tier ) . " price cannot exceed ₹$max.";
            }
        }
        if ( ! $has_price ) {
            $errors[] = 'At least one package must have a price.';
        }

        return $errors;
    }

    /**
     * Validate checkout data.
     */
    public static function validate_checkout( $data ) {
        $errors = array();

        if ( empty( $data['buyer_name'] ) || strlen( $data['buyer_name'] ) < 2 ) {
            $errors[] = 'Please enter your name.';
        }
        if ( empty( $data['buyer_email'] ) || ! is_email( $data['buyer_email'] ) ) {
            $errors[] = 'Please enter a valid email.';
        }
        if ( empty( $data['buyer_phone'] ) || strlen( $data['buyer_phone'] ) < 10 ) {
            $errors[] = 'Please enter a valid phone number.';
        }
        if ( empty( $data['service_id'] ) || (int) $data['service_id'] < 1 ) {
            $errors[] = 'Invalid service selected.';
        }

        return $errors;
    }

    /**
     * Sanitize and validate a PAN number.
     */
    public static function validate_pan( $pan ) {
        $pan = strtoupper( trim( $pan ) );
        if ( ! preg_match( '/^[A-Z]{5}[0-9]{4}[A-Z]{1}$/', $pan ) ) {
            return false;
        }
        return $pan;
    }

    /**
     * Sanitize and validate IFSC code.
     */
    public static function validate_ifsc( $ifsc ) {
        $ifsc = strtoupper( trim( $ifsc ) );
        if ( ! preg_match( '/^[A-Z]{4}0[A-Z0-9]{6}$/', $ifsc ) ) {
            return false;
        }
        return $ifsc;
    }

    /* ============================================================
       4. ANALYTICS HOOKS — fire at key business moments
       Call these from your handlers to enable tracking.
       ============================================================ */

    /**
     * Track a business event.
     * Fires a do_action that any analytics plugin can hook into.
     *
     * Built-in events:
     *   nmep_event_service_viewed   (service_id)
     *   nmep_event_checkout_started (service_id, tier, amount)
     *   nmep_event_order_placed     (order_id, amount)
     *   nmep_event_order_completed  (order_id, amount)
     *   nmep_event_review_submitted (order_id, rating)
     *   nmep_event_expert_signup    (expert_id)
     *   nmep_event_search           (query, results_count)
     */
    public static function track( $event, $data = array() ) {
        $data['timestamp'] = current_time( 'mysql' );
        $data['user_id']   = get_current_user_id();
        $data['ip']        = $_SERVER['REMOTE_ADDR'] ?? '';

        /**
         * Fires for any marketplace event.
         * @param string $event  Event name
         * @param array  $data   Event data
         */
        do_action( 'nmep_analytics_event', $event, $data );

        /**
         * Fires for a specific event.
         * Example: add_action('nmep_event_order_placed', function($data) { ... });
         */
        do_action( 'nmep_event_' . $event, $data );
    }

    /* ============================================================
       5. PAGINATION HELPER
       ============================================================ */

    /**
     * Get pagination parameters from URL.
     *
     * @param int $per_page  Items per page (default 10)
     * @return array { page, per_page, offset }
     */
    public static function get_pagination( $per_page = 10 ) {
        $page = max( 1, (int) ( $_GET['pg'] ?? 1 ) );
        return array(
            'page'     => $page,
            'per_page' => $per_page,
            'offset'   => ( $page - 1 ) * $per_page,
        );
    }

    /**
     * Render pagination nav HTML.
     *
     * @param int    $total      Total items
     * @param int    $page       Current page
     * @param int    $per_page   Items per page
     * @param string $base_url   URL without pg parameter
     * @return string HTML
     */
    public static function render_pagination( $total, $page, $per_page, $base_url = '' ) {
        $total_pages = max( 1, (int) ceil( $total / $per_page ) );
        if ( $total_pages <= 1 ) return '';

        if ( empty( $base_url ) ) {
            $base_url = remove_query_arg( 'pg' );
        }

        $html = '<div style="display:flex;justify-content:center;gap:6px;margin:24px 0;flex-wrap:wrap;">';

        // Previous
        if ( $page > 1 ) {
            $html .= '<a href="' . esc_url( add_query_arg( 'pg', $page - 1, $base_url ) ) . '" style="padding:8px 14px;border:1.5px solid #D1D5DB;border-radius:8px;text-decoration:none;color:#374151;font-size:0.9rem;">← Prev</a>';
        }

        // Page numbers (show max 7 pages with ellipsis)
        $range = 2;
        $start = max( 1, $page - $range );
        $end   = min( $total_pages, $page + $range );

        if ( $start > 1 ) {
            $html .= self::page_link( 1, $page, $base_url );
            if ( $start > 2 ) $html .= '<span style="padding:8px 6px;color:#9CA3AF;">…</span>';
        }

        for ( $i = $start; $i <= $end; $i++ ) {
            $html .= self::page_link( $i, $page, $base_url );
        }

        if ( $end < $total_pages ) {
            if ( $end < $total_pages - 1 ) $html .= '<span style="padding:8px 6px;color:#9CA3AF;">…</span>';
            $html .= self::page_link( $total_pages, $page, $base_url );
        }

        // Next
        if ( $page < $total_pages ) {
            $html .= '<a href="' . esc_url( add_query_arg( 'pg', $page + 1, $base_url ) ) . '" style="padding:8px 14px;border:1.5px solid #D1D5DB;border-radius:8px;text-decoration:none;color:#374151;font-size:0.9rem;">Next →</a>';
        }

        $html .= '</div>';
        $html .= '<div style="text-align:center;font-size:0.8rem;color:#9CA3AF;">Page ' . $page . ' of ' . $total_pages . ' · ' . $total . ' total</div>';

        return $html;
    }

    private static function page_link( $num, $current, $base_url ) {
        $active = $num === $current;
        $style  = $active
            ? 'background:#0F2419;color:#fff;border-color:#0F2419;'
            : 'color:#374151;border-color:#D1D5DB;';
        return '<a href="' . esc_url( add_query_arg( 'pg', $num, $base_url ) ) . '" style="padding:8px 14px;border:1.5px solid;border-radius:8px;text-decoration:none;font-size:0.9rem;font-weight:' . ( $active ? '700' : '400' ) . ';' . $style . '">' . $num . '</a>';
    }

    /* ============================================================
       UTILITY — XSS-safe output
       ============================================================ */

    /**
     * Escape output for safe HTML display.
     * Handles null, arrays, and objects gracefully.
     */
    public static function esc( $value, $fallback = '' ) {
        if ( is_null( $value ) || $value === '' ) return esc_html( $fallback );
        if ( is_array( $value ) || is_object( $value ) ) return esc_html( $fallback );
        return esc_html( (string) $value );
    }
}