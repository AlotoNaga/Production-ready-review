<?php
/**
 * NMEP_Disputes
 * Dispute management — buyer/expert can open, admin mediates.
 *
 * Lifecycle: open -> investigating -> resolved (with one of: refund_buyer, release_to_expert, partial_refund)
 *
 * @version 1.3.0 (Batch D)
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class NMEP_Disputes {

    const STATUS_OPEN          = 'open';
    const STATUS_INVESTIGATING = 'investigating';
    const STATUS_RESOLVED      = 'resolved';

    const RESOLUTION_REFUND_BUYER     = 'refund_buyer';
    const RESOLUTION_RELEASE_TO_EXPERT = 'release_to_expert';
    const RESOLUTION_PARTIAL_REFUND   = 'partial_refund';

    public static function init() {
        add_action( 'admin_post_nopriv_nmep_open_dispute', array( __CLASS__, 'handle_open_dispute' ) );
        add_action( 'admin_post_nmep_open_dispute',         array( __CLASS__, 'handle_open_dispute' ) );

        add_action( 'admin_post_nmep_admin_resolve_dispute', array( __CLASS__, 'handle_admin_resolve' ) );
    }

    /* ============================================================
       OPEN DISPUTE (frontend)
       ============================================================ */

    public static function handle_open_dispute() {
        if ( ! isset( $_POST['_wpnonce'] ) || ! wp_verify_nonce( $_POST['_wpnonce'], 'nmep_open_dispute' ) ) {
            wp_die( 'Security check failed.' );
        }

        $order_id = isset( $_POST['order_id'] ) ? (int) $_POST['order_id'] : 0;
        $token    = sanitize_text_field( $_POST['token'] ?? '' );
        $role     = sanitize_key( $_POST['role'] ?? '' );
        $reason   = sanitize_text_field( $_POST['reason'] ?? '' );
        $description = sanitize_textarea_field( $_POST['description'] ?? '' );

        $order = NMEP_Orders::get( $order_id );
        if ( ! $order ) {
            wp_die( 'Order not found.' );
        }

        // Authorize: either buyer's view token, or logged-in expert
        $authorized = false;
        if ( $role === 'buyer' && $order->view_token === $token ) {
            $authorized = true;
        } elseif ( $role === 'expert' && is_user_logged_in() ) {
            $expert = NMEP_Compat::get_expert_by_user( get_current_user_id() );
            if ( $expert && (int) $expert->id === (int) $order->expert_id ) {
                $authorized = true;
            }
        }

        if ( ! $authorized ) {
            wp_die( 'Permission denied.' );
        }

        if ( empty( $reason ) || empty( $description ) || strlen( $description ) < 30 ) {
            self::redirect_with_error( 'Please provide a reason and detailed description (30+ chars).', $order );
            return;
        }

        // Cannot dispute completed orders
        if ( in_array( $order->status, array( NMEP_Orders::STATUS_COMPLETED, NMEP_Orders::STATUS_REFUNDED ), true ) ) {
            self::redirect_with_error( 'This order is already finalized and cannot be disputed.', $order );
            return;
        }

        // Check if dispute already open
        global $wpdb;
        $existing = $wpdb->get_var( $wpdb->prepare(
            "SELECT id FROM " . NMEP_Database::table( 'disputes' ) . "
             WHERE order_id = %d AND status != %s",
            $order_id, self::STATUS_RESOLVED
        ) );

        if ( $existing ) {
            self::redirect_with_error( 'A dispute is already open for this order.', $order );
            return;
        }

        // Create dispute
        $wpdb->insert( NMEP_Database::table( 'disputes' ), array(
            'order_id'    => $order_id,
            'opened_by'   => is_user_logged_in() ? get_current_user_id() : null,
            'opened_role' => $role,
            'reason'      => $reason,
            'description' => $description,
            'status'      => self::STATUS_OPEN,
        ) );

        $dispute_id = (int) $wpdb->insert_id;

        // Mark order as disputed
        NMEP_Orders::update( $order_id, array(
            'status'       => NMEP_Orders::STATUS_DISPUTED,
            'disputed_at'  => current_time( 'mysql' ),
        ) );

        NMEP_Logger::warning( 'Dispute opened', array(
            'order_id'   => $order_id,
            'dispute_id' => $dispute_id,
            'role'       => $role,
            'reason'     => $reason,
        ) );

        NMEP_Compat::audit_log( 'dispute_opened', 'order', $order_id, array(
            'role'   => $role,
            'reason' => $reason,
        ) );

        // Notify admin
        if ( class_exists( 'NMEP_Emails' ) ) {
            NMEP_Emails::send_admin_dispute_opened( $order, $reason, $description, $role );
        }

        if ( class_exists( 'NMEP_Events' ) ) {
            NMEP_Events::emit( NMEP_Events::DISPUTE_OPENED, $order_id, $dispute_id, $role, $reason );
            NMEP_Events::emit( NMEP_Events::ORDER_DISPUTED, $order_id, $dispute_id );
        }

        // Redirect with success
        $url = $role === 'buyer'
            ? add_query_arg( array( 'order' => $order->order_number, 'token' => $order->view_token, 'nmep_status' => 'success', 'nmep_msg' => urlencode( 'Dispute opened. Our team will contact you within 24 hours.' ) ), nmep_get_page_url( 'order-track' ) )
            : add_query_arg( array( 'nmep_status' => 'success', 'nmep_msg' => urlencode( 'Dispute opened. Admin will mediate.' ) ), nmep_get_page_url( 'expert-dashboard' ) );

        wp_safe_redirect( $url );
        exit;
    }

    /* ============================================================
       ADMIN RESOLVE
       ============================================================ */

    public static function handle_admin_resolve() {
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Permission denied.' );

        $dispute_id = isset( $_POST['dispute_id'] ) ? (int) $_POST['dispute_id'] : 0;
        if ( ! wp_verify_nonce( $_POST['_wpnonce'] ?? '', 'nmep_resolve_dispute_' . $dispute_id ) ) {
            wp_die( 'Invalid request.' );
        }

        global $wpdb;
        $dispute = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM " . NMEP_Database::table( 'disputes' ) . " WHERE id = %d",
            $dispute_id
        ) );

        if ( ! $dispute ) wp_die( 'Dispute not found.' );

        $resolution      = sanitize_key( $_POST['resolution'] ?? '' );
        $notes           = sanitize_textarea_field( $_POST['notes'] ?? '' );
        $partial_amount  = isset( $_POST['partial_amount'] ) ? (float) $_POST['partial_amount'] : 0;

        $valid_resolutions = array(
            self::RESOLUTION_REFUND_BUYER,
            self::RESOLUTION_RELEASE_TO_EXPERT,
            self::RESOLUTION_PARTIAL_REFUND,
        );

        if ( ! in_array( $resolution, $valid_resolutions, true ) ) {
            wp_die( 'Invalid resolution.' );
        }

        $order = NMEP_Orders::get( $dispute->order_id );
        if ( ! $order ) wp_die( 'Order not found.' );

        // Apply resolution
        $action_result = null;

        if ( $resolution === self::RESOLUTION_REFUND_BUYER ) {
            $action_result = NMEP_Refunds::create(
                $order->id, null, 'Dispute resolved in buyer favor: ' . $notes, get_current_user_id(), 'admin'
            );
        } elseif ( $resolution === self::RESOLUTION_PARTIAL_REFUND ) {
            if ( $partial_amount <= 0 || $partial_amount >= $order->gross_amount ) {
                wp_die( 'Invalid partial refund amount.' );
            }
            $action_result = NMEP_Refunds::create(
                $order->id, $partial_amount, 'Partial refund per dispute resolution: ' . $notes, get_current_user_id(), 'admin'
            );
            // Then release remainder to expert
            if ( ! is_wp_error( $action_result ) ) {
                NMEP_Escrow::release_to_expert( $order->id, 'dispute_partial' );
            }
        } elseif ( $resolution === self::RESOLUTION_RELEASE_TO_EXPERT ) {
            $action_result = NMEP_Escrow::release_to_expert( $order->id, 'dispute_resolved' );
        }

        // Mark dispute as resolved
        $wpdb->update( NMEP_Database::table( 'disputes' ), array(
            'status'           => self::STATUS_RESOLVED,
            'resolution'       => $resolution,
            'resolution_notes' => $notes,
            'resolved_by'      => get_current_user_id(),
            'resolved_at'      => current_time( 'mysql' ),
        ), array( 'id' => $dispute_id ) );

        NMEP_Logger::info( 'Dispute resolved by admin', array(
            'order_id'   => $order->id,
            'dispute_id' => $dispute_id,
            'resolution' => $resolution,
        ) );

        NMEP_Compat::audit_log( 'dispute_resolved', 'order', $order->id, array(
            'dispute_id' => $dispute_id,
            'resolution' => $resolution,
        ) );

        if ( class_exists( 'NMEP_Events' ) ) {
            NMEP_Events::emit( NMEP_Events::DISPUTE_RESOLVED, $order->id, $dispute_id, $resolution, $notes );
        }

        // Notify buyer + expert of resolution
        if ( class_exists( 'NMEP_Emails' ) && method_exists( 'NMEP_Emails', 'send_dispute_resolved' ) ) {
            NMEP_Emails::send_dispute_resolved( $order, $resolution, $notes );
        }

        wp_safe_redirect( admin_url( 'admin.php?page=nmep-disputes&resolved=1' ) );
        exit;
    }

    /* ============================================================
       QUERIES
       ============================================================ */

    public static function get( $dispute_id ) {
        global $wpdb;
        return $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM " . NMEP_Database::table( 'disputes' ) . " WHERE id = %d",
            (int) $dispute_id
        ) );
    }

    public static function get_open() {
        global $wpdb;
        return $wpdb->get_results( $wpdb->prepare(
            "SELECT d.*, o.order_number, o.buyer_name, o.buyer_email, o.gross_amount, o.service_title
             FROM " . NMEP_Database::table( 'disputes' ) . " d
             LEFT JOIN " . NMEP_Database::table( 'orders' ) . " o ON o.id = d.order_id
             WHERE d.status != %s
             ORDER BY d.created_at ASC",
            self::STATUS_RESOLVED
        ) );
    }

    public static function get_for_order( $order_id ) {
        global $wpdb;
        return $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM " . NMEP_Database::table( 'disputes' ) . " WHERE order_id = %d ORDER BY created_at DESC",
            (int) $order_id
        ) );
    }

    public static function count_open() {
        global $wpdb;
        return (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM " . NMEP_Database::table( 'disputes' ) . " WHERE status != %s",
            self::STATUS_RESOLVED
        ) );
    }

    private static function redirect_with_error( $message, $order ) {
        $url = add_query_arg( array(
            'order'       => $order->order_number,
            'token'       => $order->view_token,
            'nmep_status' => 'error',
            'nmep_msg'    => urlencode( $message ),
        ), nmep_get_page_url( 'order-track' ) );
        wp_safe_redirect( $url );
        exit;
    }
}
