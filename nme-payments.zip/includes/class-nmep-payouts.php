<?php
/**
 * NMEP_Payouts
 *
 * Payout ledger + admin / expert dashboard helpers.
 *
 * A "payout" is one row per expert-amount released from escrow. The Razorpay
 * transfer is the underlying mechanism; the payout row is the accounting
 * record we show experts and admins.
 *
 * Lifecycle:
 *   PAYOUT_SCHEDULED → status='scheduled'   (escrow released, Razorpay will settle)
 *   PAYOUT_COMPLETED → status='settled'     (transfer processed webhook)
 *   PAYOUT_FAILED    → status='failed'      (transfer failed webhook)
 *
 * Invariants:
 *   - At most one 'scheduled' payout per order per transfer (idempotent insert).
 *   - Money amounts are stored in INR (DECIMAL 12,2), not paise.
 *
 * @package NagalandMeExpertsPayments
 * @since   2.0.0
 *
 * v2.1.0 — bank-change freeze:
 *   If NME_Change_Requests reports a pending bank-account change for the
 *   expert, scheduled payouts are recorded with status='held' instead of
 *   'scheduled' and carry a failure_reason. The corresponding 'settled'
 *   webhook is refused while held (logged as a warning). After the admin
 *   approves or rejects the change request, NME_Change_Requests::approve_request
 *   / reject_request calls NMEP_Payouts::release_held_for_expert(), which
 *   flips the held rows back to 'scheduled' so normal settlement resumes.
 *
 *   Note: the physical Razorpay transfer is created upstream (NMEP_Escrow).
 *   This file controls the accounting ledger only; a proper upstream hold
 *   requires the escrow release path to also check
 *   NMEP_Payouts::is_held_for_bank_change() before creating the transfer.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class NMEP_Payouts {

    const STATUS_SCHEDULED = 'scheduled';
    const STATUS_PROCESSING = 'processing';
    const STATUS_SETTLED   = 'settled';
    const STATUS_FAILED    = 'failed';
    const STATUS_REVERSED  = 'reversed';
    const STATUS_HELD      = 'held'; // v2.1.0 — bank-change review in progress

    public static function init() {
        add_action( NMEP_Events::PAYOUT_SCHEDULED, array( __CLASS__, 'on_scheduled' ), 10, 2 );
        add_action( NMEP_Events::PAYOUT_COMPLETED, array( __CLASS__, 'on_completed' ), 10, 3 );
        add_action( NMEP_Events::PAYOUT_FAILED,    array( __CLASS__, 'on_failed' ),    10, 3 );
    }

    /* ============================================================
       EVENT LISTENERS
       ============================================================ */

    /**
     * Triggered from NMEP_Escrow when escrow is released to the expert.
     * Creates (or updates) a payout row per on-hold-released transfer.
     *
     * @param int   $order_id
     * @param float $expert_amount  Amount payable (may be split across transfers)
     */
    public static function on_scheduled( $order_id, $expert_amount = 0 ) {
        global $wpdb;
        $order = NMEP_Orders::get( $order_id );
        if ( ! $order ) return;

        // v2.1.0 — if a bank-account change is under review for this expert,
        // hold the payout in the ledger instead of marking it scheduled.
        $is_held  = self::is_held_for_bank_change( (int) $order->expert_id );
        $status   = $is_held ? self::STATUS_HELD : self::STATUS_SCHEDULED;
        $hold_msg = $is_held ? 'Payout paused while expert bank-account change is under review' : null;

        $transfers = $wpdb->get_results( $wpdb->prepare(
            "SELECT id, razorpay_transfer_id, amount, status
             FROM " . NMEP_Database::table( 'transfers' ) . "
             WHERE order_id = %d",
            (int) $order_id
        ) );

        if ( empty( $transfers ) ) {
            // Non-Route / test-mode flow — create a single synthetic ledger row
            self::upsert( array(
                'order_id'             => (int) $order_id,
                'expert_id'            => (int) $order->expert_id,
                'transfer_id'          => null,
                'razorpay_transfer_id' => null,
                'method'               => 'bank',
                'amount'               => (float) $expert_amount,
                'currency'             => $order->currency ?: 'INR',
                'status'               => $status,
                'scheduled_at'         => current_time( 'mysql' ),
                'failure_reason'       => $hold_msg,
            ) );
            if ( $is_held ) {
                NMEP_Logger::info( 'Payout held — bank change under review', array(
                    'order_id'  => $order_id,
                    'expert_id' => $order->expert_id,
                    'amount'    => $expert_amount,
                ) );
            }
            return;
        }

        foreach ( $transfers as $t ) {
            self::upsert( array(
                'order_id'             => (int) $order_id,
                'expert_id'            => (int) $order->expert_id,
                'transfer_id'          => (int) $t->id,
                'razorpay_transfer_id' => $t->razorpay_transfer_id,
                'method'               => self::resolve_method( (int) $order->expert_id ),
                'amount'               => (float) $t->amount,
                'currency'             => $order->currency ?: 'INR',
                'status'               => $status,
                'scheduled_at'         => current_time( 'mysql' ),
                'failure_reason'       => $hold_msg,
            ) );
        }

        if ( $is_held ) {
            NMEP_Logger::info( 'Payout held — bank change under review', array(
                'order_id'  => $order_id,
                'expert_id' => $order->expert_id,
                'transfers' => count( $transfers ),
            ) );
        }
    }

    public static function on_completed( $order_id, $amount = 0, $razorpay_transfer_id = '' ) {
        global $wpdb;
        $table = NMEP_Database::table( 'payouts' );

        $where = array( 'order_id' => (int) $order_id );
        if ( $razorpay_transfer_id ) {
            $where['razorpay_transfer_id'] = $razorpay_transfer_id;
        }

        // v2.1.0 — refuse to settle held rows; leave them for manual review.
        if ( $razorpay_transfer_id ) {
            $held_row = $wpdb->get_var( $wpdb->prepare(
                "SELECT id FROM $table WHERE order_id = %d AND status = %s AND razorpay_transfer_id = %s LIMIT 1",
                (int) $order_id, self::STATUS_HELD, $razorpay_transfer_id
            ) );
        } else {
            $held_row = $wpdb->get_var( $wpdb->prepare(
                "SELECT id FROM $table WHERE order_id = %d AND status = %s LIMIT 1",
                (int) $order_id, self::STATUS_HELD
            ) );
        }
        if ( $held_row ) {
            NMEP_Logger::error( 'Payout settlement refused — row is held pending bank change', array(
                'order_id' => $order_id,
                'amount'   => $amount,
                'transfer' => $razorpay_transfer_id,
                'payout'   => (int) $held_row,
            ) );
            return;
        }

        $updated = $wpdb->update( $table, array(
            'status'     => self::STATUS_SETTLED,
            'settled_at' => current_time( 'mysql' ),
        ), $where );

        if ( ! $updated ) {
            // No prior scheduled row — create a settled row so history is complete
            self::upsert( array(
                'order_id'             => (int) $order_id,
                'expert_id'            => (int) ( NMEP_Orders::get( $order_id )->expert_id ?? 0 ),
                'razorpay_transfer_id' => $razorpay_transfer_id ?: null,
                'amount'               => (float) $amount,
                'status'               => self::STATUS_SETTLED,
                'settled_at'           => current_time( 'mysql' ),
                'scheduled_at'         => current_time( 'mysql' ),
            ) );
        }

        // Notify expert
        if ( class_exists( 'NMEP_Emails' ) ) {
            $order = NMEP_Orders::get( $order_id );
            if ( $order ) {
                NMEP_Emails::send_payout_completed( $order, (float) $amount );
            }
        }

        NMEP_Logger::info( 'Payout settled', array(
            'order_id' => $order_id,
            'amount'   => $amount,
            'transfer' => $razorpay_transfer_id,
        ) );
    }

    public static function on_failed( $order_id, $amount = 0, $reason = '' ) {
        global $wpdb;
        $table = NMEP_Database::table( 'payouts' );

        $wpdb->update( $table, array(
            'status'         => self::STATUS_FAILED,
            'failure_reason' => (string) $reason,
        ), array( 'order_id' => (int) $order_id ) );

        NMEP_Logger::error( 'Payout failed', array(
            'order_id' => $order_id,
            'amount'   => $amount,
            'reason'   => $reason,
        ) );
    }

    /* ============================================================
       DATA HELPERS
       ============================================================ */

    /**
     * Insert a payout row, or update an existing scheduled row if the same
     * (order_id, razorpay_transfer_id) already exists.
     */
    public static function upsert( array $row ) {
        global $wpdb;
        $table = NMEP_Database::table( 'payouts' );

        if ( ! empty( $row['razorpay_transfer_id'] ) ) {
            $existing = $wpdb->get_var( $wpdb->prepare(
                "SELECT id FROM $table WHERE order_id = %d AND razorpay_transfer_id = %s LIMIT 1",
                (int) $row['order_id'], $row['razorpay_transfer_id']
            ) );
            if ( $existing ) {
                $wpdb->update( $table, $row, array( 'id' => (int) $existing ) );
                return (int) $existing;
            }
        }

        $wpdb->insert( $table, $row );
        return (int) $wpdb->insert_id;
    }

    public static function get( $payout_id ) {
        global $wpdb;
        return $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM " . NMEP_Database::table( 'payouts' ) . " WHERE id = %d",
            (int) $payout_id
        ) );
    }

    public static function get_for_order( $order_id ) {
        global $wpdb;
        return $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM " . NMEP_Database::table( 'payouts' ) . "
             WHERE order_id = %d ORDER BY created_at ASC",
            (int) $order_id
        ) );
    }

    public static function get_for_expert( $expert_id, $limit = 100, $offset = 0 ) {
        global $wpdb;
        return $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM " . NMEP_Database::table( 'payouts' ) . "
             WHERE expert_id = %d
             ORDER BY created_at DESC
             LIMIT %d OFFSET %d",
            (int) $expert_id, (int) $limit, (int) $offset
        ) );
    }

    /**
     * Aggregate earnings for an expert — used on the expert dashboard.
     *
     * 'held' payouts (frozen pending a bank-change review) are surfaced in their
     * own bucket AND also rolled into 'pending' so the dashboard total the seller
     * sees never appears to "disappear" during review.
     *
     * @return array{pending:float, held:float, settled:float, failed:float, total:float, count:int}
     */
    public static function earnings_summary( $expert_id ) {
        global $wpdb;
        $table = NMEP_Database::table( 'payouts' );

        $row = $wpdb->get_row( $wpdb->prepare(
            "SELECT
                SUM(CASE WHEN status IN ('scheduled','processing','held') THEN amount ELSE 0 END) AS pending,
                SUM(CASE WHEN status = 'held'    THEN amount ELSE 0 END) AS held,
                SUM(CASE WHEN status = 'settled' THEN amount ELSE 0 END) AS settled,
                SUM(CASE WHEN status = 'failed'  THEN amount ELSE 0 END) AS failed,
                SUM(amount) AS total,
                COUNT(*)    AS count
             FROM $table
             WHERE expert_id = %d",
            (int) $expert_id
        ), ARRAY_A );

        return array(
            'pending' => (float) ( $row['pending'] ?? 0 ),
            'held'    => (float) ( $row['held']    ?? 0 ),
            'settled' => (float) ( $row['settled'] ?? 0 ),
            'failed'  => (float) ( $row['failed']  ?? 0 ),
            'total'   => (float) ( $row['total']   ?? 0 ),
            'count'   => (int)   ( $row['count']   ?? 0 ),
        );
    }

    /**
     * Admin view — recent payouts across all experts, optionally filtered.
     */
    public static function list_recent( $args = array() ) {
        global $wpdb;
        $defaults = array(
            'status'    => '',
            'expert_id' => 0,
            'limit'     => 50,
            'offset'    => 0,
        );
        $args = wp_parse_args( $args, $defaults );

        $where  = array( '1=1' );
        $params = array();

        if ( $args['status'] ) {
            $where[] = 'status = %s';
            $params[] = sanitize_key( $args['status'] );
        }
        if ( (int) $args['expert_id'] > 0 ) {
            $where[] = 'expert_id = %d';
            $params[] = (int) $args['expert_id'];
        }

        $sql = "SELECT * FROM " . NMEP_Database::table( 'payouts' ) . "
                WHERE " . implode( ' AND ', $where ) . "
                ORDER BY created_at DESC
                LIMIT %d OFFSET %d";
        $params[] = (int) $args['limit'];
        $params[] = (int) $args['offset'];

        return $wpdb->get_results( $wpdb->prepare( $sql, $params ) );
    }

    /* ============================================================
       v2.1.0 — BANK-CHANGE FREEZE
       ============================================================ */

    /**
     * Should this expert's payout be held because a bank-account change
     * is under admin review?
     *
     * Safe to call even if the experts plugin is not installed — falls
     * back to false.
     */
    public static function is_held_for_bank_change( $expert_id ) {
        $expert_id = (int) $expert_id;
        if ( $expert_id <= 0 ) {
            return false;
        }
        if ( ! class_exists( 'NME_Change_Requests' ) ) {
            return false;
        }
        $pending = (bool) NME_Change_Requests::has_pending_bank_request( $expert_id );

        /**
         * Filter: allow other code (e.g. manual admin holds) to force-hold.
         *
         * @param bool $pending  true if we would otherwise hold
         * @param int  $expert_id
         */
        return (bool) apply_filters( 'nmep_payout_held_for_expert', $pending, $expert_id );
    }

    /**
     * Release all 'held' payouts for an expert back to 'scheduled'. Called
     * by NME_Change_Requests::approve_request() / reject_request() after
     * the bank-change review completes.
     *
     * Returns the number of rows released.
     */
    public static function release_held_for_expert( $expert_id ) {
        $expert_id = (int) $expert_id;
        if ( $expert_id <= 0 ) {
            return 0;
        }

        global $wpdb;
        $table    = NMEP_Database::table( 'payouts' );
        $released = (int) $wpdb->query( $wpdb->prepare(
            "UPDATE $table
                SET status = %s,
                    failure_reason = NULL,
                    scheduled_at = COALESCE(scheduled_at, %s)
              WHERE expert_id = %d
                AND status = %s",
            self::STATUS_SCHEDULED,
            current_time( 'mysql' ),
            $expert_id,
            self::STATUS_HELD
        ) );

        if ( $released > 0 && class_exists( 'NMEP_Logger' ) ) {
            NMEP_Logger::info( 'Held payouts released after bank-change review', array(
                'expert_id' => $expert_id,
                'released'  => $released,
            ) );
        }

        return $released;
    }

    /**
     * Count rows currently held for an expert (admin dashboard helper).
     */
    public static function count_held_for_expert( $expert_id ) {
        $expert_id = (int) $expert_id;
        if ( $expert_id <= 0 ) return 0;

        global $wpdb;
        return (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM " . NMEP_Database::table( 'payouts' ) . "
              WHERE expert_id = %d AND status = %s",
            $expert_id, self::STATUS_HELD
        ) );
    }

    /**
     * Resolve the payout method for an expert from their linked account row.
     * Returns 'upi' or 'bank' (default).
     */
    private static function resolve_method( $expert_id ) {
        global $wpdb;
        $method = $wpdb->get_var( $wpdb->prepare(
            "SELECT payout_method FROM " . NMEP_Database::table( 'linked_accounts' ) . "
             WHERE expert_id = %d
             ORDER BY id DESC LIMIT 1",
            (int) $expert_id
        ) );
        return $method ?: 'bank';
    }
}