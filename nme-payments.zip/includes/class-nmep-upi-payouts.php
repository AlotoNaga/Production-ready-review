<?php
/**
 * NMEP_UPI_Payouts
 *
 * UPI payout support on top of Razorpay RazorpayX / Fund Accounts.
 *
 * Flow:
 *   1. Expert saves a UPI VPA on their linked-account profile.
 *   2. register_fund_account() creates a Razorpay Fund Account of type 'vpa',
 *      stores the returned fund_account id on the linked_accounts row.
 *   3. On PAYOUT_SCHEDULED, if the resolved method is 'upi' and a fund-account
 *      id exists, we issue a RazorpayX payout to that fund account.
 *   4. payout.processed / payout.failed webhooks update the ledger.
 *
 * Notes:
 *   - Bank payouts continue to flow via the existing Route transfer hold-release
 *     mechanism. This class is ADDITIVE; it does not replace bank payouts.
 *   - VPA format is validated against the standard `user@handle` shape.
 *
 * @package NagalandMeExpertsPayments
 * @since   2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class NMEP_UPI_Payouts {

    const VPA_REGEX = '/^[a-zA-Z0-9.\-_]{2,256}@[a-zA-Z]{2,64}$/';

    public static function init() {
        add_action( NMEP_Events::PAYOUT_SCHEDULED, array( __CLASS__, 'maybe_dispatch_upi_payout' ), 20, 2 );
    }

    /* ============================================================
       FUND ACCOUNT REGISTRATION
       ============================================================ */

    /**
     * Validate a VPA string.
     */
    public static function is_valid_vpa( $vpa ) {
        $vpa = trim( (string) $vpa );
        return (bool) preg_match( self::VPA_REGEX, $vpa );
    }

    /**
     * Persist the expert's UPI VPA and (if API configured) create a matching
     * Razorpay Fund Account so payouts can be issued.
     *
     * @param int    $linked_account_id Local linked_accounts row id.
     * @param string $vpa
     * @return true|WP_Error
     */
    public static function save_vpa( $linked_account_id, $vpa ) {
        $vpa = trim( (string) $vpa );
        if ( ! self::is_valid_vpa( $vpa ) ) {
            return new WP_Error( 'invalid_vpa', 'Please enter a valid UPI ID (e.g. name@okhdfcbank).' );
        }

        global $wpdb;
        $table = NMEP_Database::table( 'linked_accounts' );
        $row   = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $table WHERE id = %d", (int) $linked_account_id ) );
        if ( ! $row ) {
            return new WP_Error( 'not_found', 'Linked account not found.' );
        }

        $wpdb->update( $table, array(
            'upi_vpa'       => $vpa,
            'payout_method' => 'upi',
        ), array( 'id' => (int) $linked_account_id ) );

        $fund_account_id = self::create_fund_account_for( $row, $vpa );
        if ( is_wp_error( $fund_account_id ) ) {
            // VPA saved but remote fund account failed — operator can retry later
            NMEP_Logger::warning( 'UPI VPA saved locally but Razorpay fund account creation failed', array(
                'linked_account_id' => $linked_account_id,
                'error'             => $fund_account_id->get_error_message(),
            ) );
            return $fund_account_id;
        }

        $wpdb->update( $table, array(
            'razorpay_fund_account_id' => $fund_account_id,
        ), array( 'id' => (int) $linked_account_id ) );

        NMEP_Logger::info( 'UPI VPA + fund account saved', array(
            'linked_account_id' => $linked_account_id,
            'fund_account_id'   => $fund_account_id,
        ) );

        return true;
    }

    /**
     * Create a Razorpay Fund Account of type vpa tied to the linked account's
     * contact. If a contact doesn't exist yet, we create one.
     *
     * @return string|WP_Error fund_account id
     */
    public static function create_fund_account_for( $linked_account, $vpa ) {
        // Step 1: Ensure a contact exists. Razorpay Contacts live under the
        // RazorpayX stack. For simplicity, we reuse the linked account's
        // name/email/phone to create a fresh contact per VPA. Operators can
        // refactor to cache contact ids if volume grows.
        $contact = NMEP_Razorpay_Client::post( '/contacts', array(
            'name'    => $linked_account->account_holder_name,
            'email'   => $linked_account->account_email,
            'contact' => $linked_account->account_phone,
            'type'    => 'vendor',
            'reference_id' => 'expert-' . (int) $linked_account->expert_id,
            'notes'   => array(
                'linked_account_id' => (string) $linked_account->id,
                'expert_id'         => (string) $linked_account->expert_id,
            ),
        ) );
        if ( is_wp_error( $contact ) || empty( $contact['id'] ) ) {
            return is_wp_error( $contact ) ? $contact : new WP_Error( 'contact_failed', 'Could not create Razorpay contact' );
        }

        // Step 2: Create a vpa-type fund account against that contact.
        $fa = NMEP_Razorpay_Client::post( '/fund_accounts', array(
            'contact_id'   => $contact['id'],
            'account_type' => 'vpa',
            'vpa'          => array( 'address' => $vpa ),
        ) );
        if ( is_wp_error( $fa ) || empty( $fa['id'] ) ) {
            return is_wp_error( $fa ) ? $fa : new WP_Error( 'fa_failed', 'Could not create Razorpay fund account' );
        }

        return $fa['id'];
    }

    /* ============================================================
       PAYOUT DISPATCH
       ============================================================ */

    /**
     * Listener for PAYOUT_SCHEDULED. Only fires a UPI payout if the expert's
     * linked-account has method='upi' and a fund_account id is present.
     *
     * Non-UPI experts fall through to the existing Route transfer hold-release
     * flow, which has already fired at this point.
     */
    public static function maybe_dispatch_upi_payout( $order_id, $expert_amount = 0 ) {
        global $wpdb;
        $order = NMEP_Orders::get( $order_id );
        if ( ! $order ) return;

        $la = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM " . NMEP_Database::table( 'linked_accounts' ) . "
             WHERE expert_id = %d AND mode = %s ORDER BY id DESC LIMIT 1",
            (int) $order->expert_id, NMEP_Settings::get_mode()
        ) );

        if ( ! $la || $la->payout_method !== 'upi' || empty( $la->razorpay_fund_account_id ) ) {
            return; // Bank flow owns this payout
        }

        $amount_paise = nmep_to_paise( (float) $expert_amount );
        if ( $amount_paise < 100 ) return; // Razorpay minimum

        $payout = NMEP_Razorpay_Client::post( '/payouts', array(
            'account_number' => NMEP_Settings::get( 'razorpay_x_account_number', '' ),
            'fund_account_id' => $la->razorpay_fund_account_id,
            'amount'         => $amount_paise,
            'currency'       => $order->currency ?: 'INR',
            'mode'           => 'UPI',
            'purpose'        => 'payout',
            'queue_if_low_balance' => true,
            'reference_id'   => 'order-' . (int) $order->id,
            'narration'      => 'NMEP ' . $order->order_number,
            'notes'          => array(
                'order_id'  => (string) $order->id,
                'expert_id' => (string) $order->expert_id,
            ),
        ) );

        if ( is_wp_error( $payout ) ) {
            NMEP_Logger::error( 'UPI payout dispatch failed', array(
                'order_id' => $order_id,
                'error'    => $payout->get_error_message(),
            ) );
            NMEP_Events::emit( NMEP_Events::PAYOUT_FAILED, $order_id, (float) $expert_amount, $payout->get_error_message() );
            return;
        }

        // Update the scheduled payout ledger row with provider id + method.
        $wpdb->update( NMEP_Database::table( 'payouts' ), array(
            'method'               => 'upi',
            'razorpay_transfer_id' => $payout['id'] ?? null,
            'status'               => NMEP_Payouts::STATUS_PROCESSING,
        ), array( 'order_id' => (int) $order_id ) );

        NMEP_Logger::info( 'UPI payout dispatched', array(
            'order_id'   => $order_id,
            'payout_id'  => $payout['id'] ?? null,
            'amount'     => $expert_amount,
        ) );
    }
}
