<?php
/**
 * NMEP_Reviews_V2
 *
 * Adds v2.0 review features on top of the existing NMEP_Reviews class
 * WITHOUT rewriting it. New capabilities:
 *
 *   - Multi-criteria ratings on buyer→expert reviews
 *     (communication, as_described, recommend).
 *   - Seller → buyer reviews written to nmep_buyer_reviews.
 *   - Report-review-abuse with moderation queue (nmep_review_reports).
 *   - Three-day edit window for buyer reviews (tracked via created_at).
 *
 * Uses the same services layer — renders forms / lists on existing review
 * shortcodes via hooks where possible, otherwise exposes new endpoints.
 *
 * @package NagalandMeExpertsPayments
 * @since   2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class NMEP_Reviews_V2 {

    const EDIT_WINDOW_DAYS = 3;

    public static function init() {
        // POST handlers (pages live on the buyer / expert dashboards already)
        add_action( 'admin_post_nmep_submit_buyer_review', array( __CLASS__, 'handle_buyer_review_submit' ) );
        add_action( 'admin_post_nopriv_nmep_submit_buyer_review', array( __CLASS__, 'handle_buyer_review_submit' ) );

        add_action( 'admin_post_nmep_submit_seller_review', array( __CLASS__, 'handle_seller_review_submit' ) );

        add_action( 'admin_post_nmep_report_review', array( __CLASS__, 'handle_report_review' ) );
        add_action( 'admin_post_nopriv_nmep_report_review', array( __CLASS__, 'handle_report_review' ) );

        add_action( 'admin_post_nmep_edit_review', array( __CLASS__, 'handle_edit_review' ) );
        add_action( 'admin_post_nopriv_nmep_edit_review', array( __CLASS__, 'handle_edit_review' ) );

        // Admin moderation page
        add_action( 'admin_menu', array( __CLASS__, 'register_menu' ), 25 );
    }

    /* ============================================================
       BUYER → EXPERT (multi-criteria update)
       ============================================================ */

    public static function handle_buyer_review_submit() {
        check_admin_referer( 'nmep_buyer_review' );
        $order_id = (int) ( $_POST['order_id'] ?? 0 );
        $token    = sanitize_text_field( $_POST['token'] ?? '' );
        $order    = NMEP_Orders::get( $order_id );
        if ( ! $order || ! hash_equals( (string) $order->view_token, $token ) ) {
            wp_die( 'Invalid review link.' );
        }
        if ( ! in_array( $order->status, array( NMEP_Orders::STATUS_COMPLETED, NMEP_Orders::STATUS_AUTO_RELEASED ), true ) ) {
            wp_die( 'You can only review a completed order.' );
        }

        global $wpdb;
        $reviews_t = NMEP_Database::table( 'reviews' );

        $rating       = max( 1, min( 5, (int) ( $_POST['rating'] ?? 0 ) ) );
        $communication = max( 0, min( 5, (int) ( $_POST['communication_rating'] ?? 0 ) ) );
        $as_described  = max( 0, min( 5, (int) ( $_POST['as_described_rating'] ?? 0 ) ) );
        $recommend     = max( 0, min( 5, (int) ( $_POST['recommend_rating'] ?? 0 ) ) );
        $comment       = sanitize_textarea_field( wp_unslash( $_POST['comment'] ?? '' ) );

        $existing = $wpdb->get_row( $wpdb->prepare( "SELECT id FROM $reviews_t WHERE order_id = %d", $order_id ) );

        $data = array(
            'rating'               => $rating,
            'communication_rating' => $communication,
            'as_described_rating'  => $as_described,
            'recommend_rating'     => $recommend,
            'comment'              => $comment,
        );

        if ( $existing ) {
            $wpdb->update( $reviews_t, $data, array( 'id' => (int) $existing->id ) );
            $review_id = (int) $existing->id;
        } else {
            $wpdb->insert( $reviews_t, array_merge( $data, array(
                'order_id'     => (int) $order->id,
                'service_id'   => (int) $order->service_id,
                'expert_id'    => (int) $order->expert_id,
                'buyer_user_id'=> (int) $order->buyer_user_id,
                'buyer_name'   => $order->buyer_name,
                'buyer_email'  => $order->buyer_email,
            ) ) );
            $review_id = (int) $wpdb->insert_id;
        }

        NMEP_Events::emit( NMEP_Events::REVIEW_SUBMITTED, $review_id, $order->id, $rating );
        wp_safe_redirect( add_query_arg( array( 'reviewed' => 1 ), nmep_get_page_url( 'order-track' ) ) );
        exit;
    }

    /**
     * Buyer edits their review within EDIT_WINDOW_DAYS.
     */
    public static function handle_edit_review() {
        check_admin_referer( 'nmep_edit_review' );
        global $wpdb;
        $review_id = (int) ( $_POST['review_id'] ?? 0 );
        $token     = sanitize_text_field( $_POST['token'] ?? '' );

        $review = $wpdb->get_row( $wpdb->prepare(
            "SELECT r.*, o.view_token FROM " . NMEP_Database::table( 'reviews' ) . " r
             JOIN " . NMEP_Database::table( 'orders' ) . " o ON o.id = r.order_id
             WHERE r.id = %d", $review_id
        ) );
        if ( ! $review || ! hash_equals( (string) $review->view_token, $token ) ) wp_die( 'Invalid edit link.' );

        $age_days = ( time() - strtotime( $review->created_at ) ) / 86400;
        if ( $age_days > self::EDIT_WINDOW_DAYS ) {
            wp_die( 'Reviews can only be edited within ' . self::EDIT_WINDOW_DAYS . ' days.' );
        }

        $wpdb->update( NMEP_Database::table( 'reviews' ), array(
            'rating'   => max( 1, min( 5, (int) ( $_POST['rating'] ?? $review->rating ) ) ),
            'comment'  => sanitize_textarea_field( wp_unslash( $_POST['comment'] ?? $review->comment ) ),
        ), array( 'id' => $review_id ) );

        NMEP_Compat::audit_log( 'review_edited', 'review', $review_id, array() );
        wp_safe_redirect( wp_get_referer() ?: home_url( '/' ) );
        exit;
    }

    /* ============================================================
       EXPERT → BUYER
       ============================================================ */

    public static function handle_seller_review_submit() {
        check_admin_referer( 'nmep_seller_review' );
        if ( ! is_user_logged_in() ) wp_die( 'Please log in.' );

        $order_id = (int) ( $_POST['order_id'] ?? 0 );
        $order    = NMEP_Orders::get( $order_id );
        if ( ! $order ) wp_die( 'Order not found.' );

        $expert = class_exists( 'NMEP_Compat' ) ? NMEP_Compat::get_expert_by_user( get_current_user_id() ) : null;
        if ( ! $expert || (int) $expert->id !== (int) $order->expert_id ) {
            wp_die( 'You are not the expert on this order.' );
        }
        if ( ! in_array( $order->status, array( NMEP_Orders::STATUS_COMPLETED, NMEP_Orders::STATUS_AUTO_RELEASED ), true ) ) {
            wp_die( 'You can only review the buyer after order completion.' );
        }

        global $wpdb;
        $table = NMEP_Database::table( 'buyer_reviews' );

        $existing = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM $table WHERE order_id = %d", $order_id ) );
        if ( $existing ) wp_die( 'You have already reviewed this buyer.' );

        $wpdb->insert( $table, array(
            'order_id'             => (int) $order_id,
            'expert_id'            => (int) $order->expert_id,
            'buyer_user_id'        => (int) $order->buyer_user_id,
            'buyer_email'          => $order->buyer_email,
            'rating'               => max( 1, min( 5, (int) ( $_POST['rating'] ?? 5 ) ) ),
            'communication_rating' => max( 1, min( 5, (int) ( $_POST['communication_rating'] ?? 5 ) ) ),
            'instructions_rating'  => max( 1, min( 5, (int) ( $_POST['instructions_rating'] ?? 5 ) ) ),
            'payment_rating'       => max( 1, min( 5, (int) ( $_POST['payment_rating'] ?? 5 ) ) ),
            'comment'              => sanitize_textarea_field( wp_unslash( $_POST['comment'] ?? '' ) ),
            'is_public'            => (int) (bool) ( $_POST['is_public'] ?? 0 ),
        ) );
        $review_id = (int) $wpdb->insert_id;

        NMEP_Events::emit( NMEP_Events::REVIEW_SUBMITTED, $review_id, $order->id, (int) $_POST['rating'] );
        wp_safe_redirect( wp_get_referer() ?: home_url( '/' ) );
        exit;
    }

    /* ============================================================
       REPORT ABUSE
       ============================================================ */

    public static function handle_report_review() {
        check_admin_referer( 'nmep_report_review' );
        $review_id = (int) ( $_POST['review_id'] ?? 0 );
        if ( ! $review_id ) wp_die( 'Invalid review.' );

        global $wpdb;
        $wpdb->insert( NMEP_Database::table( 'review_reports' ), array(
            'review_id'  => $review_id,
            'reported_by'=> get_current_user_id() ?: null,
            'reason'     => sanitize_text_field( $_POST['reason'] ?? 'inappropriate' ),
            'note'       => sanitize_textarea_field( wp_unslash( $_POST['note'] ?? '' ) ),
            'status'     => 'open',
        ) );

        // Auto-flag the review for admin attention after 3+ reports
        $count = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM " . NMEP_Database::table( 'review_reports' ) . " WHERE review_id = %d AND status = 'open'",
            $review_id
        ) );
        if ( $count >= 3 ) {
            $wpdb->update( NMEP_Database::table( 'reviews' ), array( 'is_flagged' => 1 ), array( 'id' => $review_id ) );
        }

        NMEP_Events::emit( NMEP_Events::REVIEW_REPORTED, $review_id, get_current_user_id() );
        wp_safe_redirect( add_query_arg( 'reported', 1, wp_get_referer() ?: home_url( '/' ) ) );
        exit;
    }

    /* ============================================================
       ADMIN MODERATION QUEUE
       ============================================================ */

    public static function register_menu() {
        add_submenu_page(
            'nmep-dashboard', 'Review Reports', 'Review Reports',
            'manage_options', 'nmep-review-reports', array( __CLASS__, 'render_moderation' )
        );
    }

    public static function render_moderation() {
        global $wpdb;
        $action    = sanitize_key( $_GET['nmep_action'] ?? '' );
        $report_id = (int) ( $_GET['report_id'] ?? 0 );

        if ( $report_id && $action && check_admin_referer( 'nmep_review_mod' ) ) {
            if ( $action === 'dismiss' ) {
                $wpdb->update( NMEP_Database::table( 'review_reports' ),
                    array( 'status' => 'dismissed', 'resolved_at' => current_time( 'mysql' ) ),
                    array( 'id' => $report_id ) );
            } elseif ( $action === 'remove_review' ) {
                $report = $wpdb->get_row( $wpdb->prepare(
                    "SELECT review_id FROM " . NMEP_Database::table( 'review_reports' ) . " WHERE id = %d", $report_id
                ) );
                if ( $report ) {
                    $wpdb->update( NMEP_Database::table( 'reviews' ),
                        array( 'status' => 'removed', 'is_flagged' => 1 ),
                        array( 'id' => (int) $report->review_id ) );
                    $wpdb->update( NMEP_Database::table( 'review_reports' ),
                        array( 'status' => 'actioned', 'resolved_at' => current_time( 'mysql' ) ),
                        array( 'review_id' => (int) $report->review_id ) );
                }
            }
        }

        $reports = $wpdb->get_results(
            "SELECT rr.*, r.comment, r.rating, r.buyer_name
             FROM " . NMEP_Database::table( 'review_reports' ) . " rr
             LEFT JOIN " . NMEP_Database::table( 'reviews' ) . " r ON r.id = rr.review_id
             WHERE rr.status = 'open'
             ORDER BY rr.created_at DESC LIMIT 100"
        );

        echo '<div class="wrap"><h1>Review Reports</h1>';
        if ( empty( $reports ) ) {
            echo '<p>No open reports.</p></div>';
            return;
        }
        echo '<table class="widefat striped"><thead><tr>';
        echo '<th>Reported</th><th>Review</th><th>Reason</th><th>Reported by</th><th>Actions</th>';
        echo '</tr></thead><tbody>';
        foreach ( $reports as $rr ) {
            $dismiss_url = wp_nonce_url( add_query_arg( array( 'page'=>'nmep-review-reports', 'nmep_action'=>'dismiss', 'report_id'=>$rr->id ) ), 'nmep_review_mod' );
            $remove_url  = wp_nonce_url( add_query_arg( array( 'page'=>'nmep-review-reports', 'nmep_action'=>'remove_review', 'report_id'=>$rr->id ) ), 'nmep_review_mod' );
            echo '<tr>';
            echo '<td>' . esc_html( $rr->created_at ) . '</td>';
            echo '<td><strong>' . esc_html( $rr->buyer_name ) . '</strong> (' . esc_html( $rr->rating ) . '★)<br>'
                . esc_html( wp_trim_words( (string) $rr->comment, 30 ) ) . '</td>';
            echo '<td>' . esc_html( $rr->reason ) . '<br><span class="muted">' . esc_html( wp_trim_words( (string) $rr->note, 20 ) ) . '</span></td>';
            echo '<td>' . ( $rr->reported_by ? '#' . (int) $rr->reported_by : 'guest' ) . '</td>';
            echo '<td><a class="button" href="' . esc_url( $dismiss_url ) . '">Dismiss</a> ';
            echo '<a class="button button-primary" href="' . esc_url( $remove_url ) . '">Remove review</a></td>';
            echo '</tr>';
        }
        echo '</tbody></table></div>';
    }
}
