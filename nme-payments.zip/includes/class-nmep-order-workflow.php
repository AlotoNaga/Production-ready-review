<?php
/**
 * NMEP_Order_Workflow
 * Order lifecycle actions:
 * - Expert: Mark delivered (with optional message + attachment URL)
 * - Buyer: Approve work (releases escrow immediately)
 * - Buyer: Request revision (sends back to expert)
 * - Buyer/Expert: Open dispute (handled by NMEP_Disputes)
 *
 * @version 1.3.0 (Batch D)
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class NMEP_Order_Workflow {

    public static function init() {
        // Expert actions (logged in)
        add_action( 'admin_post_nmep_mark_delivered', array( __CLASS__, 'handle_mark_delivered' ) );

        // Buyer actions (token-authenticated)
        add_action( 'admin_post_nopriv_nmep_approve_order', array( __CLASS__, 'handle_approve_order' ) );
        add_action( 'admin_post_nmep_approve_order',         array( __CLASS__, 'handle_approve_order' ) );

        add_action( 'admin_post_nopriv_nmep_request_revision', array( __CLASS__, 'handle_request_revision' ) );
        add_action( 'admin_post_nmep_request_revision',         array( __CLASS__, 'handle_request_revision' ) );
    }

    /* ============================================================
       EXPERT: MARK DELIVERED
       ============================================================ */

    public static function handle_mark_delivered() {
        if ( ! is_user_logged_in() ) wp_die( 'Login required.' );

        $order_id = isset( $_POST['order_id'] ) ? (int) $_POST['order_id'] : 0;
        if ( ! wp_verify_nonce( $_POST['_wpnonce'] ?? '', 'nmep_deliver_' . $order_id ) ) {
            wp_die( 'Invalid request.' );
        }

        $order = NMEP_Orders::get( $order_id );
        if ( ! $order ) wp_die( 'Order not found.' );

        // Verify expert owns this order
        $expert = NMEP_Compat::get_expert_by_user( get_current_user_id() );
        if ( ! $expert || (int) $expert->id !== (int) $order->expert_id ) {
            wp_die( 'Permission denied.' );
        }

        // Order must be paid + not yet delivered
        if ( ! in_array( $order->status, array( NMEP_Orders::STATUS_PAID, NMEP_Orders::STATUS_IN_PROGRESS, NMEP_Orders::STATUS_REVISION ), true ) ) {
            self::redirect_to_dashboard_with_error( 'This order cannot be marked as delivered in its current state.' );
            return;
        }

        $message = sanitize_textarea_field( $_POST['delivery_message'] ?? '' );
        $attachment_url = esc_url_raw( $_POST['attachment_url'] ?? '' );

        if ( empty( $message ) || strlen( $message ) < 10 ) {
            self::redirect_to_dashboard_with_error( 'Please write a delivery message (10+ characters).' );
            return;
        }

        $now = current_time( 'mysql' );

        // Update order
        NMEP_Orders::update( $order_id, array(
            'status'           => NMEP_Orders::STATUS_DELIVERED,
            'delivery_status'  => 'delivered',
            'delivered_at'     => $now,
        ) );

        // Save delivery message
        global $wpdb;
        $wpdb->insert( NMEP_Database::table( 'order_messages' ), array(
            'order_id'        => $order_id,
            'sender_user_id'  => get_current_user_id(),
            'sender_role'     => 'expert',
            'sender_name'     => $expert->full_name,
            'message'         => $message,
            'attachment_urls' => $attachment_url ? wp_json_encode( array( $attachment_url ) ) : null,
            'is_delivery'     => 1,
        ) );

        NMEP_Logger::info( 'Order delivered by expert', array( 'order_id' => $order_id ) );
        NMEP_Compat::audit_log( 'order_delivered', 'order', $order_id );

        // Send delivery email to buyer
        if ( class_exists( 'NMEP_Emails' ) ) {
            $order = NMEP_Orders::get( $order_id );
            NMEP_Emails::send_delivery_to_buyer( $order, $message, $attachment_url );
        }

        if ( class_exists( 'NMEP_Events' ) ) {
            NMEP_Events::emit( NMEP_Events::ORDER_DELIVERED, $order_id, $message, $attachment_url );
        } else {
            do_action( 'nmep_order_delivered', $order_id );
        }

        $url = add_query_arg( array(
            'edit_service' => 0, // back to dashboard home
            'nmep_status'  => 'success',
            'nmep_msg'     => urlencode( 'Order marked as delivered. The buyer has been notified.' ),
        ), nmep_get_page_url( 'expert-dashboard' ) );

        wp_safe_redirect( $url );
        exit;
    }

    /* ============================================================
       BUYER: APPROVE ORDER
       ============================================================ */

    public static function handle_approve_order() {
        $order_id = isset( $_POST['order_id'] ) ? (int) $_POST['order_id'] : 0;
        $token    = sanitize_text_field( $_POST['token'] ?? '' );

        if ( ! wp_verify_nonce( $_POST['_wpnonce'] ?? '', 'nmep_approve_' . $order_id ) ) {
            wp_die( 'Invalid request.' );
        }

        $order = NMEP_Orders::get( $order_id );
        if ( ! $order || $order->view_token !== $token ) {
            wp_die( 'Permission denied.' );
        }

        // Order must be delivered
        if ( $order->status !== NMEP_Orders::STATUS_DELIVERED ) {
            self::redirect_to_track_with_error( $order, 'This order is not in a state to be approved.' );
            return;
        }

        $now = current_time( 'mysql' );

        NMEP_Orders::update( $order_id, array(
            'status'      => NMEP_Orders::STATUS_COMPLETED,
            'approved_at' => $now,
        ) );

        NMEP_Logger::info( 'Order approved by buyer — releasing escrow', array( 'order_id' => $order_id ) );
        NMEP_Compat::audit_log( 'order_approved_by_buyer', 'order', $order_id );

        // Release escrow immediately (+ fire high-level completed event)
        do_action( 'nmep_after_order_approved', $order_id );
        if ( class_exists( 'NMEP_Events' ) ) {
            NMEP_Events::emit( NMEP_Events::ORDER_COMPLETED, $order_id, 'buyer_approved' );
        }

        self::redirect_to_track_with_success( $order, '🎉 Order approved! The expert has been paid. Thank you for using Nagaland Me Experts.' );
    }

    /* ============================================================
       BUYER: REQUEST REVISION
       ============================================================ */

    public static function handle_request_revision() {
        $order_id = isset( $_POST['order_id'] ) ? (int) $_POST['order_id'] : 0;
        $token    = sanitize_text_field( $_POST['token'] ?? '' );

        if ( ! wp_verify_nonce( $_POST['_wpnonce'] ?? '', 'nmep_revision_' . $order_id ) ) {
            wp_die( 'Invalid request.' );
        }

        $order = NMEP_Orders::get( $order_id );
        if ( ! $order || $order->view_token !== $token ) {
            wp_die( 'Permission denied.' );
        }

        if ( $order->status !== NMEP_Orders::STATUS_DELIVERED ) {
            self::redirect_to_track_with_error( $order, 'You can only request revisions on delivered orders.' );
            return;
        }

        // Check revision limit
        if ( $order->revisions_used >= $order->revisions_allowed ) {
            self::redirect_to_track_with_error( $order, 'You have used all ' . $order->revisions_allowed . ' revisions. Please approve or open a dispute.' );
            return;
        }

        $message = sanitize_textarea_field( $_POST['revision_message'] ?? '' );
        if ( empty( $message ) || strlen( $message ) < 10 ) {
            self::redirect_to_track_with_error( $order, 'Please describe what needs to be revised (10+ characters).' );
            return;
        }

        // Update order
        NMEP_Orders::update( $order_id, array(
            'status'         => NMEP_Orders::STATUS_REVISION,
            'revisions_used' => (int) $order->revisions_used + 1,
        ) );

        // Save revision message
        global $wpdb;
        $wpdb->insert( NMEP_Database::table( 'order_messages' ), array(
            'order_id'       => $order_id,
            'sender_user_id' => is_user_logged_in() ? get_current_user_id() : null,
            'sender_role'    => 'buyer',
            'sender_name'    => $order->buyer_name,
            'message'        => $message,
            'is_revision_request' => 1,
        ) );

        NMEP_Logger::info( 'Revision requested by buyer', array(
            'order_id'        => $order_id,
            'revisions_used'  => $order->revisions_used + 1,
            'revisions_total' => $order->revisions_allowed,
        ) );

        NMEP_Compat::audit_log( 'revision_requested', 'order', $order_id );

        // Notify expert
        if ( class_exists( 'NMEP_Emails' ) ) {
            $order = NMEP_Orders::get( $order_id );
            NMEP_Emails::send_revision_request( $order, $message );
        }

        if ( class_exists( 'NMEP_Events' ) ) {
            NMEP_Events::emit( NMEP_Events::ORDER_IN_REVISION, $order_id, $message );
        }

        self::redirect_to_track_with_success( $order, 'Revision requested. The expert has been notified and will respond shortly.' );
    }

    /* ============================================================
       HELPERS
       ============================================================ */

    private static function redirect_to_track_with_success( $order, $message ) {
        $url = add_query_arg( array(
            'order'       => $order->order_number,
            'token'       => $order->view_token,
            'nmep_status' => 'success',
            'nmep_msg'    => urlencode( $message ),
        ), nmep_get_page_url( 'order-track' ) );
        wp_safe_redirect( $url );
        exit;
    }

    private static function redirect_to_track_with_error( $order, $message ) {
        $url = add_query_arg( array(
            'order'       => $order->order_number,
            'token'       => $order->view_token,
            'nmep_status' => 'error',
            'nmep_msg'    => urlencode( $message ),
        ), nmep_get_page_url( 'order-track' ) );
        wp_safe_redirect( $url );
        exit;
    }

    private static function redirect_to_dashboard_with_error( $message ) {
        $url = add_query_arg( array(
            'nmep_status' => 'error',
            'nmep_msg'    => urlencode( $message ),
        ), nmep_get_page_url( 'expert-dashboard' ) );
        wp_safe_redirect( $url );
        exit;
    }
}
