<?php
/**
 * NMEP Photo Upload Handler
 *
 * AJAX endpoint for service cover image uploads.
 * - Accepts JPG/PNG only (no other formats)
 * - 5MB max file size
 * - Auto-resizes to max 1280x720 (preserves aspect ratio)
 * - Auto-stores in WordPress Media Library
 * - Returns URL for use in service form
 *
 * @version 1.5.4
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class NMEP_Uploads {

    const MAX_FILE_SIZE_BYTES = 5242880; // 5MB
    const MAX_WIDTH  = 1280;
    const MAX_HEIGHT = 720;
    const ALLOWED_MIMES = array( 'image/jpeg', 'image/png' );

    public static function init() {
        // AJAX endpoint (logged-in users only — must be an approved expert)
        add_action( 'wp_ajax_nmep_upload_cover', array( __CLASS__, 'handle_cover_upload' ) );
    }

    /**
     * AJAX handler: receive uploaded photo, resize, save to Media Library
     * Returns JSON: { success: true, url: '...', attachment_id: 123 }
     *           or: { success: false, message: '...' }
     */
    public static function handle_cover_upload() {
        // Security: nonce check
        if ( ! check_ajax_referer( 'nmep_upload_cover', 'nonce', false ) ) {
            wp_send_json_error( array( 'message' => 'Security check failed. Please refresh the page and try again.' ) );
        }

        // User must be logged in
        if ( ! is_user_logged_in() ) {
            wp_send_json_error( array( 'message' => 'You must be logged in.' ) );
        }

        // User must be an approved expert
        $expert = NMEP_Compat::get_expert_by_user( get_current_user_id() );
        if ( ! $expert || $expert->status !== 'approved' ) {
            wp_send_json_error( array( 'message' => 'Only approved experts can upload service photos.' ) );
        }

        // File present?
        if ( empty( $_FILES['cover_image'] ) || ! is_uploaded_file( $_FILES['cover_image']['tmp_name'] ) ) {
            wp_send_json_error( array( 'message' => 'No file uploaded.' ) );
        }

        $file = $_FILES['cover_image'];

        // Check upload error
        if ( $file['error'] !== UPLOAD_ERR_OK ) {
            wp_send_json_error( array( 'message' => self::get_upload_error_message( $file['error'] ) ) );
        }

        // Size check
        if ( $file['size'] > self::MAX_FILE_SIZE_BYTES ) {
            wp_send_json_error( array( 'message' => 'Photo must be under 5MB. Yours was ' . self::format_size( $file['size'] ) . '.' ) );
        }

        // MIME type check (real check, not just extension)
        $finfo = finfo_open( FILEINFO_MIME_TYPE );
        $mime  = finfo_file( $finfo, $file['tmp_name'] );
        finfo_close( $finfo );

        if ( ! in_array( $mime, self::ALLOWED_MIMES, true ) ) {
            wp_send_json_error( array( 'message' => 'Only JPG and PNG photos allowed. Your file is: ' . esc_html( $mime ) ) );
        }

        // Validate it's actually an image
        $image_info = @getimagesize( $file['tmp_name'] );
        if ( ! $image_info || ! in_array( $image_info[2], array( IMAGETYPE_JPEG, IMAGETYPE_PNG ), true ) ) {
            wp_send_json_error( array( 'message' => 'File is not a valid image.' ) );
        }

        // Required WordPress files for media handling
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';
        require_once ABSPATH . 'wp-admin/includes/media.php';

        // Move to uploads with WordPress's safe handling
        $upload_overrides = array(
            'test_form' => false,
            'mimes'     => array(
                'jpg|jpeg' => 'image/jpeg',
                'png'      => 'image/png',
            ),
        );

        $movefile = wp_handle_upload( $file, $upload_overrides );

        if ( ! $movefile || isset( $movefile['error'] ) ) {
            $err = $movefile['error'] ?? 'Could not save file. Please try again.';
            NMEP_Logger::error( 'Cover upload failed', array( 'error' => $err, 'expert_id' => $expert->id ) );
            wp_send_json_error( array( 'message' => $err ) );
        }

        // Resize if larger than max dimensions
        $resized = self::maybe_resize_image( $movefile['file'] );
        if ( $resized ) {
            // Update file info if it was resized
            $movefile['file'] = $resized['path'];
            $movefile['url']  = $resized['url'];
        }

        // Insert as attachment in Media Library
        $attachment = array(
            'post_mime_type' => $movefile['type'],
            'post_title'     => 'Service cover by ' . $expert->full_name . ' - ' . current_time( 'mysql' ),
            'post_content'   => '',
            'post_status'    => 'inherit',
            'post_author'    => get_current_user_id(),
        );

        $attachment_id = wp_insert_attachment( $attachment, $movefile['file'] );
        if ( is_wp_error( $attachment_id ) ) {
            NMEP_Logger::error( 'Attachment insert failed', array( 'error' => $attachment_id->get_error_message() ) );
            wp_send_json_error( array( 'message' => 'Could not save to Media Library.' ) );
        }

        // Generate WordPress thumbnails
        $attach_data = wp_generate_attachment_metadata( $attachment_id, $movefile['file'] );
        wp_update_attachment_metadata( $attachment_id, $attach_data );

        NMEP_Logger::info( 'Service cover uploaded', array(
            'expert_id'     => $expert->id,
            'attachment_id' => $attachment_id,
            'url'           => $movefile['url'],
        ) );

        wp_send_json_success( array(
            'url'           => $movefile['url'],
            'attachment_id' => $attachment_id,
            'message'       => 'Photo uploaded successfully!',
        ) );
    }

    /**
     * Resize image if larger than MAX_WIDTH x MAX_HEIGHT (preserves aspect ratio)
     * Returns array with 'path' and 'url' OR false if no resize needed
     */
    private static function maybe_resize_image( $file_path ) {
        $info = @getimagesize( $file_path );
        if ( ! $info ) return false;

        $width  = $info[0];
        $height = $info[1];

        // Already small enough? Skip resize.
        if ( $width <= self::MAX_WIDTH && $height <= self::MAX_HEIGHT ) {
            return false;
        }

        // Use WordPress's image editor (handles GD or Imagick automatically)
        $editor = wp_get_image_editor( $file_path );
        if ( is_wp_error( $editor ) ) {
            NMEP_Logger::error( 'Image editor failed', array( 'error' => $editor->get_error_message() ) );
            return false;
        }

        // Resize preserving aspect ratio
        $resize_result = $editor->resize( self::MAX_WIDTH, self::MAX_HEIGHT, false );
        if ( is_wp_error( $resize_result ) ) {
            return false;
        }

        // Save back to same path (overwrites original)
        $saved = $editor->save( $file_path );
        if ( is_wp_error( $saved ) ) {
            return false;
        }

        // Return the URL based on uploads dir
        $upload_dir = wp_upload_dir();
        $url = str_replace( $upload_dir['basedir'], $upload_dir['baseurl'], $saved['path'] );

        return array(
            'path' => $saved['path'],
            'url'  => $url,
        );
    }

    /**
     * Convert PHP upload error code to friendly message
     */
    private static function get_upload_error_message( $code ) {
        switch ( $code ) {
            case UPLOAD_ERR_INI_SIZE:
            case UPLOAD_ERR_FORM_SIZE:
                return 'File is too large. Maximum 5MB.';
            case UPLOAD_ERR_PARTIAL:
                return 'Upload was interrupted. Please try again.';
            case UPLOAD_ERR_NO_FILE:
                return 'No file was uploaded.';
            case UPLOAD_ERR_NO_TMP_DIR:
            case UPLOAD_ERR_CANT_WRITE:
                return 'Server error: cannot save file. Contact support.';
            case UPLOAD_ERR_EXTENSION:
                return 'File type blocked by server.';
            default:
                return 'Unknown upload error. Please try again.';
        }
    }

    /**
     * Format byte size as human-readable
     */
    private static function format_size( $bytes ) {
        if ( $bytes >= 1048576 ) {
            return round( $bytes / 1048576, 1 ) . 'MB';
        }
        if ( $bytes >= 1024 ) {
            return round( $bytes / 1024 ) . 'KB';
        }
        return $bytes . 'B';
    }
}
