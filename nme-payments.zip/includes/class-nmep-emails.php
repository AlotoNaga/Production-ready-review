<?php
/**
 * NMEP_Emails
 * Transactional emails for the marketplace.
 *
 * @version 1.2.0 (Batch C)
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class NMEP_Emails {

    /* ============================================================
       HEADERS & FROM
       ============================================================ */

    private static function from_header() {
        $support = NMEP_Settings::get( 'support_email', 'info@nagaland.me' );
        $name    = NMEP_Settings::get( 'merchant_name', 'Nagaland Me Experts' );
        return array(
            'From: ' . $name . ' <' . $support . '>',
            'Content-Type: text/html; charset=UTF-8',
            'Reply-To: ' . $support,
        );
    }

    /**
     * Wrap content in a branded HTML template
     */
    private static function wrap( $title, $body_html, $cta_text = '', $cta_url = '' ) {
        $merchant   = NMEP_Settings::get( 'merchant_name', 'Nagaland Me Experts' );
        $support    = NMEP_Settings::get( 'support_email', 'info@nagaland.me' );
        $logo_url   = NMEP_Settings::get( 'logo_url', '' );
        $color      = NMEP_Settings::get( 'theme_color', '#0F2419' );
        $year       = date( 'Y' );
        $home_url   = home_url();

        $cta_html = '';
        if ( $cta_text && $cta_url ) {
            $cta_html = '<table cellpadding="0" cellspacing="0" border="0" style="margin:24px auto;"><tr><td style="background:#D4A843;border-radius:50px;"><a href="' . esc_url( $cta_url ) . '" style="display:inline-block;padding:14px 32px;color:' . esc_attr( $color ) . ';text-decoration:none;font-weight:700;font-family:Arial,sans-serif;">' . esc_html( $cta_text ) . '</a></td></tr></table>';
        }

        $logo_html = '';
        if ( $logo_url ) {
            $logo_html = '<img src="' . esc_url( $logo_url ) . '" alt="' . esc_attr( $merchant ) . '" style="max-height:50px;display:block;margin:0 auto;">';
        } else {
            $logo_html = '<div style="font-size:1.5rem;font-weight:700;color:' . esc_attr( $color ) . ';font-family:Georgia,serif;">' . esc_html( $merchant ) . '</div>';
        }

        return '<!DOCTYPE html>
<html><head><meta charset="UTF-8"><title>' . esc_html( $title ) . '</title></head>
<body style="margin:0;padding:0;background:#F5F2E8;font-family:Arial,Helvetica,sans-serif;color:#1F2937;">
    <table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:#F5F2E8;padding:30px 20px;">
        <tr><td align="center">
            <table width="600" cellpadding="0" cellspacing="0" border="0" style="max-width:600px;background:#FFFFFF;border-radius:12px;overflow:hidden;box-shadow:0 4px 12px rgba(0,0,0,0.05);">
                <tr><td style="background:' . esc_attr( $color ) . ';padding:24px;text-align:center;">
                    <a href="' . esc_url( $home_url ) . '" style="text-decoration:none;color:#fff;">' . $logo_html . '</a>
                </td></tr>
                <tr><td style="padding:32px 28px;">
                    <h1 style="color:' . esc_attr( $color ) . ';font-family:Georgia,serif;font-size:24px;margin:0 0 16px;">' . esc_html( $title ) . '</h1>
                    <div style="font-size:15px;line-height:1.6;color:#374151;">' . $body_html . '</div>
                    ' . $cta_html . '
                </td></tr>
                <tr><td style="background:#F9FAFB;padding:20px 28px;border-top:1px solid #E5E7EB;text-align:center;font-size:13px;color:#6B7280;">
                    <p style="margin:0 0 6px;">Need help? Email us at <a href="mailto:' . esc_attr( $support ) . '" style="color:' . esc_attr( $color ) . ';">' . esc_html( $support ) . '</a></p>
                    <p style="margin:0;">© ' . $year . ' ' . esc_html( $merchant ) . ' — <a href="' . esc_url( $home_url ) . '" style="color:#6B7280;">' . esc_html( str_replace( array( 'https://', 'http://', 'www.' ), '', $home_url ) ) . '</a></p>
                </td></tr>
            </table>
        </td></tr>
    </table>
</body></html>';
    }

    /**
     * Render an order summary table (used in multiple emails)
     */
    private static function render_order_summary_table( $order ) {
        $thank_you_url = add_query_arg( array(
            'order_id' => $order->id,
            'token'    => $order->view_token,
        ), nmep_get_page_url( 'order-thank-you' ) );

        return '<table width="100%" cellpadding="10" cellspacing="0" border="0" style="background:#F9FAFB;border-radius:8px;margin:16px 0;font-size:14px;">
            <tr><td style="padding:8px 12px;color:#6B7280;width:50%;">Order Number:</td><td style="padding:8px 12px;color:#0F2419;font-weight:600;text-align:right;font-family:monospace;">' . esc_html( $order->order_number ) . '</td></tr>
            <tr><td style="padding:8px 12px;color:#6B7280;">Service:</td><td style="padding:8px 12px;color:#0F2419;font-weight:600;text-align:right;">' . esc_html( $order->service_title ) . '</td></tr>
            <tr><td style="padding:8px 12px;color:#6B7280;">Package:</td><td style="padding:8px 12px;color:#0F2419;font-weight:600;text-align:right;">' . esc_html( $order->package_title ) . '</td></tr>
            <tr><td style="padding:8px 12px;color:#6B7280;">Amount Paid:</td><td style="padding:8px 12px;color:#10B981;font-weight:700;text-align:right;font-size:16px;">' . nmep_format_inr( $order->gross_amount ) . '</td></tr>
            <tr><td style="padding:8px 12px;color:#6B7280;">Delivery in:</td><td style="padding:8px 12px;color:#0F2419;font-weight:600;text-align:right;">' . (int) $order->delivery_days . ' days</td></tr>
            <tr><td style="padding:8px 12px;color:#6B7280;">Revisions:</td><td style="padding:8px 12px;color:#0F2419;font-weight:600;text-align:right;">' . (int) $order->revisions_allowed . '</td></tr>
        </table>';
    }

    /* ============================================================
       BUYER EMAILS
       ============================================================ */

    /**
     * Send order confirmation to buyer
     */
    public static function send_order_confirmation( $order ) {
        if ( ! $order || empty( $order->buyer_email ) ) return false;

        $thank_you_url = add_query_arg( array(
            'order_id' => $order->id,
            'token'    => $order->view_token,
        ), nmep_get_page_url( 'order-thank-you' ) );

        $body = '<p>Hi <strong>' . esc_html( $order->buyer_name ) . '</strong>,</p>
        <p>Thank you for your order on <strong>Nagaland Me Experts</strong>! Your payment was successful and the expert has been notified.</p>
        ' . self::render_order_summary_table( $order ) . '
        <h3 style="color:#0F2419;margin-top:24px;">What happens next?</h3>
        <ol style="color:#374151;line-height:1.8;">
            <li>Your payment is held in <strong>secure escrow</strong> — the expert only gets paid after you approve their work.</li>
            <li>The expert will start working on your order and deliver within <strong>' . (int) $order->delivery_days . ' days</strong>.</li>
            <li>You will receive an email when the work is delivered.</li>
            <li>You can request up to <strong>' . (int) $order->revisions_allowed . ' revisions</strong> before approving.</li>
        </ol>
        <p>You can track your order anytime using the link below.</p>';

        $subject = 'Order Confirmed — ' . $order->order_number . ' — ' . NMEP_Settings::get( 'merchant_name', 'Nagaland Me Experts' );
        $html = self::wrap( 'Order Confirmed!', $body, 'Track Your Order', $thank_you_url );

        $sent = wp_mail( $order->buyer_email, $subject, $html, self::from_header() );

        NMEP_Logger::info( 'Order confirmation email sent to buyer', array(
            'order_id' => $order->id,
            'email'    => $order->buyer_email,
            'sent'     => $sent,
        ) );

        return $sent;
    }

    /* ============================================================
       EXPERT EMAILS
       ============================================================ */

    /**
     * Send notification to expert that they have a new order
     */
    public static function send_payment_received_to_expert( $order ) {
        if ( ! $order ) return false;

        $expert = NMEP_Compat::get_expert( $order->expert_id );
        if ( ! $expert || empty( $expert->email ) ) return false;

        $dashboard_url = nmep_get_page_url( 'expert-dashboard', '/expert-dashboard/' );

        $body = '<p>Hi <strong>' . esc_html( $expert->full_name ) . '</strong>,</p>
        <p>🎉 Great news! You have received a new order on <strong>Nagaland Me Experts</strong>.</p>
        <table width="100%" cellpadding="10" cellspacing="0" border="0" style="background:#F9FAFB;border-radius:8px;margin:16px 0;font-size:14px;">
            <tr><td style="padding:8px 12px;color:#6B7280;width:50%;">Order Number:</td><td style="padding:8px 12px;color:#0F2419;font-weight:600;text-align:right;font-family:monospace;">' . esc_html( $order->order_number ) . '</td></tr>
            <tr><td style="padding:8px 12px;color:#6B7280;">Service:</td><td style="padding:8px 12px;color:#0F2419;font-weight:600;text-align:right;">' . esc_html( $order->service_title ) . '</td></tr>
            <tr><td style="padding:8px 12px;color:#6B7280;">Package:</td><td style="padding:8px 12px;color:#0F2419;font-weight:600;text-align:right;">' . esc_html( $order->package_title ) . '</td></tr>
            <tr><td style="padding:8px 12px;color:#6B7280;">Order Total:</td><td style="padding:8px 12px;color:#0F2419;font-weight:600;text-align:right;">' . nmep_format_inr( $order->gross_amount ) . '</td></tr>
            <tr><td style="padding:8px 12px;color:#10B981;font-weight:700;">Your Earnings:</td><td style="padding:8px 12px;color:#10B981;font-weight:700;text-align:right;font-size:16px;">' . nmep_format_inr( $order->expert_amount ) . '</td></tr>
            <tr><td style="padding:8px 12px;color:#6B7280;">Delivery Due:</td><td style="padding:8px 12px;color:#0F2419;font-weight:600;text-align:right;">' . esc_html( date( 'd M Y', strtotime( $order->delivery_due_at ) ) ) . '</td></tr>
        </table>
        <h3 style="color:#0F2419;margin-top:24px;">Buyer Info:</h3>
        <p>
            <strong>Name:</strong> ' . esc_html( $order->buyer_name ) . '<br>
            <strong>Email:</strong> ' . esc_html( $order->buyer_email ) . '<br>
            <strong>Phone:</strong> ' . esc_html( $order->buyer_phone ) . '
        </p>';

        if ( ! empty( $order->buyer_requirements ) ) {
            $body .= '<h3 style="color:#0F2419;margin-top:24px;">Buyer Requirements:</h3>
            <div style="background:#FFFBEB;border-left:4px solid #D4A843;padding:16px;margin:8px 0;border-radius:8px;">
                <p style="margin:0;white-space:pre-line;">' . esc_html( $order->buyer_requirements ) . '</p>
            </div>';
        }

        $body .= '<h3 style="color:#0F2419;margin-top:24px;">Important:</h3>
        <ul style="color:#374151;line-height:1.8;">
            <li>The buyer\'s payment is held in <strong>escrow</strong>.</li>
            <li>You receive your earnings <strong>5 days after delivery</strong> (or immediately on buyer approval).</li>
            <li>Please deliver the work within <strong>' . (int) $order->delivery_days . ' days</strong>.</li>
            <li>Maintain quality and communicate proactively.</li>
        </ul>';

        $subject = '🎉 New Order: ' . $order->order_number . ' (' . nmep_format_inr( $order->expert_amount ) . ')';
        $html = self::wrap( 'New Order Received!', $body, 'Open Dashboard', $dashboard_url );

        $sent = wp_mail( $expert->email, $subject, $html, self::from_header() );

        NMEP_Logger::info( 'New order email sent to expert', array(
            'order_id'  => $order->id,
            'expert_id' => $order->expert_id,
            'email'     => $expert->email,
            'sent'      => $sent,
        ) );

        return $sent;
    }

    /**
     * Notify expert their service was approved (Batch B integration)
     */
    public static function send_service_approved( $service ) {
        if ( ! $service ) return false;

        $expert = NMEP_Compat::get_expert( $service->expert_id );
        if ( ! $expert || empty( $expert->email ) ) return false;

        $service_url = home_url( '/service/' . $service->slug . '/' );
        $dashboard_url = nmep_get_page_url( 'expert-dashboard', '/expert-dashboard/' );

        $body = '<p>Hi <strong>' . esc_html( $expert->full_name ) . '</strong>,</p>
        <p>✅ Your service "<strong>' . esc_html( $service->title ) . '</strong>" has been approved and is now <strong>live</strong> on Nagaland Me Experts!</p>
        <p>Buyers can now find and order your service. Make sure your dashboard is open so you can respond quickly when orders come in.</p>
        <table width="100%" cellpadding="10" cellspacing="0" border="0" style="background:#F0FDF4;border-radius:8px;margin:16px 0;border-left:4px solid #10B981;">
            <tr><td style="padding:12px;color:#065F46;font-size:14px;">
                <strong>Service:</strong> ' . esc_html( $service->title ) . '<br>
                <strong>Starting price:</strong> ' . nmep_format_inr( $service->basic_price ) . '<br>
                <strong>Public URL:</strong> <a href="' . esc_url( $service_url ) . '" style="color:#10B981;">' . esc_html( $service_url ) . '</a>
            </td></tr>
        </table>
        <h3 style="color:#0F2419;">Tips to get your first order:</h3>
        <ul style="color:#374151;line-height:1.8;">
            <li>Share your service link on social media</li>
            <li>Message your existing audience</li>
            <li>Post in relevant Naga creator groups</li>
            <li>Respond to inquiries within 1 hour</li>
        </ul>';

        $subject = '✅ Service Approved: ' . $service->title;
        $html = self::wrap( 'Your Service is Live!', $body, 'View Dashboard', $dashboard_url );

        return wp_mail( $expert->email, $subject, $html, self::from_header() );
    }

    /**
     * Notify expert their service was rejected
     */
    public static function send_service_rejected( $service, $reason ) {
        if ( ! $service ) return false;

        $expert = NMEP_Compat::get_expert( $service->expert_id );
        if ( ! $expert || empty( $expert->email ) ) return false;

        $dashboard_url = nmep_get_page_url( 'expert-dashboard', '/expert-dashboard/' );

        $body = '<p>Hi <strong>' . esc_html( $expert->full_name ) . '</strong>,</p>
        <p>Your service "<strong>' . esc_html( $service->title ) . '</strong>" needs some changes before we can approve it.</p>
        <h3 style="color:#0F2419;">Reason:</h3>
        <div style="background:#FEF2F2;border-left:4px solid #EF4444;padding:16px;margin:8px 0;border-radius:8px;">
            <p style="margin:0;color:#991B1B;">' . nl2br( esc_html( $reason ) ) . '</p>
        </div>
        <p>Please make the requested changes and re-submit. We will review again within 24-48 hours.</p>';

        $subject = 'Service Needs Updates: ' . $service->title;
        $html = self::wrap( 'Update Required', $body, 'Edit Service', $dashboard_url );

        return wp_mail( $expert->email, $subject, $html, self::from_header() );
    }

    /* ============================================================
       ADMIN EMAILS
       ============================================================ */

    /**
     * Notify admin of a new order (high priority)
     */
    public static function send_admin_new_order( $order ) {
        if ( ! $order ) return false;

        $admin_email = get_option( 'admin_email' );
        $admin_orders_url = admin_url( 'admin.php?page=nmep-orders' );

        $body = '<p>A new order has been placed.</p>
        ' . self::render_order_summary_table( $order ) . '
        <p><strong>Buyer:</strong> ' . esc_html( $order->buyer_name ) . ' (' . esc_html( $order->buyer_email ) . ')</p>
        <p>View it in your admin panel.</p>';

        $subject = '[NMEX] New Order ' . $order->order_number . ' — ' . nmep_format_inr( $order->gross_amount );
        $html = self::wrap( 'New Order Received', $body, 'View in Admin', $admin_orders_url );

        return wp_mail( $admin_email, $subject, $html, self::from_header() );
    }

    /* ============================================================
       BATCH D EMAILS — DELIVERY / REVISION / COMPLETION / REFUND / DISPUTE
       ============================================================ */

    /**
     * Notify buyer that expert delivered the work
     */
    public static function send_delivery_to_buyer( $order, $delivery_message = '', $attachment_url = '' ) {
        if ( ! $order || empty( $order->buyer_email ) ) return false;

        $expert = NMEP_Compat::get_expert( $order->expert_id );
        $expert_name = $expert ? $expert->full_name : 'The expert';

        $track_url = add_query_arg( array(
            'order' => $order->order_number,
            'token' => $order->view_token,
        ), nmep_get_page_url( 'order-track' ) );

        $auto_release_days = (int) NMEP_Settings::get( 'auto_release_days', 5 );

        $body = '<p>Hi <strong>' . esc_html( $order->buyer_name ) . '</strong>,</p>
        <p>📦 Great news! <strong>' . esc_html( $expert_name ) . '</strong> has delivered your order.</p>';

        if ( $delivery_message ) {
            $body .= '<h3 style="color:#0F2419;margin-top:24px;">Delivery Note from Expert:</h3>
            <div style="background:#F0FDF4;border-left:4px solid #10B981;padding:16px;margin:8px 0;border-radius:8px;">
                <p style="margin:0;white-space:pre-line;color:#065F46;">' . esc_html( $delivery_message ) . '</p>
            </div>';
        }

        if ( $attachment_url ) {
            $body .= '<p><strong>Files:</strong> <a href="' . esc_url( $attachment_url ) . '" style="color:#10B981;">' . esc_html( $attachment_url ) . '</a></p>';
        }

        $body .= '<h3 style="color:#0F2419;margin-top:24px;">What to do next:</h3>
        <ol style="color:#374151;line-height:1.8;">
            <li><strong>Review the work</strong> carefully.</li>
            <li>If satisfied → click <strong>"Approve & Release Payment"</strong> to release funds to the expert.</li>
            <li>If you need changes → click <strong>"Request Revision"</strong> (you have ' . (int) ( $order->revisions_allowed - $order->revisions_used ) . ' revisions left).</li>
            <li>If not done in <strong>' . $auto_release_days . ' days</strong>, payment will auto-release to the expert.</li>
        </ol>';

        $subject = '📦 Work Delivered — ' . $order->order_number;
        $html = self::wrap( 'Your Order is Ready!', $body, 'Review Delivery', $track_url );

        $sent = wp_mail( $order->buyer_email, $subject, $html, self::from_header() );

        NMEP_Logger::info( 'Delivery email sent to buyer', array(
            'order_id' => $order->id,
            'sent'     => $sent,
        ) );

        return $sent;
    }

    /**
     * Notify expert that buyer requested revision
     */
    public static function send_revision_request( $order, $revision_message = '' ) {
        if ( ! $order ) return false;

        $expert = NMEP_Compat::get_expert( $order->expert_id );
        if ( ! $expert || empty( $expert->email ) ) return false;

        $dashboard_url = nmep_get_page_url( 'expert-dashboard' );

        $body = '<p>Hi <strong>' . esc_html( $expert->full_name ) . '</strong>,</p>
        <p>The buyer for order <strong>' . esc_html( $order->order_number ) . '</strong> has requested a revision.</p>
        <p>Revisions used: <strong>' . (int) $order->revisions_used . ' of ' . (int) $order->revisions_allowed . '</strong></p>';

        if ( $revision_message ) {
            $body .= '<h3 style="color:#0F2419;margin-top:24px;">What the Buyer Says:</h3>
            <div style="background:#FFFBEB;border-left:4px solid #D4A843;padding:16px;margin:8px 0;border-radius:8px;">
                <p style="margin:0;white-space:pre-line;">' . esc_html( $revision_message ) . '</p>
            </div>';
        }

        $body .= '<p>Please make the requested changes and re-deliver via your dashboard.</p>';

        $subject = '🔄 Revision Requested — ' . $order->order_number;
        $html = self::wrap( 'Revision Requested', $body, 'Open Dashboard', $dashboard_url );

        return wp_mail( $expert->email, $subject, $html, self::from_header() );
    }

    /**
     * Notify expert that buyer approved + funds released
     */
    public static function send_order_completed( $order ) {
        if ( ! $order ) return false;

        $expert = NMEP_Compat::get_expert( $order->expert_id );
        if ( ! $expert || empty( $expert->email ) ) return false;

        $dashboard_url = nmep_get_page_url( 'expert-dashboard' );
        $reason_text = ! empty( $order->released_at ) && empty( $order->approved_at )
            ? 'Auto-released after the holding period'
            : 'Buyer approved your work';

        $body = '<p>Hi <strong>' . esc_html( $expert->full_name ) . '</strong>,</p>
        <p>🎉 Excellent! Your earnings for order <strong>' . esc_html( $order->order_number ) . '</strong> have been released.</p>
        <p><em>' . esc_html( $reason_text ) . '</em></p>
        <table width="100%" cellpadding="10" cellspacing="0" border="0" style="background:#F0FDF4;border-radius:8px;margin:16px 0;font-size:14px;">
            <tr><td style="padding:8px 12px;color:#065F46;">Order:</td><td style="padding:8px 12px;color:#065F46;text-align:right;font-family:monospace;">' . esc_html( $order->order_number ) . '</td></tr>
            <tr><td style="padding:8px 12px;color:#065F46;">Service:</td><td style="padding:8px 12px;color:#065F46;text-align:right;">' . esc_html( $order->service_title ) . '</td></tr>
            <tr><td style="padding:8px 12px;color:#10B981;font-weight:700;font-size:16px;">Released to your account:</td><td style="padding:8px 12px;color:#10B981;font-weight:700;text-align:right;font-size:18px;">' . nmep_format_inr( $order->expert_amount ) . '</td></tr>
        </table>
        <p>Funds will arrive in your bank account within 1-3 business days as per Razorpay\'s settlement schedule.</p>';

        // Also notify buyer of completion
        if ( ! empty( $order->buyer_email ) ) {
            $buyer_body = '<p>Hi <strong>' . esc_html( $order->buyer_name ) . '</strong>,</p>
            <p>✅ Your order <strong>' . esc_html( $order->order_number ) . '</strong> has been marked as completed. The expert has been paid.</p>
            <p>Thank you for using <strong>Nagaland Me Experts</strong>! We hope you had a great experience.</p>
            <p>If you have a moment, we would love your feedback to help other buyers (review feature coming soon).</p>';

            wp_mail(
                $order->buyer_email,
                '✅ Order Completed — ' . $order->order_number,
                self::wrap( 'Order Completed!', $buyer_body, 'Browse More Services', home_url( '/services/' ) ),
                self::from_header()
            );
        }

        $subject = '💰 Payment Released — ' . nmep_format_inr( $order->expert_amount ) . ' (' . $order->order_number . ')';
        $html = self::wrap( 'Payment Released!', $body, 'Open Dashboard', $dashboard_url );

        return wp_mail( $expert->email, $subject, $html, self::from_header() );
    }

    /**
     * Refund confirmation
     */
    public static function send_refund_confirmation( $order, $refund ) {
        if ( ! $order || ! $refund ) return false;

        $is_full = $refund->refund_type === 'full';
        $body = '<p>Hi <strong>' . esc_html( $order->buyer_name ) . '</strong>,</p>
        <p>Your refund for order <strong>' . esc_html( $order->order_number ) . '</strong> has been processed.</p>
        <table width="100%" cellpadding="10" cellspacing="0" border="0" style="background:#F9FAFB;border-radius:8px;margin:16px 0;font-size:14px;">
            <tr><td style="padding:8px 12px;color:#6B7280;">Refund Type:</td><td style="padding:8px 12px;text-align:right;font-weight:600;">' . ( $is_full ? 'Full Refund' : 'Partial Refund' ) . '</td></tr>
            <tr><td style="padding:8px 12px;color:#6B7280;">Refund Amount:</td><td style="padding:8px 12px;text-align:right;color:#10B981;font-weight:700;font-size:16px;">' . nmep_format_inr( $refund->refund_amount ) . '</td></tr>
            <tr><td style="padding:8px 12px;color:#6B7280;">Reason:</td><td style="padding:8px 12px;text-align:right;">' . esc_html( $refund->reason ) . '</td></tr>
        </table>
        <p><strong>When will I get the money back?</strong><br>
        Refunds typically take <strong>5-7 business days</strong> to appear in your bank/card account, depending on your bank.</p>
        <p>If you do not receive the refund after 7 business days, please contact us with the order number.</p>';

        $subject = 'Refund Processed — ' . $order->order_number;
        $html = self::wrap( 'Refund Processed', $body );

        return wp_mail( $order->buyer_email, $subject, $html, self::from_header() );
    }

    /**
     * Notify admin of new dispute
     */
    public static function send_admin_dispute_opened( $order, $reason, $description, $opened_by_role ) {
        $admin_email = get_option( 'admin_email' );
        $admin_url = admin_url( 'admin.php?page=nmep-disputes' );

        $body = '<p>A dispute has been opened.</p>
        <table width="100%" cellpadding="10" cellspacing="0" border="0" style="background:#FEF2F2;border-radius:8px;margin:16px 0;font-size:14px;">
            <tr><td style="padding:8px 12px;color:#991B1B;">Order:</td><td style="padding:8px 12px;text-align:right;font-family:monospace;">' . esc_html( $order->order_number ) . '</td></tr>
            <tr><td style="padding:8px 12px;color:#991B1B;">Amount:</td><td style="padding:8px 12px;text-align:right;font-weight:700;">' . nmep_format_inr( $order->gross_amount ) . '</td></tr>
            <tr><td style="padding:8px 12px;color:#991B1B;">Opened by:</td><td style="padding:8px 12px;text-align:right;text-transform:uppercase;font-weight:700;">' . esc_html( $opened_by_role ) . '</td></tr>
            <tr><td style="padding:8px 12px;color:#991B1B;">Reason:</td><td style="padding:8px 12px;text-align:right;">' . esc_html( $reason ) . '</td></tr>
        </table>
        <h3>Description:</h3>
        <p style="background:#F9FAFB;padding:16px;border-radius:8px;white-space:pre-line;">' . esc_html( $description ) . '</p>
        <p>Please review and respond within 24 hours.</p>';

        $subject = '🚨 [DISPUTE] ' . $order->order_number . ' — ' . $opened_by_role;
        $html = self::wrap( 'Dispute Opened', $body, 'Review Dispute', $admin_url );

        return wp_mail( $admin_email, $subject, $html, self::from_header() );
    }

    /* ============================================================
       BATCH E EMAILS — REVIEWS & MESSAGES
       ============================================================ */

    /**
     * Notify expert of new review
     */
    public static function send_new_review_to_expert( $order, $rating, $comment ) {
        if ( ! $order ) return false;
        $expert = NMEP_Compat::get_expert( $order->expert_id );
        if ( ! $expert || empty( $expert->email ) ) return false;

        $stars = str_repeat( '⭐', (int) $rating );
        $dashboard_url = nmep_get_page_url( 'expert-dashboard' );

        $body = '<p>Hi <strong>' . esc_html( $expert->full_name ) . '</strong>,</p>
        <p>You received a new review from <strong>' . esc_html( $order->buyer_name ) . '</strong> for order <strong>' . esc_html( $order->order_number ) . '</strong>.</p>
        <div style="background:#FFFBEB;border-left:4px solid #D4A843;padding:20px;margin:16px 0;border-radius:8px;">
            <div style="font-size:1.5rem;margin-bottom:10px;">' . $stars . ' (' . (int) $rating . '/5)</div>
            <div style="font-style:italic;color:#78350F;white-space:pre-line;">"' . esc_html( $comment ) . '"</div>
            <div style="font-size:0.85rem;color:#92400E;margin-top:10px;">— ' . esc_html( $order->buyer_name ) . '</div>
        </div>
        <p>Reviews help build your reputation and attract more buyers. Keep up the great work!</p>';

        $subject = $stars . ' New ' . $rating . '-star review for ' . $order->service_title;
        $html = self::wrap( 'New Review Received!', $body, 'View Dashboard', $dashboard_url );

        return wp_mail( $expert->email, $subject, $html, self::from_header() );
    }

    /**
     * Reminder to buyer to leave a review (1 day after completion)
     */
    public static function send_review_reminder( $order ) {
        if ( ! $order || empty( $order->buyer_email ) ) return false;

        $expert = NMEP_Compat::get_expert( $order->expert_id );
        $expert_name = $expert ? $expert->full_name : 'the expert';

        $track_url = add_query_arg( array(
            'order' => $order->order_number,
            'token' => $order->view_token,
        ), nmep_get_page_url( 'order-track' ) );

        $body = '<p>Hi <strong>' . esc_html( $order->buyer_name ) . '</strong>,</p>
        <p>How was your experience with <strong>' . esc_html( $expert_name ) . '</strong> on order <strong>' . esc_html( $order->order_number ) . '</strong>?</p>
        <p>Your honest review helps:</p>
        <ul>
            <li>Other buyers find great experts</li>
            <li>The expert build their reputation</li>
            <li>Our marketplace stay high-quality</li>
        </ul>
        <p>It only takes 30 seconds.</p>';

        $subject = '⭐ How was your experience with ' . $expert_name . '?';
        $html = self::wrap( 'Leave a Review', $body, 'Write a Review', $track_url );

        return wp_mail( $order->buyer_email, $subject, $html, self::from_header() );
    }

    /**
     * Notify the OTHER party of a new message
     */
    public static function send_new_message_notification( $order, $sender_role, $message_preview ) {
        if ( ! $order ) return false;

        $preview = strlen( $message_preview ) > 150 ? substr( $message_preview, 0, 150 ) . '...' : $message_preview;

        if ( $sender_role === 'buyer' ) {
            // Notify expert
            $expert = NMEP_Compat::get_expert( $order->expert_id );
            if ( ! $expert || empty( $expert->email ) ) return false;
            $to = $expert->email;
            $url = nmep_get_page_url( 'expert-dashboard' );
            $sender_name = $order->buyer_name;
            $recipient_name = $expert->full_name;
        } else {
            // Notify buyer
            if ( empty( $order->buyer_email ) ) return false;
            $to = $order->buyer_email;
            $url = add_query_arg( array(
                'order' => $order->order_number,
                'token' => $order->view_token,
            ), nmep_get_page_url( 'order-track' ) ) . '#messages';
            $sender_name = '';
            $expert = NMEP_Compat::get_expert( $order->expert_id );
            if ( $expert ) $sender_name = $expert->full_name;
            $recipient_name = $order->buyer_name;
        }

        $body = '<p>Hi <strong>' . esc_html( $recipient_name ) . '</strong>,</p>
        <p>You have a new message from <strong>' . esc_html( $sender_name ) . '</strong> on order <strong>' . esc_html( $order->order_number ) . '</strong>:</p>
        <div style="background:#F9FAFB;border-left:4px solid #10B981;padding:16px;margin:16px 0;border-radius:8px;font-style:italic;white-space:pre-line;">"' . esc_html( $preview ) . '"</div>';

        $subject = '💬 New message from ' . $sender_name . ' (' . $order->order_number . ')';
        $html = self::wrap( 'New Message', $body, 'Open Conversation', $url );

        return wp_mail( $to, $subject, $html, self::from_header() );
    }

    /* ============================================================
       LIFECYCLE REMINDERS + V2 TRANSACTIONAL EMAILS
       ============================================================ */

    /**
     * Tell the expert a delivery is approaching / overdue.
     */
    public static function send_delivery_reminder( $order, $is_overdue = false ) {
        if ( ! $order ) return false;
        $expert = NMEP_Compat::get_expert( $order->expert_id );
        if ( ! $expert || empty( $expert->email ) ) return false;

        $dashboard_url = nmep_get_page_url( 'expert-dashboard' );
        $label = $is_overdue ? '⚠️ Delivery Overdue' : '⏰ Delivery Due Soon';
        $urgency = $is_overdue
            ? 'The delivery deadline has <strong>passed</strong>. Please deliver immediately or the buyer may open a dispute and you will be marked late.'
            : 'The delivery deadline is in the <strong>next 24 hours</strong>. Please finalise and deliver on time.';

        $body = '<p>Hi <strong>' . esc_html( $expert->full_name ) . '</strong>,</p>
        <p>' . $urgency . '</p>
        <table width="100%" cellpadding="10" cellspacing="0" border="0" style="background:#FEF2F2;border-radius:8px;margin:16px 0;font-size:14px;border-left:4px solid #EF4444;">
            <tr><td style="padding:8px 12px;color:#991B1B;">Order:</td><td style="padding:8px 12px;text-align:right;font-family:monospace;">' . esc_html( $order->order_number ) . '</td></tr>
            <tr><td style="padding:8px 12px;color:#991B1B;">Service:</td><td style="padding:8px 12px;text-align:right;">' . esc_html( $order->service_title ) . '</td></tr>
            <tr><td style="padding:8px 12px;color:#991B1B;">Due by (UTC):</td><td style="padding:8px 12px;text-align:right;font-weight:700;">' . esc_html( $order->delivery_due_at ) . '</td></tr>
        </table>';

        $subject = $label . ' — ' . $order->order_number;
        $html = self::wrap( $label, $body, 'Open Dashboard', $dashboard_url );
        return wp_mail( $expert->email, $subject, $html, self::from_header() );
    }

    /**
     * Nudge expert whose revision is overdue.
     */
    public static function send_revision_overdue_reminder( $order ) {
        if ( ! $order ) return false;
        $expert = NMEP_Compat::get_expert( $order->expert_id );
        if ( ! $expert || empty( $expert->email ) ) return false;

        $body = '<p>Hi <strong>' . esc_html( $expert->full_name ) . '</strong>,</p>
        <p>The buyer requested a revision on order <strong>' . esc_html( $order->order_number ) . '</strong> more than 48 hours ago. Please address it soon to keep your on-time delivery rate high.</p>';
        $subject = '⏰ Revision Pending > 48h — ' . $order->order_number;
        $html = self::wrap( 'Revision Still Pending', $body, 'Open Dashboard', nmep_get_page_url( 'expert-dashboard' ) );
        return wp_mail( $expert->email, $subject, $html, self::from_header() );
    }

    /**
     * Notify buyer + expert that dispute was resolved.
     */
    public static function send_dispute_resolved( $order, $resolution, $notes ) {
        if ( ! $order ) return false;

        $labels = array(
            'refund_buyer'       => 'a full refund to the buyer',
            'partial_refund'     => 'a partial refund to the buyer and release to the expert',
            'release_to_expert'  => 'release of payment to the expert',
        );
        $human = $labels[ $resolution ] ?? $resolution;

        // Buyer
        if ( ! empty( $order->buyer_email ) ) {
            $buyer_body = '<p>Hi <strong>' . esc_html( $order->buyer_name ) . '</strong>,</p>
            <p>The dispute on order <strong>' . esc_html( $order->order_number ) . '</strong> has been resolved: <strong>' . esc_html( $human ) . '</strong>.</p>
            <p><strong>Admin note:</strong><br>' . nl2br( esc_html( $notes ) ) . '</p>';
            wp_mail(
                $order->buyer_email,
                'Dispute Resolved — ' . $order->order_number,
                self::wrap( 'Dispute Resolved', $buyer_body ),
                self::from_header()
            );
        }

        // Expert
        $expert = NMEP_Compat::get_expert( $order->expert_id );
        if ( $expert && ! empty( $expert->email ) ) {
            $expert_body = '<p>Hi <strong>' . esc_html( $expert->full_name ) . '</strong>,</p>
            <p>The dispute on order <strong>' . esc_html( $order->order_number ) . '</strong> has been resolved: <strong>' . esc_html( $human ) . '</strong>.</p>
            <p><strong>Admin note:</strong><br>' . nl2br( esc_html( $notes ) ) . '</p>';
            wp_mail(
                $expert->email,
                'Dispute Resolved — ' . $order->order_number,
                self::wrap( 'Dispute Resolved', $expert_body ),
                self::from_header()
            );
        }
        return true;
    }

    /**
     * Notify expert that payout was completed (transfer settled).
     */
    public static function send_payout_completed( $order, $amount ) {
        if ( ! $order ) return false;
        $expert = NMEP_Compat::get_expert( $order->expert_id );
        if ( ! $expert || empty( $expert->email ) ) return false;

        $body = '<p>Hi <strong>' . esc_html( $expert->full_name ) . '</strong>,</p>
        <p>Your payout for order <strong>' . esc_html( $order->order_number ) . '</strong> has settled.</p>
        <p style="font-size:1.4rem;color:#10B981;font-weight:700;">' . nmep_format_inr( $amount ) . '</p>
        <p>The amount should appear in your bank account within 1–3 business days as per the Razorpay settlement schedule.</p>';
        $subject = '💰 Payout Settled — ' . nmep_format_inr( $amount );
        $html = self::wrap( 'Payout Settled', $body, 'View Earnings', nmep_get_page_url( 'expert-dashboard' ) );
        return wp_mail( $expert->email, $subject, $html, self::from_header() );
    }

    /**
     * Notify buyer that a payment attempt failed.
     */
    public static function send_payment_failed( $order, $reason = '' ) {
        if ( ! $order || empty( $order->buyer_email ) ) return false;

        $retry_url = add_query_arg( array(
            'order_id' => $order->id,
            'token'    => $order->view_token,
            'action'   => 'pay',
        ), nmep_get_page_url( 'checkout' ) );

        $body = '<p>Hi <strong>' . esc_html( $order->buyer_name ) . '</strong>,</p>
        <p>Your payment for order <strong>' . esc_html( $order->order_number ) . '</strong> could not be completed.</p>'
        . ( $reason ? '<p style="background:#FEF2F2;padding:12px;border-radius:8px;color:#991B1B;">' . esc_html( $reason ) . '</p>' : '' ) .
        '<p>Don\'t worry, you were not charged. You can retry the payment using the button below.</p>';

        $subject = 'Payment Failed — Retry for Order ' . $order->order_number;
        $html = self::wrap( 'Payment Failed', $body, 'Retry Payment', $retry_url );
        return wp_mail( $order->buyer_email, $subject, $html, self::from_header() );
    }

    /**
     * Tax invoice email (platform → buyer) — attaches HTML invoice link.
     */
    public static function send_invoice_to_buyer( $order, $invoice_url ) {
        if ( ! $order || empty( $order->buyer_email ) ) return false;

        $body = '<p>Hi <strong>' . esc_html( $order->buyer_name ) . '</strong>,</p>
        <p>Your tax invoice for order <strong>' . esc_html( $order->order_number ) . '</strong> is ready.</p>
        <p>You can view or print it anytime using the button below.</p>';
        $subject = 'Tax Invoice — ' . $order->order_number;
        $html = self::wrap( 'Tax Invoice Ready', $body, 'View Invoice', $invoice_url );
        return wp_mail( $order->buyer_email, $subject, $html, self::from_header() );
    }
}
