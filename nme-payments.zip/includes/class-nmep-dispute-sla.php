<?php
/**
 * NMEP_Dispute_SLA
 *
 * 72-hour SLA and auto-escalation for order disputes.
 *
 * Responsibilities:
 *   - Stamp sla_due_at = opened_at + 72h whenever a dispute is opened
 *   - Auto-escalate disputes past SLA (called daily from lifecycle crons)
 *   - Capture expert's written response to a dispute (disputes.expert_response)
 *   - Accept evidence uploads from buyer / expert / admin into
 *     nmep_dispute_evidence, with MIME + size validation
 *
 * Emits NMEP_Events::DISPUTE_ESCALATED on auto-escalation and
 * NMEP_Events::DISPUTE_RESPONDED when the expert submits their response.
 *
 * @package NagalandMeExpertsPayments
 * @since   2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class NMEP_Dispute_SLA {

    const SLA_HOURS            = 72;
    const STATUS_ESCALATED     = 'escalated';
    const MAX_EVIDENCE_BYTES   = 10 * 1024 * 1024; // 10 MB
    const ALLOWED_EVIDENCE_MIMES = array(
        'image/jpeg', 'image/png', 'image/webp', 'image/gif',
        'application/pdf',
        'application/msword',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'application/vnd.ms-excel',
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'text/plain', 'text/csv',
        'video/mp4', 'video/quicktime',
    );

    public static function init() {
        // Stamp SLA deadline when a dispute is opened
        add_action( NMEP_Events::DISPUTE_OPENED, array( __CLASS__, 'on_dispute_opened' ), 10, 4 );

        // Evidence + response endpoints (buyer token OR logged-in expert/admin)
        add_action( 'admin_post_nopriv_nmep_upload_dispute_evidence', array( __CLASS__, 'handle_upload_evidence' ) );
        add_action( 'admin_post_nmep_upload_dispute_evidence',        array( __CLASS__, 'handle_upload_evidence' ) );

        add_action( 'admin_post_nmep_submit_dispute_response', array( __CLASS__, 'handle_submit_response' ) );
    }

    /* ============================================================
       SLA DEADLINE
       ============================================================ */

    public static function on_dispute_opened( $order_id, $dispute_id, $role = null, $reason = null ) {
        global $wpdb;

        $table = NMEP_Database::table( 'disputes' );
        $due   = gmdate( 'Y-m-d H:i:s', time() + ( self::SLA_HOURS * HOUR_IN_SECONDS ) );

        $wpdb->update(
            $table,
            array( 'sla_due_at' => $due ),
            array( 'id' => (int) $dispute_id )
        );

        NMEP_Logger::info( 'Dispute SLA deadline set', array(
            'dispute_id' => (int) $dispute_id,
            'order_id'   => (int) $order_id,
            'due_utc'    => $due,
        ) );
    }

    /**
     * Called daily by NMEP_Lifecycle_Crons::run_dispute_sla.
     * Promotes any open/investigating dispute whose sla_due_at has passed
     * and whose expert hasn't responded into 'escalated' state so admins
     * can triage it from the dispute queue.
     */
    public static function auto_escalate_overdue() {
        global $wpdb;

        $table = NMEP_Database::table( 'disputes' );
        $now   = current_time( 'mysql', true ); // UTC

        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT id, order_id, opened_role
             FROM $table
             WHERE status IN ('open','investigating')
               AND escalated_at IS NULL
               AND expert_response IS NULL
               AND sla_due_at IS NOT NULL
               AND sla_due_at <= %s",
            $now
        ) );

        if ( empty( $rows ) ) {
            NMEP_Logger::info( 'Dispute SLA cron — no overdue disputes' );
            return 0;
        }

        $escalated = 0;
        foreach ( $rows as $row ) {
            $wpdb->update(
                $table,
                array(
                    'status'       => self::STATUS_ESCALATED,
                    'escalated_at' => current_time( 'mysql' ),
                ),
                array( 'id' => (int) $row->id )
            );

            $order = NMEP_Orders::get( (int) $row->order_id );

            NMEP_Events::emit(
                NMEP_Events::DISPUTE_ESCALATED,
                (int) $row->order_id,
                (int) $row->id,
                'sla_breach'
            );

            if ( class_exists( 'NMEP_Emails' ) && method_exists( 'NMEP_Emails', 'send_admin_dispute_escalated' ) ) {
                NMEP_Emails::send_admin_dispute_escalated( $order, (int) $row->id );
            }

            NMEP_Logger::warning( 'Dispute auto-escalated after 72h', array(
                'dispute_id' => (int) $row->id,
                'order_id'   => (int) $row->order_id,
            ) );

            $escalated++;
        }

        return $escalated;
    }

    /* ============================================================
       EXPERT RESPONSE
       ============================================================ */

    public static function handle_submit_response() {
        if ( ! is_user_logged_in() ) {
            wp_die( 'Please log in.' );
        }

        $dispute_id = isset( $_POST['dispute_id'] ) ? (int) $_POST['dispute_id'] : 0;
        if ( ! wp_verify_nonce( $_POST['_wpnonce'] ?? '', 'nmep_dispute_response_' . $dispute_id ) ) {
            wp_die( 'Security check failed.' );
        }

        $response = sanitize_textarea_field( $_POST['response'] ?? '' );
        if ( strlen( $response ) < 20 ) {
            wp_die( 'Response must be at least 20 characters.' );
        }
        if ( strlen( $response ) > 5000 ) {
            wp_die( 'Response too long (max 5000 chars).' );
        }

        $dispute = NMEP_Disputes::get( $dispute_id );
        if ( ! $dispute ) {
            wp_die( 'Dispute not found.' );
        }

        $order = NMEP_Orders::get( (int) $dispute->order_id );
        if ( ! $order ) {
            wp_die( 'Order not found.' );
        }

        // Authorize: the expert on the order, or any admin
        $is_admin = current_user_can( 'manage_options' );
        $expert   = NMEP_Compat::get_expert_by_user( get_current_user_id() );
        $is_expert = $expert && (int) $expert->id === (int) $order->expert_id;

        if ( ! $is_admin && ! $is_expert ) {
            wp_die( 'Permission denied.' );
        }

        self::capture_expert_response( $dispute_id, $response, get_current_user_id() );

        $redirect = $is_admin
            ? admin_url( 'admin.php?page=nmep-disputes&responded=1' )
            : add_query_arg(
                array( 'nmep_status' => 'success', 'nmep_msg' => urlencode( 'Response recorded.' ) ),
                nmep_get_page_url( 'expert-dashboard' )
            );

        wp_safe_redirect( $redirect );
        exit;
    }

    public static function capture_expert_response( $dispute_id, $response, $actor_user_id = 0 ) {
        global $wpdb;

        $wpdb->update(
            NMEP_Database::table( 'disputes' ),
            array(
                'expert_response' => $response,
                'status'          => NMEP_Disputes::STATUS_INVESTIGATING,
            ),
            array( 'id' => (int) $dispute_id )
        );

        $dispute = NMEP_Disputes::get( $dispute_id );
        if ( $dispute ) {
            NMEP_Events::emit(
                NMEP_Events::DISPUTE_RESPONDED,
                (int) $dispute->order_id,
                (int) $dispute_id,
                (int) $actor_user_id
            );

            NMEP_Compat::audit_log( 'dispute_responded', 'dispute', (int) $dispute_id, array(
                'order_id'  => (int) $dispute->order_id,
                'actor_uid' => (int) $actor_user_id,
            ) );
        }
    }

    /* ============================================================
       EVIDENCE UPLOAD
       ============================================================ */

    public static function handle_upload_evidence() {
        $dispute_id = isset( $_POST['dispute_id'] ) ? (int) $_POST['dispute_id'] : 0;
        $token      = sanitize_text_field( $_POST['token'] ?? '' );
        $role       = sanitize_key( $_POST['role'] ?? '' );
        $note       = sanitize_textarea_field( $_POST['note'] ?? '' );

        if ( ! wp_verify_nonce( $_POST['_wpnonce'] ?? '', 'nmep_dispute_evidence_' . $dispute_id ) ) {
            wp_die( 'Security check failed.' );
        }

        $dispute = NMEP_Disputes::get( $dispute_id );
        if ( ! $dispute ) {
            wp_die( 'Dispute not found.' );
        }
        $order = NMEP_Orders::get( (int) $dispute->order_id );
        if ( ! $order ) {
            wp_die( 'Order not found.' );
        }

        // Authorize
        $actor_user_id = 0;
        $authorized    = false;
        if ( $role === 'buyer' && hash_equals( (string) $order->view_token, $token ) ) {
            $authorized    = true;
            $actor_user_id = (int) $order->buyer_user_id;
        } elseif ( $role === 'expert' && is_user_logged_in() ) {
            $expert = NMEP_Compat::get_expert_by_user( get_current_user_id() );
            if ( $expert && (int) $expert->id === (int) $order->expert_id ) {
                $authorized    = true;
                $actor_user_id = get_current_user_id();
            }
        } elseif ( $role === 'admin' && current_user_can( 'manage_options' ) ) {
            $authorized    = true;
            $actor_user_id = get_current_user_id();
        }

        if ( ! $authorized ) {
            wp_die( 'Permission denied.' );
        }

        if ( empty( $_FILES['evidence'] ) || ! is_uploaded_file( $_FILES['evidence']['tmp_name'] ) ) {
            self::redirect_evidence_error( 'No file provided.', $order, $dispute_id, $role );
        }

        $result = self::upload_evidence( (int) $dispute_id, $_FILES['evidence'], $role, $actor_user_id, $note );

        if ( is_wp_error( $result ) ) {
            self::redirect_evidence_error( $result->get_error_message(), $order, $dispute_id, $role );
        }

        // Success redirect
        if ( $role === 'buyer' ) {
            $url = add_query_arg( array(
                'order'       => $order->order_number,
                'token'       => $order->view_token,
                'nmep_status' => 'success',
                'nmep_msg'    => urlencode( 'Evidence uploaded.' ),
            ), nmep_get_page_url( 'order-track' ) );
        } elseif ( $role === 'admin' ) {
            $url = admin_url( 'admin.php?page=nmep-disputes&evidence=1' );
        } else {
            $url = add_query_arg( array(
                'nmep_status' => 'success',
                'nmep_msg'    => urlencode( 'Evidence uploaded.' ),
            ), nmep_get_page_url( 'expert-dashboard' ) );
        }
        wp_safe_redirect( $url );
        exit;
    }

    /**
     * Validate + store an uploaded evidence file and return the inserted row ID
     * or WP_Error on validation failure. $file is a $_FILES entry.
     */
    public static function upload_evidence( $dispute_id, $file, $role, $actor_user_id, $note = '' ) {
        if ( ! is_array( $file ) || empty( $file['tmp_name'] ) ) {
            return new WP_Error( 'no_file', 'No file received.' );
        }
        if ( (int) ( $file['error'] ?? UPLOAD_ERR_NO_FILE ) !== UPLOAD_ERR_OK ) {
            return new WP_Error( 'upload_error', 'Upload failed (error code ' . (int) $file['error'] . ').' );
        }

        $size = (int) ( $file['size'] ?? 0 );
        if ( $size <= 0 ) {
            return new WP_Error( 'empty_file', 'File is empty.' );
        }
        if ( $size > self::MAX_EVIDENCE_BYTES ) {
            return new WP_Error( 'too_large', 'File exceeds 10 MB limit.' );
        }

        $mime = '';
        if ( function_exists( 'finfo_open' ) ) {
            $finfo = finfo_open( FILEINFO_MIME_TYPE );
            $mime  = (string) finfo_file( $finfo, $file['tmp_name'] );
            finfo_close( $finfo );
        }
        if ( ! $mime && ! empty( $file['type'] ) ) {
            $mime = (string) $file['type'];
        }

        if ( ! in_array( $mime, self::ALLOWED_EVIDENCE_MIMES, true ) ) {
            return new WP_Error( 'bad_mime', 'File type not allowed: ' . esc_html( $mime ) );
        }

        // Move into uploads/nmep-dispute-evidence/<dispute_id>/
        require_once ABSPATH . 'wp-admin/includes/file.php';

        $upload = wp_upload_dir();
        $sub    = 'nmep-dispute-evidence/' . (int) $dispute_id;
        $target_dir = trailingslashit( $upload['basedir'] ) . $sub;
        if ( ! wp_mkdir_p( $target_dir ) ) {
            return new WP_Error( 'mkdir_failed', 'Could not create upload directory.' );
        }

        $base_name  = wp_unique_filename( $target_dir, sanitize_file_name( $file['name'] ) );
        $dest_path  = trailingslashit( $target_dir ) . $base_name;

        if ( ! @move_uploaded_file( $file['tmp_name'], $dest_path ) ) {
            return new WP_Error( 'move_failed', 'Could not save file.' );
        }
        @chmod( $dest_path, 0644 );

        $file_url = trailingslashit( $upload['baseurl'] ) . $sub . '/' . $base_name;

        global $wpdb;
        $wpdb->insert( NMEP_Database::table( 'dispute_evidence' ), array(
            'dispute_id'    => (int) $dispute_id,
            'uploaded_by'   => (int) $actor_user_id,
            'uploaded_role' => sanitize_key( $role ),
            'file_url'      => esc_url_raw( $file_url ),
            'file_mime'     => $mime,
            'file_size'     => $size,
            'note'          => $note ? substr( $note, 0, 500 ) : null,
        ) );

        $evidence_id = (int) $wpdb->insert_id;

        NMEP_Logger::info( 'Dispute evidence uploaded', array(
            'dispute_id'  => (int) $dispute_id,
            'evidence_id' => $evidence_id,
            'role'        => $role,
            'mime'        => $mime,
            'size'        => $size,
        ) );

        NMEP_Compat::audit_log( 'dispute_evidence_uploaded', 'dispute', (int) $dispute_id, array(
            'evidence_id' => $evidence_id,
            'role'        => $role,
        ) );

        return $evidence_id;
    }

    /* ============================================================
       QUERIES
       ============================================================ */

    public static function get_evidence_for_dispute( $dispute_id ) {
        global $wpdb;
        return $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM " . NMEP_Database::table( 'dispute_evidence' ) . "
             WHERE dispute_id = %d ORDER BY created_at ASC",
            (int) $dispute_id
        ) );
    }

    public static function time_remaining_label( $dispute ) {
        if ( empty( $dispute->sla_due_at ) ) return '';
        $due    = strtotime( $dispute->sla_due_at . ' UTC' );
        $remain = $due - time();
        if ( $remain <= 0 ) return 'SLA breached';
        if ( $remain < HOUR_IN_SECONDS ) return ceil( $remain / MINUTE_IN_SECONDS ) . ' min remaining';
        if ( $remain < DAY_IN_SECONDS )  return round( $remain / HOUR_IN_SECONDS, 1 ) . ' h remaining';
        return round( $remain / DAY_IN_SECONDS, 1 ) . ' d remaining';
    }

    /* ============================================================
       HELPERS
       ============================================================ */

    private static function redirect_evidence_error( $message, $order, $dispute_id, $role ) {
        if ( $role === 'buyer' ) {
            $url = add_query_arg( array(
                'order'       => $order->order_number,
                'token'       => $order->view_token,
                'nmep_status' => 'error',
                'nmep_msg'    => urlencode( $message ),
            ), nmep_get_page_url( 'order-track' ) );
        } elseif ( $role === 'admin' ) {
            $url = admin_url( 'admin.php?page=nmep-disputes&evidence_error=1&msg=' . urlencode( $message ) );
        } else {
            $url = add_query_arg( array(
                'nmep_status' => 'error',
                'nmep_msg'    => urlencode( $message ),
            ), nmep_get_page_url( 'expert-dashboard' ) );
        }
        wp_safe_redirect( $url );
        exit;
    }
}
