<?php
/**
 * NMEP_SMS
 *
 * MSG91-powered SMS and WhatsApp notifications for key lifecycle events.
 *
 * Templates map NMEP event constants to plain-text message bodies. Each
 * message is queued into `nmep_sms_log`, then dispatched via MSG91's
 * Send SMS API (for SMS) or Send WA API (for WhatsApp). All outbound
 * traffic is logged with provider response for audit.
 *
 * Requires:
 *   - msg91_enabled = true
 *   - msg91_auth_key set
 *   - msg91_sender_id (6-char DLT sender id for SMS)
 *
 * @package NagalandMeExpertsPayments
 * @since   2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class NMEP_SMS {

    const CHANNEL_SMS       = 'sms';
    const CHANNEL_WHATSAPP  = 'whatsapp';

    const STATUS_QUEUED   = 'queued';
    const STATUS_SENT     = 'sent';
    const STATUS_FAILED   = 'failed';

    public static function init() {
        add_action( NMEP_Events::ORDER_CREATED,     array( __CLASS__, 'on_order_created' ),     10, 2 );
        add_action( NMEP_Events::ORDER_PAID,        array( __CLASS__, 'on_order_paid' ),        10 );
        add_action( NMEP_Events::ORDER_DELIVERED,   array( __CLASS__, 'on_order_delivered' ),   10 );
        add_action( NMEP_Events::ORDER_COMPLETED,   array( __CLASS__, 'on_order_completed' ),   10 );
        add_action( NMEP_Events::ORDER_CANCELLED,   array( __CLASS__, 'on_order_cancelled' ),   10 );
        add_action( NMEP_Events::DISPUTE_OPENED,    array( __CLASS__, 'on_dispute_opened' ),    10, 4 );
    }

    /* ============================================================
       LIFECYCLE LISTENERS
       ============================================================ */

    public static function on_order_created( $order_id, $order = null ) {
        if ( ! $order ) $order = NMEP_Orders::get( $order_id );
        if ( ! $order ) return;

        $text = sprintf(
            "Order %s placed on Nagaland Me. Complete payment to start. View: %s",
            $order->order_number,
            self::order_url( $order )
        );
        self::send( $order->buyer_phone ?? '', $text, 'order_created' );
    }

    public static function on_order_paid( $order_id ) {
        $order = NMEP_Orders::get( $order_id );
        if ( ! $order ) return;

        $buyer_text = sprintf(
            "Payment received for %s. Your expert will begin work shortly.",
            $order->order_number
        );
        self::send( $order->buyer_phone ?? '', $buyer_text, 'order_paid_buyer' );

        $expert_phone = self::expert_phone( (int) $order->expert_id );
        if ( $expert_phone ) {
            $expert_text = sprintf(
                "New paid order %s on Nagaland Me: %s. Deliver by %s.",
                $order->order_number,
                $order->service_title,
                $order->delivery_due_at ? gmdate( 'd M', strtotime( $order->delivery_due_at ) ) : 'TBD'
            );
            self::send( $expert_phone, $expert_text, 'order_paid_expert' );
        }
    }

    public static function on_order_delivered( $order_id ) {
        $order = NMEP_Orders::get( $order_id );
        if ( ! $order ) return;
        $text = sprintf(
            "Your order %s is delivered. Please review and accept within %d days.",
            $order->order_number,
            (int) NMEP_Settings::get( 'auto_release_days', 5 )
        );
        self::send( $order->buyer_phone ?? '', $text, 'order_delivered' );
    }

    public static function on_order_completed( $order_id ) {
        $order = NMEP_Orders::get( $order_id );
        if ( ! $order ) return;
        $expert_phone = self::expert_phone( (int) $order->expert_id );
        if ( ! $expert_phone ) return;
        $text = sprintf(
            "Order %s completed. Payout of %s queued.",
            $order->order_number,
            nmep_format_inr( $order->expert_amount )
        );
        self::send( $expert_phone, $text, 'order_completed' );
    }

    public static function on_order_cancelled( $order_id ) {
        $order = NMEP_Orders::get( $order_id );
        if ( ! $order ) return;
        $text = sprintf( "Order %s was cancelled. Any paid amount will be refunded.", $order->order_number );
        self::send( $order->buyer_phone ?? '', $text, 'order_cancelled' );
    }

    public static function on_dispute_opened( $order_id, $dispute_id, $role = null, $reason = null ) {
        $order = NMEP_Orders::get( $order_id );
        if ( ! $order ) return;
        $admin_phone = NMEP_Settings::get( 'support_phone', '' );
        if ( ! $admin_phone ) return;
        $text = sprintf(
            "Dispute opened by %s for order %s (reason: %s). Admin action required.",
            $role ?: 'party',
            $order->order_number,
            $reason ?: 'unspecified'
        );
        self::send( $admin_phone, $text, 'dispute_opened' );
    }

    /* ============================================================
       CORE SEND
       ============================================================ */

    public static function send( $recipient, $message, $template = 'generic', $channel = self::CHANNEL_SMS ) {
        $recipient = self::normalize_phone( $recipient );
        if ( $recipient === '' ) {
            return new WP_Error( 'bad_recipient', 'No valid recipient phone.' );
        }
        if ( ! NMEP_Settings::get( 'msg91_enabled', false ) ) {
            self::log( $recipient, $message, $template, $channel, self::STATUS_FAILED, 'msg91 disabled', null );
            return new WP_Error( 'disabled', 'MSG91 is not enabled.' );
        }

        $log_id = self::log( $recipient, $message, $template, $channel, self::STATUS_QUEUED, null, null );

        $result = ( $channel === self::CHANNEL_WHATSAPP )
            ? self::dispatch_whatsapp( $recipient, $message )
            : self::dispatch_sms( $recipient, $message );

        global $wpdb;
        if ( is_wp_error( $result ) ) {
            $wpdb->update( NMEP_Database::table( 'sms_log' ), array(
                'status'   => self::STATUS_FAILED,
                'response' => wp_json_encode( array( 'error' => $result->get_error_message() ) ),
            ), array( 'id' => $log_id ) );
            NMEP_Logger::warning( 'SMS/WA dispatch failed', array(
                'channel'   => $channel,
                'template'  => $template,
                'recipient' => self::mask_phone( $recipient ),
                'error'     => $result->get_error_message(),
            ) );
            return $result;
        }

        $wpdb->update( NMEP_Database::table( 'sms_log' ), array(
            'status'      => self::STATUS_SENT,
            'provider_id' => $result['request_id'] ?? null,
            'response'    => wp_json_encode( $result ),
        ), array( 'id' => $log_id ) );

        return $log_id;
    }

    private static function dispatch_sms( $recipient, $message ) {
        $auth_key = NMEP_Settings::get( 'msg91_auth_key', '' );
        if ( ! $auth_key ) return new WP_Error( 'no_auth_key', 'MSG91 auth key missing.' );

        $sender = NMEP_Settings::get( 'msg91_sender_id', 'NMEXPT' );
        $route  = NMEP_Settings::get( 'msg91_route', '4' );
        $country = NMEP_Settings::get( 'msg91_country_code', '91' );

        $body = array(
            'sender'   => $sender,
            'route'    => $route,
            'country'  => $country,
            'sms'      => array(
                array(
                    'message' => $message,
                    'to'      => array( $recipient ),
                ),
            ),
        );

        $resp = wp_remote_post( 'https://control.msg91.com/api/v2/sendsms', array(
            'timeout' => 20,
            'headers' => array(
                'Content-Type' => 'application/json',
                'authkey'      => $auth_key,
            ),
            'body'    => wp_json_encode( $body ),
        ) );

        return self::parse_provider_response( $resp );
    }

    private static function dispatch_whatsapp( $recipient, $message ) {
        $auth_key = NMEP_Settings::get( 'msg91_auth_key', '' );
        if ( ! $auth_key ) return new WP_Error( 'no_auth_key', 'MSG91 auth key missing.' );

        $integrated_number = NMEP_Settings::get( 'whatsapp_integrated_number', '' );
        if ( ! $integrated_number ) return new WP_Error( 'no_wa_number', 'WhatsApp integrated number missing.' );

        $body = array(
            'integrated_number' => $integrated_number,
            'content_type'      => 'template',
            'payload'           => array(
                'messaging_product' => 'whatsapp',
                'type'              => 'text',
                'text'              => array( 'body' => $message ),
                'to'                => $recipient,
            ),
        );

        $resp = wp_remote_post( 'https://api.msg91.com/api/v5/whatsapp/whatsapp-outbound-message/bulk/', array(
            'timeout' => 20,
            'headers' => array(
                'Content-Type' => 'application/json',
                'authkey'      => $auth_key,
            ),
            'body'    => wp_json_encode( $body ),
        ) );

        return self::parse_provider_response( $resp );
    }

    private static function parse_provider_response( $resp ) {
        if ( is_wp_error( $resp ) ) return $resp;

        $code = (int) wp_remote_retrieve_response_code( $resp );
        $body = wp_remote_retrieve_body( $resp );
        $data = json_decode( $body, true );

        if ( $code < 200 || $code >= 300 ) {
            return new WP_Error( 'msg91_http_' . $code, 'MSG91 HTTP ' . $code . ': ' . substr( (string) $body, 0, 400 ) );
        }

        return array(
            'http_status' => $code,
            'request_id'  => is_array( $data ) ? ( $data['request_id'] ?? $data['type'] ?? null ) : null,
            'raw'         => $data ?: $body,
        );
    }

    /* ============================================================
       LOG + HELPERS
       ============================================================ */

    private static function log( $recipient, $message, $template, $channel, $status, $error = null, $provider_id = null ) {
        global $wpdb;
        $wpdb->insert( NMEP_Database::table( 'sms_log' ), array(
            'channel'     => $channel,
            'recipient'   => substr( self::mask_phone( $recipient ), 0, 40 ),
            'template'    => $template,
            'payload'     => substr( (string) $message, 0, 4000 ),
            'provider_id' => $provider_id,
            'status'      => $status,
            'response'    => $error ? wp_json_encode( array( 'error' => $error ) ) : null,
        ) );
        return (int) $wpdb->insert_id;
    }

    private static function normalize_phone( $raw ) {
        $raw = preg_replace( '/\D/', '', (string) $raw );
        if ( $raw === '' ) return '';
        $country = NMEP_Settings::get( 'msg91_country_code', '91' );

        // Indian 10-digit → prepend country
        if ( strlen( $raw ) === 10 ) return $country . $raw;
        // Already has country code
        if ( strlen( $raw ) === 12 && str_starts_with( $raw, (string) $country ) ) return $raw;
        // Already with leading 0
        if ( strlen( $raw ) === 11 && str_starts_with( $raw, '0' ) ) return $country . substr( $raw, 1 );
        return $raw;
    }

    private static function mask_phone( $phone ) {
        $n = strlen( $phone );
        if ( $n < 6 ) return $phone;
        return substr( $phone, 0, 2 ) . str_repeat( '*', max( 0, $n - 6 ) ) . substr( $phone, -4 );
    }

    private static function order_url( $order ) {
        return add_query_arg( array(
            'order' => $order->order_number,
            'token' => $order->view_token,
        ), nmep_get_page_url( 'order-track' ) );
    }

    private static function expert_phone( $expert_id ) {
        $expert = NMEP_Compat::get_expert( $expert_id );
        if ( ! $expert ) return '';
        return isset( $expert->phone ) ? (string) $expert->phone : '';
    }
}
